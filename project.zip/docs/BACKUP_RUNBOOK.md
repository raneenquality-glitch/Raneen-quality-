# النسخ الاحتياطي للسيرفر والوسائط (Runbook)

**القاعدة:** كل الأدوات هنا **قراءة فقط** على الـ production (`pg_dump` و`SELECT` و`rclone copy`). مفيش تعديل في إعدادات الإنتاج ولا في الجداول ولا في الملفات.
الإجراء الوحيد المحتمل في الـ Dashboard: إنشاء **مفتاح S3 مؤقت** للتخزين (ممكن تمسحه بعد النسخة).

## قبل ما تبدأ
- جهاز عليه: `psql` و`pg_dump` (PostgreSQL 15+)، و`rclone`، واختياري: `supabase` CLI و`age`/`gpg` للتشفير.
- **ماتكتبش أي مفتاح أو باسورد في ملف أو في Git.** مرّرهم كمتغيرات بيئة في الـ shell بس.

## 1) الـ Schema والسياسات والدوال (آمن يتحط في repo خاص)
```bash
export SUPABASE_DB_URL='postgresql://postgres:<password>@db.<ref>.supabase.co:5432/postgres'
export SUPABASE_PROJECT_REF='<ref>' SUPABASE_ACCESS_TOKEN='<token>'   # للـ Edge Functions
bash tools/backup/export_supabase.sh
```
الناتج في `backup_out/<timestamp>/`:
- `schema/public_schema.sql` — الجداول والـ indexes والـ constraints و**RLS + POLICIES** والدوال والـ triggers والـ grants
- `schema/policies.csv` و`rls_status.csv` — السياسات وحالة الـ RLS لكل جدول (public + storage)
- `schema/rpc_functions.sql` — نص كل RPC (`submit_report`, `review_report`, `manager_edit_report`, `replace_catalog`, `viewer_reports` …)
- `schema/storage_buckets.csv`, `triggers.csv`, `extensions.csv`, `cron_jobs.csv`, `table_row_estimates.csv`
- `functions/` — الـ Edge Functions (`smart-processor`, `swift-worker`, `media-transfer`؛ `supabase functions list` بيعرض الباقي)
- `MANIFEST.sha256` — بصمة كل ملف

الدفعة دي **مفيهاش بيانات**، فينفع تتحط في repo **خاص** (مثلًا `server/`) علشان تبقى مرجع للمراجعة.
إعدادات الـ Auth (providers / رسائل / SMTP) مش بتتصدّر بالـ SQL: صدّرها من الـ Dashboard أو Management API وخزّنها **برا** Git لأنها ممكن تحتوي أسرار.

## 2) البيانات (اختياري ولكن مهم)
```bash
WITH_DATA=1 bash tools/backup/export_supabase.sh
```
بينتج `data/public_data.dump` (صيغة custom). **فيه بيانات شخصية** (مستخدمين، زيارات، مخالفات): شفّره وخزّنه خارج Git:
`tar c backup_out/<dir> | age -p > raneen-backup-<date>.tar.age`

## 3) الصور والفيديوهات
```bash
export SUPABASE_PROJECT_REF='<ref>' SUPABASE_S3_ACCESS_KEY_ID='...' SUPABASE_S3_SECRET_ACCESS_KEY='...'
export B2_KEY_ID='...' B2_APPLICATION_KEY='...' B2_BUCKET='<bucket>'     # مفتاح B2 بصلاحية readFiles يكفي
bash tools/backup/backup_media.sh
```
- بيعمل `rclone copy` (من غير مسح) ثم `rclone check --one-way --checksum`، ويكتب `MANIFEST.txt` بالأعداد والأحجام.
- أسماء الـ buckets الافتراضية `report-photos chat-media` — **أكّدها** من `schema/storage_buckets.csv` قبل التشغيل (`SUPABASE_BUCKETS="..."` لتغييرها).
- أمسح مفتاح S3 المؤقت من الـ Dashboard بعد الانتهاء.

## التحقق وبعد النسخة
1. قارن `table_row_estimates.csv` بالأعداد المتوقعة، وراجع `MANIFEST.txt` للوسائط (كل سطر `OK`).
2. خزّن النسخة المشفّرة في **مكانين** مختلفين (واحد منهم خارج مزوّد الإنتاج).
3. **تمرين استرجاع (مرة كل فترة):** استرجع الـ dump في مشروع Supabase تجريبي منفصل وتأكد إن الـ schema والبيانات تشتغل — النسخة اللي ما اتجرّبتش مش نسخة.
4. حدّد جدول: يومي للبيانات، أسبوعي للوسائط (أو حسب حجم الاستخدام)، واحتفظ بآخر 30 نسخة على الأقل.

## ممنوع
- رفع `backup_out/` أو أي `*.dump` أو `*.age` على Git (محمي في `.gitignore`).
- مشاركة connection string أو مفاتيح S3/B2 في الشات أو التذاكر.
- تشغيل أي استرجاع على مشروع الإنتاج نفسه.
