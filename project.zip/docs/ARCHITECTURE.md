# المعمارية وخريطة الملفات

```
Android (Compose, Room v5, DI يدوي)                 Web (index.html)
  UI ─ ViewModel/State ─ Repository ─ Room            vanilla JS، لوحة مراجعة/إدارة
                     └── SyncRepository ─ SupabaseRemote (HttpURLConnection)
                              │                               │
                              ▼                               ▼
                    Supabase: Auth · PostgREST · RPC · Storage · Edge Functions ──► Backblaze B2
                    Firebase FCM (الشات معطّل)
```

## الحزم (`app/src/main/java/com/raneen/quality`)
| الملف | المسؤولية |
|---|---|
| `MainActivity.kt` | الجذر والـ DI اليدوي (`remember`) والتوجيه حسب الدور |
| `RaneenApp.kt` | بناء Room + الترحيلات |
| `domain/RaneenScoring.kt` | معادلات التقييم (`controlLoss`, `scoreUnit`, `mergeAreaPartViolations`) |
| `data/RaneenEntities.kt`, `RaneenDao.kt`, `RaneenSeedLoader.kt` | الكيانات والـ DAOs وقاعدة البيانات والـ seed |
| `data/RaneenRemote.kt` | عميل Supabase (REST/RPC/Storage/B2) |
| `data/RaneenSync.kt` | المزامنة: رفع التقارير والصور، سحب الكتالوج والتقارير والمستخدمين |
| `data/RaneenAuth.kt` | الدخول (أونلاين/أوف لاين)، الأدوار، إدارة المستخدمين |
| `data/RaneenReports.kt` | حالات التقرير، تجميع بيانات التقرير، مراجعة/اعتماد |
| `data/RaneenCatalogAdmin.kt`, `RaneenCatalogFixups.kt` | تعديل الكتالوج والترتيب والتسميات |
| `data/RaneenCensus*.kt` | الحصر (أسعار/عرض/صيانة/هيكل) وملخصه |
| `data/RaneenExport.kt` | PDF و Word و Excel |
| `data/RaneenPhotos.kt`, `RaneenMedia.kt`, `RaneenVideoStamper.kt` | ضغط الصور وختم الفيديو والحفظ |
| `data/RaneenVisitSeats.kt` | مقاعد المراقبين |
| `data/RaneenChat.kt`, `RaneenPush.kt`, `RaneenNotify.kt` | الشات (معطّل)، FCM، الإشعارات وWorker المزامنة |
| `ui/*` | الشاشات: تقييم، تقارير، إدارة، دخول، كاميرا |

## تدفق المزامنة (`SyncRepository.syncAll`)
1. رفع التقارير الجاهزة: صور → `submit_report` (متسلسل لكل زيارة).
2. للأدمن: رفع الكتالوج لو فيه تعديلات (`replace_catalog`) ← `CensusDefaults.ensure`.
3. سحب الكتالوج (بصفحات، بصمة نص) → استبدال محلي داخل transaction.
4. سحب المستخدمين، ثم التقارير بـ cursor على `updated_at` (والمشاهد عبر `viewer_reports`).
5. نقل الملفات الجديدة لـ B2 في الخلفية (`media-transfer`).
- Mutex لكل نسخة `SyncRepository`؛ الـ Worker (كل 15 د) بينشئ نسخة منفصلة (مخاطرة معروفة).

## الوسائط
صورة: أقصى بُعد 1920px، JPEG، **رفع streaming** لـ Supabase ثم نقل لـ B2؛ التنزيل من B2 وfallback لـ Supabase. فيديو: إعادة ترميز بختم تاريخ/وقت (Media3 Transformer).

## استدعاءات السيرفر (من الكود)
RPC: `submit_report`, `review_report`, `manager_edit_report`, `replace_catalog`, `viewer_reports`, `get/set_viewer_units`, `password_changed`، وحجز المقاعد وغيرها. REST: `profiles`, `catalog_items`, `reports`… Edge Functions: `smart-processor` (إدارة المستخدمين), `swift-worker` (روابط B2), `media-transfer`.
الأسماء الدقيقة والنصوص الفعلية تتصدّر بـ `tools/backup/export_supabase.sh`.

## الويب (`index.html`)
ملف واحد ~250KB، **بدون مكتبات خارجية**: دخول، قائمة التقارير، عرض/طباعة التقرير، المراجعة والاعتماد، إدارة المستخدمين والكتالوج، المقاعد. منطق التقييم والحصر مكرر من التطبيق.

## البناء
Gradle (Kotlin DSL) بدون wrapper · AGP 8.5.2 · Kotlin 2.0.20 · KSP · compileSdk/targetSdk 34 · minSdk 26. الـ CI: `.github/workflows/ci.yml` (راجع `CI.md`).
