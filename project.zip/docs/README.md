# توثيق مشروع رنين (Raneen Quality)

| الملف | محتواه |
|---|---|
| [CURRENT_STATE.md](CURRENT_STATE.md) | الوضع الحالي: الأدوار، سير العمل، قواعد التقييم، الحصر، التسميات، الاعتماديات على السيرفر |
| [ARCHITECTURE.md](ARCHITECTURE.md) | المعمارية وخريطة الملفات وتدفّق المزامنة والوسائط |
| [ROOM_MIGRATIONS_REVIEW.md](ROOM_MIGRATIONS_REVIEW.md) | مراجعة ترحيلات قاعدة البيانات المحلية |
| [CI.md](CI.md) | GitHub Actions: الـ Compile والاختبارات والـ Lint وحماية الفرع الرئيسي |
| [BACKUP_RUNBOOK.md](BACKUP_RUNBOOK.md) | النسخ الاحتياطي للسيرفر والوسائط (قراءة فقط) |

ملفات الجذر المرتبطة: `SUPABASE-*.txt` (متطلبات السيرفر المعلّقة) و `CHANGELOG-AR.txt`.
