# مراجعة ترحيلات قاعدة البيانات المحلية (Room)

**النطاق:** مراجعة فقط — **ما اتغيّرتش أي كيانات أو جداول أو نسخة الداتابيز** (النسخة الحالية 5).

## الوضع الحالي
- `RaneenDatabase` (`@Database(version = 5, exportSchema = true)`) فيها 13 كيان.
- البناء في `RaneenApp.kt`: `.addMigrations(MIGRATION_3_4, MIGRATION_4_5)` و `.fallbackToDestructiveMigrationFrom(1, 2)`.
- `room.schemaLocation` متظبط في `app/build.gradle.kts` → `app/schemas`، **لكن الملفات نفسها مش متثبّتة في الـ repo**.

## مراجعة كل ترحيل
| الترحيل | SQL | مطابقة الكيان | الحكم |
|---|---|---|---|
| 1→… و 2→… | تدمير وإعادة إنشاء (`fallbackToDestructiveMigrationFrom(1, 2)`) | — | مقبول لنسخ قبل الإطلاق؛ **أي جهاز لسه على 1 أو 2 هيفقد بياناته المحلية** |
| 3→4 | `CREATE TABLE IF NOT EXISTS chat_messages (…10 أعمدة…)` + `CREATE INDEX index_chat_messages_conversationId_createdAt` | الأعمدة والأنواع و NOT NULL والـ PK والـ index **مطابقة** لـ `ChatMessageEntity` | سليم |
| 4→5 | `ALTER TABLE findings ADD COLUMN violationNote TEXT` | عمود `String?` بدون default — مطابق لـ `FindingEntity` | سليم |

## ملاحظات ومخاطر
1. **لا يمكن إثبات مطابقة الـ schema بالكامل** بدون ملفات `3.json` و`4.json` و`5.json`؛ المراجعة اليدوية اتأكدت من الترحيلين فقط، ومش بتضمن إن مفيش عمود تاني اتغيّر بين النسخ. (لازم تتثبّت الملفات من الآن، النسخ 3 و4 القديمة مش هتتولّد تاني.)
2. **مفيش اختبار للترحيلات** (`MigrationTestHelper`). بعد تثبيت الـ schemas: أضف `androidTest` بـ `sourceSets["androidTest"].assets.srcDir("$projectDir/schemas")`.
3. **كود الترحيلات موجود جوه `RaneenChat.kt`** (ميزة الشات المعطّلة). لو الشات اتشال، الترحيلات لازم تتنقل أولًا لملف مستقل (`DatabaseMigrations.kt`) — وإلا التطبيق هيفشل في الترقية.
4. تعليق قديم في `RaneenChat.kt` بيذكر `fallbackToDestructiveMigration` الكامل — **قديم**؛ الفعلي `From(1, 2)` فقط.
5. أي تغيير مستقبلي في الكيانات = رفع النسخة + Migration + تحديث `app/schemas` (الـ CI هيفشّل لو اتنسى).

## الخطوات
1. شغّل **Export Room schemas** (يدوي) وادمج الـ PR → `app/schemas/com.raneen.quality.data.RaneenDatabase/5.json`.
2. ما تغيّرش أي كيان قبل ما الملف يتثبّت.
3. بعدها: اختبار ترحيل 3→4→5 على قاعدة بيانات نسخة 3 مولّدة من الـ schema.
