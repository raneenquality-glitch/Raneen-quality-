# GitHub Actions (CI)

## الوضع قبل التعديل
ملف الـ workflow الحالي **ما كانش ضمن الملفات اللي وصلتني**، فاستنتجت شكله من لوج البناء: runner Ubuntu، بيبني `debug` بـ Gradle (من غير wrapper) من المسار `src_build/RaneenQuality`، وبدون خطوات اختبارات أو Lint ظاهرة.
**مطلوب منك:** ابعتلي محتوى `.github/workflows/*.yml` الحالي علشان أراجعه فعليًا (الأذونات، الـ triggers، الأسرار، الـ caching، خطوات التوقيع).

نقاط هراجعها فيه: `permissions` ضيقة · الأسرار مش بتتطبع في اللوج · `pull_request_target` مش مستخدم بالغلط · نسخ الـ actions مثبّتة · مفيش خطوة بتعمل push/إصدار تلقائي من غير فحص.

## اللي اتضاف
| الملف | بيعمل إيه |
|---|---|
| `.github/workflows/ci.yml` | **verify**: Compile (الكود + الاختبارات) → Unit tests → Lint → فحص تغيير الـ Room schema → بناء الـ APK. **أي خطوة تفشل = البناء يفشل ومفيش APK.** |
| `.github/workflows/room-schemas.yml` | يدوي: يبني المشروع ويفتح Pull Request بملفات `app/schemas`. |

- Gradle متثبّت على `8.9` (متوافق مع AGP 8.5.2) لأن المشروع مفيهوش wrapper — **توصية:** أضف `gradlew` + `gradle/wrapper` لتثبيت النسخة.
- `PROJECT_DIR` في أول الملفين = `src_build/RaneenQuality` (استنتاج من اللوج). لو مختلف عدّله، أو `.` لو المشروع في جذر الـ repo.
- الـ `.github/` لازم يكون في **جذر الـ repo** (انقله من مجلد المشروع لو لزم).

## تفعيل "إيقاف اعتماد أي بناء فاشل"
الـ workflow بيفشّل البناء، لكن **المنع نفسه** إعداد في GitHub (مش في الكود):
1. Settings → Branches → Add rule على `main`.
2. فعّل **Require a pull request before merging** و **Require status checks to pass** واختار الـ check اسمه **`verify`**.
3. فعّل **Do not allow bypassing the above settings** (علشان حتى الأدمن ما يتخطاش).

## الـ Lint
بيشتغل ويرفع التقرير (`lint-report`) لكن **مش بيوقف البناء** في الأول (`LINT_BLOCKING: "false"`) لأن مفيش baseline: لو اتقفل دلوقتي هيفشل على ملاحظات قديمة.
لتحويله لـ blocking: (1) شغّل `gradle :app:updateLintBaseline` وثبّت `lint-baseline.xml` وأضف `lint { baseline = file("lint-baseline.xml") }` في `app/build.gradle.kts` (تعديل بناء مستقل أطلب موافقتك عليه)، (2) غيّر `LINT_BLOCKING` لـ `"true"`.

## الاختبارات
حاليًا ملف واحد (9 اختبارات للتقييم `RaneenScoringTest`). راجعتها ضد التعديلات الأخيرة على التقييم: بتستخدم بنود عامة، فمش متأثرة. **التغطية قليلة جدًا** (مفيش اختبارات للمزامنة أو الدخول أو الحصر أو التصدير) — دي أول أولوية بعد تفعيل الـ CI.

## أول تشغيل (بالترتيب)
1. انسخ الـ workflows لجذر الـ repo وادفعها في Pull Request (هيشتغل `verify` عليه).
2. شغّل **Export Room schemas** يدويًا (Actions) → افتح الـ PR → ادمجه.
3. فعّل حماية `main` (فوق).
4. بعد أول ما يبقى أخضر: قرر مصير الـ Lint baseline.
