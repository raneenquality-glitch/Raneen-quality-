package com.raneen.quality.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign

private val PREVIEW_LINES = listOf("الفرع", "القسم / البند", "التاريخ والوقت", "المراقب")

/**
 * معاينة شريط البيانات فوق الكاميرا. المراقب يسحبه لفوق/لتحت ومكانه بيتحفظ ويتطبق على الصور والفيديو.
 * المحتوى الفعلي للشريط (الفرع / القسم / التاريخ / المراقب) بيتكتب تلقائي زي ما هو، والسحب بيغيّر المكان بس.
 */
@Composable
fun DraggableInfoBar(
    modifier: Modifier = Modifier,
    topInset: Dp = 112.dp,      // تحت شريط الفلاش/الكاميرا
    bottomInset: Dp = 210.dp    // reserved for controls (used in landscape placement)
) {
    BoxWithConstraints(modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val topPx = with(density) { topInset.toPx() }
        val landscape = maxWidth > maxHeight
                Column(
            Modifier
                .fillMaxWidth()
                .offset(y = if (landscape) maxHeight - bottomInset else topInset)
                .background(Color(0xB3000000))
                 .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text("بيانات الزيارة", color = Color(0xFFFFCC80), fontSize = 9.sp, textAlign = TextAlign.Start)
            PREVIEW_LINES.forEach { Text(it, color = Color.White, fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
