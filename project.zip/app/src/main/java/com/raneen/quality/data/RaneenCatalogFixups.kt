package com.raneen.quality.data

/**
 * تعديلات ثابتة على أسماء/نصوص الكتالوج (idempotent: تتنفذ أكتر من مرة من غير ما تتكرر).
 * بتتطبق: بعد الـ seed، وعند سحب الكتالوج من السيرفر، وعلى قاعدة البيانات المحلية القديمة —
 * عشان كل الأجهزة تظهر نفس الأسماء حتى لو السيرفر لسه فيه الأسماء القديمة.
 */
object CatalogFixups {
    private const val SECTION_PREFIX = "قسم "
    private const val ADMIN_PREFIX = "إدارة "
    private val ADMIN_STARTS = listOf("إدارة", "ادارة", "الإدارة", "الادارة")
    // بند 13 صيانة رجع: الصيانة = 2 والدهان = 2. أي تلميح قديم (الوزن كامل) جاي من السيرفر بيتحوّل للتلميح الصحيح.
    private const val FULL_WEIGHT_I13_HINT = "اختيار الصيانة أو الدهان (أو الاتنين) يخصم الوزن كامل (4 درجات)"
    private const val PER_PART_I13_HINT = "الصيانة درجتان، والدهان درجتان؛ يمكن تحديد كل جزء بشكل مستقل"

    /** الصيانة والتكييفات (أوف لاين وزايد): بتبدأ بكلمة "قسم" مش "إدارة". */
    private val MAINTENANCE_UNITS = setOf("maintenance", "ac_maintenance", "zayed_maintenance", "zayed_air_conditioning")
    private val LEADING_PREFIX = Regex("^\\s*(قسم|إدارة|ادارة)\\s+")
    private val LEADING_SECTION = Regex("^\\s*قسم\\s+")

    /**
     * أسماء الوحدات:
     *  - الأقسام (SECTION) تبدأ بكلمة قسم: قسم الأدوات المنزلية، قسم الألعاب ومستلزمات الأطفال...
     *  - مدير المعرض من غير كلمة قسم: "مدير المعرض".
     *  - الصيانة والتكييفات: قسم الصيانة، قسم التكييفات.
     *  - باقي الإدارات المساعدة تبدأ بكلمة إدارة: إدارة الكاميرات، إدارة الأمن...
     */
    fun unitName(id: String, name: String, kind: String): String {
        val n = name.trim()
        return when {
            id in MAINTENANCE_UNITS -> SECTION_PREFIX + n.replace(LEADING_PREFIX, "")
            id.contains("branch_manager") -> n.replace(LEADING_SECTION, "")
            kind == "SECTION" -> if (n.startsWith("قسم")) name else SECTION_PREFIX + n
            kind == "ADMINISTRATION" -> if (ADMIN_STARTS.any { n.startsWith(it) }) name else ADMIN_PREFIX + n
            else -> name
        }
    }

    /** بند 13 صيانة: كل جزء (صيانة / دهان) = درجتين */
    fun controlHint(id: String, hint: String?): String? = if (id == "maintenance_i13" && hint == FULL_WEIGHT_I13_HINT) PER_PART_I13_HINT else hint

    /** على قاعدة البيانات المحلية (من غير ما نعلّم الكتالوج "متعدّل" — مفيش رفع للسيرفر بسببها) */
    suspend fun applyToLocal(dao: CatalogDao) {
        val units = dao.allUnits().mapNotNull { u ->
            val n = unitName(u.id, u.name, u.kind); if (n != u.name) u.copy(name = n) else null
        }
        if (units.isNotEmpty()) dao.upsertUnits(units)
        val controls = dao.allControls().mapNotNull { c ->
            val h = controlHint(c.id, c.hint); if (h != c.hint) c.copy(hint = h) else null
        }
        if (controls.isNotEmpty()) dao.upsertControls(controls)
    }
}
