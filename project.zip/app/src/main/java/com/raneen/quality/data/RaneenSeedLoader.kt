package com.raneen.quality.data

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

// الداتابيز
// لو عندك @Database موجودة في المشروع: انقل الكيانات والـ DAOs لها بدل ما تعمل كلاس جديد.
@Database(
    entities = [
        TemplateEntity::class, EvaluationUnitEntity::class, ProductGroupEntity::class,
        CategoryEntity::class, ControlEntity::class, BranchEntity::class,
        InspectionEntity::class, InspectionUnitEntity::class, UserEntity::class,
        FindingEntity::class, PhotoEntity::class, AuditEntity::class, ChatMessageEntity::class
    ],
    version = 5,
    exportSchema = true   // بيطلّع ملف schemas/<version>.json عشان نقدر نراجع كل Migration
)
abstract class RaneenDatabase : RoomDatabase() {
    abstract fun catalogDao(): CatalogDao
    abstract fun inspectionDao(): InspectionDao
    abstract fun userDao(): UserDao
    abstract fun chatDao(): ChatDao
}

// تحميل الـ seed
/**
 * بيقرا assets/raneen_seed.json ويملأ: templates / evaluation_units / product_groups /
 * categories / controls. بيشتغل مرة واحدة (لو جدول الضوابط فاضي).
 * الكل جوه transaction واحدة: يا كله يتكتب يا مفيش حاجة (مفيش seed نصّه).
 *
 * محتاج dependency:  androidx.room:room-ktx  (withTransaction)
 */
class SeedLoader(
    private val context: Context,
    private val db: RaneenDatabase
) {
    companion object {
        private const val ASSET = "raneen_seed.json"
        private const val TEMPLATE_ID = "main"   // قالب "تقرير الجودة" الأساسي
        const val PREFS = "raneen_seed"
        const val KEY_PATCH_V = "patch_v"
        const val KEY_PUSH_PENDING = "push_pending"       // الأدمن لازم يرفع الكتالوج المصحّح للسيرفر مرة
        private const val PATCH_VERSION = 1               // زوّده لما تضيف تصحيح جديد
        private val ZAYED_FULL_WEIGHT_UNITS = setOf(
            "zayed_branch_manager", "zayed_cafe", "zayed_customer_service", "zayed_security",
            "zayed_maintenance", "zayed_air_conditioning", "zayed_hr"
        )
        private val ZAYED_PART_IDS = setOf("zayed_branch_manager_i1", "zayed_branch_manager_i3", "zayed_branch_manager_i4", "zayed_branch_manager_i5", "zayed_branch_manager_i9")
        private val HINT_PATCH_IDS = setOf("zayed_branch_manager_i1", "receiving_fmc_i1", "receiving_fmc_i2", "maintenance_i13")
    }

    suspend fun seedIfEmpty() = withContext(Dispatchers.IO) {
        if (db.catalogDao().controlCount() > 0) {
            addMissingSeedUnits()
            applyPatches()
            CatalogFixups.applyToLocal(db.catalogDao())
            return@withContext
        }
        load()
        // قاعدة جديدة: الـ seed أصلًا فيه التصحيحات، فمفيش حاجة تتطبّق ولا تتبعت
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_PATCH_V, PATCH_VERSION).apply()
        CatalogFixups.applyToLocal(db.catalogDao())
    }

    /** استرجاع الكتالوج الأصلي: بيمسح الأقسام/الضوابط الحالية (بما فيها تعديلات الأدمن) ويحمّل الـ seed من الأول */
    suspend fun reseed() = withContext(Dispatchers.IO) {
        val dao = db.catalogDao()
        db.withTransaction {
            dao.wipeControls(); dao.wipeCategories(); dao.wipeGroups(); dao.wipeUnits(); dao.wipeTemplates()
        }
        load()
        CatalogFixups.applyToLocal(dao)
    }

    /** يضيف الوحدات الجديدة فقط من seed بدون استبدال أي تعديل إداري قائم. */
    private suspend fun addMissingSeedUnits() {
        val dao = db.catalogDao()
        val root = JSONObject(context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() })
        val all = root.getJSONArray("units")
        val known = dao.allUnitIds().toSet()
        val missingRoot = JSONObject().put("units", org.json.JSONArray())
        val missing = missingRoot.getJSONArray("units")
        for (i in 0 until all.length()) {
            val unit = all.getJSONObject(i)
            if (unit.getString("id") !in known) missing.put(unit)
        }
        if (missing.length() == 0) return
        // بنحلّل الوحدات الناقصة بس هنا
        val unitList = mutableListOf<EvaluationUnitEntity>()
        val groupList = mutableListOf<ProductGroupEntity>()
        val categoryList = mutableListOf<CategoryEntity>()
        val controlList = mutableListOf<ControlEntity>()
        for (i in 0 until missing.length()) {
            val u = missing.getJSONObject(i); val unitId = u.getString("id")
            unitList += EvaluationUnitEntity(unitId, u.optString("templateId", TEMPLATE_ID), u.getString("name"), u.getString("kind"), u.optString("scoringMode", "X_COUNT"), u.optInt("sortOrder", 0))
            val groups = u.optJSONArray("groups")
            if (groups != null) for (g in 0 until groups.length()) groupList += ProductGroupEntity("${unitId}_g${g+1}", unitId, groups.getString(g), g)
            val cats = u.getJSONArray("categories")
            for (c in 0 until cats.length()) { val o=cats.getJSONObject(c); categoryList += CategoryEntity(o.getString("id"), unitId, o.getString("name"), o.optInt("sort",0)) }
            val controls = u.getJSONArray("controls")
            for (k in 0 until controls.length()) { val o=controls.getJSONObject(k); controlList += ControlEntity(o.getString("id"),o.getString("categoryId"),o.getString("text"),o.getDouble("maxScore"),o.optDouble("penaltyPerViolation",1.0),o.optBoolean("photoRequired",true),o.optBoolean("perGroup",false),if(o.isNull("hint")) null else o.optString("hint"),o.optInt("no",k+1)) }
        }
        val templates = mutableListOf(TemplateEntity(TEMPLATE_ID, "تقرير الجودة"), TemplateEntity("zayed", "تقييم فرع زايد"))
        db.withTransaction { dao.upsertTemplates(templates); dao.upsertUnits(unitList); dao.upsertGroups(groupList); dao.upsertCategories(categoryList); dao.upsertControls(controlList) }
    }

    /**
     * تصحيحات الكتالوج (مرة واحدة لكل رقم إصدار — مش كل مرة التطبيق يفتح).
     * قبل كده كانت بتكتب فوق نص/وزن البنود من الـ seed في كل تشغيل، فتعديلات الأدمن (زي حذف كلمة من بند صيانة 2
     * أو وزن بند 12 في مدير المعرض زايد) كانت بترجع وبتتبعت للسيرفر كمان.
     * دلوقتي: التصحيح بيتطبّق مرة، وبعدها أي تعديل من الأدمن هو اللي يفضل. التصحيح بيلمس بس الحقول المذكورة تحت.
     */
    suspend fun applyPatches() {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (sp.getInt(KEY_PATCH_V, 0) >= PATCH_VERSION) return
        patchControlsFromSeed()
        sp.edit().putInt(KEY_PATCH_V, PATCH_VERSION).putBoolean(KEY_PUSH_PENDING, true).apply()
    }

    /** بيرجّع تصحيحات الإصدار فوق نسخة جت من السيرفر (الأدمن بس، قبل رفع الكتالوج) */
    suspend fun reapplyPatches() = patchControlsFromSeed()

    private suspend fun patchControlsFromSeed() {
        val dao = db.catalogDao()
        val root = JSONObject(context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() })
        val units = root.getJSONArray("units")
        val existing = dao.allControls().associateBy { it.id }
        val updates = mutableListOf<ControlEntity>()
        for (i in 0 until units.length()) {
            val u = units.getJSONObject(i)
            val unitId = u.getString("id")
            val controls = u.getJSONArray("controls")
            for (j in 0 until controls.length()) {
                val o = controls.getJSONObject(j)
                val id = o.getString("id")
                val cur = existing[id] ?: continue
                val hint = if (o.isNull("hint")) null else o.optString("hint")
                var next = cur
                // الخصم: تقييم زايد (الإدارات من غير مجموعات منتجات) — الخصم = الوزن كامل
                // الأوزان (maxScore) بتفضل زي ما هي في الكتالوج الحالي (تعديلات الأدمن + مجموع 100) — بنغيّر الخصم بس.
                if (unitId in ZAYED_FULL_WEIGHT_UNITS && id !in ZAYED_PART_IDS && cur.penaltyPerViolation < cur.maxScore)
                    next = next.copy(penaltyPerViolation = cur.maxScore)
                // التلميحات: بنود الأجزاء الجديدة / بند 13 صيانة
                if (id in HINT_PATCH_IDS) next = next.copy(hint = hint)
                if (next != cur) updates += next
            }
        }
        if (updates.isNotEmpty()) dao.upsertControls(updates)
    }

    private suspend fun load() {
        val dao = db.catalogDao()

        val json = context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(json)
        val templates = root.optJSONArray("templates")
        val units = root.getJSONArray("units")

        val unitList = mutableListOf<EvaluationUnitEntity>()
        val groupList = mutableListOf<ProductGroupEntity>()
        val categoryList = mutableListOf<CategoryEntity>()
        val controlList = mutableListOf<ControlEntity>()

        for (i in 0 until units.length()) {
            val u = units.getJSONObject(i)
            val unitId = u.getString("id")

            unitList += EvaluationUnitEntity(
                id = unitId,
                templateId = u.optString("templateId", TEMPLATE_ID),
                name = u.getString("name"),
                kind = u.getString("kind"),
                scoringMode = u.getString("scoringMode"),
                sortOrder = u.getInt("sortOrder")
            )

            // المجموعات: مجموعات منتجات (الأقسام) أو ق1–ق4 (الخدمات). الإدارات المساعدة مفيهاش.
            val groups = u.optJSONArray("groups")
            if (groups != null) for (g in 0 until groups.length()) {
                groupList += ProductGroupEntity(
                    id = "${unitId}_g${g + 1}", unitId = unitId,
                    name = groups.getString(g), sortOrder = g
                )
            }

            val cats = u.getJSONArray("categories")
            for (c in 0 until cats.length()) {
                val o = cats.getJSONObject(c)
                categoryList += CategoryEntity(
                    id = o.getString("id"), unitId = unitId,
                    name = o.getString("name"), sortOrder = o.getInt("sort")
                )
            }

            val controls = u.getJSONArray("controls")
            for (k in 0 until controls.length()) {
                val o = controls.getJSONObject(k)
                controlList += ControlEntity(
                    id = o.getString("id"),
                    categoryId = o.getString("categoryId"),
                    text = o.getString("text"),
                    maxScore = o.getDouble("maxScore"),
                    penaltyPerViolation = o.getDouble("penaltyPerViolation"),
                    photoRequired = o.getBoolean("photoRequired"),
                    perGroup = o.getBoolean("perGroup"),
                    hint = if (o.isNull("hint")) null else o.getString("hint"),
                    sortOrder = o.getInt("no")
                )
            }
        }

        // الترتيب مهم بسبب الـ Foreign Keys: القالب → الوحدات → المجموعات/الكاتجري → الضوابط
        db.withTransaction {
            val templateList = mutableListOf(TemplateEntity(TEMPLATE_ID, "تقرير الجودة"))
            if (templates != null) for (ti in 0 until templates.length()) {
                val t = templates.getJSONObject(ti)
                templateList += TemplateEntity(t.getString("id"), t.getString("name"), t.optBoolean("isActive", true))
            }
            templateList += unitList.map { TemplateEntity(it.templateId, if (it.templateId == "zayed") "تقييم فرع زايد" else "تقرير الجودة") }.distinctBy { it.id }
            dao.upsertTemplates(templateList.distinctBy { it.id })
            dao.upsertUnits(unitList)
            dao.upsertGroups(groupList)
            dao.upsertCategories(categoryList)
            dao.upsertControls(controlList)
        }
        CensusDefaults.ensure(dao)
    }
}
