# Room schemas

هنا بيتحط ملف الـ schema الخاص بكل نسخة من الداتابيز: `com.raneen.quality.data.RaneenDatabase/<version>.json`
(النسخة الحالية 5). الملفات دي بيطلّعها Room أثناء البناء (`exportSchema = true` + `room.schemaLocation`).

**ماتتعدّلش باليد.** للإضافة لأول مرة: شغّل workflow **Export Room schemas** (Actions → Run workflow)، هيفتح Pull Request فيه الملفات.
بعد كده الـ CI بيقارن الملفات المتثبّتة بالمولّدة، وأي تغيير في الداتابيز من غير تحديث الملف (وإضافة Migration) بيفشّل البناء.
تفاصيل المراجعة: `docs/ROOM_MIGRATIONS_REVIEW.md`.
