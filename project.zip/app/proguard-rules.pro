# Room / Kotlin / Media3 / Firebase بيجيبوا قواعدهم بنفسهم. هنا بس اللي بنحتاجه.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keep class com.raneen.quality.data.*Entity { *; }
# org.json بيستخدم أسماء الحقول كنصوص، فمفيش تغيير أسماء في الـ data models
-keep class com.raneen.quality.data.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn javax.annotation.**
