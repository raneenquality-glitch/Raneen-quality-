# التوقيع بمفتاح ثابت على GitHub (مرة واحدة)

الهدف: كل APK يطلع من GitHub يتوقّع بنفس المفتاح، فالتحديثات تتثبت فوق بعض من غير مسح التطبيق.
الملفات اللي سلّمتهالك: `raneen-release.keystore` و `raneen-keystore-info.properties` (فيه الباسوردات). احتفظ بيهم في مكان آمن. لو ضاعوا مفيش تحديث هيتثبت فوق النسخة دي تاني. **ماترفعهومش على GitHub نفسه.**

## الخطوات
1. حوّل ملف الـ keystore لنص base64:
   - Linux / Mac: `base64 -w0 raneen-release.keystore`
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("raneen-release.keystore"))`
2. على GitHub: المستودع ← Settings ← Secrets and variables ← Actions ← New repository secret. أضف 4 أسرار بالأسماء دي بالظبط:
   - `KEYSTORE_BASE64`: النص الطويل من الخطوة 1
   - `KEYSTORE_PASSWORD`: storePassword من ملف info
   - `KEY_ALIAS`: keyAlias من ملف info
   - `KEY_PASSWORD`: keyPassword من ملف info
3. شغّل الـ workflow (Run workflow أو push). الـ APK في Artifacts باسم `raneen-debug-apk`.

## ملاحظات
- أول مرة بس: لازم تمسح النسخة القديمة من الموبايل وتثبّت الجديدة (المفتاح اتغيّر). بعد كده التحديثات بتتثبت فوقها عادي.
- رقم النسخة (versionCode) بياخد رقم تشغيل الـ workflow، فبيزيد لوحده مع كل بناء.
- لو الأسرار مش موجودة الـ workflow هيبني بمفتاح مؤقت ويطلّع تحذير.
