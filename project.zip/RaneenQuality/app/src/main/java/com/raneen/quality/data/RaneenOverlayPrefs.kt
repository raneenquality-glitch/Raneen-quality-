package com.raneen.quality.data

import android.content.Context
import android.content.SharedPreferences

/**
 * مكان شريط البيانات على الصور والفيديو (الفرع / القسم / التاريخ / المراقب).
 * القيمة من 0 (أعلى الصورة) إلى 1 (أسفل الصورة = الوضع الافتراضي). بتتحفظ على الجهاز وبتتطبق على كل الصور والفيديوهات الجديدة.
 * تحريك الشريط بيغيّر مكانه بس، ومحتواه بيفضل زي ما هو.
 */
object OverlayPrefs {
    private var prefs: SharedPreferences? = null
    fun init(ctx: Context) { prefs = ctx.applicationContext.getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE) }

    var barPos: Float
        get() = (prefs?.getFloat("bar_pos", 1f) ?: 1f).coerceIn(0f, 1f)
        set(v) { prefs?.edit()?.putFloat("bar_pos", v.coerceIn(0f, 1f))?.apply() }
}
