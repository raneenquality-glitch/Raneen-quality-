package com.raneen.quality.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raneen.quality.data.OverlayPrefs
import kotlin.math.roundToInt

private val PREVIEW_LINES = listOf("الفرع", "القسم / البند", "التاريخ والوقت", "المراقب")

/**
 * معاينة شريط البيانات فوق الكاميرا. المراقب يسحبه لفوق/لتحت ومكانه بيتحفظ ويتطبق على الصور والفيديو.
 * المحتوى الفعلي للشريط (الفرع / القسم / التاريخ / المراقب) بيتكتب تلقائي زي ما هو، والسحب بيغيّر المكان بس.
 */
@Composable
fun DraggableInfoBar(
    modifier: Modifier = Modifier,
    topInset: Dp = 112.dp,      // تحت شريط الفلاش/الكاميرا
    bottomInset: Dp = 210.dp    // فوق أزرار الزوم والتصوير
) {
    var pos by remember { mutableFloatStateOf(OverlayPrefs.barPos) }
    var barH by remember { mutableIntStateOf(0) }
    BoxWithConstraints(modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val topPx = with(density) { topInset.toPx() }
        val bottomPx = with(density) { bottomInset.toPx() }
        val usable = (with(density) { maxHeight.toPx() } - topPx - bottomPx - barH).coerceAtLeast(1f)
        val range by rememberUpdatedState(usable)
        Column(
            Modifier
                .fillMaxWidth()
                .offset { IntOffset(0, (topPx + usable * pos).roundToInt()) }
                .onSizeChanged { barH = it.height }
                .background(Color(0xB3000000))
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = { OverlayPrefs.barPos = pos },
                        onDragCancel = { OverlayPrefs.barPos = pos }
                    ) { change, drag ->
                        change.consume()
                        pos = (pos + drag.y / range).coerceIn(0f, 1f)
                    }
                }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text("↕ اسحب الشريط لتحريكه", color = Color(0xFFFFCC80), fontSize = 10.sp)
            PREVIEW_LINES.forEach { Text(it, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
