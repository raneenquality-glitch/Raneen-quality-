package com.raneen.quality.data

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.raneen.quality.MainActivity
import org.json.JSONObject

// إشعارات الشات الفورية (FCM)
// السيرفر (Edge Function) بيبعت رسالة "data" بس، والتطبيق هو اللي بيبني الإشعار.
// الحقول: type="chat", peer=<id المرسل>, title=<اسم المرسل>, body=<معاينة الرسالة>

/** الإشعار نفسه: الضغط عليه بيفتح محادثة المرسل مباشرة */
object ChatPush {
    private const val CHANNEL = "raneen_chat"
    const val EXTRA_PEER = "chat_peer"

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, peerId: String, title: String, body: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (Build.VERSION.SDK_INT >= 26) {
            ctx.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "رسائل الشات", NotificationManager.IMPORTANCE_HIGH))
        }
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_PEER, peerId)
        }
        val code = peerId.hashCode()                       // كل محادثة ليها PendingIntent وإشعار خاص بيها
        val pi = PendingIntent.getActivity(ctx, code, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pi).setAutoCancel(true).build()
        NotificationManagerCompat.from(ctx).notify(code, n)   // رسالة جديدة من نفس الشخص بتحدّث نفس الإشعار
    }
}

class RaneenMessagingService : FirebaseMessagingService() {
    /** Google أصدرت/غيّرت توكن الجهاز: نسجّله مع أول مزامنة */
    override fun onNewToken(token: String) = PushRegistrar.onNewToken(applicationContext)

    override fun onMessageReceived(message: RemoteMessage) {
        val d = message.data
        if (d["type"] == "chat") {
            ChatPush.show(applicationContext, d["peer"].orEmpty(), d["title"] ?: "رسالة جديدة", d["body"].orEmpty())
        }
    }
}

/** ربط توكن الجهاز بالمستخدم على السيرفر (جدول device_tokens عن طريق دوال register_device / unregister_device) */
object PushRegistrar {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("raneen_push", Context.MODE_PRIVATE)

    fun onNewToken(ctx: Context) { prefs(ctx).edit().remove("registered").apply() }

    /** من المزامنة (thread خلفي). بتسجّل بس لو المستخدم أو التوكن اتغيّر. */
    fun register(ctx: Context, remote: SupabaseRemote, userId: String) {
        val token = try { Tasks.await(FirebaseMessaging.getInstance().token) } catch (e: Exception) { return }
        val key = "$userId:$token"
        if (prefs(ctx).getString("registered", null) == key) return
        try {
            remote.rpc("register_device", JSONObject().put("p_token", token).toString())
        } catch (e: ApiException) {
            if (e.code == 404) return        // دوال السيرفر لسه ما اتعملتش: نحاول بعدين من غير إزعاج
            throw e
        }
        prefs(ctx).edit().putString("registered", key).apply()
    }

    /** عند تسجيل الخروج: نفصل الجهاز عن المستخدم (عشان إشعارات الشخص ده ماتوصلش لمستخدم تاني)، وبعدها ننفّذ onDone */
    fun logoutAsync(ctx: Context, remote: SupabaseRemote, onDone: () -> Unit) {
        Thread {
            var token: String? = null
            var access: String? = null
            try { token = Tasks.await(FirebaseMessaging.getInstance().token); access = remote.freshAccessToken() } catch (e: Exception) { }
            prefs(ctx).edit().remove("registered").apply()
            onDone()                                    // الجلسة بتنتهي فورًا، وفصل الجهاز بيتم بالتوكن اللي معانا
            if (token != null && access != null) {
                // لو فشل (مفيش نت): التوكن بيتنقل أوتوماتيك لأي مستخدم يسجّل دخول على الجهاز ده بعد كده
                try { remote.rpcWithToken(access, "unregister_device", JSONObject().put("p_token", token).toString()) } catch (e: Exception) { }
            }
        }.start()
    }
}
