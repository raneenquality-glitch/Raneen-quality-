package com.raneen.quality.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** مكوّنات واجهة الكاميرا (صور + فيديو): نفس الشكل في الشاشتين. */
val CameraRed = Color(0xFFE50914)

/** زرار كبسولة شبه شفاف (فلاش / تبديل الكاميرا). */
@Composable
fun CameraPill(text: String, onClick: () -> Unit, enabled: Boolean = true, modifier: Modifier = Modifier, compact: Boolean = false) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier.clip(shape)
            .background(Color.White.copy(alpha = if (enabled) 0.2f else 0.1f))
            .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = if (compact) 10.dp else 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White.copy(alpha = if (enabled) 1f else 0.5f), fontSize = if (compact) 12.sp else 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** الشريط العلوي العائم: تدرّج أسود شفاف + أزرار. */
@Composable
fun CameraTopBar(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/** زرار "إضافة سبب اختياري": كبسولة بحدود متقطّعة. */
@Composable
fun ReasonPill(onClick: () -> Unit, enabled: Boolean = true) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier.clip(shape).background(Color.Black.copy(alpha = 0.5f))
            .drawBehind {
                drawRoundRect(
                    Color.White.copy(alpha = 0.4f), cornerRadius = CornerRadius(16.dp.toPx()),
                    style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                )
            }
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp)
    ) { Text("＋ إضافة سبب اختياري", color = Color(0xFFE0E0E0), fontSize = 12.sp) }
}

/** كارت الزوم: (− الزوم 1.0× +) وتحتها سلايدر أحمر. */
@Composable
fun CameraZoomCard(zoom: Float, max: Float, enabled: Boolean, onZoom: (Float) -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 10.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.4f))
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val canOut = enabled && zoom > 1f
        val canIn = enabled && zoom < max
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                "−", color = Color.White.copy(alpha = if (canOut) 1f else 0.4f), fontSize = 22.sp,
                modifier = Modifier.clickable(enabled = canOut) { onZoom((zoom - 0.5f).coerceAtLeast(1f)) }.padding(horizontal = 12.dp, vertical = 2.dp)
            )
            Text("الزوم ${"%.1f".format(zoom)}×", color = Color(0xFFCCCCCC), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(
                "+", color = Color.White.copy(alpha = if (canIn) 1f else 0.4f), fontSize = 22.sp,
                modifier = Modifier.clickable(enabled = canIn) { onZoom((zoom + 0.5f).coerceAtMost(max)) }.padding(horizontal = 12.dp, vertical = 2.dp)
            )
        }
        if (max > 1f) {
            Slider(
                value = zoom.coerceIn(1f, max), onValueChange = onZoom, valueRange = 1f..max, enabled = enabled,
                colors = SliderDefaults.colors(thumbColor = CameraRed, activeTrackColor = CameraRed, inactiveTrackColor = Color.White.copy(alpha = 0.3f))
            )
        } else {
            Text("الزوم غير مدعوم في الكاميرا دي", color = Color(0xFFCCCCCC), fontSize = 12.sp)
        }
    }
}

/** الشريط السفلي الغامق: إلغاء (يمين/بداية) — زرار الكاميرا في النص — مساحة/زرار إضافي في الطرف التاني. */
@Composable
fun CameraBottomBar(cancel: @Composable () -> Unit, center: @Composable () -> Unit, end: @Composable () -> Unit = {}) {
    Box(Modifier.fillMaxWidth().background(Color(0xFF121212)).padding(20.dp)) {
        Box(Modifier.align(Alignment.CenterStart).widthIn(min = 60.dp), contentAlignment = Alignment.Center) { cancel() }
        Box(Modifier.align(Alignment.Center)) { center() }
        Box(Modifier.align(Alignment.CenterEnd).width(60.dp), contentAlignment = Alignment.Center) { end() }
    }
}

@Composable
fun CameraCancelButton(onClick: () -> Unit, enabled: Boolean = true) {
    TextButton(onClick = onClick, enabled = enabled) {
        Text("إلغاء", color = Color(0xFFAAAAAA), fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

/** زرار التصوير الدايري الأحمر (68dp) بحلقة بيضاء ووهج خفيف، بيصغّر شوية وقت الضغط. */
@Composable
fun CameraShutterButton(enabled: Boolean, busy: Boolean, onClick: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, label = "shutter")
    Box(
        Modifier.size(68.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(14.dp, CircleShape, ambientColor = CameraRed.copy(alpha = 0.6f), spotColor = CameraRed.copy(alpha = 0.6f))
            .clip(CircleShape).background(CameraRed.copy(alpha = if (enabled) 1f else 0.4f))
            .border(4.dp, Color.White, CircleShape)
            .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
            .semantics { contentDescription = "تصوير" },
        contentAlignment = Alignment.Center
    ) {
        if (busy) CircularProgressIndicator(Modifier.size(26.dp), color = Color.White, strokeWidth = 3.dp)
    }
}
