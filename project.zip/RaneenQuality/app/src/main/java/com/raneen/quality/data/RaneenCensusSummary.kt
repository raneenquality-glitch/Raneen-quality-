package com.raneen.quality.data

import java.util.Locale

/** صف في جدول "حصر مخالفات الأسعار": العدد أو القيمة (للأكواد). */
data class CensusRowOut(val group: String, val label: String, val count: Int, val money: Double? = null) {
    val valueText: String get() = if (money != null) String.format(Locale.US, "%.2f", money) else count.toString()
}

/** صف في جدول "حصر أدوات العرض": العدد × قيمة القطعة. */
data class DisplayToolLine(val label: String, val count: Int, val pieceValue: Double) {
    val total: Double get() = count * pieceValue
}

/** بند واحد من حصر الصيانة / صيانة التكييفات. */
data class MaintenanceCensusItem(
    val item: String, val state: String, val problem: String, val faultDate: String,
    val ticket: String, val escalation: String, val status: String, val count: Int = 0
) {
    val isViolation: Boolean get() = state == "مخالف"
    val hasDetails: Boolean get() = problem.isNotBlank() || ticket.isNotBlank() || faultDate.isNotBlank() || count > 0
    /** نص البند ومعاه العدد (لو مكتوب) للجداول المصدّرة */
    val itemWithCount: String get() = if (count > 0) "$item (العدد: $count)" else item
}

data class MaintenanceCensusBlock(val unitId: String, val unitName: String, val isAc: Boolean, val rows: List<MaintenanceCensusItem>) {
    val title: String get() = if (isAc) "حصر صيانة التكييفات" else "حصر الصيانة"
    val violated: Int get() = rows.count { it.isViolation }
    /** الصفوف اللي تتعرض في التقرير: المخالفة أو اللي فيها شرح/تيكت/تاريخ عطل. */
    val shown: List<MaintenanceCensusItem> get() = rows.filter { it.isViolation || it.hasDetails }
}

/** ملخص الحصر المجمّع تلقائيًا من المخالفات — بيظهر في آخر ورقة بالتقرير (PDF / Word / Excel). */
data class CensusSummary(
    val price: List<CensusRowOut> = emptyList(),
    val display: List<DisplayToolLine> = emptyList(),
    val maintenance: List<MaintenanceCensusBlock> = emptyList()
) {
    /** إجمالي أعداد مخالفات الأسعار (من غير صف قيمة الأكواد). */
    val priceTotal: Int get() = price.filter { it.money == null }.sumOf { it.count }
    val displayTotalCount: Int get() = display.sumOf { it.count }
    val displayTotalValue: Double get() = display.sumOf { it.total }
}

object CensusSummaryBuilder {
    private const val MAINT_CONTROL = "__maintenance_census__"
    private const val MAINT_PREFIX = "RQ_MAINTENANCE_CENSUS_V1:"
    private val CNS = Regex("^cns_(pricing|missing)_(.+)_(\\d+)$")

    /** قيمة القطعة لكل نوع أداة عرض (من ورقة نواقص مساطر الأسعار في الإكسل). */
    private val DISPLAY_TOOLS = listOf(
        Triple("display_ruler", "مسطرة", 26.0),
        Triple("display_sadabat", "المداسات (السدابات)", 8.42),
        Triple("display_acrylic", "الاكليرك", 33.25),
        Triple("display_polystyrene", "بولسترين", 5.0),
        Triple("display_half_a6_acrylic", "اكليرك نص A6", 16.45)
    )
    // أرقام ضوابط "حصر أدوات العرض" (كسر + فقد) لكل نوع
    private val MISSING_IDX = mapOf(
        "display_ruler" to listOf(1, 2), "display_acrylic" to listOf(3, 4), "display_half_a6_acrylic" to listOf(5, 6),
        "display_sadabat" to listOf(7, 8), "display_polystyrene" to listOf(9, 10)
    )

    fun build(findings: List<FindingEntity>, naUnits: Set<String>, units: List<EvaluationUnitEntity>): CensusSummary {
        val active = findings.filter { it.unitId !in naUnits }
        val counts = HashMap<String, Int>()
        var codeValue = 0.0
        fun inc(k: String, c: Int) { if (c > 0) counts[k] = (counts[k] ?: 0) + c }

        active.filter { it.controlId != MAINT_CONTROL && it.violationCount > 0 }.forEach { f ->
            // 1) حقول الحصر الملحقة بالمخالفة نفسها
            InlineCensusData.parse(f.note).forEach { (k, v) ->
                inc("in_$k", v.count)
                if (k == "no_code") codeValue += v.value
            }
            // 2) ضوابط الحصر (الأعداد لكل مجموعة منتجات)
            val m = CNS.matchEntire(f.controlId)
            if (m != null) {
                val kind = m.groupValues[1]
                val n = m.groupValues[3].toIntOrNull() ?: return@forEach
                inc("$kind$n", f.violationCount)
                if (kind == "pricing" && n in 10..12) {
                    val price = f.note?.takeIf { it.startsWith("PRICE:") }?.removePrefix("PRICE:")?.toDoubleOrNull() ?: 0.0
                    codeValue += f.violationCount * price
                }
            }
        }
        fun g(vararg k: String) = k.sumOf { counts[it] ?: 0 }

        val price = buildList {
            add(CensusRowOut("شيلفات", "بدون شيلف", g("in_no_shelf", "pricing1")))
            add(CensusRowOut("شيلفات", "عدم تطابق", g("in_mismatch", "pricing3")))
            add(CensusRowOut("صاينات", "صاين عرض", g("in_stand_offer", "pricing5", "pricing6", "in_partial_damage", "pricing7")))
            add(CensusRowOut("صاينات", "صاين سعر", g("in_stand_price")))
            add(CensusRowOut("أكواد", "عدد", g("in_no_code", "pricing10", "pricing11", "pricing12")))
            add(CensusRowOut("أكواد", "قيمة", 0, codeValue))
            add(CensusRowOut("سعر", "عدد الأسعار", g("in_no_price", "pricing13", "pricing14", "pricing15")))
            // بنود إضافية بتظهر بس لو فيها أعداد
            listOf(
                Triple("شيلفات", "شيلف تالف", g("pricing2")),
                Triple("صاينات", "بدون صاين", g("pricing4")),
                Triple("صاينات", "بدون توكر", g("pricing8")),
                Triple("صاينات", "صاين / توكر تالف", g("pricing9"))
            ).filter { it.third > 0 }.forEach { add(CensusRowOut(it.first, it.second, it.third)) }
        }

        val display = DISPLAY_TOOLS.map { (key, label, piece) ->
            val missing = (MISSING_IDX[key] ?: emptyList()).sumOf { g("missing$it") }
            DisplayToolLine(label, g("in_$key") + missing, piece)
        }

        val order = units.withIndex().associate { it.value.id to it.index }
        val maintenance = active.filter { it.controlId == MAINT_CONTROL && it.note?.startsWith(MAINT_PREFIX) == true }
            .mapNotNull { f ->
                val rows = parseMaintenance(f.note!!.removePrefix(MAINT_PREFIX))
                if (rows.isEmpty()) return@mapNotNull null
                val u = units.firstOrNull { it.id == f.unitId }
                val isAc = f.unitId.contains("air") || f.unitId.startsWith("ac") || (u?.name ?: "").contains("تكييف")
                MaintenanceCensusBlock(f.unitId, u?.name ?: f.unitId, isAc, rows)
            }.sortedBy { order[it.unitId] ?: 999 }

        return CensusSummary(price, display, maintenance)
    }

    private fun parseMaintenance(json: String): List<MaintenanceCensusItem> = try {
        val a = org.json.JSONArray(json)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            MaintenanceCensusItem(
                o.optString("item"), o.optString("inspectionState", "غير مخالف"), o.optString("problem"),
                o.optString("faultDate"), o.optString("ticket"), o.optString("escalation", "لم يتم التصعيد"), o.optString("status", "معلق"),
                o.optInt("count", 0).coerceAtLeast(0)
            )
        }
    } catch (_: Exception) { emptyList() }
}
