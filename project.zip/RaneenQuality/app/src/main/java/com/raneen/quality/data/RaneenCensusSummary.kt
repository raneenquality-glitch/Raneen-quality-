package com.raneen.quality.data

import java.util.Locale

/** صف في جدول "حصر مخالفات الأسعار": العدد أو القيمة (للأكواد). */
data class CensusRowOut(val group: String, val label: String, val count: Int, val money: Double? = null) {
    val valueText: String get() = if (money != null) String.format(Locale.US, "%.2f", money) else count.toString()
}

/** صف في جدول "حصر أدوات العرض": العدد × قيمة القطعة. */
data class DisplayToolLine(val label: String, val count: Int, val pieceValue: Double) {
    val total: Double get() = count * pieceValue
}

/** بند واحد من حصر الصيانة / صيانة التكييفات. */
data class MaintenanceCensusItem(
    val item: String, val state: String, val problem: String, val faultDate: String,
    val ticket: String, val escalation: String, val status: String, val count: Int = 0
) {
    val isViolation: Boolean get() = state == "مخالف"
    val hasDetails: Boolean get() = problem.isNotBlank() || ticket.isNotBlank() || faultDate.isNotBlank() || count > 0
    /** نص البند ومعاه العدد (لو مكتوب) للجداول المصدّرة */
    val itemWithCount: String get() = if (count > 0) "$item (العدد: $count)" else item
}

data class MaintenanceCensusBlock(val unitId: String, val unitName: String, val isAc: Boolean, val rows: List<MaintenanceCensusItem>) {
    val title: String get() = if (isAc) "حصر صيانة التكييفات" else "حصر الصيانة"
    val violated: Int get() = rows.count { it.isViolation }
    /** الصفوف اللي تتعرض في التقرير: المخالفة أو اللي فيها شرح/تيكت/تاريخ عطل. */
    val shown: List<MaintenanceCensusItem> get() = rows.filter { it.isViolation || it.hasDetails }
}

/**
 * حصر هيكل الفرع (قسم الموارد البشرية): العدد المعتمد للهيكل × العدد الفعلي لكل مجموعة وظيفية، والفرق،
 * وتصنيف العجز (داخل / خارج الفترة المسموحة). بيتخزّن في الزيارة كنوتة على ضابط خاص (مفيش درجة ولا خصم).
 */
object StructureCensus {
    const val CONTROL_ID = "__structure_census__"
    const val PREFIX = "RQ_STRUCTURE_CENSUS_V1:"
    val UNITS = setOf("hr", "zayed_hr")
    /** بند "عدم وجود عجز بهيكل الفرع" (hr_i11 / zayed_hr_i11): مخالف/غير مخالف في الحصر بيسجّل مخالفة عليه */
    fun violationControlId(unitId: String) = unitId + "_i11"
    val UNIT_NAMES = mapOf("hr" to "إدارة الموارد البشرية", "zayed_hr" to "إدارة الموارد البشرية — زايد")
    /** المجموعات الوظيفية بنفس ترتيب شيت "حصر الهيكل" */
    val GROUPS = listOf(
        "operations" to "إدارة التشغيل", "services" to "الخدمات", "customer_cashier" to "خدمة العملاء والكاشير",
        "security" to "الأمن", "cameras" to "الكاميرات",
        "receiving" to "إدارة الاستلامات"
    )
    /** الفرق بعلامة صريحة (+ / -) ومعاها LRM عشان العلامة ما تنقلبش في النص العربي */
    fun signed(d: Int): String = if (d == 0) "0" else "\u200E" + (if (d > 0) "+" else "") + d
}

/** مجموعة وظيفية: العدد المعتمد / الفعلي + تصنيف عجزها (داخل الفترة / خارج الفترة) لكل مجموعة لوحدها. */
data class StructureCensusGroup(
    val key: String, val name: String, val planned: Int, val actual: Int, val within: Int = 0, val outside: Int = 0
) {
    val diff: Int get() = actual - planned
    /** عجز المجموعة (لو الفعلي أقل من المعتمد) */
    val deficit: Int get() = maxOf(0, planned - actual)
    val classified: Int get() = within + outside
}

data class StructureCensusBlock(
    val unitId: String, val unitName: String, val groups: List<StructureCensusGroup>,
    /** مخالف: اتسجّلت مخالفة على بند عجز الهيكل (بسبب العجز خارج الفترة) */
    val violation: Boolean = false
) {
    val statusText: String get() = if (violation) "مخالف" else "غير مخالف"
    val summaryTitle: String get() = if (violation) "سبب المخالفة — العجز خارج الفترة" else "العجز خارج الفترة"
    val totalPlanned: Int get() = groups.sumOf { it.planned }
    val totalActual: Int get() = groups.sumOf { it.actual }
    val totalDiff: Int get() = totalActual - totalPlanned
    /** إجمالي العجز (مجموع عجز المجموعات) */
    val deficit: Int get() = groups.sumOf { it.deficit }
    /** إجمالي الزيادة (المجموعات اللي فعليها أكبر من المعتمد) */
    val surplus: Int get() = groups.sumOf { maxOf(0, it.actual - it.planned) }
    /** الإجماليات بتتجمّع من المجموعات */
    val within: Int get() = groups.sumOf { it.within }
    val outside: Int get() = groups.sumOf { it.outside }
    val classified: Int get() = within + outside
    /** العجز خارج الفترة بس (هو سبب المخالفة)، مثال: "عجز 1 خدمة العملاء والكاشير خارج الفترة" */
    val summaryLines: List<String> get() = groups.filter { it.outside > 0 }.map { "عجز ${it.outside} ${it.name} خارج الفترة" }
}

/** عدد مخالفات نوع معيّن في قسم معيّن (جدول مخالفات الأسعار على مستوى القسم). */
data class PriceSectionCount(val unitId: String, val label: String, val count: Int)

/** نوع مخالفة أسعار + أعداده لكل قسم. */
data class PriceTypeBlock(val type: String, val sections: List<PriceSectionCount>) {
    val subtotal: Int get() = sections.sumOf { it.count }
}

/** ملخص الحصر المجمّع تلقائيًا من المخالفات — بيظهر في آخر ورقة بالتقرير (PDF / Word / Excel). */
data class CensusSummary(
    val price: List<CensusRowOut> = emptyList(),
    val display: List<DisplayToolLine> = emptyList(),
    val maintenance: List<MaintenanceCensusBlock> = emptyList(),
    val structure: List<StructureCensusBlock> = emptyList(),
    val priceByType: List<PriceTypeBlock> = emptyList(),
    val codesValue: Double = 0.0,
    /** جداول مخالفات الأسعار وأدوات العرض: بتظهر بس لو في الزيارة قسم تشغيل (SECTION) ظاهر للمستخدم */
    val showPrice: Boolean = false
) {
    /** في أي حاجة تتعرض في صفحة الحصر المجمّع؟ لو لأ الصفحة كلها بتتشال */
    val hasAnything: Boolean get() = showPrice || structure.isNotEmpty() || maintenance.isNotEmpty()

    /** إجمالي مخالفات الأسعار (كل الأنواع × كل الأقسام). */
    val priceGrandTotal: Int get() = priceByType.sumOf { it.subtotal }

    /**
     * صفوف جدول مخالفات الأسعار جاهزة للطباعة: م | نوع المخالفة (في أول صف من كل نوع بس) | القسم | العدد (فاضي لو صفر).
     * نفس شكل جدول الإكسل: كل نوع مخالفة متفصّل على الأقسام، والإجمالي في الآخر.
     */
    val priceTableRows: List<List<String>> get() {
        var n = 0
        return priceByType.flatMap { t ->
            t.sections.mapIndexed { i, sec ->
                n += 1
                listOf(n.toString(), if (i == 0) t.type else "", sec.label, if (sec.count > 0) sec.count.toString() else "")
            }
        }
    }

    /** إجمالي أعداد مخالفات الأسعار (من غير صف قيمة الأكواد). */
    val priceTotal: Int get() = price.filter { it.money == null }.sumOf { it.count }
    val displayTotalCount: Int get() = display.sumOf { it.count }
    val displayTotalValue: Double get() = display.sumOf { it.total }
}

object CensusSummaryBuilder {
    private const val MAINT_CONTROL = "__maintenance_census__"
    private const val MAINT_PREFIX = "RQ_MAINTENANCE_CENSUS_V1:"
    private val CNS = Regex("^cns_(pricing|missing)_(.+)_(\\d+)$")

    /** الأقسام في جدول مخالفات الأسعار (بنفس تسمية الإكسل) — بتظهر دايمًا حتى لو من غير أعداد. */
    // كل قسم بيجمّع نفس القسم من القوالب التلاتة (أوف لاين / ديجيتال / زايد) — تقرير أي معرض بيملّي الصف بتاعه
    private val PRICE_SECTIONS: List<Pair<List<String>, String>> = listOf(
        listOf("home_tools", "zayed_home_tools") to "الأدوات المنزلية",
        listOf("toys_kids") to "ألعاب الأطفال",
        listOf("furnishings", "digital_furnishings", "zayed_furnishings") to "المفروشات",
        listOf("electrical", "digital_electricity", "zayed_electricity") to "الكهرباء",
        listOf("digital_furniture") to "الأثاث"
    )
    /** أنواع المخالفات وإزاي بتتجمع من بنود الحصر (كل بنود الأسعار متغطية — مفيش حاجة بتضيع من الإجمالي). */
    private val PRICE_TYPES = listOf(
        "عدم وجود شيلف" to listOf("in_no_shelf", "pricing1"),
        "عدم تطابق الشيلفات" to listOf("in_mismatch", "pricing3"),
        "التكويد" to listOf("in_no_code", "pricing10", "pricing11", "pricing12"),
        "التسعير" to listOf("in_no_price", "pricing13", "pricing14", "pricing15"),
        "صاينات (سعر - عرض)" to listOf(
            "in_stand_offer", "in_stand_price", "in_partial_damage",
            "pricing2", "pricing4", "pricing5", "pricing6", "pricing7", "pricing8", "pricing9"
        )
    )

    /** قيمة القطعة لكل نوع أداة عرض (من ورقة نواقص مساطر الأسعار في الإكسل). */
    private val DISPLAY_TOOLS = listOf(
        Triple("display_ruler", "مسطرة", 26.0),
        Triple("display_sadabat", "المداسات (السدابات)", 8.42),
        Triple("display_acrylic", "الاكليرك", 33.25),
        Triple("display_polystyrene", "بولسترين", 5.0),
        Triple("display_half_a6_acrylic", "اكليرك نص A6", 16.45)
    )
    // أرقام ضوابط "حصر أدوات العرض" (كسر + فقد) لكل نوع
    private val MISSING_IDX = mapOf(
        "display_ruler" to listOf(1, 2), "display_acrylic" to listOf(3, 4), "display_half_a6_acrylic" to listOf(5, 6),
        "display_sadabat" to listOf(7, 8), "display_polystyrene" to listOf(9, 10)
    )

    fun build(findings: List<FindingEntity>, naUnits: Set<String>, units: List<EvaluationUnitEntity>): CensusSummary {
        // الظهور حسب الجهة: الحصر بيتحسب من الوحدات الظاهرة للمستخدم بس (مشاهد الإدارة = وحداته، أدوار الإدارة = كل الوحدات)
        val visibleIds = units.map { it.id }.toSet()
        val active = findings.filter { it.unitId !in naUnits && it.unitId in visibleIds }
        val hasOps = units.any { it.kind == "SECTION" }                                  // إدارة التشغيل
        val showStructure = hasOps || units.any { it.id in StructureCensus.UNITS }       // التشغيل + الموارد البشرية
        val counts = HashMap<String, Int>()
        val perUnit = HashMap<String, HashMap<String, Int>>()   // نفس الأعداد لكن لكل قسم لوحده
        var codeValue = 0.0
        fun inc(u: String, k: String, c: Int) {
            if (c <= 0) return
            counts[k] = (counts[k] ?: 0) + c
            val m = perUnit.getOrPut(u) { HashMap() }
            m[k] = (m[k] ?: 0) + c
        }

        active.filter { it.controlId != MAINT_CONTROL && it.violationCount > 0 }.forEach { f ->
            // 1) حقول الحصر الملحقة بالمخالفة نفسها
            InlineCensusData.parse(f.note).forEach { (k, v) ->
                inc(f.unitId, "in_$k", v.count)
                if (k == "no_code") codeValue += v.value
            }
            // 2) ضوابط الحصر (الأعداد لكل مجموعة منتجات)
            val m = CNS.matchEntire(f.controlId)
            if (m != null) {
                val kind = m.groupValues[1]
                val n = m.groupValues[3].toIntOrNull() ?: return@forEach
                inc(f.unitId, "$kind$n", f.violationCount)
                if (kind == "pricing" && n in 10..12) {
                    val price = f.note?.takeIf { it.startsWith("PRICE:") }?.removePrefix("PRICE:")?.toDoubleOrNull() ?: 0.0
                    codeValue += f.violationCount * price
                }
            }
        }
        fun g(vararg k: String) = k.sumOf { counts[it] ?: 0 }

        val price = buildList {
            add(CensusRowOut("شيلفات", "بدون شيلف", g("in_no_shelf", "pricing1")))
            add(CensusRowOut("شيلفات", "عدم تطابق", g("in_mismatch", "pricing3")))
            add(CensusRowOut("صاينات", "صاين عرض", g("in_stand_offer", "pricing5", "pricing6", "in_partial_damage", "pricing7")))
            add(CensusRowOut("صاينات", "صاين سعر", g("in_stand_price")))
            add(CensusRowOut("أكواد", "عدد", g("in_no_code", "pricing10", "pricing11", "pricing12")))
            add(CensusRowOut("أكواد", "قيمة", 0, codeValue))
            add(CensusRowOut("سعر", "عدد الأسعار", g("in_no_price", "pricing13", "pricing14", "pricing15")))
            // بنود إضافية بتظهر بس لو فيها أعداد
            listOf(
                Triple("شيلفات", "شيلف تالف", g("pricing2")),
                Triple("صاينات", "بدون صاين", g("pricing4")),
                Triple("صاينات", "بدون توكر", g("pricing8")),
                Triple("صاينات", "صاين / توكر تالف", g("pricing9"))
            ).filter { it.third > 0 }.forEach { add(CensusRowOut(it.first, it.second, it.third)) }
        }

        val display = DISPLAY_TOOLS.map { (key, label, piece) ->
            val missing = (MISSING_IDX[key] ?: emptyList()).sumOf { g("missing$it") }
            DisplayToolLine(label, g("in_$key") + missing, piece)
        }

        val order = units.withIndex().associate { it.value.id to it.index }
        // جدول مخالفات الأسعار على مستوى القسم (+ أي قسم تاني عنده أعداد غير الأقسام الخمسة)
        val priceSections = PRICE_SECTIONS + perUnit.keys.filter { u -> PRICE_SECTIONS.none { u in it.first } }
            .sortedBy { order[it] ?: 999 }.map { u -> listOf(u) to (units.firstOrNull { it.id == u }?.name ?: u) }
        val priceByType = PRICE_TYPES.map { (type, keys) ->
            PriceTypeBlock(type, priceSections.map { (ids, label) ->
                PriceSectionCount(ids.first(), label, keys.sumOf { k -> ids.sumOf { u -> perUnit[u]?.get(k) ?: 0 } })
            })
        }

        // حصر الصيانة / التكييفات: لإدارته (لو ظاهرة) + إدارة التشغيل (بتشوف الحصر كله) + أدوار الإدارة (كل الوحدات ظاهرة)
        val maintenance = (if (hasOps) findings.filter { it.unitId !in naUnits } else active)
            .filter { it.controlId == MAINT_CONTROL && it.note?.startsWith(MAINT_PREFIX) == true }
            .mapNotNull { f ->
                val rows = parseMaintenance(f.note!!.removePrefix(MAINT_PREFIX))
                if (rows.isEmpty()) return@mapNotNull null
                val u = units.firstOrNull { it.id == f.unitId }
                val isAc = f.unitId.contains("air") || f.unitId.startsWith("ac") || (u?.name ?: "").contains("تكييف")
                // لو الوحدة مش ظاهرة للمستخدم (مشاهد التشغيل) الاسم من الـ id
                val name = u?.name ?: ("قسم " + (if (isAc) "التكييفات" else "الصيانة") + (if (f.unitId.startsWith("zayed")) " — زايد" else ""))
                MaintenanceCensusBlock(f.unitId, name, isAc, rows)
            }.sortedBy { order[it.unitId] ?: 999 }

        // حصر الهيكل: للموارد البشرية وإدارة التشغيل (ومعاهم أدوار الإدارة اللي بتشوف كل الوحدات)
        val structure = (if (showStructure) findings.filter { it.unitId !in naUnits && it.controlId == StructureCensus.CONTROL_ID && it.note?.startsWith(StructureCensus.PREFIX) == true } else emptyList())
            .mapNotNull { f ->
                val b = parseStructure(f.unitId, units.firstOrNull { it.id == f.unitId }?.name ?: StructureCensus.UNIT_NAMES[f.unitId] ?: f.unitId, f.note!!.removePrefix(StructureCensus.PREFIX))
                // الحالة من بند المخالفة نفسه (مخالف لو عدّاده أكبر من صفر) — مفيش حالة تانية تتخزن وتتعارض
                val violated = findings.any { it.unitId == f.unitId && it.controlId == StructureCensus.violationControlId(f.unitId) && it.violationCount > 0 }
                if (b != null && (b.totalPlanned > 0 || b.totalActual > 0 || b.classified > 0 || violated)) b.copy(violation = violated) else null
            }.sortedBy { order[it.unitId] ?: 999 }

        return CensusSummary(price, display, maintenance, structure, priceByType, codeValue, hasOps)
    }

    private fun parseStructure(unitId: String, unitName: String, json: String): StructureCensusBlock? = try {
        val o = org.json.JSONObject(json)
        val arr = o.optJSONArray("groups")
        val byKey = HashMap<String, org.json.JSONObject>()
        if (arr != null) for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { byKey[it.optString("key")] = it }
        val groups = StructureCensus.GROUPS.map { (key, name) ->
            val g = byKey[key]
            StructureCensusGroup(
                key, name, (g?.optInt("planned", 0) ?: 0).coerceAtLeast(0), (g?.optInt("actual", 0) ?: 0).coerceAtLeast(0),
                (g?.optInt("within", 0) ?: 0).coerceAtLeast(0), (g?.optInt("outside", 0) ?: 0).coerceAtLeast(0)
            )
        }
        StructureCensusBlock(unitId, unitName, groups)
    } catch (_: Exception) { null }

    private fun parseMaintenance(json: String): List<MaintenanceCensusItem> = try {
        val a = org.json.JSONArray(json)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            MaintenanceCensusItem(
                o.optString("item"), o.optString("inspectionState", "غير مخالف"), o.optString("problem"),
                o.optString("faultDate"), o.optString("ticket"), o.optString("escalation", "لم يتم التصعيد"), o.optString("status", "معلق"),
                o.optInt("count", 0).coerceAtLeast(0)
            )
        }
    } catch (_: Exception) { emptyList() }
}
