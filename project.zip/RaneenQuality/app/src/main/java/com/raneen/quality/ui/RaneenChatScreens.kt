package com.raneen.quality.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.raneen.quality.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────── أدوات الوقت ─────────────
private fun hm(ms: Long) = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))
private fun ymd(ms: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))
private fun dayKey(ms: Long) = ymd(ms)

/** اليوم → الساعة، إمبارح → "أمس"، غير كده → التاريخ (زي واتساب) */
private fun listTime(ms: Long): String {
    val now = System.currentTimeMillis()
    return when (dayKey(ms)) {
        dayKey(now) -> hm(ms)
        dayKey(now - 86_400_000L) -> "أمس"
        else -> ymd(ms)
    }
}

private fun dayLabel(ms: Long): String {
    val now = System.currentTimeMillis()
    return when (dayKey(ms)) {
        dayKey(now) -> "اليوم"
        dayKey(now - 86_400_000L) -> "أمس"
        else -> ymd(ms)
    }
}

/** دايرة بالحرف الأول من الاسم */
@Composable
private fun Avatar(name: String?, size: Int = 46) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Text(
            (name?.trim()?.firstOrNull() ?: '؟').toString(),
            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium
        )
    }
}

/** زر "الرسائل" في الشريط العلوي، عليه شارة بعدد غير المقروء */
@Composable
fun ChatAction(unread: Int, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        BadgedBox(badge = { if (unread > 0) Badge { Text(if (unread > 99) "99+" else unread.toString()) } }) { Text("الرسائل") }
    }
}

// ───────────── ٣) شاشة المحادثة ─────────────
private sealed interface ChatItem {
    data class Day(val label: String, val key: String) : ChatItem
    data class Msg(val m: ChatMessageEntity) : ChatItem
}

private fun withDayHeaders(list: List<ChatMessageEntity>): List<ChatItem> {
    val out = ArrayList<ChatItem>()
    var last = ""
    for (m in list) {
        val k = dayKey(m.createdAt)
        if (k != last) { out += ChatItem.Day(dayLabel(m.createdAt), k); last = k }
        out += ChatItem.Msg(m)
    }
    return out
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(user: UserEntity, chat: ChatRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs by remember { chat.teamMessages() }.collectAsState(initial = emptyList())
    val users by remember { chat.users() }.collectAsState(initial = emptyList())
    val byId = remember(users) { users.associateBy { it.id } }
    val reads by chat.teamReads.collectAsState()
    val chatItems = remember(msgs) { withDayHeaders(msgs) }
    val listState = rememberLazyListState()

    // استقبال فوري تقريبًا: مزامنة كل ٣ ثواني طول ما المحادثة مفتوحة
    LaunchedEffect(user.id) { while (isActive) { chat.refresh(user.id); delay(3_000) } }

    var draft by rememberSaveable { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }          // بيتعرض أثناء ختم الصورة/الفيديو
    var pendingRaw by rememberSaveable { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<String?>(null) }   // صورة مفتوحة بحجم كبير

    // كل ما تيجي رسالة جديدة: انزل لآخر المحادثة + علّم اللي وصلني كمقروء
    LaunchedEffect(msgs.size) {
        if (chatItems.isNotEmpty()) listState.animateScrollToItem(chatItems.lastIndex)
        chat.markRead(user.id)
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val path = pendingRaw; pendingRaw = null
        if (path != null) {
            if (ok) {
                sending = true
                scope.launch {
                    val done = chat.sendPhoto(user, File(path))
                    sending = false
                    if (!done) Toast.makeText(context, "تعذّر إرسال الصورة", Toast.LENGTH_LONG).show()
                }
            } else File(path).delete()
        }
    }
    fun launchCamera() {
        try {
            val dir = File(context.cacheDir, "cap").apply { mkdirs() }
            val raw = File(dir, "chat_${System.currentTimeMillis()}.jpg")
            pendingRaw = raw.path
            takePicture.launch(FileProvider.getUriForFile(context, "${context.packageName}.files", raw))
        } catch (e: Exception) {
            pendingRaw = null
            Toast.makeText(context, "تعذّر فتح الكاميرا", Toast.LENGTH_LONG).show()
        }
    }
    var afterPerm by remember { mutableStateOf<(() -> Unit)?>(null) }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) afterPerm?.invoke() else Toast.makeText(context, "لازم إذن الكاميرا", Toast.LENGTH_LONG).show()
        afterPerm = null
    }
    fun withCamera(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) action()
        else { afterPerm = action; camPerm.launch(Manifest.permission.CAMERA) }
    }

    Scaffold(
        containerColor = Color(0xFFF5F5F5),   // خلفية المحادثة (فاتحة ناعمة)
        topBar = {
            RaneenTopBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(38.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) { Text("👥") }
                        Column {
                            Text("مجموعة العمل", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${users.count { it.isActive }} عضو · كل التعليمات والتواصل هنا", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
                        }
                    }
                },
                actions = {
                    TextButton(onClick = onBack) { Text("رجوع") }
                }
            )
        },
        bottomBar = {
            // شريط الكتابة: كاميرا + فيديو + حقل نص مدوّر + زر إرسال
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 6.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TextButton(onClick = { withCamera { launchCamera() } }, enabled = !sending, contentPadding = PaddingValues(8.dp), modifier = Modifier.defaultMinSize(minWidth = 44.dp)) { Text("📷", style = MaterialTheme.typography.titleLarge) }
                    TextButton(onClick = { withCamera { recording = true } }, enabled = !sending, contentPadding = PaddingValues(8.dp), modifier = Modifier.defaultMinSize(minWidth = 44.dp)) { Text("🎥", style = MaterialTheme.typography.titleLarge) }
                    OutlinedTextField(
                        value = draft, onValueChange = { draft = it }, placeholder = { Text("اكتب رسالة") },
                        maxLines = 4, shape = RoundedCornerShape(24.dp), modifier = Modifier.weight(1f)
                    )
                    FilledIconButton(
                        onClick = { val t = draft; draft = ""; scope.launch { chat.sendText(user.id, t) } },
                        enabled = draft.isNotBlank(), modifier = Modifier.size(48.dp)
                    ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال") }
                }
            }
        }
    ) { padding ->
      Column(Modifier.padding(padding).fillMaxSize()) {
        LazyColumn(
            state = listState, modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(chatItems, key = { if (it is ChatItem.Msg) it.m.id else (it as ChatItem.Day).key }) { item ->
                when (item) {
                    is ChatItem.Day -> Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                        Text(
                            item.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.9f)).padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                    is ChatItem.Msg -> Bubble(
                        item.m, mine = item.m.senderId == user.id, sender = byId[item.m.senderId],
                        seen = reads.count { (uid, t) -> uid != user.id && t >= item.m.createdAt },
                        onMedia = { m ->
                        val p = m.mediaPath
                        if (p != null) { if (m.type == ChatType.VIDEO) playVideo(context, p) else viewer = p }
                    })
                }
            }
        }
      }
    }

    // أثناء ختم الصورة/الفيديو بالبيانات
    if (sending) AlertDialog(
        onDismissRequest = {}, confirmButton = {},
        title = { Text("جاري تجهيز المرفق…") },
        text = { Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp)); Text("بيتم إضافة التاريخ والوقت") } }
    )

    if (recording) VideoRecorderDialog(
        onFinished = { path, snaps, customText ->
            recording = false
            snaps.forEach { File(it).delete() }       // الصور الجانبية بتاعة المخالفات مش مستخدمة في الشات
            sending = true
            scope.launch {
                val r = chat.sendVideo(user, File(path), customText)
                sending = false
                if (r == 0) Toast.makeText(context, "الفيديو ماتحفظش", Toast.LENGTH_LONG).show()
                if (r == 2) Toast.makeText(context, "الفيديو اتبعت من غير شريط التاريخ", Toast.LENGTH_LONG).show()
                if (r == 3) Toast.makeText(context, "الفيديو كبير (أكتر من 25 ميجا). صوّر مدة أقصر", Toast.LENGTH_LONG).show()
            }
        },
        onCancel = { recording = false }
    )

    viewer?.let { path -> ChatImageDialog(path) { viewer = null } }
}

// ───────────── الفقاعة ─────────────
@Composable
private fun Bubble(m: ChatMessageEntity, mine: Boolean, sender: UserEntity?, seen: Int, onMedia: (ChatMessageEntity) -> Unit) {
    // التطبيق RTL: Start = اليمين. رسايلي يمين، رسايل الزمايل شمال. الذيل الصغير عند الركن السفلي الخارجي.
    val shape = if (mine) RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 4.dp)
    else RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomEnd = 4.dp, bottomStart = 16.dp)
    // رسايل الإدارة والمديرين (تعليمات العمل) بتتميّز بلون دافي
    val fromManagement = sender != null && sender.role != Roles.INSPECTOR
    val bg = when { mine -> MaterialTheme.colorScheme.primaryContainer; fromManagement -> Color(0xFFFFF3E0); else -> Color.White }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
        Column(
            Modifier.widthIn(max = 290.dp).clip(shape).background(bg).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            if (!mine) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(sender?.name ?: "مستخدم", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                sender?.let { Text(Roles.label(it.role), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            when (m.type) {
                ChatType.TEXT -> Text(m.text.orEmpty(), color = MaterialTheme.colorScheme.onSurface)
                else -> m.mediaPath?.let { ChatMedia(it, m.type == ChatType.VIDEO) { onMedia(m) } }
                    ?: Text("📎 المرفق غير متاح (انتهت مدته)", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(hm(m.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (mine) Text(
                    // 🕓 لسه محلية (مفيش مزامنة) · ✓ اتبعتت · 👁 N = عدد الزمايل اللي شافوها
                    when { seen > 0 -> "👁 $seen"; m.status == ChatStatus.SENT -> "✓"; else -> "🕓" },
                    style = MaterialTheme.typography.labelSmall, color = if (seen > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun decodeChatImage(path: String, sample: Int): ImageBitmap? =
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()

private fun chatVideoFrame(path: String): ImageBitmap? = try {
    val r = MediaMetadataRetriever(); r.setDataSource(path)
    val f = r.getFrameAtTime(0); r.release()
    f?.let { Bitmap.createScaledBitmap(it, 320, maxOf(1, (320f * it.height / it.width).toInt()), true).asImageBitmap() }
} catch (e: Exception) { null }

@Composable
private fun ChatMedia(path: String, video: Boolean, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { if (video) chatVideoFrame(path) else decodeChatImage(path, 2) }
    }
    Box(Modifier.width(230.dp).heightIn(min = 120.dp, max = 300.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE0E0E0)).clickable(onClick = onClick)) {
        bmp?.let { Image(it, null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth) }
        if (video) Text("▶", color = Color.White, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
private fun ChatImageDialog(path: String, onClose: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) { value = withContext(Dispatchers.IO) { decodeChatImage(path, 1) } }
    AlertDialog(
        onDismissRequest = onClose,
        text = { bmp?.let { Image(it, null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth) } ?: CircularProgressIndicator() },
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } }
    )
}
