package com.raneen.quality.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaSaver {
    /** نسخة في معرض الموبايل (Pictures/Raneen أو Movies/Raneen). الأصل الموثّق بيفضل جوه التطبيق. */
    fun saveToGallery(ctx: Context, file: File, video: Boolean): Boolean {
        return try {
            val name = "Raneen_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + if (video) ".mp4" else ".jpg"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/Raneen" else "Pictures/Raneen")
                }
                val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val uri = ctx.contentResolver.insert(collection, cv) ?: return false
                ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: return false
                true
            } else {
                val type = if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                val dir = File(ctx.getExternalFilesDir(type), "Raneen").apply { mkdirs() }
                file.copyTo(File(dir, name), overwrite = true)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
