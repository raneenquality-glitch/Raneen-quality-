package com.raneen.quality.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.*
import com.raneen.quality.domain.UnitScore
import android.widget.Toast
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ───────────── كارت تقرير في القوائم ─────────────
@Composable
fun ReportRowCard(row: ReportRow, showInspector: Boolean, onClick: () -> Unit) {
    val accent = statusColor(row.status)
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        // شريط ملوّن على الجنب بلون حالة التقرير (نظرة سريعة من غير قراءة)
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(accent))
            Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(row.branchName.ifBlank { "فرع محذوف" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    StatusChip(row.status)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📅 ${fmtDate(row.visitDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    visitLabel(row.visitNumber)?.let {
                        Text(
                            it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                if (showInspector) Text("المراقب: ${row.inspectorName}", style = MaterialTheme.typography.bodySmall)
                Text(row.reportNumber, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}

// ───────────── الرئيسية للمراقب: زيارة جديدة + زياراتي ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InspectorHome(
    user: UserEntity, reports: ReportRepository, sync: SyncRepository,
    onNew: () -> Unit, onOpen: (ReportRow) -> Unit, onLogout: () -> Unit,
    unread: Int = 0, onChat: (() -> Unit)? = null
) {
    val rows by remember { reports.rows() }.collectAsState(initial = emptyList())
    val mine = rows.filter { it.inspectorId == user.id }
    var filter by rememberSaveable { mutableStateOf("ALL") }
    val needEdit = mine.filter { Status.editable(it.status) }
    val inReview = mine.filter { it.status == Status.SUBMITTED || it.status == Status.REVIEWED }
    val approved = mine.filter { it.status == Status.FINAL }
    val shown = when (filter) { "EDIT" -> needEdit; "REVIEW" -> inReview; "DONE" -> approved; else -> mine }
    val syncStatus by sync.status.collectAsState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            RaneenTopBar(title = { Text("رنين", fontWeight = FontWeight.ExtraBold) }, actions = {
                onChat?.let { ChatAction(unread, it) }
                TextButton(onClick = onLogout) { Text("خروج") }
            })
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // بطاقة الترحيب + حالة المزامنة
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(Color.White).border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                        .padding(18.dp)
                ) {
                    Text("أهلاً، ${user.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(Roles.label(user.role), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(syncStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        TextButton(onClick = { sync.kick() }) { Text("مزامنة الآن", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            // أرقام سريعة
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("زياراتي", mine.size, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatTile("قيد المراجعة", inReview.size, Color(0xFFEF6C00), Modifier.weight(1f))
                    StatTile("معتمدة", approved.size, Color(0xFF1D7A4D), Modifier.weight(1f))
                }
            }
            item {
                Button(
                    onClick = onNew, modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("＋  زيارة تفتيش جديدة", style = MaterialTheme.typography.titleMedium) }
            }
            // فلتر الزيارات
            item {
                Text("زياراتي", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val opts = listOf(
                        Triple("ALL", "الكل", mine.size), Triple("EDIT", "تحتاج استكمال", needEdit.size),
                        Triple("REVIEW", "قيد المراجعة", inReview.size), Triple("DONE", "معتمدة", approved.size)
                    )
                    items(opts, key = { it.first }) { (k, label, n) ->
                        FilterChip(selected = filter == k, onClick = { filter = k }, label = { Text("$label ($n)") }, shape = RoundedCornerShape(12.dp))
                    }
                }
            }
            if (shown.isEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (mine.isEmpty()) "لسه معندكش زيارات.\nاضغط «زيارة تفتيش جديدة» عشان تبدأ." else "مفيش زيارات في الفلتر ده.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
            items(shown, key = { it.id }) { ReportRowCard(it, false) { onOpen(it) } }
        }
    }
}

@Composable
private fun StatTile(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color.White)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)).padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ───────────── اختيار الفرع لبدء زيارة ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchPickerScreen(repo: InspectionRepository, inspectorId: String, onBack: () -> Unit, onStarted: (String) -> Unit) {
    val branches by remember(repo) { repo.branches() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var starting by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<BranchEntity?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedTemplateId by rememberSaveable { mutableStateOf("offline") }
    val shownBranches = remember(branches, query, selectedTemplateId) {
        branches.filterByQuery(query).filter { b ->
            selectedTemplateId != "smart" || b.name.contains("زايد", ignoreCase = true) || b.name.contains("zayed", ignoreCase = true)
        }.sortedByBranchNumber()
    }
    fun start(b: BranchEntity, visit: String) {
        starting = true
        pending = null
        scope.launch {
            val number = "RQ-2026-" + (System.currentTimeMillis() % 1_000_000).toString().padStart(6, '0')
            onStarted(repo.startInspection(b.id, inspectorId, number, visit, selectedTemplateId))
        }
    }
    Scaffold(topBar = {
        RaneenTopBar(title = { Text("اختر الفرع") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("اختار نوع التقييم أولًا", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("smart" to "تقييم سمارت", "digital" to "تقييم ديجتال", "offline" to "تقييم أوف لاين").forEach { (id, label) ->
                        FilterChip(
                            selected = selectedTemplateId == id,
                            onClick = { selectedTemplateId = id },
                            label = { Text(label) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    Text(
                        when (selectedTemplateId) {
                            "smart" -> "قالب فرع زايد فقط، مستقل عن باقي الفروع."
                            "digital" -> "أقسام الديجتال + الأقسام العادية عدا المفروشات والكهرباء + الإدارات المساعدة العادية."
                            else -> "جميع الأقسام العادية الحالية بالكامل."
                        }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item { Text("اختر الفرع لبدء زيارة تفتيش", style = MaterialTheme.typography.titleMedium) }
            // بحث بالاسم أو رقم الفرع (الفروع مرتبة برقم الفرع)
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("ابحث بالاسم أو رقم الفرع") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("مسح") } }
                )
            }
            if (branches.isEmpty()) item { Text("مفيش فروع. الأدمن لازم يضيف فروع الأول.", color = MaterialTheme.colorScheme.error) }
            else if (shownBranches.isEmpty()) item { Text("مفيش فرع مطابق للبحث.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            else item { Text("${shownBranches.size} فرع", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(shownBranches, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().border(1.dp, Color(0xFFE3E3E3), RoundedCornerShape(16.dp)).clickable(enabled = !starting) { pending = b }, colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(b.name, style = MaterialTheme.typography.titleMedium)
                        Text("رقم ${b.code}" + if (b.region.isNotBlank()) " · ${b.region}" else "", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    pending?.let { b ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("رقم الزيارة — ${b.name}") },
            text = { Text("الفرع بيتزار مرتين في الشهر. اختار رقم الزيارة دي:") },
            confirmButton = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { start(b, "1") }, modifier = Modifier.fillMaxWidth()) { Text("الزيارة الأولى") }
                    Button(onClick = { start(b, "2") }, modifier = Modifier.fillMaxWidth()) { Text("الزيارة الثانية") }
                }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("إلغاء") } }
        )
    }
}

// ───────────── أقسام الزيارة (درجات لحظية + N/A + مراجعة) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitsScreen(
    user: UserEntity, repo: InspectionRepository, reports: ReportRepository, inspectionId: String,
    onOpen: (String, String) -> Unit, onReview: () -> Unit, onDeleted: () -> Unit
) {
    val units by remember(repo) { repo.units() }.collectAsState(initial = emptyList())
    val insp by remember(inspectionId) { repo.inspectionFlow(inspectionId) }.collectAsState(initial = null)
    val states by remember(inspectionId) { repo.unitStates(inspectionId) }.collectAsState(initial = emptyList())
    val findings by remember(inspectionId) { repo.allFindings(inspectionId) }.collectAsState(initial = emptyList())
    val audit by remember(inspectionId) { reports.audit(inspectionId) }.collectAsState(initial = emptyList())
    val scores by produceState<Map<String, UnitScore>>(emptyMap(), findings) { value = repo.unitScores(inspectionId) }
    val scope = rememberCoroutineScope()
    var confirmDelete by remember { mutableStateOf(false) }

    val editable = insp?.let { Status.editableBy(user.role, it.status) } ?: false
    val currentTemplateId = insp?.templateId ?: "main"
    val visibleUnits = units.filter { belongsToEvaluationTemplate(it, currentTemplateId) }
    val naIds = states.filter { it.isNA }.map { it.unitId }.toSet()
    val returnNote = if (insp?.status == Status.RETURNED) audit.lastOrNull { it.action == "RETURNED" }?.note else null

    Scaffold(
        topBar = {
            RaneenTopBar(title = { Text(evaluationTemplateLabel(currentTemplateId)) }, actions = {
                if (insp?.status == Status.DRAFT) TextButton(onClick = { confirmDelete = true }) {
                    Text("حذف الزيارة")
                }
            })
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = onReview, shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(12.dp).heightIn(min = 54.dp)
                ) { Text(if (editable && user.role == Roles.INSPECTOR) "مراجعة وإرسال التقرير" else if (editable) "عرض التقرير والاعتماد" else "عرض التقرير", style = MaterialTheme.typography.titleMedium) }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (returnNote != null) item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("التقرير اترجّع للتعديل", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                        Text(returnNote)
                    }
                }
            }
            // ملخص لحظي: متوسط الأقسام والإدارات المساعدة وعدد المخالفات
            item {
                val live = visibleUnits.filter { it.id !in naIds }
                fun avg(kind: String): Double? =
                    live.filter { it.kind == kind }.mapNotNull { scores[it.id]?.percent }.let { if (it.isEmpty()) null else it.average() }
                val violated = findings.count { it.violationCount > 0 && it.unitId !in naIds }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(Color.White).border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(20.dp)).padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SummaryCell("متوسط الأقسام", fmtPct(avg("SECTION")), Modifier.weight(1f))
                    SummaryCell("متوسط الإدارات", fmtPct(avg("ADMINISTRATION")), Modifier.weight(1f))
                    SummaryCell("المخالفات", violated.toString(), Modifier.weight(1f))
                }
            }
            item { Text("الأقسام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(visibleUnits.filter { it.kind == "SECTION" }.chunked(2), key = { row -> "s_" + row.first().id }) { row ->
                UnitRowTiles(row, scores, findings, naIds, editable, onOpen) { id, na -> scope.launch { repo.setNA(inspectionId, id, na); reports.markManagerEdit(inspectionId, user) } }
            }
            item { Spacer(Modifier.height(4.dp)); Text("الإدارات المساعدة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(visibleUnits.filter { it.kind == "ADMINISTRATION" }.chunked(2), key = { row -> "a_" + row.first().id }) { row ->
                UnitRowTiles(row, scores, findings, naIds, editable, onOpen) { id, na -> scope.launch { repo.setNA(inspectionId, id, na); reports.markManagerEdit(inspectionId, user) } }
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("حذف الزيارة؟") },
        text = { Text("هتتمسح الزيارة وكل مخالفاتها وصورها من الجهاز. مينفعش تتراجع.") },
        confirmButton = {
            TextButton(onClick = {
                scope.launch { if (reports.deleteDraft(inspectionId, user) == null) onDeleted() }
                confirmDelete = false
            }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
    )
}

@Composable
private fun SummaryCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** صف من مربعين (قسمين جنب بعض) */
@Composable
private fun UnitRowTiles(
    row: List<EvaluationUnitEntity>, scores: Map<String, UnitScore>, findings: List<FindingEntity>,
    naIds: Set<String>, editable: Boolean, onOpen: (String, String) -> Unit, onNA: (String, Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        row.forEach { u ->
            UnitTile(
                unit = u, score = scores[u.id], violations = findings.count { it.unitId == u.id && it.violationCount > 0 },
                isNA = u.id in naIds, editable = editable, modifier = Modifier.weight(1f).heightIn(min = 150.dp),
                onOpen = { onOpen(u.id, u.name) }, onNA = { onNA(u.id, it) }
            )
        }
        if (row.size == 1) Spacer(Modifier.weight(1f))
    }
}

/** مربع قسم: الاسم + الدرجة + شريط + عدد المخالفات. أحمر خفيف لو فيه مخالفات، رمادي لو "غير موجود بالفرع" */
@Composable
private fun UnitTile(
    unit: EvaluationUnitEntity, score: UnitScore?, violations: Int, isNA: Boolean, editable: Boolean,
    modifier: Modifier = Modifier, onOpen: () -> Unit, onNA: (Boolean) -> Unit
) {
    val red = MaterialTheme.colorScheme.error
    val bg = when { isNA -> Color(0xFFF0F0F0); violations > 0 -> Color(0xFFFFF3F3); else -> Color.White }
    val accent = if (violations > 0) red else MaterialTheme.colorScheme.primary
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(bg)
            .border(1.dp, if (violations > 0 && !isNA) Color(0xFFF2C4C4) else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            .clickable(enabled = !isNA, onClick = onOpen).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                unit.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 2,
                color = if (isNA) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(8.dp))
            if (isNA) Text("غير موجود بالفرع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            else if (score != null) {
                Text(fmtPct(score.percent), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = accent)
                Text("${fmtScore(score.actual)} / ${fmtScore(score.planned)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (score.percent / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                    color = accent, trackColor = if (violations > 0) Color(0xFFF2C4C4) else MaterialTheme.colorScheme.primaryContainer
                )
                if (violations > 0) Text("⚠ $violations بند مخالف", style = MaterialTheme.typography.labelMedium, color = red, modifier = Modifier.padding(top = 4.dp))
            }
        }
        if (editable) TextButton(onClick = { onNA(!isNA) }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) {
            Text(if (isNA) "↩ إرجاع القسم" else "غير موجود بالفرع؟", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ───────────── تفاصيل التقرير (مراجعة قبل الإرسال + اعتماد المديرين + تصدير) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportDetailScreen(
    user: UserEntity, reports: ReportRepository, inspectionId: String,
    onBack: () -> Unit, onEdit: () -> Unit, onChanged: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val insp by remember(inspectionId) { reports.inspectionFlow(inspectionId) }.collectAsState(initial = null)
    val audit by remember(inspectionId) { reports.audit(inspectionId) }.collectAsState(initial = emptyList())
    var refresh by remember { mutableStateOf(0) }
    val data by produceState<ReportData?>(null, insp?.status, insp?.notes, refresh) { value = reports.build(inspectionId) }

    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmSubmit by remember { mutableStateOf(false) }
    var confirmDeletePhotos by remember { mutableStateOf(false) }
    var returning by remember { mutableStateOf(false) }
    var reason by remember { mutableStateOf("") }
    // مفتاح ثابت حتى لا يعاد ضبط النص مع كل تحديث من قاعدة البيانات أثناء الكتابة.
    var generalNotes by rememberSaveable(inspectionId) { mutableStateOf(insp?.notes.orEmpty()) }
    var preview by remember { mutableStateOf<PhotoEntity?>(null) }

    fun act(block: suspend () -> String?) {
        scope.launch {
            busy = true
            error = block()
            busy = false
            if (error == null) onChanged()
        }
    }

    fun approveFinal() {
        scope.launch {
            busy = true
            val (e, note) = reports.finalApprove(inspectionId, user)
            busy = false
            error = e
            info = note
            if (e == null) onChanged()
        }
    }

    fun export(kind: String) {
        val d = data ?: return
        scope.launch {
            try {
                val (file, mime) = withContext(Dispatchers.IO) {
                    when (kind) {
                        "pdf" -> ReportExporter.pdf(context, d) to ReportExporter.MIME_PDF
                        "docx" -> ReportExporter.docx(context, d) to ReportExporter.MIME_DOCX
                        "zip" -> ReportExporter.photosZip(context, d)?.let { it to "application/zip" }
                            ?: throw IllegalStateException("no photos")
                        else -> ReportExporter.xlsx(context, d) to ReportExporter.MIME_XLSX
                    }
                }
                ReportExporter.share(context, file, mime)
            } catch (e: IllegalStateException) {
                error = "مفيش صور محفوظة على الجهاز للتقرير ده"
            } catch (e: Exception) {
                error = "تعذّر إنشاء الملف"
            }
        }
    }

    val i = insp
    val canSubmit = user.role == Roles.INSPECTOR && i != null && i.inspectorId == user.id && Status.editable(i.status)
    LaunchedEffect(inspectionId, generalNotes, canSubmit) {
        if (!canSubmit) return@LaunchedEffect
        delay(700)
        reports.saveGeneralVisitNotes(inspectionId, user, generalNotes)
    }
    val canArea = user.role == Roles.AREA_MANAGER && i?.status == Status.SUBMITTED
    val canDept = user.role == Roles.DEPT_MANAGER && i?.status == Status.REVIEWED

    Scaffold(topBar = {
        RaneenTopBar(title = { Text("تقرير الزيارة") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } })
    }) { padding ->
        val d = data
        if (d == null || i == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // ملاحظات الزيارة العامة — إلزامية للمراقب قبل الإرسال
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ملاحظات الزيارة العامة *", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (canSubmit) {
                            OutlinedTextField(
                                value = generalNotes,
                                onValueChange = { generalNotes = it },
                                modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 10, singleLine = false,
                                // زرار الإدخال في الكيبورد = سطر جديد (مش "تم")
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                    capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences,
                                    imeAction = androidx.compose.ui.text.input.ImeAction.Default
                                ),
                                label = { Text("اكتب الملاحظات العامة للزيارة") },
                                placeholder = { Text("الملاحظات مطلوبة قبل إرسال التقرير") },
                                isError = generalNotes.isBlank()
                            )
                            if (generalNotes.isBlank()) Text("يجب كتابة الملاحظات العامة قبل إرسال التقرير إلى مدير المنطقة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text(insp?.notes?.takeIf { it.isNotBlank() } ?: "لا توجد ملاحظات عامة مسجلة.")
                        }
                    }
                }
            }
            // الترويسة
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(d.branchName.ifBlank { "فرع محذوف" }, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                            StatusChip(i.status)
                        }
                        Text("نوع التقييم: ${evaluationTemplateLabel(i.templateId)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("رقم التقرير: ${i.reportNumber}")
                        visitLabel(i.visitNumber)?.let { Text(it, fontWeight = FontWeight.Bold) }
                        Text("تاريخ الزيارة: ${fmtDate(i.visitDate)}")
                        Text("المراقب: ${d.inspectorName}")
                        Text(Status.label(i.status), color = statusColor(i.status), fontWeight = FontWeight.Bold)
                        Text(
                            when (i.syncState) {
                                "SYNCED" -> "تمت المزامنة مع السيرفر."
                                "PENDING" -> "في انتظار الرفع للسيرفر — هيترفع لوحده أول ما يبقى فيه إنترنت."
                                else -> "محفوظ على الجهاز."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // المتوسطات
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(fmtPct(d.sectionsAvg), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("متوسط الأقسام", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(fmtPct(d.adminsAvg), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("متوسط الإدارات", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            // تحذير الصور الناقصة
            if (d.missingPhotos.isNotEmpty()) item {
                Text("⚠ فيه ${d.missingPhotos.size} مخالفة محتاجة صورة ومفيش عليها.", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
            // سبب الإعادة
            if (i.status == Status.RETURNED) audit.lastOrNull { it.action == "RETURNED" }?.let { a ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("سبب الإعادة (${a.actorName}):", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            Text(a.note ?: "")
                        }
                    }
                }
            }
            // الدرجات
            item { Text("الدرجات", style = MaterialTheme.typography.titleMedium) }
            items(d.units, key = { "u_" + it.unit.id }) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(l.unit.name, Modifier.weight(1f))
                    Text(
                        if (l.isNA) "N/A" else "${fmtScore(l.score!!.actual)} / ${fmtScore(l.score.planned)}  ·  ${l.violationCount} مخالفة",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            // المخالفات
            item { Text("المخالفات (${d.violations.size})", style = MaterialTheme.typography.titleMedium) }
            if (d.violations.isEmpty()) item { Text("لا توجد مخالفات.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            d.violations.groupBy { it.unitName }.forEach { (unitName, list) ->
                item(key = "h_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                items(list, key = { it.findingId }) { v ->
                    val photos = d.photosByFinding[v.findingId].orEmpty()
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${v.controlNo}. ${v.controlText}")
                            val sub = listOfNotNull(v.categoryName, v.groupName?.takeIf { it.isNotBlank() }).joinToString(" · ")
                            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            com.raneen.quality.data.InlineCensusData.summary(v.findingNote).takeIf { it.isNotBlank() }?.let { summary ->
                                Text("حصر المخالفة: $summary", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                            }
                            v.violationNote?.takeIf { it.isNotBlank() }?.let { note ->
                                Text("ملاحظات المخالفة: $note", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                            }
                            val live = photos.filter { it.syncState != "PURGED" && it.syncState != "MISSING" }
                            if (live.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(live, key = { it.id }) { p -> Thumb(p.filePath, 72.dp) {
                                    if (!isVideo(p.filePath)) preview = p
                                    else if (File(p.filePath).exists()) playVideo(context, p.filePath)
                                    else scope.launch {
                                        toast(context, "جاري تنزيل الفيديو...")
                                        val e = reports.downloadMedia(i.inspectorId, inspectionId, p)
                                        if (e == null) playVideo(context, p.filePath) else error = e
                                    }
                                } }
                            } else if (photos.isNotEmpty()) Text(if (user.id == i.inspectorId) "الصور اتمسحت من موبايلك" else "الصور محفوظة على موبايل المراقب", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else if (v.photoRequired) Text("⚠ بدون صورة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            // ضوابط الحصر
            if (d.census.isNotEmpty()) {
                item { Text("ضوابط الحصر", style = MaterialTheme.typography.titleMedium) }
                d.census.groupBy { it.unitName }.forEach { (unitName, list) ->
                    item(key = "ch_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                    items(list, key = { it.unitId + "|" + it.controlId }) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.controlText)
                                    Text(c.categoryName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (c.priced) "${c.expr}، إجمالي القيمة = ${c.amount} ج.م" else c.expr, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            // سجل المراجعة
            if (audit.isNotEmpty()) {
                item { Text("سجل المراجعة", style = MaterialTheme.typography.titleMedium) }
                items(audit, key = { it.id }) { a ->
                    Column {
                        Text("${Status.actionLabel(a.action)} — ${a.actorName} (${Roles.label(a.actorRole)})", style = MaterialTheme.typography.bodyMedium)
                        Text(fmtDate(a.at) + (a.note?.let { "  ·  $it" } ?: ""), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            info?.let { item { Text(it, color = Color(0xFF1D7A4D), fontWeight = FontWeight.Bold) } }
            // الإجراءات حسب الدور والحالة
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (canSubmit) {
                        Button(onClick = { if (generalNotes.isBlank()) error = "اكتب الملاحظات العامة للزيارة أولًا" else confirmSubmit = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إرسال التقرير") }
                        RaneenOutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("رجوع للتعديل") }
                    }
                    if (canArea) {
                        Button(onClick = { act { reports.areaApprove(inspectionId, user) } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("اعتماد المراجعة") }
                        RaneenOutlinedButton(onClick = onEdit, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("تعديل التقرير") }
                        RaneenOutlinedButton(onClick = { reason = ""; returning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إعادة للمراقب") }
                    }
                    if (canDept) {
                        Button(onClick = { approveFinal() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("الاعتماد النهائي") }
                        RaneenOutlinedButton(onClick = onEdit, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("تعديل التقرير") }
                        RaneenOutlinedButton(onClick = { reason = ""; returning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إعادة للمراقب") }
                    }
                    Text("تصدير ومشاركة", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RaneenOutlinedButton(onClick = { export("pdf") }, modifier = Modifier.weight(1f)) { Text("PDF") }
                        RaneenOutlinedButton(onClick = { export("docx") }, modifier = Modifier.weight(1f)) { Text("Word") }
                        RaneenOutlinedButton(onClick = { export("xlsx") }, modifier = Modifier.weight(1f)) { Text("Excel") }
                    }
                    val hasLocalPhotos = d.photosByFinding.values.flatten().any { it.syncState != "PURGED" && it.syncState != "MISSING" }
                    if (user.role == Roles.INSPECTOR && i.inspectorId == user.id && !Status.editable(i.status) && i.syncState != "PENDING" && hasLocalPhotos) {
                        RaneenOutlinedButton(onClick = { confirmDeletePhotos = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("مسح صور التقرير من موبايلي", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    RaneenOutlinedButton(onClick = { export("zip") }, modifier = Modifier.fillMaxWidth()) { Text("تحميل الصور الأصلية (ZIP)") }
                    Text("التلات ملفات فيهم الصور المتاحة على الجهاز.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (confirmSubmit) AlertDialog(
            onDismissRequest = { confirmSubmit = false },
            title = { Text("إرسال التقرير؟") },
            text = {
                Text(
                    if (d.missingPhotos.isNotEmpty()) "فيه ${d.missingPhotos.size} مخالفة محتاجة صورة ومفيش عليها. تبعت برضو؟ مش هتقدر تعدّل بعد الإرسال."
                    else "هيتبعت لمدير المنطقة ومش هتقدر تعدّل بعد كده. متأكد؟"
                )
            },
            confirmButton = { TextButton(onClick = { confirmSubmit = false; act { val saveError = reports.saveGeneralVisitNotes(inspectionId, user, generalNotes); if (saveError != null) saveError else reports.submit(inspectionId, user) } }) { Text("إرسال") } },
            dismissButton = { TextButton(onClick = { confirmSubmit = false }) { Text("إلغاء") } }
        )
        if (confirmDeletePhotos) AlertDialog(
            onDismissRequest = { confirmDeletePhotos = false },
            title = { Text("مسح الصور من موبايلك؟") },
            text = {
                Text("الصور هتتمسح من الموبايل ده بس. لو التقرير لسه ماتعتمدش نهائيًا، نسختها على السيرفر هتفضل لحد الاعتماد النهائي، وبعد كده الصور الأصلية هتفضل في أرشيف مدير الإدارة. صدّر ZIP الصور الأول لو عايز نسخة.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDeletePhotos = false
                    scope.launch { error = reports.deleteMyPhotos(inspectionId, user); refresh++ }
                }) { Text("مسح", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDeletePhotos = false }) { Text("إلغاء") } }
        )
        if (returning) AlertDialog(
            onDismissRequest = { returning = false },
            title = { Text("سبب الإعادة") },
            text = { OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("اكتب السبب (إجباري)") }, minLines = 2) },
            confirmButton = {
                TextButton(onClick = {
                    val r = reason
                    returning = false
                    act { reports.returnReport(inspectionId, user, r) }
                }) { Text("إعادة") }
            },
            dismissButton = { TextButton(onClick = { returning = false }) { Text("إلغاء") } }
        )
        preview?.let { PhotoDialog(it, false, {}, { preview = null }) }
    }
}

// ───────────── قائمة التقارير (مدير المنطقة / مدير الإدارة / الأدمن) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsListScreen(
    title: String, user: UserEntity, reports: ReportRepository, sync: SyncRepository,
    leaveLabel: String, onLeave: () -> Unit,
    unread: Int = 0, onChat: (() -> Unit)? = null,
    onOpen: (ReportRow) -> Unit
) {
    val rows by remember { reports.rows() }.collectAsState(initial = emptyList())
    fun needsAction(r: ReportRow) = (user.role == Roles.AREA_MANAGER && r.status == Status.SUBMITTED) ||
            (user.role == Roles.DEPT_MANAGER && r.status == Status.REVIEWED)
    val isManager = user.role == Roles.AREA_MANAGER || user.role == Roles.DEPT_MANAGER
    var onlyPending by remember { mutableStateOf(isManager) }
    // المراقب مسوّدته مش المفروض تظهر للمديرين قبل الإرسال
    val visible = rows.filter { it.status != Status.DRAFT }.filter { !onlyPending || needsAction(it) }

    Scaffold(topBar = {
        RaneenTopBar(title = { Text(title) }, actions = {
            onChat?.let { ChatAction(unread, it) }
            TextButton(onClick = onLeave) { Text(leaveLabel) }
        })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.bodyMedium)
                SyncBar(sync)
                if (isManager) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = onlyPending, onClick = { onlyPending = true }, label = { Text("تحتاج إجراء") })
                    FilterChip(selected = !onlyPending, onClick = { onlyPending = false }, label = { Text("الكل") })
                }
            }
            if (visible.isEmpty()) item { Text("مفيش تقارير.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(visible, key = { it.id }) { ReportRowCard(it, true) { onOpen(it) } }
        }
    }
}

private fun toast(ctx: android.content.Context, msg: String) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
