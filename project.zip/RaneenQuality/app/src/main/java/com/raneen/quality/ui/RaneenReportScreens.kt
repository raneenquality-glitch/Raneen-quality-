package com.raneen.quality.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.raneen.quality.R
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.*
import com.raneen.quality.domain.UnitScore
import com.raneen.quality.domain.ControlDef
import com.raneen.quality.domain.controlLoss
import android.widget.Toast
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ───────────── كارت تقرير في القوائم ─────────────
@Composable
fun ReportRowCard(row: ReportRow, showInspector: Boolean, onClick: () -> Unit) {
    val accent = statusColor(row.status)
    val icon = when (row.status) {
        Status.DRAFT -> "✏️"; Status.SUBMITTED -> "📤"; Status.REVIEWED -> "🔎"; Status.RETURNED -> "↩️"; Status.FINAL -> "✅"; else -> "📄"
    }
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            // أيقونة الحالة بلون الحالة (نظرة سريعة من غير قراءة)
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                Text(icon, style = MaterialTheme.typography.titleLarge)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(row.branchName.ifBlank { "فرع محذوف" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    StatusChip(row.status)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (row.templateId.isNotBlank()) Text(
                        evaluationTemplateLabel(row.templateId), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    visitLabel(row.visitNumber)?.let {
                        Text(
                            it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                if (showInspector) Text("المراقب: ${row.inspectorName}", style = MaterialTheme.typography.bodySmall)
                Text("📅 ${fmtDate(row.visitDate)}  ·  ${row.reportNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
}

// ───────────── الرئيسية للمراقب: زيارة جديدة + زياراتي ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InspectorHome(
    user: UserEntity, reports: ReportRepository, sync: SyncRepository,
    onNew: () -> Unit, onOpen: (ReportRow) -> Unit, onLogout: () -> Unit,
    unread: Int = 0, onChat: (() -> Unit)? = null
) {
    val rows by remember { reports.rows() }.collectAsState(initial = emptyList())
    val mine = rows.filter { it.inspectorId == user.id }
    var filter by rememberSaveable { mutableStateOf("ALL") }
    val needEdit = mine.filter { Status.editable(it.status) }
    val inReview = mine.filter { it.status == Status.SUBMITTED || it.status == Status.REVIEWED }
    val approved = mine.filter { it.status == Status.FINAL }
    val shown = when (filter) { "EDIT" -> needEdit; "REVIEW" -> inReview; "DONE" -> approved; else -> mine }
    val syncStatus by sync.status.collectAsState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            RaneenTopBar(title = { Text("رنين", fontWeight = FontWeight.ExtraBold) }, actions = {
                onChat?.let { ChatAction(unread, it) }
                TextButton(onClick = onLogout) { Text("خروج") }
            })
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // بطاقة الترحيب (تدرّج أحمر) + المزامنة + الأرقام السريعة في كارت واحد
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, Color(0xFF8E0000))))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(54.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                            Text(user.name.trim().take(1).uppercase(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("أهلاً، ${user.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(Roles.label(user.role) + " · نسخة " + BuildInfo.STAMP, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.16f))
                            .clickable { sync.kick() }.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔄", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.width(8.dp))
                        Text(syncStatus, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.95f), modifier = Modifier.weight(1f))
                        Text("مزامنة الآن", style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        HeroStat("زياراتي", mine.size, Modifier.weight(1f))
                        HeroStat("قيد المراجعة", inReview.size, Modifier.weight(1f))
                        HeroStat("معتمدة", approved.size, Modifier.weight(1f))
                    }
                }
            }
            // زرار الزيارة الجديدة
            item {
                Row(
                    Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp))
                        .background(Color.White).clickable(onClick = onNew).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(Modifier.size(50.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        Text("＋", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("زيارة تفتيش جديدة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("اختار نوع التقييم والفرع وابدأ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // فلتر الزيارات
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("زياراتي", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${shown.size} زيارة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val opts = listOf(
                        Triple("ALL", "الكل", mine.size), Triple("EDIT", "تحتاج استكمال", needEdit.size),
                        Triple("REVIEW", "قيد المراجعة", inReview.size), Triple("DONE", "معتمدة", approved.size)
                    )
                    items(opts, key = { it.first }) { (k, label, n) ->
                        FilterChip(
                            selected = filter == k, onClick = { filter = k }, label = { Text("$label ($n)") }, shape = RoundedCornerShape(50),
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color.White, selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
            if (shown.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🗂️", style = MaterialTheme.typography.displaySmall)
                    Text(
                        if (mine.isEmpty()) "لسه معندكش زيارات.\nاضغط «زيارة تفتيش جديدة» عشان تبدأ." else "مفيش زيارات في الفلتر ده.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            items(shown, key = { it.id }) { ReportRowCard(it, false) { onOpen(it) } }
        }
    }
}

@Composable
private fun HeroStat(label: String, value: Int, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.16f)).padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
        Text(label, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.9f))
    }
}

// ───────────── اختيار الفرع لبدء زيارة ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchPickerScreen(repo: InspectionRepository, inspectorId: String, remote: SupabaseRemote, onBack: () -> Unit, onStarted: (String) -> Unit) {
    val branches by remember(repo) { repo.branches() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var starting by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<BranchEntity?>(null) }
    var seatFor by remember { mutableStateOf<Pair<BranchEntity, String>?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedTemplateId by rememberSaveable { mutableStateOf<String?>(null) }
    val shownBranches = remember(branches, query, selectedTemplateId) {
        branches.filterByQuery(query).filter { b ->
            selectedTemplateId != "smart" || b.name.contains("زايد", ignoreCase = true) || b.name.contains("zayed", ignoreCase = true)
        }.sortedByBranchNumber()
    }
    fun start(b: BranchEntity, visit: String, seat: String) {
        starting = true
        pending = null
        seatFor = null
        scope.launch {
            val number = "RQ-2026-" + (System.currentTimeMillis() % 1_000_000).toString().padStart(6, '0')
            val id = repo.startInspection(b.id, inspectorId, number, visit, selectedTemplateId ?: "offline")
            SeatStore.set(id, seat)
            onStarted(id)
        }
    }
    Scaffold(topBar = {
        RaneenTopBar(title = { Text("اختر الفرع") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("اختار نوع التقييم أولًا", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(Triple("smart", "⚡", "تقييم معارض سمارت"), Triple("digital", "💻", "تقييم معارض الديجيتال"), Triple("offline", "🏬", "تقييم المعارض الأوف لاين")).forEach { (id, icon, label) ->
                            val sel = selectedTemplateId == id
                            Card(
                                modifier = Modifier.weight(1f).heightIn(min = 118.dp)
                                    .border(if (sel) 2.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color(0xFFE3E3E3), RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp)).clickable { selectedTemplateId = id },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                            ) {
                                Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    // أيقونة النوع: صورة الكيوسك للديجيتال، صورة المعرض للأوف لاين، وصورة المبنى لسمارت
                                    val iconRes = when (id) { "digital" -> R.drawable.icon_eval_digital; "offline" -> R.drawable.icon_eval_offline; "smart" -> R.drawable.icon_eval_smart; else -> null }
                                    Box(Modifier.fillMaxWidth().height(84.dp), contentAlignment = Alignment.Center) {
                                        if (iconRes != null) Image(painterResource(iconRes), contentDescription = label, modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Fit)
                                        else Text(icon, style = MaterialTheme.typography.displaySmall)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(label, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
            if (selectedTemplateId != null) {
            item { Text("اختر الفرع لبدء زيارة تفتيش", style = MaterialTheme.typography.titleMedium) }
            // بحث بالاسم أو رقم الفرع (الفروع مرتبة برقم الفرع)
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("ابحث بالاسم أو رقم الفرع") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("مسح") } }
                )
            }
            if (branches.isEmpty()) item { Text("مفيش فروع. الأدمن لازم يضيف فروع الأول.", color = MaterialTheme.colorScheme.error) }
            else if (shownBranches.isEmpty()) item { Text("مفيش فرع مطابق للبحث.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            else item { Text("${shownBranches.size} فرع", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(shownBranches, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().border(1.dp, Color(0xFFE3E3E3), RoundedCornerShape(16.dp)).clickable(enabled = !starting) { pending = b }, colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(b.name, style = MaterialTheme.typography.titleMedium)
                        Text("رقم ${b.code}" + if (b.region.isNotBlank()) " · ${b.region}" else "", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            }
        }
    }

    pending?.let { b ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("اختار رقم الزيارة") },
            confirmButton = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { seatFor = b to "1"; pending = null }, modifier = Modifier.fillMaxWidth()) { Text("الزيارة الأولى") }
                    Button(onClick = { seatFor = b to "2"; pending = null }, modifier = Modifier.fillMaxWidth()) { Text("الزيارة الثانية") }
                }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("إلغاء") } }
        )
    }

    seatFor?.let { (b, visit) ->
        SeatPickerDialog(remote, b, selectedTemplateId ?: "offline", visit, onCancel = { seatFor = null }, onChosen = { seat -> start(b, visit, seat) })
    }
}

/** اختيار الدور في الزيارة: مقعد التشغيل / مقعد الإدارات المساعدة / الاتنين. مراقب تالت مينفعش يدخل. */
@Composable
private fun SeatPickerDialog(remote: SupabaseRemote, branch: BranchEntity, templateId: String, visit: String, onCancel: () -> Unit, onChosen: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var seats by remember { mutableStateOf<List<SeatInfo>?>(null) }
    var loadFailed by remember { mutableStateOf(false) }
    var reload by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(branch.id, templateId, visit, reload) {
        loadFailed = false
        val r = withContext(Dispatchers.IO) { VisitSeats.status(remote, branch.id, templateId, visit) }
        r.onSuccess { seats = it }.onFailure { loadFailed = true }
    }
    fun heldByOther(seat: String) = seats?.firstOrNull { it.seat == seat && !it.mine }
    fun choose(seat: String) {
        busy = true; error = null
        scope.launch {
            val err = withContext(Dispatchers.IO) { VisitSeats.claim(remote, branch.id, templateId, visit, seat) }
            busy = false
            if (err == null) onChosen(seat) else { error = err; reload++ }
        }
    }
    val opOther = heldByOther("OPERATIONAL"); val supOther = heldByOther("SUPPORT")
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        title = { Text("اختار دورك في الزيارة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${branch.name} — الزيارة ${if (visit == "1") "الأولى" else "الثانية"}", style = MaterialTheme.typography.bodySmall)
                when {
                    loadFailed -> {
                        Text("محتاج اتصال بالإنترنت عشان تحجز دورك في الزيارة.", color = MaterialTheme.colorScheme.error)
                        OutlinedButton(onClick = { reload++ }, modifier = Modifier.fillMaxWidth()) { Text("حاول تاني") }
                    }
                    seats == null -> CircularProgressIndicator(Modifier.size(24.dp))
                    else -> {
                        if (opOther != null && supOther != null)
                            Text("الزيارة دي فيها مراقبين الاتنين (${opOther.holder} و${supOther.holder}). مينفعش تدخل عليها.", color = MaterialTheme.colorScheme.error)
                        Button(onClick = { choose("OPERATIONAL") }, enabled = !busy && opOther == null, modifier = Modifier.fillMaxWidth()) {
                            Text(if (opOther != null) "الأقسام التشغيلية — ماسكها ${opOther.holder}" else "الأقسام التشغيلية")
                        }
                        Button(onClick = { choose("SUPPORT") }, enabled = !busy && supOther == null, modifier = Modifier.fillMaxWidth()) {
                            Text(if (supOther != null) "الإدارات المساعدة — ماسكها ${supOther.holder}" else "الإدارات المساعدة")
                        }
                        OutlinedButton(onClick = { choose("BOTH") }, enabled = !busy && opOther == null && supOther == null, modifier = Modifier.fillMaxWidth()) {
                            Text("الاتنين (زيارة منفردة)")
                        }
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text("إلغاء") } }
    )
}

private val operationsUnitOrder = listOf("قسم الأدوات المنزلية", "قسم الألعاب ومستلزمات الأطفال", "قسم المفروشات", "قسم الكهرباء", "قسم الخدمات وعمال التحميل", "قسم مدير المعرض")
private val supportUnitOrder = listOf("إدارة خدمة العملاء", "إدارة الكاشير", "إدارة الكاميرات", "إدارة الأمن", "إدارة الاستلامات", "إدارة الصيانة", "إدارة التكييفات", "إدارة الموارد البشرية")
private fun unitOrderIndex(name: String, kind: String): Int {
    val targetList = if (kind == "SECTION") operationsUnitOrder else supportUnitOrder
    fun norm(s: String) = s.replace("إ", "ا").replace("أ", "ا").replace("آ", "ا").replace(" ", "")
    return targetList.indexOfFirst { norm(name).contains(norm(it)) || norm(it).contains(norm(name)) }.let { if (it < 0) Int.MAX_VALUE else it }
}

// ───────────── أقسام الزيارة (درجات لحظية + N/A + مراجعة) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitsScreen(
    user: UserEntity, repo: InspectionRepository, reports: ReportRepository, inspectionId: String,
    onOpen: (String, String) -> Unit, onReview: () -> Unit, onDeleted: () -> Unit
) {
    val units by remember(repo) { repo.units() }.collectAsState(initial = emptyList())
    val insp by remember(inspectionId) { repo.inspectionFlow(inspectionId) }.collectAsState(initial = null)
    val states by remember(inspectionId) { repo.unitStates(inspectionId) }.collectAsState(initial = emptyList())
    val findings by remember(inspectionId) { repo.allFindings(inspectionId) }.collectAsState(initial = emptyList())
    val audit by remember(inspectionId) { reports.audit(inspectionId) }.collectAsState(initial = emptyList())
    val scores by produceState<Map<String, UnitScore>>(emptyMap(), findings) { value = repo.unitScores(inspectionId) }
    val scope = rememberCoroutineScope()
    var confirmDelete by remember { mutableStateOf(false) }
    var pendingNAUnit by remember { mutableStateOf<String?>(null) }

    val editable = insp?.let { Status.editableBy(user.role, it.status) } ?: false
    val currentTemplateId = insp?.templateId ?: "main"
    val seat = remember(inspectionId) { SeatStore.getOrNull(inspectionId) }
    val isOwner = insp?.inspectorId == user.id          // زيارتي أنا (مراقب أو مدير منطقة) مش تعديل مدير على تقرير حد تاني
    val visibleUnits = units.filter { belongsToEvaluationTemplate(it, currentTemplateId) && SeatStore.allows(seat, it.kind) }.sortedWith(compareBy<EvaluationUnitEntity>({ if (it.kind == "SECTION") 0 else 1 }, { unitOrderIndex(it.name, it.kind) }, { it.sortOrder }, { it.name }))
    val naIds = states.filter { it.isNA }.map { it.unitId }.toSet()
    val returnNote = if (insp?.status == Status.RETURNED) (audit.lastOrNull { it.action == "RETURNED" }?.note.orEmpty()) else null

    Scaffold(
        topBar = {
            RaneenTopBar(title = { Text(evaluationTemplateLabel(currentTemplateId)) }, actions = {
                if (insp?.status == Status.DRAFT) TextButton(onClick = { confirmDelete = true }) {
                    Text("حذف الزيارة")
                }
            })
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = onReview, shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(12.dp).heightIn(min = 54.dp)
                ) { Text(if (editable && (user.role == Roles.INSPECTOR || isOwner)) "مراجعة وإرسال التقرير" else if (editable) "عرض التقرير والاعتماد" else "عرض التقرير", style = MaterialTheme.typography.titleMedium) }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (returnNote != null) item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("التقرير اترجّع للتعديل", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                        Text(returnNote.ifBlank { "بدون سبب محدد" })
                    }
                }
            }
            if (editable && user.role != Roles.INSPECTOR && !isOwner) item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("تعديل التقييم", fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                    }
                }
            }
            // أيقونة الحصر المجمّع (مخالفات الأسعار + أدوات العرض + الصيانة) بتتجمع تلقائي من المخالفات
            item(key = "census_summary") { CensusSummaryCard(remember(findings, naIds, visibleUnits) { CensusSummaryBuilder.build(findings, naIds, visibleUnits) }) }
            // ملخص لحظي: متوسط الأقسام والإدارات المساعدة وعدد المخالفات
            item {
                val live = visibleUnits.filter { it.id !in naIds }
                fun avg(kind: String): Double? =
                    live.filter { it.kind == kind }.mapNotNull { scores[it.id]?.percent }.let { if (it.isEmpty()) null else it.average() }
                val violated = findings.count { it.violationCount > 0 && it.unitId !in naIds }
                fun groupAvg(pred: (EvaluationUnitEntity) -> Boolean): Double? =
                    live.filter(pred).mapNotNull { scores[it.id]?.percent }.let { if (it.isEmpty()) null else it.average() }
                val opsAvg = groupAvg { unitGroup(it) == "MAIN" }
                val supportAvg = groupAvg { unitGroup(it) == "SUPPORT" }
                val overallAvg = groupAvg { unitGroup(it) != "SUPPORT" }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(Color.White).border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(20.dp)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SummaryCell("النتيجة النهائية", fmtPct(overallAvg), Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryCell("متوسط أقسام التشغيل", fmtPct(opsAvg), Modifier.weight(1f))
                        SummaryCell("الإدارات المساعدة", fmtPct(supportAvg), Modifier.weight(1f))
                        SummaryCell("المخالفات", violated.toString(), Modifier.weight(1f))
                    }
                }
            }
            item { Text("إدارة التشغيل — الأقسام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(visibleUnits.filter { it.kind == "SECTION" }.chunked(2), key = { row -> "s_" + row.first().id }) { row ->
                UnitRowTiles(row, scores, findings, naIds, editable, onOpen) { id, na ->
                    if (na) pendingNAUnit = id
                    else scope.launch { repo.setNA(inspectionId, id, false); reports.markManagerEdit(inspectionId, user) }
                }
            }
            item { Spacer(Modifier.height(4.dp)); Text("الإدارات المساعدة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(visibleUnits.filter { it.kind == "ADMINISTRATION" }.chunked(2), key = { row -> "a_" + row.first().id }) { row ->
                UnitRowTiles(row, scores, findings, naIds, editable, onOpen) { id, na ->
                    if (na) pendingNAUnit = id
                    else scope.launch { repo.setNA(inspectionId, id, false); reports.markManagerEdit(inspectionId, user) }
                }
            }
        }
    }

    pendingNAUnit?.let { unitId ->
        AlertDialog(
            onDismissRequest = { pendingNAUnit = null },
            title = { Text("تأكيد عدم وجود القسم") },
            text = { Text("هل أنت متأكد من أن القسم غير موجود بالمعرض؟") },
            confirmButton = {
                TextButton(onClick = {
                    pendingNAUnit = null
                    scope.launch { repo.setNA(inspectionId, unitId, true); reports.markManagerEdit(inspectionId, user) }
                }) { Text("نعم، غير موجود") }
            },
            dismissButton = { TextButton(onClick = { pendingNAUnit = null }) { Text("إلغاء") } }
        )
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("حذف الزيارة؟") },
        text = { Text("هتتمسح الزيارة وكل مخالفاتها وصورها من الجهاز. مينفعش تتراجع.") },
        confirmButton = {
            TextButton(onClick = {
                scope.launch { if (reports.deleteDraft(inspectionId, user) == null) onDeleted() }
                confirmDelete = false
            }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
    )
}

@Composable
private fun SummaryCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** صف من مربعين (قسمين جنب بعض) */
@Composable
private fun UnitRowTiles(
    row: List<EvaluationUnitEntity>, scores: Map<String, UnitScore>, findings: List<FindingEntity>,
    naIds: Set<String>, editable: Boolean, onOpen: (String, String) -> Unit, onNA: (String, Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        row.forEach { u ->
            UnitTile(
                unit = u, score = scores[u.id], violations = findings.count { it.unitId == u.id && it.violationCount > 0 },
                isNA = u.id in naIds, editable = editable, modifier = Modifier.weight(1f).heightIn(min = 150.dp),
                onOpen = { onOpen(u.id, u.name) }, onNA = { onNA(u.id, it) }
            )
        }
        if (row.size == 1) Spacer(Modifier.weight(1f))
    }
}

/** مربع قسم: الاسم + الدرجة + شريط + عدد المخالفات. أحمر خفيف لو فيه مخالفات، رمادي لو "غير موجود بالفرع" */
@Composable
private fun UnitTile(
    unit: EvaluationUnitEntity, score: UnitScore?, violations: Int, isNA: Boolean, editable: Boolean,
    modifier: Modifier = Modifier, onOpen: () -> Unit, onNA: (Boolean) -> Unit
) {
    val red = MaterialTheme.colorScheme.error
    val bg = when { isNA -> Color(0xFFF0F0F0); violations > 0 -> Color(0xFFFFF3F3); else -> Color.White }
    val accent = if (violations > 0) red else MaterialTheme.colorScheme.primary
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(bg)
            .border(1.dp, if (violations > 0 && !isNA) Color(0xFFF2C4C4) else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            .clickable(enabled = !isNA, onClick = onOpen).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                unit.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 2,
                color = if (isNA) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(8.dp))
            if (isNA) Text("غير موجود بالفرع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            else if (score != null) {
                Text(fmtPct(score.percent), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = accent)
                Text("${fmtScore(score.actual)} / ${fmtScore(score.planned)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (score.percent / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                    color = accent, trackColor = if (violations > 0) Color(0xFFF2C4C4) else MaterialTheme.colorScheme.primaryContainer
                )
                if (violations > 0) Text("⚠ $violations بند مخالف", style = MaterialTheme.typography.labelMedium, color = red, modifier = Modifier.padding(top = 4.dp))
            }
        }
        if (editable) TextButton(onClick = { onNA(!isNA) }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) {
            Text(if (isNA) "↩ إرجاع القسم" else "غير موجود بالفرع؟", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ───────────── تفاصيل التقرير (مراجعة قبل الإرسال + اعتماد المديرين + تصدير) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportDetailScreen(
    user: UserEntity, reports: ReportRepository, inspectionId: String,
    onBack: () -> Unit, onEdit: () -> Unit, onEditPart: (String) -> Unit = { onEdit() }, onChanged: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val insp by remember(inspectionId) { reports.inspectionFlow(inspectionId) }.collectAsState(initial = null)
    val audit by remember(inspectionId) { reports.audit(inspectionId) }.collectAsState(initial = emptyList())
    var refresh by remember { mutableStateOf(0) }
    val data by produceState<ReportData?>(null, insp?.status, insp?.notes, refresh) { value = reports.build(inspectionId) }
    // حالة ملفات التقرير (رفع / أرشيف / إعادة محاولة) للمراقب والمديرين
    val mediaLine by produceState<String?>(null, inspectionId, refresh) {
        value = if (user.role == Roles.VIEWER) null else reports.mediaStatus(inspectionId)
    }
    // مشاهد الإدارة: صور التقرير بتتنزّل لما يفتحه (مش كلها مرة واحدة في المزامنة)
    LaunchedEffect(inspectionId) {
        if (user.role == Roles.VIEWER) { reports.ensureImages(inspectionId); refresh++ }
    }

    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmSubmit by remember { mutableStateOf(false) }
    var returning by remember { mutableStateOf(false) }
    var returningToArea by remember { mutableStateOf(false) }
    var returnTargets by remember { mutableStateOf<Set<String>>(emptySet()) }
    var reason by remember { mutableStateOf("") }
    // مفتاح ثابت حتى لا يعاد ضبط النص مع كل تحديث من قاعدة البيانات أثناء الكتابة.
    var generalNotes by rememberSaveable(inspectionId, stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue(insp?.notes.orEmpty())) }
    var hasEditedGeneralNotes by rememberSaveable(inspectionId) { mutableStateOf(false) }
    var preview by remember { mutableStateOf<PhotoEntity?>(null) }

    fun act(block: suspend () -> String?) {
        scope.launch {
            busy = true
            error = block()
            busy = false
            if (error == null) onChanged()
        }
    }

    fun approveFinal() {
        scope.launch {
            busy = true
            val (e, note) = reports.finalApprove(inspectionId, user)
            busy = false
            error = e
            info = note
            if (e == null) onChanged()
        }
    }

    fun export(kind: String) {
        val d = data ?: return
        scope.launch {
            try {
                val (file, mime) = withContext(Dispatchers.IO) {
                    when (kind) {
                        "pdf" -> ReportExporter.pdf(context, d) to ReportExporter.MIME_PDF
                        "docx" -> ReportExporter.docx(context, d) to ReportExporter.MIME_DOCX
                        "zip" -> ReportExporter.photosZip(context, d)?.let { it to "application/zip" }
                            ?: throw IllegalStateException("no photos")
                        else -> ReportExporter.xlsx(context, d) to ReportExporter.MIME_XLSX
                    }
                }
                ReportExporter.share(context, file, mime)
            } catch (e: IllegalStateException) {
                error = "مفيش صور محفوظة على الجهاز للتقرير ده"
            } catch (e: Exception) {
                error = "تعذّر إنشاء الملف"
            }
        }
    }

    val i = insp
    val canSubmit = canInspect(user.role) && i != null && i.inspectorId == user.id && Status.editable(i.status)
    // لو بيانات الزيارة وصلت بعد فتح الشاشة، حمّلها دون مسح أي نص بدأ المراقب في كتابته.
    LaunchedEffect(inspectionId, insp?.notes) {
        val saved = insp?.notes.orEmpty()
        if (!hasEditedGeneralNotes && generalNotes.text.isBlank() && saved.isNotBlank()) generalNotes = TextFieldValue(saved)
    }
    LaunchedEffect(inspectionId, generalNotes.text, canSubmit) {
        if (!canSubmit) return@LaunchedEffect
        delay(900)
        reports.saveGeneralVisitNotes(inspectionId, user, generalNotes.text)
    }
    val mStatus = data?.inspection?.status ?: i?.status      // حالة الزيارة كلها (أقل حالة بين الجزئين)
    val canArea = user.role == Roles.AREA_MANAGER && mStatus == Status.SUBMITTED
    val canDept = user.role == Roles.DEPT_MANAGER && mStatus == Status.REVIEWED

    Scaffold(topBar = {
        RaneenTopBar(title = { Text("تقرير الزيارة") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } })
    }) { padding ->
        val d = data
        if (d == null || i == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        val orderedReportUnits = d.units.sortedWith(compareBy<UnitLine>({ if (it.unit.kind == "SECTION") 0 else 1 }, { unitOrderIndex(it.unit.name, it.unit.kind) }, { it.unit.sortOrder }, { it.unit.name }))
        val orderedReportViolations = d.violations.sortedWith(compareBy<ViolationRow>({ if (d.units.firstOrNull { u -> u.unit.id == it.unitId }?.unit?.kind == "ADMINISTRATION") 1 else 0 }, { unitOrderIndex(it.unitName, if (d.units.firstOrNull { u -> u.unit.id == it.unitId }?.unit?.kind == "ADMINISTRATION") "ADMINISTRATION" else "SECTION") }, { it.unitName }, { it.controlNo }))
        val operationsViolations = orderedReportViolations.filter { v -> d.units.firstOrNull { it.unit.id == v.unitId }?.unit?.kind != "ADMINISTRATION" }
        val supportViolations = orderedReportViolations.filter { v -> d.units.firstOrNull { it.unit.id == v.unitId }?.unit?.kind == "ADMINISTRATION" }
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // ملاحظات الزيارة العامة — إلزامية للمراقب قبل الإرسال
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ملاحظات الزيارة العامة *", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (canSubmit) {
                            OutlinedTextField(
                                value = generalNotes,
                                onValueChange = { generalNotes = it; hasEditedGeneralNotes = true },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp), minLines = 5, maxLines = 15, singleLine = false,
                                // زرار الإدخال في الكيبورد = سطر جديد (مش "تم")
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                    capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences,
                                    imeAction = androidx.compose.ui.text.input.ImeAction.Default
                                ),
                                label = { Text("اكتب الملاحظات العامة للزيارة") },
                                placeholder = { Text("الملاحظات مطلوبة قبل إرسال التقرير") },
                                isError = generalNotes.text.isBlank()
                            )
                            if (generalNotes.text.isBlank()) Text("يجب كتابة الملاحظات العامة قبل إرسال التقرير إلى مدير المنطقة.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text(insp?.notes?.takeIf { it.isNotBlank() } ?: "لا توجد ملاحظات عامة مسجلة.")
                        }
                    }
                }
            }
            // الترويسة
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(d.branchName.ifBlank { "فرع محذوف" }, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                            StatusChip(mStatus ?: i.status)
                        }
                        Text("نوع التقييم: ${evaluationTemplateLabel(i.templateId)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("رقم التقرير: ${i.reportNumber}")
                        visitLabel(i.visitNumber)?.let { Text(it, fontWeight = FontWeight.Bold) }
                        Text("تاريخ الزيارة: ${fmtDate(i.visitDate)}")
                        Text("المراقب: ${d.inspectorName}")
                        Text(Status.label(mStatus ?: i.status), color = statusColor(mStatus ?: i.status), fontWeight = FontWeight.Bold)
                        Text(
                            when (i.syncState) {
                                "SYNCED" -> "تمت المزامنة مع السيرفر."
                                "PENDING" -> "في انتظار الرفع للسيرفر — هيترفع لوحده أول ما يبقى فيه إنترنت."
                                else -> "محفوظ على الجهاز."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        // زر تعديل بارز للمديرين (مدير المنطقة وهو "مُرسل"، مدير الإدارة وهو "مُرسل" أو "تمت المراجعة")
                        if (user.role != Roles.INSPECTOR && i.inspectorId != user.id && Status.editableBy(user.role, mStatus ?: i.status)) {
                            if (d.parts.size > 1) {
                                // زيارة بمراقبين: بتعدّل كل جزء لوحده (الأقسام بتاعته بس)
                                d.parts.forEach { part ->
                                    Button(onClick = { onEditPart(part.id) }, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        Text("تعديل: ${part.label} — ${part.inspectorName}")
                                    }
                                }
                            } else Button(onClick = onEdit, enabled = !busy, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                Text("تعديل التقرير (الأقسام والضوابط)")
                            }
                        }
                    }
                }
            }
            // النتيجة المرحلية (الأقسام الرئيسية) + النتيجة النهائية (كل الأقسام) + الإدارات المساعدة (نتيجة نهائية واحدة)
            mediaLine?.let { line -> item { Text(line, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
            // المشاهد بيشوف جزء إدارته بس، فالمتوسطات الكلية هتبقى مضللة: بنخفيها
            if (user.role != Roles.VIEWER) item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ScoreBox("متوسط أقسام التشغيل", "", d.mainAvg, Modifier.weight(1f))
                        ScoreBox("النتيجة النهائية", "", d.finAvg, Modifier.weight(1f))
                        ScoreBox("الإدارات المساعدة", "النتيجة النهائية", d.supAvg, Modifier.weight(1f))
                    }
                }
            }
            // تحذير الصور الناقصة
            if (d.missingPhotos.isNotEmpty()) item {
                Text("⚠ فيه ${d.missingPhotos.size} مخالفة محتاجة صورة ومفيش عليها.", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
            // سبب الإعادة
            if ((mStatus ?: i.status) == Status.RETURNED) audit.lastOrNull { it.action == "RETURNED" }?.let { a ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("سبب الإعادة (${a.actorName}):", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            Text(a.note?.takeIf { it.isNotBlank() } ?: "بدون سبب محدد")
                        }
                    }
                }
            }
            // الدرجات مفصولة حسب الإدارة
            item { Text("أولًا: إدارة التشغيل — الدرجات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(orderedReportUnits.filter { it.unit.kind == "SECTION" }, key = { "u_" + it.unit.id }) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(l.unit.name, Modifier.weight(1f))
                    Text(if (l.isNA) "N/A" else "${fmtScore(l.score!!.actual)} / ${fmtScore(l.score.planned)}  ·  ${fmtPct(l.score.percent)}  ·  ${l.violationCount} مخالفة", style = MaterialTheme.typography.bodyMedium)
                }
            }
            item { Text("ثانيًا: الإدارات المساعدة — الدرجات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            items(orderedReportUnits.filter { it.unit.kind == "ADMINISTRATION" }, key = { "u_" + it.unit.id }) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(l.unit.name, Modifier.weight(1f))
                    Text(if (l.isNA) "N/A" else "${fmtScore(l.score!!.actual)} / ${fmtScore(l.score.planned)}  ·  ${fmtPct(l.score.percent)}  ·  ${l.violationCount} مخالفة", style = MaterialTheme.typography.bodyMedium)
                }
            }
            // المخالفات مرتبة: التشغيل ثم الإدارات المساعدة
            item { Text("أولًا: إدارة التشغيل — المخالفات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (d.violations.isEmpty()) item { Text("لا توجد مخالفات.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            operationsViolations.groupBy { it.unitName }.forEach { (unitName, list) ->
                item(key = "h_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                items(list, key = { it.findingId }) { v ->
                    val photos = d.photosByFinding[v.findingId].orEmpty()
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${v.controlNo}. ${v.controlText}")
                            v.itemScoreLine()?.let { Text(it, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error) }
                            val sub = listOfNotNull(v.categoryName, v.groupName?.takeIf { it.isNotBlank() }).joinToString(" · ")
                            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            com.raneen.quality.data.InlineCensusData.summary(v.findingNote).takeIf { it.isNotBlank() }?.let { summary ->
                                Text("حصر المخالفة: $summary", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                            }
                            v.violationNote?.takeIf { it.isNotBlank() }?.let { note ->
                                Text("ملاحظات المخالفة: $note", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                            }
                            val live = photos.filter { it.syncState != "PURGED" && it.syncState != "MISSING" }
                            if (live.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(live, key = { it.id }) { p -> Thumb(p.filePath, 72.dp) {
                                    if (!isVideo(p.filePath)) preview = p
                                    else if (File(p.filePath).exists()) playVideo(context, p.filePath)
                                    else scope.launch {
                                        toast(context, "جاري تنزيل الفيديو...")
                                        val e = reports.downloadMedia(d.photoOwner[p.id]?.first ?: i.inspectorId, d.photoOwner[p.id]?.second ?: inspectionId, p)
                                        if (e == null) playVideo(context, p.filePath) else error = e
                                    }
                                } }
                            } else if (photos.isNotEmpty()) Text(if (user.id == i.inspectorId) "الصور اتمسحت من موبايلك" else "الصور محفوظة على موبايل المراقب", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else if (v.photoRequired) Text("⚠ بدون صورة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item { Text("ثانيًا: الإدارات المساعدة — المخالفات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            supportViolations.groupBy { it.unitName }.forEach { (unitName, list) ->
                item(key = "h_support_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                items(list, key = { it.findingId }) { v ->
                    val photos = d.photosByFinding[v.findingId].orEmpty()
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${v.controlNo}. ${v.controlText}")
                            v.itemScoreLine()?.let { Text(it, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error) }
                            Text(listOfNotNull(v.categoryName, v.groupName?.takeIf { it.isNotBlank() }).joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            com.raneen.quality.data.InlineCensusData.summary(v.findingNote).takeIf { it.isNotBlank() }?.let { Text("حصر المخالفة: $it", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium) }
                            v.violationNote?.takeIf { it.isNotBlank() }?.let { Text("ملاحظات المخالفة: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
                            val live = photos.filter { it.syncState != "PURGED" && it.syncState != "MISSING" }
                            if (live.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(live, key = { it.id }) { p -> Thumb(p.filePath, 72.dp) {
                                    if (!isVideo(p.filePath)) preview = p
                                    else if (File(p.filePath).exists()) playVideo(context, p.filePath)
                                    else scope.launch { toast(context, "جاري تنزيل الفيديو..."); val e = reports.downloadMedia(d.photoOwner[p.id]?.first ?: i.inspectorId, d.photoOwner[p.id]?.second ?: inspectionId, p); if (e == null) playVideo(context, p.filePath) else error = e }
                                } }
                            } else if (photos.isNotEmpty()) Text(if (user.id == i.inspectorId) "الصور اتمسحت من موبايلك" else "الصور محفوظة على موبايل المراقب", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else if (v.photoRequired) Text("⚠ بدون صورة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            // الحصر المجمّع (مجمّع تلقائي من المخالفات)
            item(key = "census_summary_detail") { CensusSummaryCard(d.censusSummary) }
            // ضوابط الحصر
            if (d.census.isNotEmpty()) {
                item { Text("ضوابط الحصر", style = MaterialTheme.typography.titleMedium) }
                d.census.groupBy { it.unitName }.forEach { (unitName, list) ->
                    item(key = "ch_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                    items(list, key = { it.unitId + "|" + it.controlId }) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.controlText)
                                    Text(c.categoryName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (c.priced) "${c.expr}، إجمالي القيمة = ${c.amount} ج.م" else c.expr, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            // سجل المراجعة
            if (audit.isNotEmpty()) {
                item { Text("سجل المراجعة", style = MaterialTheme.typography.titleMedium) }
                items(audit, key = { it.id }) { a ->
                    Column {
                        Text("${Status.actionLabel(a.action)} — ${a.actorName} (${Roles.label(a.actorRole)})", style = MaterialTheme.typography.bodyMedium)
                        Text(fmtDate(a.at) + (a.note?.let { "  ·  $it" } ?: ""), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            info?.let { item { Text(it, color = Color(0xFF1D7A4D), fontWeight = FontWeight.Bold) } }
            // الإجراءات حسب الدور والحالة
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (canSubmit) {
                        Button(onClick = { if (generalNotes.text.isBlank()) error = "اكتب الملاحظات العامة للزيارة أولًا" else confirmSubmit = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إرسال التقرير") }
                        RaneenOutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("رجوع للتعديل") }
                    }
                    if (canArea) {
                        Button(onClick = { act { reports.areaApprove(inspectionId, user) } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("اعتماد المراجعة") }
                        if (d.parts.size <= 1) RaneenOutlinedButton(onClick = onEdit, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("تعديل التقرير") }
                        RaneenOutlinedButton(onClick = { reason = ""; returnTargets = d.parts.map { it.id }.toSet(); returning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إعادة للمراقب") }
                    }
                    if (canDept) {
                        Button(onClick = { approveFinal() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("الاعتماد النهائي") }
                        if (d.parts.size <= 1) RaneenOutlinedButton(onClick = onEdit, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("تعديل التقرير") }
                        RaneenOutlinedButton(onClick = { reason = ""; returningToArea = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("↩ إعادة إلى مدير المنطقة") }
                        RaneenOutlinedButton(onClick = { reason = ""; returnTargets = d.parts.map { it.id }.toSet(); returning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إعادة للمراقب") }
                    }
                    Text("تصدير ومشاركة", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RaneenOutlinedButton(onClick = { export("pdf") }, modifier = Modifier.weight(1f)) { Text("PDF") }
                        RaneenOutlinedButton(onClick = { export("docx") }, modifier = Modifier.weight(1f)) { Text("Word") }
                        RaneenOutlinedButton(onClick = { export("xlsx") }, modifier = Modifier.weight(1f)) { Text("Excel") }
                    }
                    RaneenOutlinedButton(onClick = { export("zip") }, modifier = Modifier.fillMaxWidth()) { Text("تحميل الصور الأصلية (ZIP)") }
                    Text("التلات ملفات فيهم الصور المتاحة على الجهاز.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (confirmSubmit) AlertDialog(
            onDismissRequest = { confirmSubmit = false },
            title = { Text("إرسال التقرير؟") },
            text = {
                Text(
                    if (d.missingPhotos.isNotEmpty()) "فيه ${d.missingPhotos.size} مخالفة محتاجة صورة ومفيش عليها. تبعت برضو؟ مش هتقدر تعدّل بعد الإرسال."
                    else "هيتبعت لمدير المنطقة ومش هتقدر تعدّل بعد كده. متأكد؟"
                )
            },
            confirmButton = { TextButton(onClick = { confirmSubmit = false; act { val saveError = reports.saveGeneralVisitNotes(inspectionId, user, generalNotes.text); if (saveError != null) saveError else reports.submit(inspectionId, user) } }) { Text("إرسال") } },
            dismissButton = { TextButton(onClick = { confirmSubmit = false }) { Text("إلغاء") } }
        )
        if (returningToArea) AlertDialog(
            onDismissRequest = { returningToArea = false },
            title = { Text("إعادة إلى مدير المنطقة") },
            text = { OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب الإعادة (اختياري)") }, minLines = 2) },
            confirmButton = {
                TextButton(onClick = {
                    val r = reason
                    returningToArea = false
                    act { reports.returnToAreaManager(inspectionId, user, r) }
                }) { Text("إعادة إلى مدير المنطقة") }
            },
            dismissButton = { TextButton(onClick = { returningToArea = false }) { Text("إلغاء") } }
        )
        if (returning) AlertDialog(
            onDismissRequest = { returning = false },
            title = { Text("سبب الإعادة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (d.parts.size > 1) {
                        Text("ترجّع أنهي جزء؟", style = MaterialTheme.typography.bodySmall)
                        d.parts.forEach { part ->
                            Row(Modifier.fillMaxWidth().clickable { returnTargets = if (part.id in returnTargets) returnTargets - part.id else returnTargets + part.id }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = part.id in returnTargets, onCheckedChange = { returnTargets = if (it) returnTargets + part.id else returnTargets - part.id })
                                Text("${part.label} — ${part.inspectorName}")
                            }
                        }
                    }
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("سبب الإعادة (اختياري)") }, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(enabled = d.parts.size <= 1 || returnTargets.isNotEmpty(), onClick = {
                    val r = reason
                    val only = if (d.parts.size > 1) returnTargets else null
                    returning = false
                    act { reports.returnReport(inspectionId, user, r, only) }
                }) { Text("إعادة") }
            },
            dismissButton = { TextButton(onClick = { returning = false }) { Text("إلغاء") } }
        )
        preview?.let { PhotoDialog(it, false, {}, { preview = null }) }
    }
}

// ───────────── قائمة التقارير (مدير المنطقة / مدير الإدارة / الأدمن) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsListScreen(
    title: String, user: UserEntity, reports: ReportRepository, sync: SyncRepository,
    leaveLabel: String, onLeave: () -> Unit,
    unread: Int = 0, onChat: (() -> Unit)? = null,
    onNew: (() -> Unit)? = null,
    onOpen: (ReportRow) -> Unit
) {
    val rows by remember { reports.rows() }.collectAsState(initial = emptyList())
    fun needsAction(r: ReportRow) = (user.role == Roles.AREA_MANAGER && r.status == Status.SUBMITTED) ||
            (user.role == Roles.DEPT_MANAGER && r.status == Status.REVIEWED) ||
            (r.inspectorId == user.id && Status.editable(r.status))      // زيارتي أنا اللي محتاجة استكمال
    val isManager = user.role == Roles.AREA_MANAGER || user.role == Roles.DEPT_MANAGER
    var onlyPending by remember { mutableStateOf(isManager) }
    var showSeats by remember { mutableStateOf(false) }
    // مشاهد الإدارة: المعتمد نهائيًا فقط، ومن اللي السيرفر بعته له بس (مش أي تقرير تاني متخزّن على الموبايل)
    val viewerIds = remember(rows) { if (user.role == Roles.VIEWER) sync.viewerReportIds(user.id) else emptySet() }
    val scoped = if (user.role == Roles.VIEWER) rows.filter { it.status == Status.FINAL && it.id in viewerIds } else rows
    // المراقب مسوّدته مش المفروض تظهر للمديرين قبل الإرسال
    val visible = mergeVisitRows(scoped.filter { it.status != Status.DRAFT || it.inspectorId == user.id }).filter { !onlyPending || needsAction(it) }

    Scaffold(topBar = {
        RaneenTopBar(title = { Text(title) }, actions = {
            onChat?.let { ChatAction(unread, it) }
            TextButton(onClick = onLeave) { Text(leaveLabel) }
        })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.bodyMedium)
                SyncBar(sync)
                if (onNew != null) Button(onClick = onNew, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) { Text("＋ زيارة تفتيش جديدة") }
                if (user.role != Roles.VIEWER) OutlinedButton(onClick = { showSeats = true }, modifier = Modifier.fillMaxWidth()) { Text("🪑 المقاعد المحجوزة (إلغاء مقعد)") }
                if (isManager) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = onlyPending, onClick = { onlyPending = true }, label = { Text("تحتاج إجراء") })
                    FilterChip(selected = !onlyPending, onClick = { onlyPending = false }, label = { Text("الكل") })
                }
            }
            if (visible.isEmpty()) item { Text("مفيش تقارير.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(visible, key = { it.id }) { ReportRowCard(it, true) { onOpen(it) } }
        }
    }
    if (showSeats) OpenSeatsDialog(reports, onClose = { showSeats = false })
}

/** يعرض الوزن الأصلي والخصم الفعلي بنفس منطق احتساب درجات التطبيق. */
private fun ViolationRow.itemScoreLine(): String? {
    if (maxScore <= 0.0 || cnt <= 0) return null
    val deducted = controlLoss(
        ControlDef(controlId, categoryId = "", maxScore = maxScore, penaltyPerViolation = penaltyPerViolation),
        cnt
    ).coerceIn(0.0, maxScore)
    if (deducted <= 0.0) return null
    val remaining = (maxScore - deducted).coerceAtLeast(0.0)
    return "الوزن الأصلي: ${fmtWeight(maxScore)}  ·  الخصم: ${fmtWeight(deducted)}  ·  المتبقي: ${fmtWeight(remaining)}"
}

private fun ScoreBox(title: String, subtitle: String, value: Double?, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(fmtPct(value), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** المقاعد اللي مراقب حجزها ومشتغلش عليها: الأدمن / مدير المنطقة / مدير الإدارة يقدروا يلغوها. */
@Composable
private fun OpenSeatsDialog(reports: ReportRepository, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var seats by remember { mutableStateOf<List<OpenSeat>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var reload by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<OpenSeat?>(null) }
    LaunchedEffect(reload) {
        failed = false
        reports.openSeats().onSuccess { seats = it }.onFailure { failed = true }
    }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("المقاعد المحجوزة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مقاعد مراقبين فتحوا الزيارة ولسه ماأرسلوش. الإلغاء بيفك المقعد عشان مراقب تاني ياخده.", style = MaterialTheme.typography.bodySmall)
                when {
                    failed -> Text("محتاج اتصال بالإنترنت.", color = MaterialTheme.colorScheme.error)
                    seats == null -> CircularProgressIndicator(Modifier.size(24.dp))
                    seats!!.isEmpty() -> Text("مفيش مقاعد محجوزة دلوقتي.")
                    else -> seats!!.forEach { st ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(st.branchName, fontWeight = FontWeight.Bold)
                                Text("${evaluationTemplateLabel(st.templateId)} · الزيارة ${if (st.visit == "1") "الأولى" else "الثانية"} · ${st.month}", style = MaterialTheme.typography.bodySmall)
                                Text("${SeatStore.label(st.seat)} — ${st.holderName} · من ${st.createdAt}", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { confirm = st }, enabled = !busy) { Text("إلغاء المقعد", color = MaterialTheme.colorScheme.error) }
                            }
                        }
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = onClose, enabled = !busy) { Text("إغلاق") } }
    )
    confirm?.let { st ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("إلغاء المقعد؟") },
            text = { Text("هيتفك مقعد ${SeatStore.label(st.seat)} في ${st.branchName} (${st.holderName}). المراقب مش هيقدر يرفع التقرير ده بعد كده.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null; busy = true; error = null
                    scope.launch { error = reports.cancelSeat(st); busy = false; reload++ }
                }) { Text("إلغاء المقعد", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("رجوع") } }
        )
    }
}

private fun toast(ctx: android.content.Context, msg: String) { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
