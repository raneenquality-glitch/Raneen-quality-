package com.raneen.quality.ui

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

/** حالة إعدادات الكاميرا (مشتركة بين كاميرا الصور وكاميرا الفيديو). بتترجع للوضع الافتراضي لما الكاميرا تتبدّل. */
@Stable
class CameraSettingsState {
    var open by mutableStateOf(false)
    var grid by mutableStateOf(false)
    var manualFocus by mutableStateOf(false)
    /** 0 = بعيد (إنفينيتي) ... 1 = أقرب مسافة تركيز */
    var focusValue by mutableFloatStateOf(0f)
    var exposure by mutableFloatStateOf(0f)

    fun resetForCamera() { manualFocus = false; focusValue = 0f; exposure = 0f }
}

/** أقرب مسافة تركيز بالديوبتر. 0 = الكاميرا دي تركيزها ثابت (مفيش تركيز يدوي). */
@OptIn(ExperimentalCamera2Interop::class)
fun cameraMinFocusDiopters(cam: Camera): Float = try {
    Camera2CameraInfo.from(cam.cameraInfo).getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
} catch (_: Throwable) { 0f }

/** تركيز يدوي: بيقفل الأوتوفوكس ويثبّت مسافة التركيز. لما يتقفل بيرجع الأوتوفوكس العادي. */
@OptIn(ExperimentalCamera2Interop::class)
fun applyManualFocus(cam: Camera, enabled: Boolean, value: Float) {
    try {
        val ctl = Camera2CameraControl.from(cam.cameraControl)
        if (enabled) {
            val diopters = value.coerceIn(0f, 1f) * cameraMinFocusDiopters(cam)
            ctl.setCaptureRequestOptions(
                CaptureRequestOptions.Builder()
                    .setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
                    .setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, diopters)
                    .build()
            )
        } else {
            ctl.clearCaptureRequestOptions()
        }
    } catch (_: Throwable) { }
}

fun cameraExposureRange(cam: Camera): IntRange = try {
    val r = cam.cameraInfo.exposureState.exposureCompensationRange
    r.lower..r.upper
} catch (_: Throwable) { 0..0 }

fun applyExposure(cam: Camera, value: Float) {
    try { cam.cameraControl.setExposureCompensationIndex(value.roundToInt()) } catch (_: Throwable) { }
}

/** زوم بإصبعين + لمسة للتركيز. الدوال بتتحدّث لوحدها من غير ما الإيماءة تتقطع في نص القرص (ده كان سبب ضعف الزوم). */
@Composable
fun Modifier.cameraGestures(onZoomBy: (Float) -> Unit, onTap: (Offset) -> Unit): Modifier {
    val zoomBy by rememberUpdatedState(onZoomBy)
    val tap by rememberUpdatedState(onTap)
    return this
        .pointerInput(Unit) { detectTransformGestures { _, _, zoom, _ -> if (zoom != 1f) zoomBy(zoom) } }
        .pointerInput(Unit) { detectTapGestures { tap(it) } }
}

/** إطار التركيز اللي بيظهر مكان اللمسة (زي كاميرا الموبايل). */
@Composable
fun FocusRing(point: Offset?, onDone: () -> Unit) {
    if (point == null) return
    LaunchedEffect(point) { delay(1200); onDone() }
    val half = with(LocalDensity.current) { 34.dp.toPx() }
    Box(
        Modifier
            .offset { IntOffset((point.x - half).roundToInt(), (point.y - half).roundToInt()) }
            .size(68.dp)
            .border(2.dp, Color.White, RoundedCornerShape(10.dp))
    )
}

/** مؤشر الزوم الحالي (بدل أزرار + و -). التحكم بالقرص بإصبعين. */
@Composable
fun ZoomBadge(zoom: Float, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(String.format(Locale.US, "%.1fx", zoom), color = Color(0xFFFFB300), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        if (zoom <= 1.05f) Text("اقرص بإصبعين للتكبير", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

/** خطوط الشبكة (ثلث الصورة). */
@Composable
fun CameraGrid() {
    Canvas(Modifier.fillMaxSize()) {
        val c = Color.White.copy(alpha = 0.45f)
        for (i in 1..2) {
            val x = size.width * i / 3f
            val y = size.height * i / 3f
            drawLine(c, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1.5f)
            drawLine(c, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.5f)
        }
    }
}

/** يمنع الشاشة من الانطفاء/القفل طول ما الكاميرا مفتوحة (مهم أثناء تسجيل الفيديو الطويل). */
@Composable
fun KeepScreenOn() {
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
}

/** شريط إعدادات الكاميرا: شبكة + تعريض (إضاءة) + تركيز يدوي بسلايدر. */
@Composable
fun CameraSettingsPanel(state: CameraSettingsState, cam: Camera?, modifier: Modifier = Modifier) {
    if (!state.open) return
    val minFocus = remember(cam) { cam?.let { cameraMinFocusDiopters(it) } ?: 0f }
    val expRange = remember(cam) { cam?.let { cameraExposureRange(it) } ?: 0..0 }
    Column(
        modifier.fillMaxWidth().padding(horizontal = 12.dp)
            .background(Color(0xE6111111), RoundedCornerShape(14.dp))
            .padding(12.dp)
            .heightIn(max = 300.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("إعدادات الكاميرا", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { state.open = false }) { Text("إغلاق", color = Color(0xFFFFB300)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("خطوط الشبكة", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = state.grid, onCheckedChange = { state.grid = it })
        }
        if (expRange.last > expRange.first) {
            Text("الإضاءة (التعريض)", color = Color.White)
            Slider(
                value = state.exposure.coerceIn(expRange.first.toFloat(), expRange.last.toFloat()),
                onValueChange = { state.exposure = it },
                valueRange = expRange.first.toFloat()..expRange.last.toFloat(),
                steps = (expRange.last - expRange.first - 1).coerceAtLeast(0)
            )
        }
        if (minFocus > 0f) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تركيز يدوي", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = state.manualFocus, onCheckedChange = { state.manualFocus = it })
            }
            Slider(
                value = state.focusValue,
                onValueChange = { state.focusValue = it },
                enabled = state.manualFocus,
                valueRange = 0f..1f
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("بعيد", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                Text("قريب", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            }
        } else {
            Text("التركيز اليدوي غير مدعوم في الكاميرا دي (التركيز تلقائي).", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
        }
    }
}

/** بيطبّق إعدادات التعريض والتركيز اليدوي على الكاميرا كل ما تتغيّر. */
@Composable
fun ApplyCameraSettings(state: CameraSettingsState, cam: Camera?) {
    LaunchedEffect(cam, state.exposure) { cam?.let { applyExposure(it, state.exposure) } }
    LaunchedEffect(cam, state.manualFocus, state.focusValue) { cam?.let { applyManualFocus(it, state.manualFocus, state.focusValue) } }
}
