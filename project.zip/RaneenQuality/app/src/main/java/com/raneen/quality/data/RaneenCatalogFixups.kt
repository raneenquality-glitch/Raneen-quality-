package com.raneen.quality.data

/**
 * تعديلات ثابتة على أسماء/نصوص الكتالوج (idempotent: تتنفذ أكتر من مرة من غير ما تتكرر).
 * بتتطبق: بعد الـ seed، وعند سحب الكتالوج من السيرفر، وعلى قاعدة البيانات المحلية القديمة —
 * عشان كل الأجهزة تظهر نفس الأسماء حتى لو السيرفر لسه فيه الأسماء القديمة.
 */
object CatalogFixups {
    private const val SECTION_PREFIX = "قسم "
    private const val ADMIN_PREFIX = "إدارة "
    private val ADMIN_STARTS = listOf("إدارة", "ادارة", "الإدارة", "الادارة")
    private const val OLD_I13_HINT = "الصيانة درجتان، والدهان درجتان؛ يمكن تحديد كل جزء بشكل مستقل"
    private const val NEW_I13_HINT = "اختيار الصيانة أو الدهان (أو الاتنين) يخصم الوزن كامل (4 درجات)"

    /**
     * كل "قسم" اسمه يبدأ بكلمة قسم (قسم الأدوات المنزلية، قسم الألعاب ومستلزمات الأطفال...)،
     * وكل إدارة مساعدة اسمها يبدأ بكلمة إدارة (إدارة الكاميرات، إدارة الأمن، إدارة الصيانة...).
     */
    fun unitName(name: String, kind: String): String {
        val n = name.trim()
        return when (kind) {
            "SECTION" -> if (n.startsWith("قسم")) name else SECTION_PREFIX + n
            "ADMINISTRATION" -> if (ADMIN_STARTS.any { n.startsWith(it) }) name else ADMIN_PREFIX + n
            else -> name
        }
    }

    /** بند 13 صيانة: أي جزء (صيانة / دهان / الاتنين) = خصم الوزن كامل */
    fun controlHint(id: String, hint: String?): String? = if (id == "maintenance_i13" && hint == OLD_I13_HINT) NEW_I13_HINT else hint

    /** على قاعدة البيانات المحلية (من غير ما نعلّم الكتالوج "متعدّل" — مفيش رفع للسيرفر بسببها) */
    suspend fun applyToLocal(dao: CatalogDao) {
        val units = dao.allUnits().mapNotNull { u ->
            val n = unitName(u.name, u.kind); if (n != u.name) u.copy(name = n) else null
        }
        if (units.isNotEmpty()) dao.upsertUnits(units)
        val controls = dao.allControls().mapNotNull { c ->
            val h = controlHint(c.id, c.hint); if (h != c.hint) c.copy(hint = h) else null
        }
        if (controls.isNotEmpty()) dao.upsertControls(controls)
    }
}
