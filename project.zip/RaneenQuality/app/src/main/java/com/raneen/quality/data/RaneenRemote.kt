package com.raneen.quality.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** إعدادات Supabase. الـ publishable key آمن يتحط في التطبيق؛ الحماية الحقيقية بـ RLS على السيرفر. */
object SupabaseConfig {
    const val URL = "https://rdhmulfhwgdjtadpcsge.supabase.co"
    const val KEY = "sb_publishable_7zeqh0Qa5ppXCgqlohLVdA_JwtEEHoT"
    const val ADMIN_FUNCTION = "smart-processor"   // دالة إدارة المستخدمين (admin-users)
    const val BUCKET = "report-photos"
    const val EMAIL_DOMAIN = "raneen.app"
}

/** مفيش إنترنت / السيرفر مش متاح */
class NetworkException(cause: Throwable) : Exception(cause.message, cause)

/** السيرفر رد بخطأ (4xx/5xx) */
class ApiException(val code: Int, val body: String) : Exception("HTTP $code")

class Resp(val code: Int, val bytes: ByteArray) {
    val text: String get() = String(bytes, Charsets.UTF_8)
}

class Session(val access: String, val refresh: String, val expiresAt: Long, val userId: String)

/**
 * تخزين الجلسة مشفّر (EncryptedSharedPreferences بمفتاح من Android Keystore).
 * لو الجلسة القديمة كانت متخزنة عادي، بننقلها للمشفّر ونمسح القديم. لو الـ Keystore نفسه فيه مشكلة بنرجع للتخزين العادي بدل ما التطبيق يقع.
 */
private fun openSessionPrefs(context: Context): android.content.SharedPreferences {
    val app = context.applicationContext
    val plain = app.getSharedPreferences("raneen_session", Context.MODE_PRIVATE)
    fun create() = androidx.security.crypto.EncryptedSharedPreferences.create(
        app, "raneen_session_enc",
        androidx.security.crypto.MasterKey.Builder(app).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build(),
        androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    val enc = try { create() } catch (e: Exception) {
        try { app.deleteSharedPreferences("raneen_session_enc"); create() } catch (e2: Exception) { return plain }
    }
    if (plain.contains("a")) {
        enc.edit().putString("a", plain.getString("a", null)).putString("r", plain.getString("r", null))
            .putLong("e", plain.getLong("e", 0L)).putString("u", plain.getString("u", null)).apply()
        plain.edit().clear().apply()
    }
    return enc
}

/** عميل HTTP بسيط (من غير مكتبات): Auth + REST + Storage + Edge Function */
class SupabaseRemote(context: Context) {
    private val prefs: android.content.SharedPreferences = openSessionPrefs(context)

    fun session(): Session? {
        val a = prefs.getString("a", null) ?: return null
        val r = prefs.getString("r", null) ?: return null
        val u = prefs.getString("u", null) ?: return null
        return Session(a, r, prefs.getLong("e", 0L), u)
    }

    private fun save(s: Session) {
        prefs.edit().putString("a", s.access).putString("r", s.refresh).putLong("e", s.expiresAt).putString("u", s.userId).apply()
    }

    fun clearSession() { prefs.edit().clear().apply() }

    private fun raw(
        method: String, path: String, token: String?, body: ByteArray? = null,
        contentType: String? = null, extra: Map<String, String> = emptyMap(), readTimeout: Int = 30_000
    ): Resp {
        val conn = URL(SupabaseConfig.URL + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeout
            conn.setRequestProperty("apikey", SupabaseConfig.KEY)
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType)
            extra.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code >= 400) throw ApiException(code, String(bytes, Charsets.UTF_8))
            return Resp(code, bytes)
        } catch (e: IOException) {
            throw NetworkException(e)
        } finally {
            conn.disconnect()
        }
    }

    private fun parseSession(j: JSONObject): Session = Session(
        access = j.getString("access_token"),
        refresh = j.getString("refresh_token"),
        expiresAt = System.currentTimeMillis() + j.optLong("expires_in", 3600L) * 1000,
        userId = j.getJSONObject("user").getString("id")
    )

    fun signIn(email: String, password: String): Session {
        val body = JSONObject().put("email", email).put("password", password).toString().toByteArray(Charsets.UTF_8)
        val s = parseSession(JSONObject(raw("POST", "/auth/v1/token?grant_type=password", null, body, "application/json").text))
        save(s)
        return s
    }

    /** بيرجّع access token صالح، ولو قارب على الانتهاء بيجدده */
    @Synchronized
    private fun token(): String {
        val s = session() ?: throw ApiException(401, "no session")
        if (System.currentTimeMillis() < s.expiresAt - 60_000) return s.access
        try {
            val body = JSONObject().put("refresh_token", s.refresh).toString().toByteArray(Charsets.UTF_8)
            val n = parseSession(JSONObject(raw("POST", "/auth/v1/token?grant_type=refresh_token", null, body, "application/json").text))
            save(n)
            return n.access
        } catch (e: ApiException) {
            if (e.code in 400..403) clearSession()
            throw e
        }
    }

    fun get(path: String): String = raw("GET", path, token()).text

    fun post(path: String, json: String): String =
        raw("POST", path, token(), json.toByteArray(Charsets.UTF_8), "application/json").text

    fun rpc(fn: String, json: String): String = post("/rest/v1/rpc/$fn", json)

    /** توكن صالح (بيجدّد لو لزم) أو null: بنستخدمه عند الخروج عشان نفصل الجهاز قبل مسح الجلسة */
    fun freshAccessToken(): String? = try { token() } catch (e: Exception) { null }

    /** استدعاء دالة بتوكن محدد (من غير ما نعتمد على الجلسة المحلية) */
    fun rpcWithToken(accessToken: String, fn: String, json: String) {
        raw("POST", "/rest/v1/rpc/$fn", accessToken, json.toByteArray(Charsets.UTF_8), "application/json")
    }

    /** POST مع هيدر Prefer (مثلًا ignore-duplicates عشان إعادة الإرسال متكررش الصف) */
    fun postPrefer(path: String, json: String, prefer: String): String =
        raw("POST", path, token(), json.toByteArray(Charsets.UTF_8), "application/json", mapOf("Prefer" to prefer)).text

    fun patch(path: String, json: String) {
        raw("PATCH", path, token(), json.toByteArray(Charsets.UTF_8), "application/json", mapOf("Prefer" to "return=minimal"))
    }

    fun putUser(json: String) {
        raw("PUT", "/auth/v1/user", token(), json.toByteArray(Charsets.UTF_8), "application/json")
    }

    // ───────── وسائط التقارير على Backblaze B2 ─────────
    // وظيفة swift-worker بتتأكد من المستخدم وبتديله رابط مؤقت (15 دقيقة)، والرفع/التنزيل بيحصل على الرابط مباشرة.
    // التقارير القديمة اللي لسه على Supabase بتتقرا منها (fallback) من غير أي نقل بيانات.

    /** آخر سبب فشل لـ B2 (null = سليم). بنعرضه في حالة المزامنة عشان أي مشكلة تبان بدل ما التقرير يفضل واقف من غير تفسير */
    @Volatile var lastB2Error: String? = null

    private fun b2Reason(e: ApiException): String {
        val j = try { JSONObject(e.body) } catch (ex: Exception) { null }
        val fromJson = j?.optString("error")?.takeIf { it.isNotBlank() } ?: j?.optString("message")?.takeIf { it.isNotBlank() }
        val xmlCode = Regex("<Code>(.*?)</Code>").find(e.body)?.groupValues?.get(1)
        val xmlMsg = Regex("<Message>(.*?)</Message>").find(e.body)?.groupValues?.get(1)
        val xml = listOfNotNull(xmlCode, xmlMsg?.take(50)).joinToString(" - ").ifBlank { null }
        return "(${e.code}) ${fromJson ?: xml ?: e.body.take(60)}"
    }

    private fun b2Url(action: String, objectPath: String): String {
        val body = JSONObject().put("action", action).put("path", objectPath).toString().toByteArray(Charsets.UTF_8)
        return JSONObject(raw("POST", "/functions/v1/swift-worker", token(), body, "application/json").text).getString("url")
    }

    /** طلب على رابط موقّع كامل (من غير هيدرات Supabase، عشان توقيع S3 ما يتعارضش) */
    private fun rawUrl(method: String, url: String, body: ByteArray? = null, contentType: String? = null, readTimeout: Int = 90_000): Resp {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeout
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType)
            if (body != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code >= 400) throw ApiException(code, String(bytes, Charsets.UTF_8))
            return Resp(code, bytes)
        } catch (e: IOException) {
            throw NetworkException(e)
        } finally {
            conn.disconnect()
        }
    }

    /** رفع ملف بالـ streaming (من غير ما نحمّله كله في الذاكرة) */
    private fun sendFile(method: String, url: String, file: File, contentType: String, headers: Map<String, String>, readTimeout: Int): Resp {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeout
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.setRequestProperty("Content-Type", contentType)
            conn.doOutput = true
            conn.setFixedLengthStreamingMode(file.length())
            file.inputStream().use { input -> conn.outputStream.use { out -> input.copyTo(out, 64 * 1024) } }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code >= 400) throw ApiException(code, String(bytes, Charsets.UTF_8))
            return Resp(code, bytes)
        } catch (e: IOException) {
            throw NetworkException(e)
        } finally {
            conn.disconnect()
        }
    }

    /** تنزيل ملف بالـ streaming لملف مؤقت (.part) وبعدين نسميه — فلو الاتصال قطع مفيش ملف نصفه يفضل بالاسم الصح */
    private fun streamDownload(url: String, headers: Map<String, String>, dest: File, readTimeout: Int) {
        val conn = URL(url).openConnection() as HttpURLConnection
        val part = File(dest.path + ".part")
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeout
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val code = conn.responseCode
            if (code >= 400) throw ApiException(code, String(conn.errorStream?.use { it.readBytes() } ?: ByteArray(0), Charsets.UTF_8))
            dest.parentFile?.mkdirs()
            conn.inputStream.use { input -> part.outputStream().use { out -> input.copyTo(out, 64 * 1024) } }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("rename failed")
        } catch (e: IOException) {
            part.delete()
            throw NetworkException(e)
        } finally {
            conn.disconnect()
        }
    }

    private fun supabaseHeaders(extra: Map<String, String> = emptyMap()): Map<String, String> =
        mapOf("apikey" to SupabaseConfig.KEY, "Authorization" to "Bearer ${token()}") + extra

    /** الرفع على Supabase أولًا (مفيش اعتماد على B2). نقل الملف لـ B2 بيحصل بعد كده على السيرفر في الخلفية (media-transfer). */
    fun upload(objectPath: String, file: File) {
        val mime = if (objectPath.endsWith(".mp4")) "video/mp4" else "image/jpeg"
        val timeout = if (file.length() > 5L * 1024 * 1024) 240_000 else 90_000
        sendFile("POST", SupabaseConfig.URL + "/storage/v1/object/${SupabaseConfig.BUCKET}/$objectPath", file, mime, supabaseHeaders(mapOf("x-upsert" to "true")), timeout)
    }

    /** بينبّه وظيفة النقل تشتغل (بترد فورًا والشغل بيكمل على السيرفر). لو فشل مفيش مشكلة: الدفعة الجاية أو الـ cron هيكمّلوا. */
    fun kickTransfer() {
        try {
            raw("POST", "/functions/v1/media-transfer", token(), """{"action":"run"}""".toByteArray(Charsets.UTF_8), "application/json")
        } catch (e: Exception) { /* مش مهم */ }
    }

    fun download(objectPath: String, dest: File) {
        try {
            streamDownload(b2Url("get", objectPath), emptyMap(), dest, 240_000)
        } catch (e: ApiException) {
            if (e.code != 404) lastB2Error = "B2 تنزيل ${b2Reason(e)}"
            // مش موجود على B2 (تقرير قديم) أو B2 واقف: نجرّب Supabase
            streamDownload(SupabaseConfig.URL + "/storage/v1/object/authenticated/${SupabaseConfig.BUCKET}/$objectPath", supabaseHeaders(), dest, 240_000)
        }
    }

    /** رفع مرفق شات على bucket الشات الخاص. من غير upsert؛ لو الملف موجود (إعادة محاولة) بنعتبرها نجاح. */
    fun uploadChat(objectPath: String, file: File) {
        val mime = if (objectPath.endsWith(".mp4")) "video/mp4" else "image/jpeg"
        try {
            sendFile("POST", SupabaseConfig.URL + "/storage/v1/object/chat-media/$objectPath", file, mime, supabaseHeaders(),
                if (file.length() > 5L * 1024 * 1024) 240_000 else 90_000)
        } catch (e: ApiException) {
            val dup = e.code == 409 || e.body.contains("Duplicate", ignoreCase = true) || e.body.contains("already exists", ignoreCase = true)
            if (!dup) throw e
        }
    }

    fun downloadChat(objectPath: String, dest: File) {
        streamDownload(SupabaseConfig.URL + "/storage/v1/object/authenticated/chat-media/$objectPath", supabaseHeaders(), dest, 240_000)
    }

    /** حذف صورة من السحابة (لو مش موجودة أصلًا مفيش مشكلة) */
    fun deleteObject(objectPath: String) {
        // Backblaze: الوظيفة بتمسح من جهتها (ملف مش موجود = مفيش مشكلة)
        try {
            raw("POST", "/functions/v1/swift-worker", token(),
                JSONObject().put("action", "delete").put("path", objectPath).toString().toByteArray(Charsets.UTF_8), "application/json")
        } catch (e: ApiException) {
            if (e.code != 404 && e.code != 400) lastB2Error = "B2 حذف ${b2Reason(e)}"   // ما نوقفش مسح نسخة Supabase بسبب B2
        }
        // Supabase: تقارير قديمة
        try {
            raw("DELETE", "/storage/v1/object/${SupabaseConfig.BUCKET}/$objectPath", token())
        } catch (e: ApiException) {
            if (e.code != 404 && e.code != 400) throw e
        }
    }

    fun callAdmin(json: String): JSONObject =
        JSONObject(raw("POST", "/functions/v1/${SupabaseConfig.ADMIN_FUNCTION}", token(), json.toByteArray(Charsets.UTF_8), "application/json").text)
}
