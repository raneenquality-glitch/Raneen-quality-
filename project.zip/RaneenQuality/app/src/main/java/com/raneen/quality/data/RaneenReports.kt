package com.raneen.quality.data

import android.content.Context
import androidx.room.withTransaction
import com.raneen.quality.domain.UnitScore
import com.raneen.quality.domain.kindAverage
import com.raneen.quality.domain.scoreUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import java.util.UUID

object Status {
    const val DRAFT = "DRAFT"
    const val SUBMITTED = "SUBMITTED"
    const val REVIEWED = "REVIEWED"
    const val RETURNED = "RETURNED"
    const val FINAL = "FINAL_APPROVED"

    fun label(s: String) = when (s) {
        DRAFT -> "مسودة"
        SUBMITTED -> "مُرسل — بانتظار مدير المنطقة"
        REVIEWED -> "تمت المراجعة — بانتظار مدير الإدارة"
        RETURNED -> "أُعيد للمراقب للتعديل"
        FINAL -> "معتمد نهائيًا"
        else -> s
    }
    fun short(s: String) = when (s) {
        DRAFT -> "مسودة"; SUBMITTED -> "مُرسل"; REVIEWED -> "تمت المراجعة"
        RETURNED -> "مُعاد"; FINAL -> "معتمد"; else -> s
    }
    fun editable(s: String) = s == DRAFT || s == RETURNED

    fun actionLabel(a: String) = when (a) {
        "SUBMITTED" -> "إرسال التقرير"; "RESUBMITTED" -> "إعادة إرسال بعد التعديل"
        "REVIEWED" -> "مراجعة واعتماد (مدير المنطقة)"; "RETURNED" -> "إعادة للتعديل"
        "FINAL_APPROVED" -> "اعتماد نهائي"; else -> a
    }
}

data class UnitLine(val unit: EvaluationUnitEntity, val isNA: Boolean, val score: UnitScore?, val violationCount: Int)

/** سطر ضابط حصر في التقرير: الأعداد لكل مجموعة (parts) ومجموعها */
data class CensusLine(
    val unitId: String, val unitName: String, val categoryName: String, val controlId: String,
    val controlText: String, val parts: List<Int>, val unitPrice: Double = 0.0,
    val amountOverride: Double? = null
) {
    val total: Int get() = parts.sum()
    val expr: String get() = if (parts.size > 1) "(${parts.joinToString("+")}) = $total" else "$total"
    val amount: Double get() = amountOverride ?: total * unitPrice
    val priced: Boolean get() = controlText.replace(" ", "").let { it.contains("بدونكود") || it.contains("كودتالف") || it.contains("كودخطأ") || it.contains("أبديتمسمى") || it.contains("ابديتمسمى") }
}

data class ReportData(
    val inspection: InspectionEntity,
    val branchName: String,
    val inspectorName: String,
    val units: List<UnitLine>,
    val sectionsAvg: Double?,
    val adminsAvg: Double?,
    val violations: List<ViolationRow>,
    val photosByFinding: Map<String, List<PhotoEntity>>,
    val census: List<CensusLine> = emptyList()
) {
    /** مخالفات بنودها بتطلب صورة ومفيش عليها صورة */
    val missingPhotos: List<ViolationRow>
        get() = violations.filter { it.photoRequired && photosByFinding[it.findingId].isNullOrEmpty() }
}

class ReportRepository(
    private val db: RaneenDatabase,
    private val appContext: Context,
    private val remote: SupabaseRemote,
    private val sync: SyncRepository
) {
    private val dao = db.inspectionDao()

    fun rows(): Flow<List<ReportRow>> = dao.observeReportRows()
    fun inspectionFlow(id: String): Flow<InspectionEntity?> = dao.observeInspection(id)
    fun audit(id: String): Flow<List<AuditEntity>> = dao.observeAudit(id)

    suspend fun build(id: String): ReportData? = withContext(Dispatchers.IO) {
        val insp = dao.inspection(id) ?: return@withContext null
        val units = dao.activeUnits(insp.templateId)
        val na = dao.unitStates(id).filter { it.isNA }.map { it.unitId }.toSet()
        val lines = units.map { u ->
            if (u.id in na) UnitLine(u, true, null, 0)
            else {
                val findings = dao.findingsFor(id, u.id)
                val defs = dao.controlDefs(u.id)
                val censusIds = defs.filter { it.maxScore <= 0 }.map { it.id }.toSet()
                UnitLine(u, false, scoreUnit(defs, findings), findings.count { it.violations > 0 && it.controlId !in censusIds })
            }
        }
        ReportData(
            inspection = insp,
            branchName = dao.branchName(insp.branchId) ?: "",
            inspectorName = dao.userName(insp.inspectorId) ?: "",
            units = lines,
            sectionsAvg = kindAverage(lines.filter { it.unit.kind == "SECTION" }.map { it.score?.percent }),
            adminsAvg = kindAverage(lines.filter { it.unit.kind == "ADMINISTRATION" }.map { it.score?.percent }),
            violations = dao.violations(id).filter { it.unitId !in na },
            photosByFinding = dao.photosOfInspection(id).groupBy { it.findingId },
            census = dao.censusRows(id).filter { it.unitId !in na }.groupBy { it.unitId to it.controlId }.map { (_, rows) ->
                val f = rows.first()
                CensusLine(
                    f.unitId, f.unitName, f.categoryName, f.controlId, f.controlText,
                    rows.map { it.cnt }, 0.0,
                    rows.sumOf { row ->
                        val rowPrice = row.note?.takeIf { n -> n.startsWith("PRICE:") }
                            ?.removePrefix("PRICE:")?.toDoubleOrNull() ?: 0.0
                        row.cnt * rowPrice
                    }
                )
            }
        )
    }

    // ───────── تغيير الحالة (كل إجراء بيتسجل في سجل المراجعة) ─────────
    private suspend fun log(id: String, actor: UserEntity, action: String, note: String?) =
        dao.insertAudit(AuditEntity(UUID.randomUUID().toString(), id, action, actor.name, actor.role, note, System.currentTimeMillis()))

    /** حفظ الملاحظات العامة للزيارة أثناء المسودة أو بعد الإعادة. */
    suspend fun saveGeneralVisitNotes(id: String, actor: UserEntity, notes: String): String? {
        val i = dao.inspection(id) ?: return "التقرير غير موجود"
        if (actor.role != Roles.INSPECTOR || i.inspectorId != actor.id) return "غير مصرّح"
        if (!Status.editable(i.status)) return "التقرير اتبعت قبل كده"
        dao.setInspectionNotes(id, notes.trim().ifBlank { null })
        return null
    }

    /** المراقب (صاحب الزيارة) بيرسل من مسودة أو بعد الإعادة. الرفع للسيرفر بيحصل لوحده لما يبقى فيه إنترنت. */
    suspend fun submit(id: String, actor: UserEntity): String? {
        val err: String? = db.withTransaction {
            val i = dao.inspection(id) ?: return@withTransaction "التقرير غير موجود"
            if (actor.role != Roles.INSPECTOR || i.inspectorId != actor.id) return@withTransaction "غير مصرّح"
            if (!Status.editable(i.status)) return@withTransaction "التقرير اتبعت قبل كده"
            if (i.notes.isNullOrBlank()) return@withTransaction "اكتب الملاحظات العامة للزيارة قبل إرسال التقرير"
            dao.setStatus(id, Status.SUBMITTED)
            dao.setSync(id, "PENDING")
            log(id, actor, if (i.status == Status.RETURNED) "RESUBMITTED" else "SUBMITTED", null)
            null
        }
        if (err == null) sync.kick()
        return err
    }

    /** الاعتماد والإعادة بيتنفّذوا على السيرفر الأول (قواعد الصلاحيات هناك)، فمحتاجين إنترنت */
    private suspend fun remoteReview(id: String, action: String, note: String?): String? = withContext(Dispatchers.IO) {
        try {
            remote.rpc(
                "review_report",
                JSONObject().put("p_id", id).put("p_action", action).put("p_note", note ?: JSONObject.NULL).toString()
            )
            null
        } catch (e: NetworkException) {
            "محتاج اتصال بالإنترنت للاعتماد"
        } catch (e: ApiException) {
            val msg = try { JSONObject(e.body).optString("message") } catch (ex: Exception) { "" }
            when {
                e.code == 401 -> "الجلسة انتهت. اخرج وادخل تاني"
                msg.contains("not found") -> "التقرير مش موجود على السيرفر — المراقب لسه ماأرسلهوش. استنى مزامنته وجرّب تاني"
                else -> "السيرفر رفض العملية (${e.code}): ${msg.take(120)}"
            }
        }
    }

    private fun notUploaded(i: InspectionEntity) = i.syncState == "PENDING"
    private val notUploadedMsg = "التقرير لسه ماترفعش للسيرفر. استنى المزامنة وجرّب تاني"

    suspend fun areaApprove(id: String, actor: UserEntity): String? {
        val i = dao.inspection(id) ?: return "التقرير غير موجود"
        if (actor.role != Roles.AREA_MANAGER) return "غير مصرّح"
        if (i.status != Status.SUBMITTED) return "حالة التقرير اتغيّرت"
        if (notUploaded(i)) return notUploadedMsg
        remoteReview(id, "REVIEWED", null)?.let { return it }
        db.withTransaction { dao.setStatus(id, Status.REVIEWED); log(id, actor, "REVIEWED", null) }
        sync.kick()
        return null
    }

    /**
     * الاعتماد النهائي (مدير الإدارة): لازم كل الصور تكون على موبايله الأول، وبعد الاعتماد بيتحفظ
     * PDF + ZIP بالصور الأصلية في Downloads/Raneen. بيرجّع (رسالة خطأ، رسالة نجاح).
     */
    suspend fun finalApprove(id: String, actor: UserEntity): Pair<String?, String?> {
        val i = dao.inspection(id) ?: return "التقرير غير موجود" to null
        if (actor.role != Roles.DEPT_MANAGER) return "غير مصرّح" to null
        if (i.status != Status.REVIEWED) return "حالة التقرير اتغيّرت" to null
        if (notUploaded(i)) return notUploadedMsg to null
        sync.ensurePhotos(id)?.let { return it to null }
        remoteReview(id, "FINAL_APPROVED", null)?.let { return it to null }
        db.withTransaction { dao.setStatus(id, Status.FINAL); log(id, actor, "FINAL_APPROVED", null) }
        val note = try { archive(id) } catch (e: Exception) { "اتعتمد التقرير، بس تعذّر حفظ نسخة الأرشيف — صدّرها بإيدك من أزرار التصدير." }
        sync.kick()
        return null to note
    }

    private suspend fun archive(id: String): String = withContext(Dispatchers.IO) {
        val d = build(id) ?: return@withContext "اتعتمد التقرير."
        val pdf = ReportExporter.pdf(appContext, d)
        val zip = ReportExporter.photosZip(appContext, d)
        val okPdf = ReportExporter.saveToDownloads(appContext, pdf, ReportExporter.MIME_PDF)
        val okZip = if (zip != null) ReportExporter.saveToDownloads(appContext, zip, "application/zip") else true
        if (okPdf && okZip) "اتحفظ التقرير PDF" + (if (zip != null) " وملف الصور (ZIP)" else "") + " في مجلد Downloads/Raneen."
        else "اتعتمد التقرير، بس تعذّر حفظ نسخة الأرشيف — صدّرها بإيدك."
    }

    /** مدير المنطقة بيعيد المُرسل، ومدير الإدارة بيعيد اللي اتراجع. السبب إجباري. */
    suspend fun returnReport(id: String, actor: UserEntity, reason: String): String? {
        if (reason.isBlank()) return "اكتب سبب الإعادة"
        val i = dao.inspection(id) ?: return "التقرير غير موجود"
        val ok = (actor.role == Roles.AREA_MANAGER && i.status == Status.SUBMITTED) ||
                 (actor.role == Roles.DEPT_MANAGER && i.status == Status.REVIEWED)
        if (!ok) return "مش مسموح بالإعادة في الحالة دي"
        if (notUploaded(i)) return notUploadedMsg
        remoteReview(id, "RETURNED", reason.trim())?.let { return it }
        db.withTransaction { dao.setStatus(id, Status.RETURNED); log(id, actor, "RETURNED", reason.trim()) }
        sync.kick()
        return null
    }

    /** المراقب بيمسح صور تقريره من موبايله بإيده (بعد ما التقرير يتبعت ويتزامن) */
    suspend fun deleteMyPhotos(id: String, actor: UserEntity): String? = withContext(Dispatchers.IO) {
        val i = dao.inspection(id) ?: return@withContext "التقرير غير موجود"
        if (actor.role != Roles.INSPECTOR || i.inspectorId != actor.id) return@withContext "غير مصرّح"
        if (Status.editable(i.status) || i.syncState == "PENDING") return@withContext "استنى لحد ما التقرير يتبعت ويتزامن الأول"
        dao.photosOfInspection(id).forEach { File(it.filePath).delete(); dao.setPhotoSync(it.id, "PURGED") }
        null
    }

    suspend fun downloadMedia(inspectorId: String, inspectionId: String, p: PhotoEntity): String? =
        sync.downloadMedia(inspectorId, inspectionId, p)

    /** حذف مسودة (لسه مبعوتة) — بيمسح الصور من الجهاز كمان */
    suspend fun deleteDraft(id: String, actor: UserEntity): String? = withContext(Dispatchers.IO) {
        val i = dao.inspection(id) ?: return@withContext "التقرير غير موجود"
        if (i.inspectorId != actor.id || i.status != Status.DRAFT) return@withContext "مينفعش حذف التقرير ده"
        dao.photosOfInspection(id).forEach { File(it.filePath).delete() }
        db.withTransaction { dao.deleteAudit(id); dao.deleteInspection(id) }
        null
    }
}
