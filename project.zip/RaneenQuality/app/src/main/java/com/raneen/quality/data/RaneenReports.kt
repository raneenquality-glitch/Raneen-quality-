package com.raneen.quality.data

import android.content.Context
import androidx.room.withTransaction
import com.raneen.quality.domain.RENUMBER_UNITS
import com.raneen.quality.domain.UnitScore
import com.raneen.quality.domain.controlLoss
import com.raneen.quality.domain.itemScoreText
import com.raneen.quality.domain.kindAverage
import com.raneen.quality.domain.scoreUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import java.util.UUID

object Status {
    const val DRAFT = "DRAFT"
    const val SUBMITTED = "SUBMITTED"
    const val REVIEWED = "REVIEWED"
    const val RETURNED = "RETURNED"
    const val FINAL = "FINAL_APPROVED"

    fun label(s: String) = when (s) {
        DRAFT -> "مسودة"
        SUBMITTED -> "مُرسل — بانتظار مدير المنطقة"
        REVIEWED -> "تمت المراجعة — بانتظار نائب مدير الإدارة"
        RETURNED -> "أُعيد للمراقب للتعديل"
        FINAL -> "معتمد نهائيًا"
        else -> s
    }
    fun short(s: String) = when (s) {
        DRAFT -> "مسودة"; SUBMITTED -> "مُرسل"; REVIEWED -> "تمت المراجعة"
        RETURNED -> "مُعاد"; FINAL -> "معتمد"; else -> s
    }
    fun editable(s: String) = s == DRAFT || s == RETURNED

    /**
     * مين يقدر يعدّل محتوى التقرير: المراقب في المسودة/المُعاد، ومدير المنطقة وهو "مُرسل"،
     * ومدير الإدارة وهو "تمت المراجعة". بعد الاعتماد النهائي مفيش حد يعدّل.
     */
    fun editableBy(role: String, s: String) = editable(s) ||
        (role == Roles.AREA_MANAGER && s == SUBMITTED) ||
        (role == Roles.DEPT_MANAGER && (s == SUBMITTED || s == REVIEWED))

    fun actionLabel(a: String) = when (a) {
        "SUBMITTED" -> "إرسال التقرير"; "RESUBMITTED" -> "إعادة إرسال بعد التعديل"
        "REVIEWED" -> "مراجعة واعتماد (مدير المنطقة)"; "RETURNED" -> "إعادة للتعديل"
        "RETURN_TO_AREA" -> "إعادة إلى مدير المنطقة"
        "FINAL_APPROVED" -> "اعتماد نهائي"; "EDITED" -> "تعديل المحتوى (مدير)"; else -> a
    }
}

/**
 * priceViolations = إجمالي مخالفات الأسعار في القسم (من حصر الأسعار)،
 * وفي الاستلامات (FMC) = عدد الأقسام اللي اتاخدت فيها مخالفة في بند 1 وبند 2 (مجموعهم).
 */
data class UnitLine(val unit: EvaluationUnitEntity, val isNA: Boolean, val score: UnitScore?, val violationCount: Int, val priceViolations: Int = 0)

/** سطر ضابط حصر في التقرير: الأعداد لكل مجموعة (parts) ومجموعها */
data class CensusLine(
    val unitId: String, val unitName: String, val categoryName: String, val controlId: String,
    val controlText: String, val parts: List<Int>, val unitPrice: Double = 0.0,
    val amountOverride: Double? = null
) {
    val total: Int get() = parts.sum()
    val expr: String get() = if (parts.size > 1) "(${parts.joinToString("+")}) = $total" else "$total"
    val amount: Double get() = amountOverride ?: total * unitPrice
    val priced: Boolean get() = controlText.replace(" ", "").let { it.contains("بدونكود") || it.contains("كودتالف") || it.contains("كودخطأ") || it.contains("أبديتمسمى") || it.contains("ابديتمسمى") }
}

/** مين يقدر يعمل زيارات تفتيش: المراقب، ومدير المنطقة (أحيانًا التقييم بينزل من مدير المنطقة). */
fun canInspect(role: String): Boolean = role == Roles.INSPECTOR || role == Roles.AREA_MANAGER

/** تجميع الوحدات لحساب النتائج: MAIN = أقسام التشغيل (بما فيها الخدمات) • MANAGER = مدير المعرض (بيدخل في النتيجة النهائية بس، مش في متوسط أقسام التشغيل) • SUPPORT = الإدارات المساعدة. */
fun unitGroup(u: EvaluationUnitEntity): String = when {
    u.id == "branch_manager" || u.id == "zayed_branch_manager" -> "MANAGER"
    u.kind == "SECTION" -> "MAIN"
    else -> "SUPPORT"
}

/** نتايج نوع تقييم واحد (ديجيتال / أوف لاين / سمارت) في لوحة المديرين. */
data class SegScore(val key: String, val label: String, val visits: Int, val main: Double?, val fin: Double?)
data class ScoreSummary(val segs: List<SegScore>, val support: Double?, val supportVisits: Int, val months: List<String>)

/** جزء من الزيارة (مراقب واحد): الأقسام التشغيلية أو الإدارات المساعدة. */
/** نسبة وحدة واحدة لمشاهد الإدارة: متوسط على التقارير المعتمدة */
data class ViewerUnitStat(val unitName: String, val templateId: String, val avg: Double, val visits: Int, val violations: Int)
data class ViewerSummary(val stats: List<ViewerUnitStat>, val months: List<String>)

data class PartInfo(val id: String, val label: String, val inspectorId: String, val inspectorName: String, val status: String)

/** شهر الزيارة بتوقيت القاهرة (نفس طريقة السيرفر في ربط جزئي الزيارة). */
internal fun cairoMonth(ms: Long): String {
    val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Africa/Cairo")); c.timeInMillis = ms
    return String.format(java.util.Locale.US, "%04d-%02d", c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1)
}

private val STATUS_RANK = mapOf("DRAFT" to 0, "RETURNED" to 1, "SUBMITTED" to 2, "UNDER_REVIEW" to 3, "REVIEWED" to 4, "FINAL_APPROVED" to 5)

/** أقل حالة بين الجزئين (وأي جزء معاد = معاد). */
internal fun combinedStatus(statuses: List<String>): String =
    if (statuses.any { it == "RETURNED" }) "RETURNED" else statuses.minByOrNull { STATUS_RANK[it] ?: 0 } ?: "DRAFT"

/** قايمة التقارير: جزئي الزيارة الواحدة بيظهروا كارت واحد. */
fun mergeVisitRows(rows: List<ReportRow>): List<ReportRow> {
    val used = HashSet<String>()
    val out = ArrayList<ReportRow>()
    for (r in rows) {
        if (r.id in used) continue
        val partner = if (r.visitNumber == null || r.branchId.isEmpty()) null else rows.firstOrNull {
            it.id != r.id && it.id !in used && it.branchId == r.branchId && it.templateId == r.templateId && it.visitNumber == r.visitNumber &&
                it.inspectorId != r.inspectorId && cairoMonth(it.visitDate) == cairoMonth(r.visitDate)
        }
        if (partner == null) { out += r; continue }
        used += r.id; used += partner.id
        val primary = if (r.id < partner.id) r else partner
        out += primary.copy(status = combinedStatus(listOf(r.status, partner.status)), inspectorName = "${r.inspectorName} + ${partner.inspectorName}")
    }
    return out
}

data class ReportData(
    val inspection: InspectionEntity,
    val branchName: String,
    val inspectorName: String,
    val units: List<UnitLine>,
    val sectionsAvg: Double?,
    val adminsAvg: Double?,
    val violations: List<ViolationRow>,
    val photosByFinding: Map<String, List<PhotoEntity>>,
    val census: List<CensusLine> = emptyList(),
    val censusSummary: CensusSummary = CensusSummary(),
    /** لو الزيارة فيها مراقبين: الجزئين. وفاضية لو الزيارة جزء واحد. */
    val parts: List<PartInfo> = emptyList(),
    /** رقم الصورة → (المراقب صاحبها، التقرير بتاعها) عشان تنزيل صور الجزء التاني */
    val photoOwner: Map<String, Pair<String, String>> = emptyMap(),
    /** المخالفات والصور قبل دمج البند المكرر (عشان "بدون صورة" يتحسب على كل مجموعة لوحدها) */
    val rawViolations: List<ViolationRow>? = null,
    val rawPhotosByFinding: Map<String, List<PhotoEntity>>? = null
) {
    private fun groupAvg(pred: (UnitLine) -> Boolean): Double? =
        units.filter { !it.isNA && pred(it) }.mapNotNull { it.score?.percent }.let { if (it.isEmpty()) null else it.average() }
    /** متوسط أقسام التشغيل (بما فيها الخدمات، من غير مدير المعرض). */
    val mainAvg: Double? get() = groupAvg { unitGroup(it.unit) == "MAIN" }
    /** النتيجة النهائية: متوسط أقسام التشغيل + مدير المعرض (الإدارات المساعدة ليها نتيجتها لوحدها ومش داخلة هنا). */
    val finAvg: Double? get() = groupAvg { unitGroup(it.unit) != "SUPPORT" }
    /** الإدارات المساعدة: نتيجة نهائية واحدة لكلهم مجمّعين. */
    val supAvg: Double? get() = groupAvg { unitGroup(it.unit) == "SUPPORT" }

    /** مخالفات بنودها بتطلب صورة ومفيش عليها صورة */
    val missingPhotos: List<ViolationRow>
        get() = (rawViolations ?: violations).filter { it.photoRequired && (rawPhotosByFinding ?: photosByFinding)[it.findingId].isNullOrEmpty() }
}

class ReportRepository(
    private val db: RaneenDatabase,
    private val appContext: Context,
    private val remote: SupabaseRemote,
    private val sync: SyncRepository
) {
    private val dao = db.inspectionDao()

    fun rows(): Flow<List<ReportRow>> = dao.observeReportRows()
    fun inspectionFlow(id: String): Flow<InspectionEntity?> = dao.observeInspection(id)
    fun audit(id: String): Flow<List<AuditEntity>> = dao.observeAudit(id)

    /** التقرير كامل: لو الزيارة فيها مراقبين، بيجمع الجزئين في تقرير واحد (للعرض والتصدير). */
    suspend fun build(id: String): ReportData? = withContext(Dispatchers.IO) {
        val me = dao.inspection(id) ?: return@withContext null
        val partner = partnerOf(me)
        if (partner != null) cacheSeats(me, partner)
        val a = buildSingle(id) ?: return@withContext null
        val b = partner?.let { buildSingle(it.id) }
        mergeRepeatedItems(if (b == null) a else mergeParts(a, b))
    }

    /**
     * البند اللي اتكرر في التقرير (مجموعات ق1-ق4 أو أجزاء مختلفة) بيتحوّل لكارت واحد:
     * أسماء المجموعات مجمّعة، العدد مجموع، الملاحظات مجمّعة، وكل الصور تحته. الوزن والخصم والمتبقي بتفضل زي ما هي (محسوبة على البند كله).
     */
    private fun mergeRepeatedItems(d: ReportData): ReportData {
        val byControl = LinkedHashMap<String, MutableList<ViolationRow>>()
        d.violations.forEach { byControl.getOrPut(it.unitId + "|" + it.controlId) { ArrayList() }.add(it) }
        if (byControl.values.none { it.size > 1 }) return d
        val merged = ArrayList<ViolationRow>()
        val photos = HashMap(d.photosByFinding)
        for (rows in byControl.values) {
            val first = rows[0]
            if (rows.size == 1) { merged += first; continue }
            val groups = rows.mapNotNull { it.groupName?.takeIf { g -> g.isNotBlank() } }.distinct()
            val notes = rows.mapNotNull { r ->
                r.violationNote?.takeIf { it.isNotBlank() }?.let { n -> if (r.groupName.isNullOrBlank()) n else "${r.groupName}: $n" }
            }.distinct()
            merged += first.copy(
                groupName = groups.joinToString("، ").ifBlank { null },
                cnt = rows.sumOf { it.cnt },
                photoRequired = rows.any { it.photoRequired },
                violationNote = notes.joinToString(" — ").ifBlank { null }
            )
            photos[first.findingId] = rows.flatMap { d.photosByFinding[it.findingId].orEmpty() }.sortedBy { it.capturedAt }
            rows.drop(1).forEach { photos.remove(it.findingId) }
        }
        return d.copy(violations = merged, photosByFinding = photos, rawViolations = d.violations, rawPhotosByFinding = d.photosByFinding)
    }

    /** لوحة النتايج للمديرين: لكل نوع تقييم نتيجة مرحلية ونهائية، وللإدارات المساعدة نتيجة نهائية واحدة. month = "YYYY-MM" أو null للكل. */
    suspend fun scoreSummary(rows: List<ReportRow>, month: String?): ScoreSummary = withContext(Dispatchers.IO) {
        val visits = mergeVisitRows(rows.filter { it.status != Status.DRAFT })
        val months = visits.map { cairoMonth(it.visitDate) }.distinct().sortedDescending()
        val use = visits.filter { month == null || cairoMonth(it.visitDate) == month }
        val keys = listOf("digital" to "معارض الديجيتال", "offline" to "المعارض الأوف لاين", "smart" to "معارض سمارت")
        val main = keys.associate { it.first to ArrayList<Double>() }
        val fin = keys.associate { it.first to ArrayList<Double>() }
        val sup = ArrayList<Double>()
        for (v in use) {
            val d = build(v.id) ?: continue
            val seg = when (d.inspection.templateId) { "zayed", "smart" -> "smart"; "digital" -> "digital"; else -> "offline" }
            d.mainAvg?.let { main[seg]?.add(it) }
            d.finAvg?.let { fin[seg]?.add(it) }
            d.supAvg?.let { sup.add(it) }
        }
        fun avg(l: List<Double>): Double? = if (l.isEmpty()) null else l.average()
        ScoreSummary(
            keys.map { (k, label) -> SegScore(k, label, fin[k]!!.size, avg(main[k]!!), avg(fin[k]!!)) },
            avg(sup), sup.size, months
        )
    }

    private suspend fun partnerOf(i: InspectionEntity): InspectionEntity? {
        val v = i.visitNumber ?: return null
        return dao.sameVisitCandidates(i.branchId, i.templateId, v, i.id).firstOrNull {
            it.inspectorId != i.inspectorId && it.status != Status.DRAFT && cairoMonth(it.visitDate) == cairoMonth(i.visitDate)
        }
    }

    /** على جهاز المدير: بنعرف مقعد كل جزء من السيرفر مرة واحدة ونحفظه محليًا (عشان نعرف أقسام كل مراقب). */
    private val seatChecked = HashSet<String>()

    private fun cacheSeats(a: InspectionEntity, b: InspectionEntity) {
        if (SeatStore.getOrNull(a.id) != null && SeatStore.getOrNull(b.id) != null) return
        if (!seatChecked.add(a.id + "|" + b.id)) return
        val v = a.visitNumber ?: return
        val rows = try {
            org.json.JSONArray(remote.get("/rest/v1/visit_seats?select=seat,inspector_id,visit_month&branch_id=eq.${a.branchId}&template_id=eq.${a.templateId}&visit_number=eq.$v"))
        } catch (e: Exception) { return }
        val month = cairoMonth(a.visitDate)
        for (p in listOf(a, b)) {
            if (SeatStore.getOrNull(p.id) != null) continue
            val mine = (0 until rows.length()).map { rows.getJSONObject(it) }
                .filter { it.optString("inspector_id") == p.inspectorId && it.optString("visit_month") == month }
                .map { it.optString("seat") }
            when { mine.size >= 2 -> SeatStore.set(p.id, "BOTH"); mine.size == 1 -> SeatStore.set(p.id, mine[0]) }
        }
    }

    private suspend fun mergeParts(x: ReportData, y: ReportData): ReportData {
        val (a, b) = listOf(x, y).sortedBy { it.inspection.id }
        val fa = dao.findingsOf(a.inspection.id); val fb = dao.findingsOf(b.inspection.id)
        val unitIds = (a.units.map { it.unit.id } + b.units.map { it.unit.id }).distinct()
        // صاحب كل قسم: المراقب اللي مقعده يغطيه، ولو الاتنين بيغطوه (مقعد مش معروف) اللي عنده مخالفات أكتر
        val owner = unitIds.associateWith { u ->
            val inA = a.units.any { it.unit.id == u }; val inB = b.units.any { it.unit.id == u }
            when {
                inA && !inB -> 1
                inB && !inA -> 2
                fb.count { it.unitId == u } > fa.count { it.unitId == u } -> 2
                else -> 1
            }
        }
        val lines = unitIds.map { u -> (if (owner[u] == 1) a else b).units.first { it.unit.id == u } }
        val na = lines.filter { it.isNA }.map { it.unit.id }.toSet()
        fun label(d: ReportData, i: Int) = when (SeatStore.getOrNull(d.inspection.id)) {
            "OPERATIONAL" -> SeatStore.label("OPERATIONAL"); "SUPPORT" -> SeatStore.label("SUPPORT"); else -> "الجزء ${i + 1}"
        }
        val labels = listOf(label(a, 0), label(b, 1))
        val notes = listOf(a, b).mapIndexedNotNull { i, d ->
            d.inspection.notes?.takeIf { it.isNotBlank() }?.let { "${labels[i]} (${d.inspectorName}):\n$it" }
        }.joinToString("\n\n").ifBlank { null }
        val allFindings = fa.filter { owner[it.unitId] == 1 } + fb.filter { owner[it.unitId] == 2 }
        val photoOwner = HashMap<String, Pair<String, String>>()
        listOf(a, b).forEach { d -> d.photosByFinding.values.flatten().forEach { photoOwner[it.id] = d.inspection.inspectorId to d.inspection.id } }
        return ReportData(
            inspection = a.inspection.copy(status = combinedStatus(listOf(a.inspection.status, b.inspection.status)), notes = notes),
            branchName = a.branchName,
            inspectorName = "${a.inspectorName} + ${b.inspectorName}",
            units = lines,
            sectionsAvg = kindAverage(lines.filter { it.unit.kind == "SECTION" }.map { it.score?.percent }),
            adminsAvg = kindAverage(lines.filter { it.unit.kind == "ADMINISTRATION" }.map { it.score?.percent }),
            violations = a.violations.filter { owner[it.unitId] == 1 } + b.violations.filter { owner[it.unitId] == 2 },
            photosByFinding = a.photosByFinding + b.photosByFinding,
            census = a.census.filter { owner[it.unitId] == 1 } + b.census.filter { owner[it.unitId] == 2 },
            censusSummary = CensusSummaryBuilder.build(allFindings, na, lines.map { it.unit }),
            parts = listOf(a, b).mapIndexed { i, d -> PartInfo(d.inspection.id, labels[i], d.inspection.inspectorId, d.inspectorName, d.inspection.status) },
            photoOwner = photoOwner
        )
    }

    /** مشاهد الإدارة: بنعرض وحداته بس (اللي السيرفر بعتها)، مش كل وحدات القالب (وإلا الباقي هيظهر 100% غلط) */
    @Volatile var viewerMode: Boolean = false

    /** نسب إدارة المشاهد: متوسط كل وحدة على التقارير المعتمدة (month = "YYYY-MM" أو null للكل) */
    suspend fun viewerSummary(rows: List<ReportRow>, month: String?): ViewerSummary = withContext(Dispatchers.IO) {
        val visits = mergeVisitRows(rows.filter { it.status == Status.FINAL })
        val months = visits.map { cairoMonth(it.visitDate) }.distinct().sortedDescending()
        val pct = HashMap<String, ArrayList<Double>>()
        val viol = HashMap<String, Int>()
        val meta = HashMap<String, Pair<String, String>>()
        for (v in visits.filter { month == null || cairoMonth(it.visitDate) == month }) {
            val d = build(v.id) ?: continue
            for (l in d.units) {
                if (l.isNA) continue
                val s = l.score ?: continue
                val k = l.unit.id
                pct.getOrPut(k) { ArrayList() }.add(s.percent)
                viol[k] = (viol[k] ?: 0) + l.violationCount
                meta[k] = l.unit.name to d.inspection.templateId
            }
        }
        val stats = pct.map { (k, list) -> ViewerUnitStat(meta[k]!!.first, meta[k]!!.second, list.average(), list.size, viol[k] ?: 0) }
            .sortedWith(compareBy({ it.templateId }, { it.unitName }))
        ViewerSummary(stats, months)
    }

    private suspend fun buildSingle(id: String): ReportData? = withContext(Dispatchers.IO) {
        val insp = dao.inspection(id) ?: return@withContext null
        val seat = SeatStore.getOrNull(id)
        val states = dao.unitStates(id)
        var units = dao.activeUnits(insp.templateId).filter { SeatStore.allows(seat, it.kind) }
        if (viewerMode) { val mine = states.map { it.unitId }.toSet(); units = units.filter { it.id in mine } }
        val na = states.filter { it.isNA }.map { it.unitId }.toSet()
        val itemTotals = HashMap<String, Pair<Double, Double>>()   // البند → (الوزن الأصلي، مجموع الخصم)
        val displayNo = HashMap<String, Int>()                      // ترقيم متسلسل لأوراق مدير المعرض
        val allFindingsForPrices = dao.findingsOf(id)
        val lines = units.map { u ->
            if (u.id in na) UnitLine(u, true, null, 0)
            else {
                val findings = dao.findingsFor(id, u.id)
                val defs = dao.controlDefs(u.id)
                defs.forEach { d ->
                    if (d.maxScore > 0) itemTotals[d.id] = d.maxScore to controlLoss(d, findings.filter { it.controlId == d.id }.sumOf { it.violations })
                }
                if (u.id in RENUMBER_UNITS) dao.orderedControlIds(u.id).forEachIndexed { i, cid -> displayNo[cid] = i + 1 }
                val censusIds = defs.filter { it.maxScore <= 0 }.map { it.id }.toSet()
                val unitFindings = allFindingsForPrices.filter { it.unitId == u.id }
                val priceViolations = if (u.id == "receiving_fmc") {
                    // بند 1 + بند 2: كل قسم اتاخدت فيه مخالفة في أي بند منهم بيتحسب 1 (بند 1 في قسمين + بند 2 في قسم = 3)
                    unitFindings.filter { (it.controlId.endsWith("_i1") || it.controlId.endsWith("_i2")) && it.violationCount > 0 }
                        .map { it.controlId + "|" + it.groupId }.distinct().size
                } else CensusSummaryBuilder.build(unitFindings, emptySet(), listOf(u)).priceTotal
                UnitLine(u, false, scoreUnit(defs, findings), findings.count { it.violations > 0 && it.controlId !in censusIds }, priceViolations)
            }
        }
        ReportData(
            inspection = insp,
            branchName = dao.branchName(insp.branchId) ?: "",
            inspectorName = dao.userName(insp.inspectorId) ?: "",
            units = lines,
            sectionsAvg = kindAverage(lines.filter { it.unit.kind == "SECTION" }.map { it.score?.percent }),
            adminsAvg = kindAverage(lines.filter { it.unit.kind == "ADMINISTRATION" }.map { it.score?.percent }),
            violations = dao.violations(id).filter { it.unitId !in na }.map { v ->
                val t = itemTotals[v.controlId]
                v.copy(
                    controlNo = displayNo[v.controlId] ?: v.controlNo,
                    weight = t?.first ?: 0.0, deducted = t?.second ?: 0.0, remaining = (t?.first ?: 0.0) - (t?.second ?: 0.0)
                )
            },
            photosByFinding = dao.photosOfInspection(id).groupBy { it.findingId },
            censusSummary = CensusSummaryBuilder.build(dao.findingsOf(id), na, units),
            census = dao.censusRows(id).filter { it.unitId !in na }.groupBy { it.unitId to it.controlId }.map { (_, rows) ->
                val f = rows.first()
                CensusLine(
                    f.unitId, f.unitName, f.categoryName, f.controlId, f.controlText,
                    rows.map { it.cnt }, 0.0,
                    rows.sumOf { row ->
                        val rowPrice = row.note?.takeIf { n -> n.startsWith("PRICE:") }
                            ?.removePrefix("PRICE:")?.toDoubleOrNull() ?: 0.0
                        row.cnt * rowPrice
                    }
                )
            }
        )
    }

    /** المقاعد المحجوزة اللي لسه ماترفعش عليها تقرير، بأسماء الفروع والمراقبين. */
    suspend fun openSeats(): Result<List<OpenSeat>> = withContext(Dispatchers.IO) {
        VisitSeats.listOpen(remote).map { rows ->
            rows.map { o ->
                val inspector = o.optString("inspector_id")
                OpenSeat(
                    o.optString("branch_id"), dao.branchName(o.optString("branch_id")) ?: o.optString("branch_id"),
                    o.optString("template_id"), o.optString("visit_month"), o.optString("visit_number"),
                    o.optString("seat"), dao.userName(inspector) ?: "مراقب", o.optString("created_at").take(10)
                )
            }
        }
    }

    suspend fun cancelSeat(seat: OpenSeat): String? = withContext(Dispatchers.IO) { VisitSeats.cancel(remote, seat) }

    // تغيير الحالة (كل إجراء بيتسجل في سجل المراجعة)
    private suspend fun log(id: String, actor: UserEntity, action: String, note: String?) =
        dao.insertAudit(AuditEntity(UUID.randomUUID().toString(), id, action, actor.name, actor.role, note, System.currentTimeMillis()))

    /** حفظ الملاحظات العامة للزيارة أثناء المسودة أو بعد الإعادة. */
    suspend fun saveGeneralVisitNotes(id: String, actor: UserEntity, notes: String): String? {
        val i = dao.inspection(id) ?: return "التقرير غير موجود"
        if (!canInspect(actor.role) || i.inspectorId != actor.id) return "غير مصرّح"
        if (!Status.editable(i.status)) return "التقرير اتبعت قبل كده"
        dao.setInspectionNotes(id, notes.ifBlank { null })
        return null
    }

    /** المراقب (صاحب الزيارة) بيرسل من مسودة أو بعد الإعادة. الرفع للسيرفر بيحصل لوحده لما يبقى فيه إنترنت. */
    suspend fun submit(id: String, actor: UserEntity): String? {
        val err: String? = db.withTransaction {
            val i = dao.inspection(id) ?: return@withTransaction "التقرير غير موجود"
            if (!canInspect(actor.role) || i.inspectorId != actor.id) return@withTransaction "غير مصرّح"
            if (!Status.editable(i.status)) return@withTransaction "التقرير اتبعت قبل كده"
            if (i.notes.isNullOrBlank()) return@withTransaction "اكتب الملاحظات العامة للزيارة قبل إرسال التقرير"
            dao.setStatus(id, Status.SUBMITTED)
            dao.setSync(id, "PENDING")
            log(id, actor, if (i.status == Status.RETURNED) "RESUBMITTED" else "SUBMITTED", null)
            null
        }
        if (err == null) sync.kick()
        return err
    }

    /** الاعتماد والإعادة بيتنفّذوا على السيرفر الأول (قواعد الصلاحيات هناك)، فمحتاجين إنترنت */
    private suspend fun remoteReview(id: String, action: String, note: String?): String? = withContext(Dispatchers.IO) {
        try {
            remote.rpc(
                "review_report",
                JSONObject().put("p_id", id).put("p_action", action).put("p_note", note ?: JSONObject.NULL).toString()
            )
            null
        } catch (e: NetworkException) {
            "محتاج اتصال بالإنترنت للاعتماد"
        } catch (e: ApiException) {
            val msg = try { JSONObject(e.body).optString("message") } catch (ex: Exception) { "" }
            when {
                e.code == 401 -> "الجلسة انتهت. اخرج وادخل تاني"
                msg.contains("not found") -> "التقرير مش موجود على السيرفر — المراقب لسه ماأرسلهوش. استنى مزامنته وجرّب تاني"
                else -> "السيرفر رفض العملية (${e.code}): ${msg.take(120)}"
            }
        }
    }

    // PENDING_EDIT = تعديل مدير لسه ماترفعش: لازم يترفع قبل أي اعتماد/إعادة
    private fun notUploaded(i: InspectionEntity) = i.syncState == "PENDING" || i.syncState == "PENDING_EDIT"
    private val notUploadedMsg = "التقرير لسه ماترفعش للسيرفر. استنى المزامنة وجرّب تاني"

    /** الجزئين (أو الجزء الواحد) بتوع الزيارة اللي التقرير ده منها. */
    private suspend fun partsOf(id: String): List<InspectionEntity> {
        val me = dao.inspection(id) ?: return emptyList()
        return listOfNotNull(me, partnerOf(me)).sortedBy { it.id }
    }

    /** لو في مراقب حاجز مقعد ولسه ماسلّمش تقريره: مينفعش اعتماد قبل ما الجزئين يوصلوا. */
    private fun waitingGate(i: InspectionEntity): String? {
        val v = i.visitNumber ?: return null
        // لو التحقق من المقاعد فشل: نمنع الاعتماد (قبل كده كان بيعدّي)
        val seats = VisitSeats.status(remote, i.branchId, i.templateId, v).getOrNull()
            ?: return "تعذّر التحقق من حالة المقاعد. اتأكد من الإنترنت وحاول تاني."
        val open = seats.firstOrNull { !it.submitted } ?: return null
        return "في انتظار تقرير ${open.holder} (${SeatStore.label(open.seat)}) — مينفعش الاعتماد قبل ما الجزئين يوصلوا."
    }

    suspend fun areaApprove(id: String, actor: UserEntity): String? {
        val parts = partsOf(id)
        if (parts.isEmpty()) return "التقرير غير موجود"
        if (actor.role != Roles.AREA_MANAGER) return "غير مصرّح"
        withContext(Dispatchers.IO) { waitingGate(parts.first()) }?.let { return it }
        val targets = parts.filter { it.status == Status.SUBMITTED }
        if (targets.isEmpty()) return "حالة التقرير اتغيّرت"
        if (targets.any { notUploaded(it) }) return notUploadedMsg
        for (t in targets) {
            remoteReview(t.id, "REVIEWED", null)?.let { return it }
            db.withTransaction { dao.setStatus(t.id, Status.REVIEWED); log(t.id, actor, "REVIEWED", null) }
        }
        sync.kick()
        return null
    }

    /**
     * الاعتماد النهائي (مدير الإدارة): لازم كل الصور تكون على موبايله الأول، وبعد الاعتماد بيتحفظ
     * PDF + ZIP بالصور الأصلية في Downloads/Raneen. بيرجّع (رسالة خطأ، رسالة نجاح).
     */
    suspend fun finalApprove(id: String, actor: UserEntity): Pair<String?, String?> {
        val parts = partsOf(id)
        if (parts.isEmpty()) return "التقرير غير موجود" to null
        if (actor.role != Roles.DEPT_MANAGER) return "غير مصرّح" to null
        withContext(Dispatchers.IO) { waitingGate(parts.first()) }?.let { return it to null }
        val targets = parts.filter { it.status == Status.REVIEWED }
        if (targets.isEmpty()) return "حالة التقرير اتغيّرت" to null
        if (targets.any { notUploaded(it) }) return notUploadedMsg to null
        for (t in targets) sync.ensurePhotos(t.id)?.let { return it to null }
        for (t in targets) {
            remoteReview(t.id, "FINAL_APPROVED", null)?.let { return it to null }
            db.withTransaction { dao.setStatus(t.id, Status.FINAL); log(t.id, actor, "FINAL_APPROVED", null) }
        }
        val note = try { archive(id) } catch (e: Exception) { "اتعتمد التقرير، بس تعذّر حفظ نسخة الأرشيف — صدّرها بإيدك من أزرار التصدير." }
        sync.kick()
        return null to note
    }

    private suspend fun archive(id: String): String = withContext(Dispatchers.IO) {
        val d = build(id) ?: return@withContext "اتعتمد التقرير."
        val pdf = ReportExporter.pdf(appContext, d)
        val zip = ReportExporter.photosZip(appContext, d)
        val okPdf = ReportExporter.saveToDownloads(appContext, pdf, ReportExporter.MIME_PDF)
        val okZip = if (zip != null) ReportExporter.saveToDownloads(appContext, zip, "application/zip") else true
        if (okPdf && okZip) "اتحفظ التقرير PDF" + (if (zip != null) " وملف الصور (ZIP)" else "") + " في مجلد Downloads/Raneen."
        else "اتعتمد التقرير، بس تعذّر حفظ نسخة الأرشيف — صدّرها بإيدك."
    }

    /** مدير المنطقة بيعيد المُرسل، ومدير الإدارة بيعيد اللي اتراجع. السبب اختياري. onlyIds = أجزاء معينة من الزيارة (null = كلها). */
    suspend fun returnReport(id: String, actor: UserEntity, reason: String, onlyIds: Set<String>? = null): String? {
        val parts = partsOf(id).filter { onlyIds == null || it.id in onlyIds }
        if (parts.isEmpty()) return "التقرير غير موجود"
        val targets = parts.filter {
            (actor.role == Roles.AREA_MANAGER && it.status == Status.SUBMITTED) || (actor.role == Roles.DEPT_MANAGER && it.status == Status.REVIEWED)
        }
        if (targets.isEmpty()) return "مش مسموح بالإعادة في الحالة دي"
        if (targets.any { notUploaded(it) }) return notUploadedMsg
        val note = reason.trim().ifBlank { null }
        for (t in targets) {
            remoteReview(t.id, "RETURNED", note)?.let { return it }
            db.withTransaction { dao.setStatus(t.id, Status.RETURNED); log(t.id, actor, "RETURNED", note) }
        }
        sync.kick()
        return null
    }

    /** مدير الإدارة يعيد التقرير لمدير المنطقة للمراجعة مرة أخرى (الجزئين اللي حالتهم "تمت المراجعة"). */
    suspend fun returnToAreaManager(id: String, actor: UserEntity, reason: String): String? {
        val parts = partsOf(id)
        if (parts.isEmpty()) return "التقرير غير موجود"
        val targets = parts.filter { it.status == Status.REVIEWED }
        if (actor.role != Roles.DEPT_MANAGER || targets.isEmpty()) return "مش مسموح بالإعادة لمدير المنطقة في الحالة دي"
        if (targets.any { notUploaded(it) }) return notUploadedMsg
        val note = reason.trim().ifBlank { null }
        for (t in targets) {
            remoteReview(t.id, "RETURN_TO_AREA", note)?.let { return it }
            db.withTransaction { dao.setStatus(t.id, Status.SUBMITTED); log(t.id, actor, "RETURN_TO_AREA", note) }
        }
        sync.kick()
        return null
    }

    /** مدير بيعدّل محتوى التقرير (قبل الاعتماد النهائي): بنعلّم التقرير للرفع والمزامنة تبعته للسيرفر */
    suspend fun markManagerEdit(id: String, actor: UserEntity) {
        val i = dao.inspection(id) ?: return
        if (!Status.editableBy(actor.role, i.status) || actor.role == Roles.INSPECTOR || i.inspectorId == actor.id) return   // زيارة المستخدم نفسه مش "تعديل مدير"
        if (i.syncState != "PENDING_EDIT") dao.setSync(id, "PENDING_EDIT")
        sync.kick()
    }

    /** سياسة الاحتفاظ: لا يُسمح بمسح صور المراقب من الهاتف بعد رفعها. */
    suspend fun deleteMyPhotos(id: String, actor: UserEntity): String? = withContext(Dispatchers.IO) {
        "تم إيقاف حذف صور التقارير من الهاتف للحفاظ على النسخة الأصلية بعد الرفع."
    }

    suspend fun ensureImages(inspectionId: String, onProgress: () -> Unit = {}): String? = sync.ensureImages(inspectionId, onProgress)

    suspend fun mediaStatus(inspectionId: String): String? = sync.mediaStatus(inspectionId)

    suspend fun downloadMedia(inspectorId: String, inspectionId: String, p: PhotoEntity): String? =
        sync.downloadMedia(inspectorId, inspectionId, p)

    /** حذف مسودة (لسه مبعوتة) — بيمسح الصور من الجهاز كمان */
    suspend fun deleteDraft(id: String, actor: UserEntity): String? = withContext(Dispatchers.IO) {
        val i = dao.inspection(id) ?: return@withContext "التقرير غير موجود"
        if (i.inspectorId != actor.id || i.status != Status.DRAFT) return@withContext "مينفعش حذف التقرير ده"
        dao.photosOfInspection(id).forEach { File(it.filePath).delete() }
        db.withTransaction { dao.deleteAudit(id); dao.deleteInspection(id) }
        // فك المقعد المحجوز عشان مراقب تاني ياخده
        // فك المقعد: لو فشل (مفيش نت) بيتحط في طابور ويتعاد مع المزامنة بدل ما يضيع بصمت.
        // لو المقعد مش معروف محليًا بنحاول نفك الاتنين (السيرفر بيفك بس اللي المراقب ماسكه).
        val seats = SeatStore.getOrNull(id)?.let { listOf(it) } ?: listOf("OPERATIONAL", "SUPPORT")
        // لو المراقب لسه عنده تقرير شغّال تاني على نفس الزيارة: ما نفكش المقعد (ممكن يكون هو نفسه)
        val otherActive = dao.sameVisitCandidates(i.branchId, i.templateId, i.visitNumber ?: "", id)
            .any { it.inspectorId == actor.id && (it.status == Status.DRAFT || it.syncState == "PENDING") }
        if (!otherActive) seats.forEach { seat ->
            if (!VisitSeats.releaseSettled(remote, i.branchId, i.templateId, i.visitNumber ?: "", seat))
                SeatStore.queueRelease(i.branchId, i.templateId, i.visitNumber ?: "", seat)
        }
        SeatStore.clear(id)
        null
    }
}

/** "الوزن: 4 | الخصم: 3 | المتبقي: 1" لبند مخالف (null لو الوزن مش معروف) */
fun ViolationRow.itemScoreLine(): String? = if (weight > 0) itemScoreText(weight, deducted) else null
