package com.raneen.quality.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// ───────────── الأدوار ─────────────
object Roles {
    const val INSPECTOR = "INSPECTOR"        // مراقب جودة
    const val AREA_MANAGER = "AREA_MANAGER"  // مدير منطقة (مراجعة)
    const val DEPT_MANAGER = "DEPT_MANAGER"  // مدير إدارة (اعتماد نهائي)
    const val ADMIN = "ADMIN"                // مدير النظام
    val all = listOf(INSPECTOR, AREA_MANAGER, DEPT_MANAGER, ADMIN)
    fun label(r: String) = when (r) {
        INSPECTOR -> "مراقب جودة"; AREA_MANAGER -> "مدير منطقة"
        DEPT_MANAGER -> "مدير إدارة"; ADMIN -> "مدير النظام"; else -> r
    }
}

// ───────────── المستخدم ─────────────
@Entity(tableName = "users", indices = [Index(value = ["usernameKey"], unique = true)])
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val username: String,
    val usernameKey: String,          // lowercase للمقارنة (Admin = admin)
    val role: String,
    val passwordHash: String,         // Base64 من PBKDF2-HMAC-SHA256 — مفيش كلمة مرور نصية في أي مكان
    val salt: String,
    val iterations: Int,
    val mustChangePassword: Boolean = false,
    val isActive: Boolean = true
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE usernameKey = :key LIMIT 1")
    suspend fun byUsername(key: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY name")
    fun observeAll(): Flow<List<UserEntity>>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun byId(id: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users WHERE role = 'ADMIN' AND isActive = 1 AND id != :id")
    suspend fun otherActiveAdmins(id: String): Int

    @Upsert
    suspend fun upsert(u: UserEntity)
}

// ───────────── التشفير ─────────────
object PasswordHasher {
    const val ITERATIONS = 120_000
    private val b64e = Base64.getEncoder()
    private val b64d = Base64.getDecoder()

    fun newSalt(): String = ByteArray(16).also { SecureRandom().nextBytes(it) }.let(b64e::encodeToString)

    fun hash(password: String, saltB64: String, iterations: Int = ITERATIONS): String {
        val spec = PBEKeySpec(password.toCharArray(), b64d.decode(saltB64), iterations, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return b64e.encodeToString(bytes)
    }

    /** مقارنة بزمن ثابت */
    fun verify(password: String, u: UserEntity): Boolean =
        MessageDigest.isEqual(hash(password, u.salt, u.iterations).toByteArray(), u.passwordHash.toByteArray())
}

/** الأدمن الأول: Admin — مخزّن كـ hash فقط، وبيُطلب منه تغيير كلمة المرور عند أول دخول */
private object AdminSeed {
    const val SALT = "3nBFEP+3Zwnn5a1CAN5kkQ=="
    const val HASH = "fcQyhp2aOCyPAGTfzdweXU17KjNutq09jtosV8aYTPM="
    const val ITER = 120_000
}

// ───────────── الدخول وإدارة المستخدمين ─────────────
sealed interface LoginResult {
    data class Success(val user: UserEntity) : LoginResult
    object Invalid : LoginResult
    object Disabled : LoginResult
    data class Locked(val seconds: Int) : LoginResult
}

class AuthRepository(private val dao: UserDao) {
    companion object { const val MIN_PASSWORD = 8 }

    private var fails = 0
    private var lockedUntil = 0L
    private fun key(u: String) = u.trim().lowercase()

    fun users(): Flow<List<UserEntity>> = dao.observeAll()

    suspend fun seedAdminIfEmpty() {
        if (dao.count() > 0) return
        dao.upsert(
            UserEntity(
                id = "u-admin", name = "Admin", username = "Admin", usernameKey = "admin",
                role = Roles.ADMIN, passwordHash = AdminSeed.HASH, salt = AdminSeed.SALT,
                iterations = AdminSeed.ITER, mustChangePassword = true
            )
        )
    }

    /** بعد 5 محاولات غلط: قفل 30 ثانية */
    suspend fun login(username: String, password: String): LoginResult = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) return@withContext LoginResult.Locked(((lockedUntil - now) / 1000 + 1).toInt())
        val u = dao.byUsername(key(username))
        if (u == null || !PasswordHasher.verify(password, u)) {
            if (++fails >= 5) { fails = 0; lockedUntil = now + 30_000 }
            return@withContext LoginResult.Invalid
        }
        fails = 0
        if (!u.isActive) LoginResult.Disabled else LoginResult.Success(u)
    }

    suspend fun changePassword(user: UserEntity, newPassword: String): UserEntity = withContext(Dispatchers.Default) {
        val salt = PasswordHasher.newSalt()
        val updated = user.copy(
            salt = salt, iterations = PasswordHasher.ITERATIONS,
            passwordHash = PasswordHasher.hash(newPassword, salt), mustChangePassword = false
        )
        dao.upsert(updated)
        updated
    }

    // كل عمليات الإدارة: للأدمن فقط. بترجع رسالة خطأ أو null لو نجحت.
    suspend fun addUser(actor: UserEntity, name: String, username: String, role: String, password: String): String? {
        if (actor.role != Roles.ADMIN) return "غير مسموح"
        if (name.isBlank() || username.isBlank()) return "الاسم واسم المستخدم مطلوبين"
        if (password.length < MIN_PASSWORD) return "كلمة المرور لازم ${MIN_PASSWORD} أحرف على الأقل"
        if (dao.byUsername(key(username)) != null) return "اسم المستخدم موجود بالفعل"
        val salt = PasswordHasher.newSalt()
        val hash = withContext(Dispatchers.Default) { PasswordHasher.hash(password, salt) }
        dao.upsert(
            UserEntity(
                UUID.randomUUID().toString(), name.trim(), username.trim(), key(username), role,
                hash, salt, PasswordHasher.ITERATIONS, mustChangePassword = true
            )
        )
        return null
    }

    suspend fun updateUser(
        actor: UserEntity, id: String, name: String, role: String, active: Boolean, newPassword: String
    ): String? {
        if (actor.role != Roles.ADMIN) return "غير مسموح"
        val u = dao.byId(id) ?: return "المستخدم غير موجود"
        if (name.isBlank()) return "الاسم مطلوب"
        if (newPassword.isNotEmpty() && newPassword.length < MIN_PASSWORD) return "كلمة المرور لازم ${MIN_PASSWORD} أحرف على الأقل"
        // مينفعش نشيل آخر أدمن مفعّل
        if (u.role == Roles.ADMIN && (role != Roles.ADMIN || !active) && dao.otherActiveAdmins(id) == 0)
            return "لازم يفضل أدمن واحد مفعّل على الأقل"
        var updated = u.copy(name = name.trim(), role = role, isActive = active)
        if (newPassword.isNotEmpty()) {
            val salt = PasswordHasher.newSalt()
            val hash = withContext(Dispatchers.Default) { PasswordHasher.hash(newPassword, salt) }
            updated = updated.copy(salt = salt, passwordHash = hash, iterations = PasswordHasher.ITERATIONS, mustChangePassword = true)
        }
        dao.upsert(updated)
        return null
    }
}
