package com.raneen.quality.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// ───────────── الأدوار ─────────────
object Roles {
    const val INSPECTOR = "INSPECTOR"        // مراقب جودة
    const val AREA_MANAGER = "AREA_MANAGER"  // مدير منطقة (مراجعة)
    const val DEPT_MANAGER = "DEPT_MANAGER"  // مدير إدارة (اعتماد نهائي)
    const val ADMIN = "ADMIN"                // مدير النظام
    val all = listOf(INSPECTOR, AREA_MANAGER, DEPT_MANAGER, ADMIN)
    fun label(r: String) = when (r) {
        INSPECTOR -> "مراقب جودة"; AREA_MANAGER -> "مدير منطقة"
        DEPT_MANAGER -> "مدير إدارة"; ADMIN -> "مدير النظام"; else -> r
    }
}

// ───────────── المستخدم ─────────────
@Entity(tableName = "users", indices = [Index(value = ["usernameKey"], unique = true)])
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val username: String,
    val usernameKey: String,          // lowercase للمقارنة (Admin = admin)
    val role: String,
    val passwordHash: String,         // Base64 من PBKDF2-HMAC-SHA256 — مفيش كلمة مرور نصية في أي مكان
    val salt: String,
    val iterations: Int,
    val mustChangePassword: Boolean = false,
    val isActive: Boolean = true
)

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE usernameKey = :key LIMIT 1")
    suspend fun byUsername(key: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY name")
    fun observeAll(): Flow<List<UserEntity>>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun byId(id: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users WHERE role = 'ADMIN' AND isActive = 1 AND id != :id")
    suspend fun otherActiveAdmins(id: String): Int

    @Upsert
    suspend fun upsert(u: UserEntity)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM users WHERE usernameKey = :key AND id != :id")
    suspend fun deleteDupes(key: String, id: String)

    @Query("DELETE FROM users WHERE id NOT IN (:ids)")
    suspend fun deleteNotIn(ids: List<String>)
}

// ───────────── التشفير ─────────────
object PasswordHasher {
    const val ITERATIONS = 120_000
    private val b64e = Base64.getEncoder()
    private val b64d = Base64.getDecoder()

    fun newSalt(): String = ByteArray(16).also { SecureRandom().nextBytes(it) }.let(b64e::encodeToString)

    fun hash(password: String, saltB64: String, iterations: Int = ITERATIONS): String {
        val spec = PBEKeySpec(password.toCharArray(), b64d.decode(saltB64), iterations, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return b64e.encodeToString(bytes)
    }

    /** مقارنة بزمن ثابت */
    fun verify(password: String, u: UserEntity): Boolean =
        MessageDigest.isEqual(hash(password, u.salt, u.iterations).toByteArray(), u.passwordHash.toByteArray())
}

// ───────────── الدخول وإدارة المستخدمين (عن طريق Supabase، وأوفلاين بنسخة محفوظة) ─────────────
sealed interface LoginResult {
    data class Success(val user: UserEntity) : LoginResult
    object Invalid : LoginResult
    object Disabled : LoginResult
    data class Locked(val seconds: Int) : LoginResult
}

data class PwResult(val user: UserEntity?, val error: String?)

class AuthRepository(
    private val dao: UserDao,
    private val remote: SupabaseRemote,
    private val afterUserChange: suspend () -> Unit = {}
) {
    companion object {
        const val MIN_PASSWORD = 8
        private val USERNAME_RE = Regex("^[A-Za-z0-9._-]{3,30}$")
    }

    private var fails = 0
    private var lockedUntil = 0L
    private fun key(u: String) = u.trim().lowercase()

    fun users(): Flow<List<UserEntity>> = dao.observeAll()

    /** مفيش حساب افتراضي: الأدمن بيتعمل من Supabase. بنمسح بس الحساب المحلي القديم لو لسه موجود */
    suspend fun cleanupLegacySeed() { dao.deleteById("u-admin") }

    private fun fail(): LoginResult {
        if (++fails >= 5) { fails = 0; lockedUntil = System.currentTimeMillis() + 30_000 }
        return LoginResult.Invalid
    }

    /**
     * الدخول: أونلاين من السيرفر (واسم المستخدم بيتحوّل لإيميل username@raneen.app).
     * لو مفيش إنترنت: بيدخل بنسخة محلية من آخر دخول ناجح على نفس الجهاز.
     * بعد 5 محاولات غلط: قفل 30 ثانية.
     */
    suspend fun login(username: String, password: String): LoginResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) return@withContext LoginResult.Locked(((lockedUntil - now) / 1000 + 1).toInt())
        val k = key(username)
        if (!USERNAME_RE.matches(k)) return@withContext fail()
        try {
            val s = remote.signIn("$k@${SupabaseConfig.EMAIL_DOMAIN}", password)
            val rows = JSONArray(remote.get("/rest/v1/profiles?id=eq.${s.userId}&select=username,name,role,is_active,must_change"))
            if (rows.length() == 0) { remote.clearSession(); return@withContext fail() }
            val o = rows.getJSONObject(0)
            if (!o.optBoolean("is_active", true)) { remote.clearSession(); return@withContext LoginResult.Disabled }
            val salt = PasswordHasher.newSalt()
            val user = UserEntity(
                id = s.userId, name = o.getString("name"), username = o.getString("username"), usernameKey = k,
                role = o.getString("role"), passwordHash = PasswordHasher.hash(password, salt), salt = salt,
                iterations = PasswordHasher.ITERATIONS, mustChangePassword = o.optBoolean("must_change", false), isActive = true
            )
            dao.deleteDupes(k, s.userId)
            dao.upsert(user)
            fails = 0
            LoginResult.Success(user)
        } catch (e: ApiException) {
            if (e.code in 400..403) fail() else localLogin(k, password)
        } catch (e: NetworkException) {
            localLogin(k, password)
        } catch (e: JSONException) {
            localLogin(k, password)
        }
    }

    private suspend fun localLogin(k: String, password: String): LoginResult {
        val u = dao.byUsername(k)
        if (u == null || u.passwordHash.isBlank() || !PasswordHasher.verify(password, u)) return fail()
        fails = 0
        return if (!u.isActive) LoginResult.Disabled else LoginResult.Success(u)
    }

    fun logout() { remote.clearSession() }

    /** تغيير كلمة المرور بتاعتي (محتاج إنترنت). بيرجّع المستخدم المحدّث أو رسالة خطأ. */
    suspend fun changePassword(user: UserEntity, newPassword: String): PwResult = withContext(Dispatchers.IO) {
        try {
            remote.putUser(JSONObject().put("password", newPassword).toString())
            remote.rpc("password_changed", "{}")
        } catch (e: NetworkException) {
            return@withContext PwResult(null, "محتاج اتصال بالإنترنت عشان تغيّر كلمة المرور")
        } catch (e: ApiException) {
            val msg = when {
                e.code == 401 -> "الجلسة انتهت. اخرج وادخل تاني بإنترنت"
                e.body.contains("different", ignoreCase = true) -> "كلمة المرور الجديدة لازم تختلف عن القديمة"
                else -> "تعذّر تغيير كلمة المرور (${e.code})"
            }
            return@withContext PwResult(null, msg)
        }
        val salt = PasswordHasher.newSalt()
        val updated = user.copy(
            salt = salt, iterations = PasswordHasher.ITERATIONS,
            passwordHash = PasswordHasher.hash(newPassword, salt), mustChangePassword = false
        )
        dao.upsert(updated)
        PwResult(updated, null)
    }

    // ───────── إدارة المستخدمين (الأدمن فقط، عن طريق Edge Function على السيرفر) ─────────
    private fun adminError(e: ApiException): String =
        try { JSONObject(e.body).optString("error").ifBlank { "تعذّر تنفيذ العملية (${e.code})" } }
        catch (ex: JSONException) { "تعذّر تنفيذ العملية (${e.code})" }

    private suspend fun callAdmin(body: JSONObject): String? = withContext(Dispatchers.IO) {
        try {
            remote.callAdmin(body.toString())
        } catch (e: NetworkException) {
            return@withContext "محتاج اتصال بالإنترنت"
        } catch (e: ApiException) {
            return@withContext adminError(e)
        }
        try { afterUserChange() } catch (e: Exception) { /* هتتزامن في الدورة الجاية */ }
        null
    }

    suspend fun addUser(actor: UserEntity, name: String, username: String, role: String, password: String): String? {
        if (actor.role != Roles.ADMIN) return "غير مسموح"
        if (name.isBlank() || username.isBlank()) return "الاسم واسم المستخدم مطلوبين"
        if (!USERNAME_RE.matches(username.trim())) return "اسم المستخدم: حروف إنجليزي وأرقام فقط (3 إلى 30)، مثال: ahmed.fayoum"
        if (password.length < MIN_PASSWORD) return "كلمة المرور لازم ${MIN_PASSWORD} أحرف على الأقل"
        return callAdmin(
            JSONObject().put("action", "create").put("name", name.trim()).put("username", username.trim())
                .put("role", role).put("password", password)
        )
    }

    suspend fun updateUser(
        actor: UserEntity, id: String, name: String, role: String, active: Boolean, newPassword: String
    ): String? {
        if (actor.role != Roles.ADMIN) return "غير مسموح"
        if (name.isBlank()) return "الاسم مطلوب"
        if (newPassword.isNotEmpty() && newPassword.length < MIN_PASSWORD) return "كلمة المرور لازم ${MIN_PASSWORD} أحرف على الأقل"
        val body = JSONObject().put("action", "update").put("id", id).put("name", name.trim())
            .put("role", role).put("is_active", active)
        if (newPassword.isNotEmpty()) body.put("password", newPassword)
        return callAdmin(body)
    }
}
