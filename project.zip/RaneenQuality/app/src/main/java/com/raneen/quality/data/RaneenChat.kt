package com.raneen.quality.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.time.Instant
import java.time.OffsetDateTime
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ───────────── الشات بين المستخدمين ─────────────
// المرحلة ١: كل شيء محلي على الموبايل. البنية جاهزة للمزامنة (status + id ثابت + conversationId حتمي).
// المحادثة مفيهاش جدول خاص: بتتشتق من الرسائل (conversationId = معرّفي الطرفين مرتّبين)، فالطرفين يطلعوا بنفس المعرّف.

/** مجموعة العمل الواحدة لكل المستخدمين: كل الرسايل والتعليمات هنا، والمحادثات الخاصة مقفولة. */
const val TEAM_CHAT_ID = "team"

/** حد حجم المرفق في bucket الشات (25 ميجا) */
const val MAX_CHAT_MEDIA_BYTES = 25L * 1024 * 1024

object ChatType { const val TEXT = "TEXT"; const val PHOTO = "PHOTO"; const val VIDEO = "VIDEO" }

/** حالة الرسالة: PENDING لسه محلية (مفيش مزامنة) → SENT اتبعتت للسيرفر (المرحلة ٢) */
object ChatStatus { const val PENDING = "PENDING"; const val SENT = "SENT" }

@Entity(tableName = "chat_messages", indices = [Index(value = ["conversationId", "createdAt"])])
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val receiverId: String,
    val type: String,
    val text: String?,          // نص الرسالة (للنوع TEXT)
    val mediaPath: String?,     // مسار الصورة/الفيديو المختوم على الموبايل
    val createdAt: Long,
    val status: String,
    val readAt: Long?           // null = لسه المستلم ما قراهاش (أساس عدّاد غير المقروء)
)

/** صف في قايمة المحادثات: آخر رسالة + عدد غير المقروء + بيانات الطرف التاني */
data class ConversationRow(
    val conversationId: String,
    val peerId: String,
    val peerName: String?,
    val peerRole: String?,
    val lastType: String,
    val lastText: String?,
    val lastAt: Long,
    val lastSenderId: String,
    val unread: Int
)

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: ChatMessageEntity)

    @Query("SELECT * FROM chat_messages WHERE conversationId = :cid ORDER BY createdAt ASC")
    fun observeMessages(cid: String): Flow<List<ChatMessageEntity>>

    // آخر رسالة لكل محادثة (مرتبة من الأحدث) + غير المقروء + اسم الطرف التاني
    @Query("""
        SELECT m.conversationId AS conversationId,
               CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END AS peerId,
               (SELECT name FROM users WHERE id = CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END) AS peerName,
               (SELECT role FROM users WHERE id = CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END) AS peerRole,
               m.type AS lastType, m.text AS lastText, m.createdAt AS lastAt, m.senderId AS lastSenderId,
               (SELECT COUNT(*) FROM chat_messages x
                 WHERE x.conversationId = m.conversationId AND x.receiverId = :me AND x.readAt IS NULL) AS unread
        FROM chat_messages m
        WHERE (m.senderId = :me OR m.receiverId = :me)
          AND m.createdAt = (SELECT MAX(y.createdAt) FROM chat_messages y WHERE y.conversationId = m.conversationId)
        GROUP BY m.conversationId
        ORDER BY m.createdAt DESC
    """)
    fun observeConversations(me: String): Flow<List<ConversationRow>>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE conversationId = 'team' AND receiverId = :me AND readAt IS NULL")
    fun observeUnreadTotal(me: String): Flow<Int>

    @Query("UPDATE chat_messages SET readAt = :now WHERE conversationId = :cid AND receiverId = :me AND readAt IS NULL")
    suspend fun markRead(cid: String, me: String, now: Long): Int

    // ── للمزامنة ──
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(m: ChatMessageEntity): Long

    @Query("SELECT * FROM chat_messages WHERE id = :id")
    suspend fun byId(id: String): ChatMessageEntity?

    @Query("SELECT * FROM chat_messages WHERE senderId = :me AND status = 'PENDING' ORDER BY createdAt")
    suspend fun pendingAll(me: String): List<ChatMessageEntity>

    @Query("UPDATE chat_messages SET status = 'SENT' WHERE id = :id")
    suspend fun markSent(id: String)

    // وقت السيرفر هو المرجع (ترتيب موحّد على الموبايلين). readAt المحلي بيفضل لو السيرفر لسه ما عندوش
    @Query("UPDATE chat_messages SET createdAt = :createdAt, status = :status, readAt = COALESCE(:readAt, readAt) WHERE id = :id")
    suspend fun applyServer(id: String, createdAt: Long, status: String, readAt: Long?)

    @Query("SELECT id FROM chat_messages WHERE senderId = :me AND readAt IS NULL AND status = 'SENT' ORDER BY createdAt DESC LIMIT 100")
    suspend fun unreadSentIds(me: String): List<String>

    @Query("UPDATE chat_messages SET readAt = :readAt WHERE id = :id")
    suspend fun applyReadReceipt(id: String, readAt: Long)

    @Query("SELECT mediaPath FROM chat_messages WHERE conversationId = :cid AND createdAt < :cutoff AND mediaPath IS NOT NULL")
    suspend fun expiredMedia(cid: String, cutoff: Long): List<String>

    @Query("DELETE FROM chat_messages WHERE conversationId = :cid AND createdAt < :cutoff")
    suspend fun deleteExpired(cid: String, cutoff: Long)
}

/**
 * Migration حقيقية 3 → 4: بتضيف جدول الشات بس.
 * (مهم: RaneenApp فيه fallbackToDestructiveMigration، فلو رفعنا النسخة من غير Migration كانت كل الزيارات المحلية هتتمسح.)
 * الـ SQL لازم يطابق الـ @Entity حرفيًا وإلا Room هيرفض يفتح الداتابيز.
 */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `chat_messages` (`id` TEXT NOT NULL, `conversationId` TEXT NOT NULL, " +
                "`senderId` TEXT NOT NULL, `receiverId` TEXT NOT NULL, `type` TEXT NOT NULL, `text` TEXT, " +
                "`mediaPath` TEXT, `createdAt` INTEGER NOT NULL, `status` TEXT NOT NULL, `readAt` INTEGER, PRIMARY KEY(`id`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_chat_messages_conversationId_createdAt` ON `chat_messages` (`conversationId`, `createdAt`)")
    }
}

// ───────────── مزامنة الشات مع Supabase ─────────────
/**
 * بتستخدم نفس جلسة المزامنة الحالية (HTTP عادي من غير مكتبات).
 * التسليم بالـ polling: كل ٣ ثواني وشاشة الشات مفتوحة، وكل دقيقة مع المزامنة العامة. (Realtime/FCM = مرحلة لاحقة)
 * النص والصور والفيديو بيتزامنوا. المرفقات بتترفع على bucket خاص "chat-media" بمسار <conversationId>/<messageId>.<ext> وبتتنزّل عند المستلم.
 * أي دالة هنا ممكن ترمي NetworkException/ApiException، والمنادي هو اللي يتعامل معاهم.
 */
class ChatSync(private val db: RaneenDatabase, private val remote: SupabaseRemote, private val appContext: Context) {
    private val dao get() = db.chatDao()
    private val prefs = appContext.getSharedPreferences("raneen_chat", Context.MODE_PRIVATE)
    private val mutex = Mutex()
    private val ensured = HashSet<String>()

    /** الحذف التلقائي لكل محادثة: conversationId → ساعات (الغايب = من غير حذف) */
    val autoDelete = MutableStateFlow(loadAuto())

    /** آخر وقت قرا فيه كل عضو مجموعة العمل: userId → وقت (أساس علامة "👁 اتشافت" على الرسايل) */
    val teamReads = MutableStateFlow<Map<String, Long>>(emptyMap())

    private fun loadAuto(): Map<String, Int> = try {
        val o = JSONObject(prefs.getString("auto", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getInt(it) }
    } catch (e: Exception) { emptyMap() }

    private fun saveAuto(m: Map<String, Int>) {
        autoDelete.value = m
        prefs.edit().putString("auto", JSONObject(m).toString()).apply()
    }

    // مجموعات "لسه ما اتبعتش للسيرفر" (بتفضل لو مفيش نت وتتبعت بعدين)
    private fun dirty(key: String): MutableSet<String> = (prefs.getStringSet(key, emptySet()) ?: emptySet()).toMutableSet()
    private fun putDirty(key: String, s: Set<String>) = prefs.edit().putStringSet(key, HashSet(s)).apply()

    fun markReadDirty(cid: String) = putDirty("read_dirty", dirty("read_dirty") + cid)

    fun setAutoDelete(cid: String, hours: Int?) {
        saveAuto(if (hours == null) autoDelete.value - cid else autoDelete.value + (cid to hours))
        putDirty("auto_dirty", dirty("auto_dirty") + cid)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun ms(iso: String) = OffsetDateTime.parse(iso).toInstant().toEpochMilli()

    suspend fun syncOnce(me: String) = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (remote.session()?.userId != me) return@withLock
            pushSettings()
            pushMessages(me)
            pushReads(me)
            pullConversations()
            pullMessages(me)
            pullTeamReads()
            expireLocal()
        }
    }

    /** صف المحادثة على السيرفر لازم يتكوّن قبل أول رسالة (insert-if-missing) */
    private fun ensureConversation(cid: String) {
        if (cid == TEAM_CHAT_ID) return          // مجموعة العمل متكوّنة على السيرفر
        if (cid in ensured) return
        val (a, b) = cid.split("_")
        val j = JSONObject().put("id", cid).put("user_a", a).put("user_b", b)
        autoDelete.value[cid]?.let { j.put("auto_delete_hours", it) }
        remote.postPrefer("/rest/v1/chat_conversations?on_conflict=id", j.toString(), "resolution=ignore-duplicates,return=minimal")
        ensured += cid
    }

    private fun pushSettings() {
        val d = dirty("auto_dirty")
        for (cid in d.toList()) {
            ensureConversation(cid)
            val h = autoDelete.value[cid]
            remote.patch("/rest/v1/chat_conversations?id=eq.$cid", """{"auto_delete_hours":${h ?: "null"}}""")
            d -= cid; putDirty("auto_dirty", d)
        }
    }

    private suspend fun pushMessages(me: String) {
        for (m in dao.pendingAll(me)) {
            ensureConversation(m.conversationId)
            val j = JSONObject().put("id", m.id).put("conversation_id", m.conversationId)
                .put("sender_id", m.senderId).put("type", m.type)
                .put("receiver_id", if (m.conversationId == TEAM_CHAT_ID) JSONObject.NULL else m.receiverId)
            if (m.type == ChatType.TEXT) j.put("body", m.text)
            else {
                // مرفق: ارفع الملف الأول، وبعدين سجّل الرسالة بمساره. لو الملف اتمسح محليًا نتخطاه.
                val f = File(m.mediaPath ?: continue)
                if (!f.exists()) continue
                val obj = "${m.conversationId}/${m.id}.${if (m.type == ChatType.VIDEO) "mp4" else "jpg"}"
                remote.uploadChat(obj, f)
                j.put("media_path", obj)
            }
            // ignore-duplicates: لو الطلب اتكرر (النت قطع بعد وصول الرسالة) متتسجلش مرتين. created_at بيحطه السيرفر.
            remote.postPrefer("/rest/v1/chat_messages?on_conflict=id", j.toString(), "resolution=ignore-duplicates,return=minimal")
            dao.markSent(m.id)
        }
    }

    private fun pushReads(me: String) {
        val d = dirty("read_dirty")
        for (cid in d.toList()) {
            if (cid == TEAM_CHAT_ID) {
                // مجموعة العمل: بنسجّل آخر وقت قراءة ليا (صف واحد لكل عضو)
                remote.postPrefer(
                    "/rest/v1/chat_team_reads?on_conflict=user_id",
                    JSONObject().put("user_id", me).put("last_read_at", Instant.now().toString()).toString(),
                    "resolution=merge-duplicates,return=minimal"
                )
            } else remote.patch(
                "/rest/v1/chat_messages?conversation_id=eq.$cid&receiver_id=eq.$me&read_at=is.null",
                """{"read_at":"${Instant.now()}"}"""
            )
            d -= cid; putDirty("read_dirty", d)
        }
    }

    private fun pullConversations() {
        val arr = JSONArray(remote.get("/rest/v1/chat_conversations?select=id,auto_delete_hours"))
        val pending = dirty("auto_dirty")
        var m = autoDelete.value
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val cid = o.getString("id")
            if (cid in pending) continue            // تعديل محلي لسه ما اتبعتش: ميتكتبش فوقه
            m = if (o.isNull("auto_delete_hours")) m - cid else m + (cid to o.getInt("auto_delete_hours"))
        }
        if (m != autoDelete.value) saveAuto(m)
    }

    private suspend fun pullMessages(me: String) {
        var cursor = prefs.getString("cur_team_$me", "1970-01-01T00:00:00Z") ?: "1970-01-01T00:00:00Z"
        while (true) {
            val arr = JSONArray(remote.get(
                "/rest/v1/chat_messages?select=id,conversation_id,sender_id,receiver_id,type,body,media_path,created_at,read_at" +
                    "&conversation_id=eq.$TEAM_CHAT_ID&created_at=gt.${enc(cursor)}&order=created_at.asc&limit=500"
            ))
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                val at = ms(o.getString("created_at"))
                val readAt = if (o.isNull("read_at")) null else ms(o.getString("read_at"))
                val type = o.getString("type")
                if (dao.byId(id) != null) dao.applyServer(id, at, ChatStatus.SENT, readAt)
                else {
                    var local: String? = null
                    if (type != ChatType.TEXT) {
                        // مرفق وارد: ننزّله على الموبايل. لو الملف اتمسح من السيرفر (انتهت مدته) الرسالة بتتسجل بدون مرفق.
                        val remotePath = if (o.isNull("media_path")) null else o.getString("media_path")
                        if (remotePath != null) {
                            val dest = File(File(appContext.filesDir, "chat").apply { mkdirs() }, "$id.${if (type == ChatType.VIDEO) "mp4" else "jpg"}")
                            try { remote.downloadChat(remotePath, dest); local = dest.path }
                            catch (e: ApiException) { if (e.code != 400 && e.code != 404) throw e }
                        }
                    }
                    dao.insertIgnore(
                        ChatMessageEntity(
                            // رسالة المجموعة: المستلم عندنا محليًا = أنا (لو مش أنا المرسل) عشان عدّاد غير المقروء
                            id, TEAM_CHAT_ID, o.getString("sender_id"), if (o.getString("sender_id") == me) TEAM_CHAT_ID else me,
                            type, if (o.isNull("body")) null else o.getString("body"), local, at, ChatStatus.SENT,
                            if (o.getString("sender_id") == me) null else readAt
                        )
                    )
                }
                cursor = o.getString("created_at")
            }
            prefs.edit().putString("cur_team_$me", cursor).apply()
            if (arr.length() < 500) break
        }
    }

    /** آخر وقت قراءة لكل عضو: بنحسب منه "اتشافت عند كام واحد" على رسايلي */
    private fun pullTeamReads() {
        val arr = JSONArray(remote.get("/rest/v1/chat_team_reads?select=user_id,last_read_at"))
        val m = HashMap<String, Long>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!o.isNull("last_read_at")) m[o.getString("user_id")] = ms(o.getString("last_read_at"))
        }
        if (m != teamReads.value) teamReads.value = m
    }

    /** الحذف المحلي: أي رسالة أقدم من مدة المحادثة (ونسخ الصور/الفيديو بتاعتها) */
    suspend fun expireLocal() {
        val now = System.currentTimeMillis()
        for ((cid, hours) in autoDelete.value) {
            val cutoff = now - hours * 3_600_000L
            dao.expiredMedia(cid, cutoff).forEach { File(it).delete() }
            dao.deleteExpired(cid, cutoff)
        }
    }
}

class ChatRepository(private val db: RaneenDatabase, private val appContext: Context, private val sync: ChatSync) {
    private val dao get() = db.chatDao()
    val teamReads get() = sync.teamReads

    /** رسايل مجموعة العمل (المحادثات الخاصة مقفولة) */
    fun teamMessages(): Flow<List<ChatMessageEntity>> = dao.observeMessages(TEAM_CHAT_ID)
    fun unreadTotal(me: String): Flow<Int> = dao.observeUnreadTotal(me)

    /** كل المستخدمين (لأسماء المرسلين وعدد الأعضاء) */
    fun users(): Flow<List<UserEntity>> = db.userDao().observeAll()

    suspend fun sendText(me: String, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        dao.insert(newMessage(me, ChatType.TEXT, t, null))
        refresh(me)          // إرسال فوري (لو مفيش نت بتفضل 🕓 وتتبعت مع أول مزامنة)
    }

    /** مزامنة الشات مرة (إرسال + استقبال). ما بترميش أخطاء شبكة. */
    suspend fun refresh(me: String): Boolean = try {
        sync.syncOnce(me); true
    } catch (e: CancellationException) { throw e } catch (e: Exception) { false }

    /** صورة: بتتختم بالاسم + التاريخ والوقت جوه البكسلات (نفس PhotoStamper بتاع الزيارات) */
    suspend fun sendPhoto(me: UserEntity, raw: File, source: String? = null): Boolean = withContext(Dispatchers.IO) {
        val out = File(chatDir(), "${UUID.randomUUID()}.jpg")
        // source: لو الصورة مختارة من المعرض بنكتب ده على الصورة عشان يبان إنها مش متصورة وقتها
        val ok = PhotoStamper.stamp(raw, out, stampLines(me.name) + listOfNotNull(source))
        raw.delete()
        if (!ok) return@withContext false
        dao.insert(newMessage(me.id, ChatType.PHOTO, null, out.path))
        true
    }

    /** فيديو: بيتختم زي فيديوهات المخالفات. لو الختم فشل بيتبعت من غيره (زي الزيارات) والنتيجة بترجع 2 */
    suspend fun sendVideo(me: UserEntity, raw: File, customText: String = ""): Int {
        if (raw.length() == 0L) { raw.delete(); return 0 }
        val out = File(chatDir(), "${UUID.randomUUID()}.mp4")
        val stamped = VideoStamper.stamp(appContext, raw, out, stampLines(me.name), customText)
        val tooBig = withContext(Dispatchers.IO) {
            if (stamped) raw.delete()
            else {
                out.delete()
                if (!raw.renameTo(out)) { raw.copyTo(out, overwrite = true); raw.delete() }
            }
            if (out.length() > MAX_CHAT_MEDIA_BYTES) { out.delete(); true }
            else { dao.insert(newMessage(me.id, ChatType.VIDEO, null, out.path)); false }
        }
        return if (tooBig) 3 else if (stamped) 1 else 2
    }

    suspend fun markRead(me: String) {
        if (dao.markRead(TEAM_CHAT_ID, me, System.currentTimeMillis()) > 0) {
            sync.markReadDirty(TEAM_CHAT_ID)       // يتبعت للسيرفر مع المزامنة الجاية (علامة "اتشافت" عند المرسل)
            refresh(me)
        }
    }

    private fun newMessage(me: String, type: String, text: String?, media: String?) = ChatMessageEntity(
        id = UUID.randomUUID().toString(), conversationId = TEAM_CHAT_ID,
        senderId = me, receiverId = TEAM_CHAT_ID, type = type, text = text, mediaPath = media,
        createdAt = System.currentTimeMillis(), status = ChatStatus.PENDING, readAt = null
    )

    private fun chatDir() = File(appContext.filesDir, "chat").apply { mkdirs() }

    private fun stampLines(name: String): List<String> {
        val now = Date()
        return listOf(
            "رسالة من: $name",
            "التاريخ: ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)}  الوقت: ${SimpleDateFormat("HH:mm:ss", Locale.US).format(now)}"
        )
    }
}


/** Migration 4 → 5: إضافة ملاحظات المخالفة المستقلة دون المساس بالبيانات السابقة. */
val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `findings` ADD COLUMN `violationNote` TEXT")
    }
}
