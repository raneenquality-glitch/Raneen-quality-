package com.raneen.quality.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.time.Instant
import java.time.OffsetDateTime
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ───────────── الشات بين المستخدمين ─────────────
// المرحلة ١: كل شيء محلي على الموبايل. البنية جاهزة للمزامنة (status + id ثابت + conversationId حتمي).
// المحادثة مفيهاش جدول خاص: بتتشتق من الرسائل (conversationId = معرّفي الطرفين مرتّبين)، فالطرفين يطلعوا بنفس المعرّف.

object ChatType { const val TEXT = "TEXT"; const val PHOTO = "PHOTO"; const val VIDEO = "VIDEO" }

/** حالة الرسالة: PENDING لسه محلية (مفيش مزامنة) → SENT اتبعتت للسيرفر (المرحلة ٢) */
object ChatStatus { const val PENDING = "PENDING"; const val SENT = "SENT" }

@Entity(tableName = "chat_messages", indices = [Index(value = ["conversationId", "createdAt"])])
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val receiverId: String,
    val type: String,
    val text: String?,          // نص الرسالة (للنوع TEXT)
    val mediaPath: String?,     // مسار الصورة/الفيديو المختوم على الموبايل
    val createdAt: Long,
    val status: String,
    val readAt: Long?           // null = لسه المستلم ما قراهاش (أساس عدّاد غير المقروء)
)

/** صف في قايمة المحادثات: آخر رسالة + عدد غير المقروء + بيانات الطرف التاني */
data class ConversationRow(
    val conversationId: String,
    val peerId: String,
    val peerName: String?,
    val peerRole: String?,
    val lastType: String,
    val lastText: String?,
    val lastAt: Long,
    val lastSenderId: String,
    val unread: Int
)

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: ChatMessageEntity)

    @Query("SELECT * FROM chat_messages WHERE conversationId = :cid ORDER BY createdAt ASC")
    fun observeMessages(cid: String): Flow<List<ChatMessageEntity>>

    // آخر رسالة لكل محادثة (مرتبة من الأحدث) + غير المقروء + اسم الطرف التاني
    @Query("""
        SELECT m.conversationId AS conversationId,
               CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END AS peerId,
               (SELECT name FROM users WHERE id = CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END) AS peerName,
               (SELECT role FROM users WHERE id = CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END) AS peerRole,
               m.type AS lastType, m.text AS lastText, m.createdAt AS lastAt, m.senderId AS lastSenderId,
               (SELECT COUNT(*) FROM chat_messages x
                 WHERE x.conversationId = m.conversationId AND x.receiverId = :me AND x.readAt IS NULL) AS unread
        FROM chat_messages m
        WHERE (m.senderId = :me OR m.receiverId = :me)
          AND m.createdAt = (SELECT MAX(y.createdAt) FROM chat_messages y WHERE y.conversationId = m.conversationId)
        GROUP BY m.conversationId
        ORDER BY m.createdAt DESC
    """)
    fun observeConversations(me: String): Flow<List<ConversationRow>>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE receiverId = :me AND readAt IS NULL")
    fun observeUnreadTotal(me: String): Flow<Int>

    @Query("UPDATE chat_messages SET readAt = :now WHERE conversationId = :cid AND receiverId = :me AND readAt IS NULL")
    suspend fun markRead(cid: String, me: String, now: Long): Int

    // ── للمزامنة ──
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(m: ChatMessageEntity): Long

    @Query("SELECT * FROM chat_messages WHERE id = :id")
    suspend fun byId(id: String): ChatMessageEntity?

    @Query("SELECT * FROM chat_messages WHERE senderId = :me AND status = 'PENDING' AND type = 'TEXT' ORDER BY createdAt")
    suspend fun pendingText(me: String): List<ChatMessageEntity>

    @Query("UPDATE chat_messages SET status = 'SENT' WHERE id = :id")
    suspend fun markSent(id: String)

    // وقت السيرفر هو المرجع (ترتيب موحّد على الموبايلين). readAt المحلي بيفضل لو السيرفر لسه ما عندوش
    @Query("UPDATE chat_messages SET createdAt = :createdAt, status = :status, readAt = COALESCE(:readAt, readAt) WHERE id = :id")
    suspend fun applyServer(id: String, createdAt: Long, status: String, readAt: Long?)

    @Query("SELECT id FROM chat_messages WHERE senderId = :me AND readAt IS NULL AND status = 'SENT' ORDER BY createdAt DESC LIMIT 100")
    suspend fun unreadSentIds(me: String): List<String>

    @Query("UPDATE chat_messages SET readAt = :readAt WHERE id = :id")
    suspend fun applyReadReceipt(id: String, readAt: Long)

    @Query("SELECT mediaPath FROM chat_messages WHERE conversationId = :cid AND createdAt < :cutoff AND mediaPath IS NOT NULL")
    suspend fun expiredMedia(cid: String, cutoff: Long): List<String>

    @Query("DELETE FROM chat_messages WHERE conversationId = :cid AND createdAt < :cutoff")
    suspend fun deleteExpired(cid: String, cutoff: Long)
}

/**
 * Migration حقيقية 3 → 4: بتضيف جدول الشات بس.
 * (مهم: RaneenApp فيه fallbackToDestructiveMigration، فلو رفعنا النسخة من غير Migration كانت كل الزيارات المحلية هتتمسح.)
 * الـ SQL لازم يطابق الـ @Entity حرفيًا وإلا Room هيرفض يفتح الداتابيز.
 */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `chat_messages` (`id` TEXT NOT NULL, `conversationId` TEXT NOT NULL, " +
                "`senderId` TEXT NOT NULL, `receiverId` TEXT NOT NULL, `type` TEXT NOT NULL, `text` TEXT, " +
                "`mediaPath` TEXT, `createdAt` INTEGER NOT NULL, `status` TEXT NOT NULL, `readAt` INTEGER, PRIMARY KEY(`id`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_chat_messages_conversationId_createdAt` ON `chat_messages` (`conversationId`, `createdAt`)")
    }
}

// ───────────── مزامنة الشات مع Supabase ─────────────
/**
 * بتستخدم نفس جلسة المزامنة الحالية (HTTP عادي من غير مكتبات).
 * التسليم بالـ polling: كل ٣ ثواني وشاشة الشات مفتوحة، وكل دقيقة مع المزامنة العامة. (Realtime/FCM = مرحلة لاحقة)
 * الرسايل النصية بس بتتزامن دلوقتي؛ الصور والفيديو للمرحلة الجاية (رفع على bucket خاص).
 * أي دالة هنا ممكن ترمي NetworkException/ApiException، والمنادي هو اللي يتعامل معاهم.
 */
class ChatSync(private val db: RaneenDatabase, private val remote: SupabaseRemote, appContext: Context) {
    private val dao get() = db.chatDao()
    private val prefs = appContext.getSharedPreferences("raneen_chat", Context.MODE_PRIVATE)
    private val mutex = Mutex()
    private val ensured = HashSet<String>()

    /** الحذف التلقائي لكل محادثة: conversationId → ساعات (الغايب = من غير حذف) */
    val autoDelete = MutableStateFlow(loadAuto())

    private fun loadAuto(): Map<String, Int> = try {
        val o = JSONObject(prefs.getString("auto", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getInt(it) }
    } catch (e: Exception) { emptyMap() }

    private fun saveAuto(m: Map<String, Int>) {
        autoDelete.value = m
        prefs.edit().putString("auto", JSONObject(m).toString()).apply()
    }

    // مجموعات "لسه ما اتبعتش للسيرفر" (بتفضل لو مفيش نت وتتبعت بعدين)
    private fun dirty(key: String): MutableSet<String> = (prefs.getStringSet(key, emptySet()) ?: emptySet()).toMutableSet()
    private fun putDirty(key: String, s: Set<String>) = prefs.edit().putStringSet(key, HashSet(s)).apply()

    fun markReadDirty(cid: String) = putDirty("read_dirty", dirty("read_dirty") + cid)

    fun setAutoDelete(cid: String, hours: Int?) {
        saveAuto(if (hours == null) autoDelete.value - cid else autoDelete.value + (cid to hours))
        putDirty("auto_dirty", dirty("auto_dirty") + cid)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun ms(iso: String) = OffsetDateTime.parse(iso).toInstant().toEpochMilli()

    suspend fun syncOnce(me: String) = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (remote.session()?.userId != me) return@withLock
            pushSettings()
            pushMessages(me)
            pushReads(me)
            pullConversations()
            pullMessages(me)
            pullReceipts(me)
            expireLocal()
        }
    }

    /** صف المحادثة على السيرفر لازم يتكوّن قبل أول رسالة (insert-if-missing) */
    private fun ensureConversation(cid: String) {
        if (cid in ensured) return
        val (a, b) = cid.split("_")
        val j = JSONObject().put("id", cid).put("user_a", a).put("user_b", b)
        autoDelete.value[cid]?.let { j.put("auto_delete_hours", it) }
        remote.postPrefer("/rest/v1/chat_conversations?on_conflict=id", j.toString(), "resolution=ignore-duplicates,return=minimal")
        ensured += cid
    }

    private fun pushSettings() {
        val d = dirty("auto_dirty")
        for (cid in d.toList()) {
            ensureConversation(cid)
            val h = autoDelete.value[cid]
            remote.patch("/rest/v1/chat_conversations?id=eq.$cid", """{"auto_delete_hours":${h ?: "null"}}""")
            d -= cid; putDirty("auto_dirty", d)
        }
    }

    private suspend fun pushMessages(me: String) {
        for (m in dao.pendingText(me)) {
            ensureConversation(m.conversationId)
            val j = JSONObject().put("id", m.id).put("conversation_id", m.conversationId)
                .put("sender_id", m.senderId).put("receiver_id", m.receiverId)
                .put("type", m.type).put("body", m.text)
            // ignore-duplicates: لو الطلب اتكرر (النت قطع بعد وصول الرسالة) متتسجلش مرتين. created_at بيحطه السيرفر.
            remote.postPrefer("/rest/v1/chat_messages?on_conflict=id", j.toString(), "resolution=ignore-duplicates,return=minimal")
            dao.markSent(m.id)
        }
    }

    private fun pushReads(me: String) {
        val d = dirty("read_dirty")
        for (cid in d.toList()) {
            remote.patch(
                "/rest/v1/chat_messages?conversation_id=eq.$cid&receiver_id=eq.$me&read_at=is.null",
                """{"read_at":"${Instant.now()}"}"""
            )
            d -= cid; putDirty("read_dirty", d)
        }
    }

    private fun pullConversations() {
        val arr = JSONArray(remote.get("/rest/v1/chat_conversations?select=id,auto_delete_hours"))
        val pending = dirty("auto_dirty")
        var m = autoDelete.value
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val cid = o.getString("id")
            if (cid in pending) continue            // تعديل محلي لسه ما اتبعتش: ميتكتبش فوقه
            m = if (o.isNull("auto_delete_hours")) m - cid else m + (cid to o.getInt("auto_delete_hours"))
        }
        if (m != autoDelete.value) saveAuto(m)
    }

    private suspend fun pullMessages(me: String) {
        var cursor = prefs.getString("cur_$me", "1970-01-01T00:00:00Z") ?: "1970-01-01T00:00:00Z"
        while (true) {
            val arr = JSONArray(remote.get(
                "/rest/v1/chat_messages?select=id,conversation_id,sender_id,receiver_id,type,body,created_at,read_at" +
                    "&created_at=gt.${enc(cursor)}&order=created_at.asc&limit=500"
            ))
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                val at = ms(o.getString("created_at"))
                val readAt = if (o.isNull("read_at")) null else ms(o.getString("read_at"))
                if (dao.byId(id) != null) dao.applyServer(id, at, ChatStatus.SENT, readAt)
                else if (o.getString("type") == ChatType.TEXT) dao.insertIgnore(
                    ChatMessageEntity(
                        id, o.getString("conversation_id"), o.getString("sender_id"), o.getString("receiver_id"),
                        ChatType.TEXT, if (o.isNull("body")) null else o.getString("body"), null, at, ChatStatus.SENT, readAt
                    )
                )   // رسايل الصور/الفيديو بتتجاهل لحد ما نفعّل رفع الوسائط
                cursor = o.getString("created_at")
            }
            prefs.edit().putString("cur_$me", cursor).apply()
            if (arr.length() < 500) break
        }
    }

    /** علامة "اتقرت" على رسايلي: بنسأل بس عن اللي لسه ما اتقراش عندي (من غير cursor عشان فروق ساعات الأجهزة) */
    private suspend fun pullReceipts(me: String) {
        val ids = dao.unreadSentIds(me)
        if (ids.isEmpty()) return
        val arr = JSONArray(remote.get("/rest/v1/chat_messages?select=id,read_at&id=in.(${ids.joinToString(",")})&read_at=not.is.null"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            dao.applyReadReceipt(o.getString("id"), ms(o.getString("read_at")))
        }
    }

    /** الحذف المحلي: أي رسالة أقدم من مدة المحادثة (ونسخ الصور/الفيديو بتاعتها) */
    suspend fun expireLocal() {
        val now = System.currentTimeMillis()
        for ((cid, hours) in autoDelete.value) {
            val cutoff = now - hours * 3_600_000L
            dao.expiredMedia(cid, cutoff).forEach { File(it).delete() }
            dao.deleteExpired(cid, cutoff)
        }
    }
}

class ChatRepository(private val db: RaneenDatabase, private val appContext: Context, private val sync: ChatSync) {
    private val dao get() = db.chatDao()
    val autoDelete get() = sync.autoDelete

    /** معرّف محادثة ثابت لأي اتنين: نفس الناتج على الموبايلين (مهم للمزامنة بعدين) */
    fun conversationId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    fun conversations(me: String): Flow<List<ConversationRow>> = dao.observeConversations(me)
    fun messages(me: String, peerId: String): Flow<List<ChatMessageEntity>> = dao.observeMessages(conversationId(me, peerId))
    fun unreadTotal(me: String): Flow<Int> = dao.observeUnreadTotal(me)

    /** أي مستخدم مفعّل غير أنا (المراقبين والمديرين) — الأدمن بيقدر يقيّد القايمة لو حب */
    fun peers(me: String): Flow<List<UserEntity>> =
        db.userDao().observeAll().map { list -> list.filter { it.isActive && it.id != me } }

    suspend fun peer(id: String): UserEntity? = db.userDao().byId(id)

    suspend fun sendText(me: String, peerId: String, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        dao.insert(newMessage(me, peerId, ChatType.TEXT, t, null))
        refresh(me)          // إرسال فوري (لو مفيش نت بتفضل 🕓 وتتبعت مع أول مزامنة)
    }

    /** مزامنة الشات مرة (إرسال + استقبال + حذف المنتهي). ما بترميش أخطاء شبكة. */
    suspend fun refresh(me: String): Boolean = try {
        sync.syncOnce(me); true
    } catch (e: CancellationException) { throw e } catch (e: Exception) { false }

    /** تفعيل/إيقاف حذف رسايل المحادثة تلقائيًا بعد ساعات (null = إيقاف) */
    suspend fun setAutoDelete(me: String, peerId: String, hours: Int?) {
        sync.setAutoDelete(conversationId(me, peerId), hours)
        refresh(me)
    }

    /** صورة: بتتختم بالاسم + التاريخ والوقت جوه البكسلات (نفس PhotoStamper بتاع الزيارات) */
    suspend fun sendPhoto(me: UserEntity, peerId: String, raw: File): Boolean = withContext(Dispatchers.IO) {
        val out = File(chatDir(), "${UUID.randomUUID()}.jpg")
        val ok = PhotoStamper.stamp(raw, out, stampLines(me.name))
        raw.delete()
        if (!ok) return@withContext false
        dao.insert(newMessage(me.id, peerId, ChatType.PHOTO, null, out.path))
        true
    }

    /** فيديو: بيتختم زي فيديوهات المخالفات. لو الختم فشل بيتبعت من غيره (زي الزيارات) والنتيجة بترجع 2 */
    suspend fun sendVideo(me: UserEntity, peerId: String, raw: File): Int {
        if (raw.length() == 0L) { raw.delete(); return 0 }
        val out = File(chatDir(), "${UUID.randomUUID()}.mp4")
        val stamped = VideoStamper.stamp(appContext, raw, out, stampLines(me.name))
        withContext(Dispatchers.IO) {
            if (stamped) raw.delete()
            else {
                out.delete()
                if (!raw.renameTo(out)) { raw.copyTo(out, overwrite = true); raw.delete() }
            }
            dao.insert(newMessage(me.id, peerId, ChatType.VIDEO, null, out.path))
        }
        return if (stamped) 1 else 2
    }

    suspend fun markRead(me: String, peerId: String) {
        val cid = conversationId(me, peerId)
        if (dao.markRead(cid, me, System.currentTimeMillis()) > 0) {
            sync.markReadDirty(cid)       // يتبعت للسيرفر مع المزامنة الجاية (علامة ✓✓ عند المرسل)
            refresh(me)
        }
    }

    private fun newMessage(me: String, peerId: String, type: String, text: String?, media: String?) = ChatMessageEntity(
        id = UUID.randomUUID().toString(), conversationId = conversationId(me, peerId),
        senderId = me, receiverId = peerId, type = type, text = text, mediaPath = media,
        createdAt = System.currentTimeMillis(), status = ChatStatus.PENDING, readAt = null
    )

    private fun chatDir() = File(appContext.filesDir, "chat").apply { mkdirs() }

    private fun stampLines(name: String): List<String> {
        val now = Date()
        return listOf(
            "رسالة من: $name",
            "التاريخ: ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)}  الوقت: ${SimpleDateFormat("HH:mm:ss", Locale.US).format(now)}"
        )
    }
}
