package com.raneen.quality.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ───────────── الشات بين المستخدمين ─────────────
// المرحلة ١: كل شيء محلي على الموبايل. البنية جاهزة للمزامنة (status + id ثابت + conversationId حتمي).
// المحادثة مفيهاش جدول خاص: بتتشتق من الرسائل (conversationId = معرّفي الطرفين مرتّبين)، فالطرفين يطلعوا بنفس المعرّف.

object ChatType { const val TEXT = "TEXT"; const val PHOTO = "PHOTO"; const val VIDEO = "VIDEO" }

/** حالة الرسالة: PENDING لسه محلية (مفيش مزامنة) → SENT اتبعتت للسيرفر (المرحلة ٢) */
object ChatStatus { const val PENDING = "PENDING"; const val SENT = "SENT" }

@Entity(tableName = "chat_messages", indices = [Index(value = ["conversationId", "createdAt"])])
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val receiverId: String,
    val type: String,
    val text: String?,          // نص الرسالة (للنوع TEXT)
    val mediaPath: String?,     // مسار الصورة/الفيديو المختوم على الموبايل
    val createdAt: Long,
    val status: String,
    val readAt: Long?           // null = لسه المستلم ما قراهاش (أساس عدّاد غير المقروء)
)

/** صف في قايمة المحادثات: آخر رسالة + عدد غير المقروء + بيانات الطرف التاني */
data class ConversationRow(
    val conversationId: String,
    val peerId: String,
    val peerName: String?,
    val peerRole: String?,
    val lastType: String,
    val lastText: String?,
    val lastAt: Long,
    val lastSenderId: String,
    val unread: Int
)

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: ChatMessageEntity)

    @Query("SELECT * FROM chat_messages WHERE conversationId = :cid ORDER BY createdAt ASC")
    fun observeMessages(cid: String): Flow<List<ChatMessageEntity>>

    // آخر رسالة لكل محادثة (مرتبة من الأحدث) + غير المقروء + اسم الطرف التاني
    @Query("""
        SELECT m.conversationId AS conversationId,
               CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END AS peerId,
               (SELECT name FROM users WHERE id = CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END) AS peerName,
               (SELECT role FROM users WHERE id = CASE WHEN m.senderId = :me THEN m.receiverId ELSE m.senderId END) AS peerRole,
               m.type AS lastType, m.text AS lastText, m.createdAt AS lastAt, m.senderId AS lastSenderId,
               (SELECT COUNT(*) FROM chat_messages x
                 WHERE x.conversationId = m.conversationId AND x.receiverId = :me AND x.readAt IS NULL) AS unread
        FROM chat_messages m
        WHERE (m.senderId = :me OR m.receiverId = :me)
          AND m.createdAt = (SELECT MAX(y.createdAt) FROM chat_messages y WHERE y.conversationId = m.conversationId)
        GROUP BY m.conversationId
        ORDER BY m.createdAt DESC
    """)
    fun observeConversations(me: String): Flow<List<ConversationRow>>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE receiverId = :me AND readAt IS NULL")
    fun observeUnreadTotal(me: String): Flow<Int>

    @Query("UPDATE chat_messages SET readAt = :now WHERE conversationId = :cid AND receiverId = :me AND readAt IS NULL")
    suspend fun markRead(cid: String, me: String, now: Long)
}

/**
 * Migration حقيقية 3 → 4: بتضيف جدول الشات بس.
 * (مهم: RaneenApp فيه fallbackToDestructiveMigration، فلو رفعنا النسخة من غير Migration كانت كل الزيارات المحلية هتتمسح.)
 * الـ SQL لازم يطابق الـ @Entity حرفيًا وإلا Room هيرفض يفتح الداتابيز.
 */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `chat_messages` (`id` TEXT NOT NULL, `conversationId` TEXT NOT NULL, " +
                "`senderId` TEXT NOT NULL, `receiverId` TEXT NOT NULL, `type` TEXT NOT NULL, `text` TEXT, " +
                "`mediaPath` TEXT, `createdAt` INTEGER NOT NULL, `status` TEXT NOT NULL, `readAt` INTEGER, PRIMARY KEY(`id`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_chat_messages_conversationId_createdAt` ON `chat_messages` (`conversationId`, `createdAt`)")
    }
}

class ChatRepository(private val db: RaneenDatabase, private val appContext: Context) {
    private val dao get() = db.chatDao()

    /** معرّف محادثة ثابت لأي اتنين: نفس الناتج على الموبايلين (مهم للمزامنة بعدين) */
    fun conversationId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    fun conversations(me: String): Flow<List<ConversationRow>> = dao.observeConversations(me)
    fun messages(me: String, peerId: String): Flow<List<ChatMessageEntity>> = dao.observeMessages(conversationId(me, peerId))
    fun unreadTotal(me: String): Flow<Int> = dao.observeUnreadTotal(me)

    /** أي مستخدم مفعّل غير أنا (المراقبين والمديرين) — الأدمن بيقدر يقيّد القايمة لو حب */
    fun peers(me: String): Flow<List<UserEntity>> =
        db.userDao().observeAll().map { list -> list.filter { it.isActive && it.id != me } }

    suspend fun peer(id: String): UserEntity? = db.userDao().byId(id)

    suspend fun sendText(me: String, peerId: String, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        dao.insert(newMessage(me, peerId, ChatType.TEXT, t, null))
    }

    /** صورة: بتتختم بالاسم + التاريخ والوقت جوه البكسلات (نفس PhotoStamper بتاع الزيارات) */
    suspend fun sendPhoto(me: UserEntity, peerId: String, raw: File): Boolean = withContext(Dispatchers.IO) {
        val out = File(chatDir(), "${UUID.randomUUID()}.jpg")
        val ok = PhotoStamper.stamp(raw, out, stampLines(me.name))
        raw.delete()
        if (!ok) return@withContext false
        dao.insert(newMessage(me.id, peerId, ChatType.PHOTO, null, out.path))
        true
    }

    /** فيديو: بيتختم زي فيديوهات المخالفات. لو الختم فشل بيتبعت من غيره (زي الزيارات) والنتيجة بترجع 2 */
    suspend fun sendVideo(me: UserEntity, peerId: String, raw: File): Int {
        if (raw.length() == 0L) { raw.delete(); return 0 }
        val out = File(chatDir(), "${UUID.randomUUID()}.mp4")
        val stamped = VideoStamper.stamp(appContext, raw, out, stampLines(me.name))
        withContext(Dispatchers.IO) {
            if (stamped) raw.delete()
            else {
                out.delete()
                if (!raw.renameTo(out)) { raw.copyTo(out, overwrite = true); raw.delete() }
            }
            dao.insert(newMessage(me.id, peerId, ChatType.VIDEO, null, out.path))
        }
        return if (stamped) 1 else 2
    }

    suspend fun markRead(me: String, peerId: String) = dao.markRead(conversationId(me, peerId), me, System.currentTimeMillis())

    private fun newMessage(me: String, peerId: String, type: String, text: String?, media: String?) = ChatMessageEntity(
        id = UUID.randomUUID().toString(), conversationId = conversationId(me, peerId),
        senderId = me, receiverId = peerId, type = type, text = text, mediaPath = media,
        createdAt = System.currentTimeMillis(), status = ChatStatus.PENDING, readAt = null
    )

    private fun chatDir() = File(appContext.filesDir, "chat").apply { mkdirs() }

    private fun stampLines(name: String): List<String> {
        val now = Date()
        return listOf(
            "رسالة من: $name",
            "التاريخ: ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)}  الوقت: ${SimpleDateFormat("HH:mm:ss", Locale.US).format(now)}"
        )
    }
}
