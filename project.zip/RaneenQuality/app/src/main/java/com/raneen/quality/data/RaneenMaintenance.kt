package com.raneen.quality.data

import android.content.Context
import android.content.SharedPreferences
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** سجل أخطاء بسيط محلي على الجهاز فقط (مابيتبعتش لأي مكان). حد أقصى ~200KB، والأقدم بيتقص. */
object ErrorLog {
    private var file: File? = null
    private const val MAX = 200_000L
    fun init(ctx: Context) { if (file == null) file = File(ctx.applicationContext.filesDir, "raneen-errors.log") }

    @Synchronized fun w(tag: String, e: Throwable?, extra: String = "") {
        val f = file ?: return
        try {
            if (f.exists() && f.length() > MAX) f.writeText(f.readText().takeLast((MAX / 2).toInt()))
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val what = e?.let { "${it.javaClass.simpleName}: ${(it.message ?: "").take(200)}" }.orEmpty()
            f.appendText("$ts [$tag] $what $extra\n".replace("\u0000", ""))
        } catch (ex: Exception) { /* السجل ما يكسرش التطبيق */ }
    }

    fun file(): File? = file
}

/** مسح الملفات المؤقتة القديمة من الـ cache فقط (صور ومسودات التقارير في filesDir ومابتتلمسش). */
object CacheCleaner {
    private const val DAY = 24L * 3600_000L
    fun run(ctx: Context) {
        try {
            val now = System.currentTimeMillis()
            clean(File(ctx.cacheDir, "exports"), now - 2 * DAY, null)
            clean(File(ctx.cacheDir, "cap"), now - 2 * DAY, null)
            clean(ctx.cacheDir, now - DAY, "up_")
        } catch (e: Exception) { ErrorLog.w("cacheClean", e) }
    }

    private fun clean(dir: File, olderThan: Long, prefix: String?) {
        val list = dir.listFiles() ?: return
        for (f in list) {
            if (!f.isFile) continue
            if (prefix != null && !f.name.startsWith(prefix)) continue
            if (f.lastModified() < olderThan) f.delete()
        }
    }
}

/** تأخير تصاعدي (1، 2، 4... لحد 30 دقيقة) لإعادة رفع تقرير فشل بخطأ من السيرفر. انقطاع النت مش بيتحسب. */
object UploadBackoff {
    private var prefs: SharedPreferences? = null
    fun init(ctx: Context) { if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("raneen_backoff", Context.MODE_PRIVATE) }

    fun blocked(id: String): Boolean = (prefs?.getLong("next_$id", 0L) ?: 0L) > System.currentTimeMillis()

    fun fail(id: String) {
        val p = prefs ?: return
        val n = p.getInt("n_$id", 0) + 1
        val minutes = minOf(30L, 1L shl minOf(n - 1, 5))
        p.edit().putInt("n_$id", n).putLong("next_$id", System.currentTimeMillis() + minutes * 60_000L).apply()
    }

    fun clear(id: String) { prefs?.edit()?.remove("n_$id")?.remove("next_$id")?.apply() }
}
