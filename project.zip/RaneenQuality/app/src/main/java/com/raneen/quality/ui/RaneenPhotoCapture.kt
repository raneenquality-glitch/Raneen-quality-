package com.raneen.quality.ui

import android.content.Context
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import android.view.Window
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File

/** تصوير صورة من داخل التطبيق مع أدوات الفلاش والزوم وتبديل الكاميرا، وسبب اختياري. */
@Composable
fun PhotoCaptureDialog(
    onCaptured: (file: File, customText: String) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var customText by remember { mutableStateOf("") }
    var showReasonInput by remember { mutableStateOf(false) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var cameraReady by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var flashOn by remember { mutableStateOf(false) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var maxZoomRatio by remember { mutableFloatStateOf(1f) }
    var error by remember { mutableStateOf<String?>(null) }
    var taking by remember { mutableStateOf(false) }
    val settings = remember { CameraSettingsState() }
    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(owner, lensFacing) {
        cameraReady = false
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val photoCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                provider.unbindAll()
                val camera = provider.bindToLifecycle(owner, selector, preview, photoCapture)
                boundCamera = camera
                capture = photoCapture
                hasFlash = camera.cameraInfo.hasFlashUnit()
                flashOn = false
                maxZoomRatio = (camera.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f).coerceAtLeast(1f)
                zoomRatio = 1f
                settings.resetForCamera()
                cameraReady = true
                error = null
            } catch (t: Throwable) {
                cameraReady = false
                error = "تعذّر تشغيل الكاميرا: ${t.localizedMessage ?: "قد لا تكون الكاميرا الأمامية مدعومة"}"
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            try { boundCamera?.cameraControl?.enableTorch(false) } catch (_: Exception) { }
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) { }
            boundCamera = null
        }
    }

    fun setZoom(value: Float) {
        val next = value.coerceIn(1f, maxZoomRatio.coerceAtLeast(1f))
        try { boundCamera?.cameraControl?.setZoomRatio(next) } catch (_: Exception) { }
        zoomRatio = next
    }

    fun focusAt(x: Float, y: Float) {
        val cam = boundCamera ?: return
        focusPoint = Offset(x, y)
        try { val point = previewView.meteringPointFactory.createPoint(x, y); cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build()) } catch (_: Exception) { }
    }

    fun toggleFlash() {
        val cam = boundCamera ?: return
        if (!hasFlash) {
            error = "الفلاش غير مدعوم في الكاميرا الحالية"
            return
        }
        val next = !flashOn
        try {
            cam.cameraControl.enableTorch(next)
            flashOn = next
            error = null
        } catch (_: Exception) { error = "تعذّر تغيير حالة الفلاش" }
    }

    // التصوير: بيتنادى من زرار الشاتر ومن زرار رفع/خفض الصوت في التليفون
    fun shoot() {
        val current = capture ?: return
        if (taking || !cameraReady || error != null) return
        taking = true
        error = null
        val dir = File(context.filesDir, "photos/raw").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        current.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                onCaptured(file, customText.trim())
            }
            override fun onError(exception: ImageCaptureException) {
                taking = false
                file.delete()
                error = "فشل التصوير: ${exception.message ?: "حاول مرة أخرى"}"
            }
        })
    }

    // التركيز على الشاشة عشان أزرار الصوت توصلها (وترجع تاخده بعد قفل حقل السبب)
    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(showReasonInput, taking, cameraReady) {
        if (!showReasonInput) { try { focusRequester.requestFocus() } catch (_: Exception) { } }
    }

    Dialog(
        onDismissRequest = { if (!taking) onCancel() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
    ) {
        // أزرار الصوت على مستوى نافذة الكاميرا نفسها (أضمن من تركيز Compose على أغلب الموبايلات): تصوّر مرة واحدة وتمنع شريط الصوت
        val shootNow by rememberUpdatedState(newValue = { shoot() })
        var lastVolumeShot by remember { mutableStateOf(0L) }
        val hostView = LocalView.current
        DisposableEffect(hostView) {
            val window = (hostView.parent as? DialogWindowProvider)?.window
            val original = window?.callback
            if (window != null && original != null) {
                window.callback = object : Window.Callback by original {
                    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
                        if (event.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP || event.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN) {
                            if (event.action == android.view.KeyEvent.ACTION_DOWN && event.repeatCount == 0) shootNow()
                            return true
                        }
                        return original.dispatchKeyEvent(event)
                    }
                }
            }
            onDispose { if (window != null && original != null) window.callback = original }
        }
        KeepScreenOn()
        ApplyCameraSettings(settings, boundCamera)
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(
                Modifier.fillMaxSize()
                    .focusRequester(focusRequester)
                    .focusable()
                    .onPreviewKeyEvent { ev ->
                        if (ev.key == Key.VolumeUp || ev.key == Key.VolumeDown) {
                            // نصوّر مرة واحدة عند الضغط (من غير تكرار لو فضل ضاغط)، ونمنع ظهور شريط الصوت
                            // (من غير nativeKeyEvent عشان الـ Build ما يتأثرش بإصدار Compose) منع التكرار بفاصل زمني قصير
                            val now = System.currentTimeMillis()
                            if (ev.type == KeyEventType.KeyDown && now - lastVolumeShot > 700) { lastVolumeShot = now; shoot() }
                            true
                        } else false
                    }
            ) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().cameraGestures(onZoomBy = { setZoom(zoomRatio * it) }, onTap = { focusAt(it.x, it.y) }))
                if (settings.grid) CameraGrid()
                FocusRing(focusPoint) { focusPoint = null }
                DraggableInfoBar()

                // شريط علوي عائم (فلاش + تبديل الكاميرا) على تدرّج شفاف
                Box(Modifier.align(Alignment.TopCenter)) {
                    CameraTopBar {
                        CameraPill(
                            if (flashOn) "⚡ تشغيل" else "⚡ إيقاف", onClick = { toggleFlash() },
                            enabled = cameraReady && hasFlash && !taking, compact = true
                        )
                        CameraPill(
                            if (lensFacing == CameraSelector.LENS_FACING_BACK) "🔄 أمامية" else "🔄 خلفية",
                            onClick = { if (!taking) lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK },
                            enabled = cameraReady && !taking, compact = true
                        )
                        CameraPill("⚙ إعدادات", onClick = { settings.open = !settings.open }, enabled = cameraReady, compact = true)
                    }
                }

                // السبب اختياري: كبسولة متقطّعة تحت الشريط، وتفتح حقل الكتابة لو المراقب طلبه
                Column(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 70.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!showReasonInput) {
                        ReasonPill(onClick = { showReasonInput = true }, enabled = !taking)
                    } else {
                        Surface(Modifier.fillMaxWidth(), color = Color(0xCC111111), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("سبب المخالفة (اختياري)", color = Color.White, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { showReasonInput = false; customText = "" }, enabled = !taking) { Text("إخفاء", color = Color.White) }
                                }
                                OutlinedTextField(
                                    value = customText, onValueChange = { customText = it }, modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("اكتب السبب أو اتركه فارغًا") }, minLines = 1, maxLines = 3, enabled = !taking,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color.White, unfocusedBorderColor = Color.LightGray,
                                        cursorColor = Color.White, focusedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                CameraSettingsPanel(settings, boundCamera, Modifier.align(Alignment.TopCenter).padding(top = 64.dp))

                error?.let { msg ->
                    Text(msg, color = Color.White, modifier = Modifier.align(Alignment.Center)
                        .background(Color(0xDD880000), RoundedCornerShape(10.dp)).padding(16.dp))
                }

                // كارت الزوم + الشريط السفلي (إلغاء — زرار التصوير الدايري)
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                    ZoomBadge(zoomRatio, Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
                    CameraBottomBar(
                        cancel = { CameraCancelButton(onClick = onCancel, enabled = !taking) },
                        center = {
                            CameraShutterButton(enabled = cameraReady && !taking && error == null, busy = taking) { shoot() }
                        }
                    )
                }
                if (!cameraReady && error == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            }
        }
    }
}
