package com.raneen.quality.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File

/** تصوير صورة مع كتابة وصف اختياري على المعاينة قبل الضغط على زر التصوير. */
@Composable
fun PhotoCaptureDialog(
    onCaptured: (file: File, customText: String) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var customText by remember { mutableStateOf("") }
    // الكاميرا تفتح مباشرة؛ لا تظهر خانة السبب إلا إذا اختار المراقب إضافتها.
    var showReasonInput by remember { mutableStateOf(false) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var cameraReady by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var taking by remember { mutableStateOf(false) }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val photoCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, photoCapture)
                capture = photoCapture
                cameraReady = true
            } catch (t: Throwable) {
                error = "تعذّر تشغيل الكاميرا: ${t.localizedMessage ?: "خطأ غير معروف"}"
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) { }
        }
    }

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize()) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                // لا نعطّل المراقب بخانة كتابة ظاهرة دائمًا؛ تظهر فقط عند طلبه.
                Column(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!showReasonInput) {
                        OutlinedButton(
                            onClick = { showReasonInput = true },
                            enabled = !taking,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) { Text("＋ إضافة سبب اختياري") }
                    } else {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xCC111111),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("سبب المخالفة (اختياري)", color = Color.White, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = customText,
                                    onValueChange = { customText = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("اكتب السبب قبل التصوير، أو اتركه فارغًا") },
                                    minLines = 1,
                                    maxLines = 3,
                                    enabled = !taking,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color.White,
                                        unfocusedBorderColor = Color.LightGray,
                                        focusedLabelColor = Color.White,
                                        cursorColor = Color.White
                                    )
                                )
                                if (customText.isNotBlank()) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(customText, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                }
                error?.let { msg ->
                    Text(msg, color = Color.White, modifier = Modifier.align(Alignment.Center).background(Color(0xDD880000), RoundedCornerShape(10.dp)).padding(16.dp))
                }
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color(0xCC111111)).padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(onClick = onCancel, enabled = !taking, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                    Button(
                        onClick = {
                            val current = capture ?: return@Button
                            if (taking) return@Button
                            taking = true
                            error = null
                            val dir = File(context.filesDir, "photos/raw").apply { mkdirs() }
                            val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
                            val options = ImageCapture.OutputFileOptions.Builder(file).build()
                            current.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                    onCaptured(file, customText.trim())
                                }
                                override fun onError(exception: ImageCaptureException) {
                                    taking = false
                                    file.delete()
                                    error = "فشل التصوير: ${exception.message ?: "حاول مرة أخرى"}"
                                }
                            })
                        },
                        enabled = cameraReady && !taking && error == null,
                        modifier = Modifier.weight(1f)
                    ) { Text(if (taking) "جارٍ التصوير…" else "📷 تصوير") }
                }
                if (!cameraReady && error == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            }
        }
    }
}
