package com.raneen.quality.ui

import android.content.Context
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File

/** تصوير صورة من داخل التطبيق مع أدوات الفلاش والزوم وتبديل الكاميرا، وسبب اختياري. */
@Composable
fun PhotoCaptureDialog(
    onCaptured: (file: File, customText: String) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var customText by remember { mutableStateOf("") }
    var showReasonInput by remember { mutableStateOf(false) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var cameraReady by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var flashOn by remember { mutableStateOf(false) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var maxZoomRatio by remember { mutableFloatStateOf(1f) }
    var error by remember { mutableStateOf<String?>(null) }
    var taking by remember { mutableStateOf(false) }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(owner, lensFacing) {
        cameraReady = false
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val photoCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                provider.unbindAll()
                val camera = provider.bindToLifecycle(owner, selector, preview, photoCapture)
                boundCamera = camera
                capture = photoCapture
                hasFlash = camera.cameraInfo.hasFlashUnit()
                flashOn = false
                maxZoomRatio = (camera.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f).coerceAtLeast(1f)
                zoomRatio = 1f
                cameraReady = true
                error = null
            } catch (t: Throwable) {
                cameraReady = false
                error = "تعذّر تشغيل الكاميرا: ${t.localizedMessage ?: "قد لا تكون الكاميرا الأمامية مدعومة"}"
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            try { boundCamera?.cameraControl?.enableTorch(false) } catch (_: Exception) { }
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) { }
            boundCamera = null
        }
    }

    fun setZoom(value: Float) {
        val next = value.coerceIn(1f, maxZoomRatio.coerceAtLeast(1f))
        try { boundCamera?.cameraControl?.setZoomRatio(next) } catch (_: Exception) { }
        zoomRatio = next
    }

    fun toggleFlash() {
        val cam = boundCamera ?: return
        if (!hasFlash) {
            error = "الفلاش غير مدعوم في الكاميرا الحالية"
            return
        }
        val next = !flashOn
        try {
            cam.cameraControl.enableTorch(next)
            flashOn = next
            error = null
        } catch (_: Exception) { error = "تعذّر تغيير حالة الفلاش" }
    }

    Dialog(
        onDismissRequest = { if (!taking) onCancel() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize()) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

                // أدوات الكاميرا تظل ظاهرة ولا تتطلب كتابة السبب.
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 10.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { toggleFlash() }, enabled = cameraReady && hasFlash && !taking,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                    ) { Text(if (flashOn) "⚡ الفلاش تشغيل" else "⚡ الفلاش إيقاف") }
                    OutlinedButton(
                        onClick = { if (!taking) lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK },
                        enabled = cameraReady && !taking,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                    ) { Text(if (lensFacing == CameraSelector.LENS_FACING_BACK) "🔄 أمامية" else "🔄 خلفية") }
                }

                Column(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 66.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!showReasonInput) {
                        OutlinedButton(
                            onClick = { showReasonInput = true }, enabled = !taking,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) { Text("＋ إضافة سبب اختياري") }
                    } else {
                        Surface(Modifier.fillMaxWidth(), color = Color(0xCC111111), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("سبب المخالفة (اختياري)", color = Color.White, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { showReasonInput = false; customText = "" }, enabled = !taking) { Text("إخفاء", color = Color.White) }
                                }
                                OutlinedTextField(
                                    value = customText, onValueChange = { customText = it }, modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("اكتب السبب أو اتركه فارغًا") }, minLines = 1, maxLines = 3, enabled = !taking,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color.White, unfocusedBorderColor = Color.LightGray,
                                        cursorColor = Color.White, focusedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                error?.let { msg ->
                    Text(msg, color = Color.White, modifier = Modifier.align(Alignment.Center)
                        .background(Color(0xDD880000), RoundedCornerShape(10.dp)).padding(16.dp))
                }

                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xCC111111)).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("الزوم ${"%.1f".format(zoomRatio)}×", color = Color.White, modifier = Modifier.weight(1f))
                        TextButton(onClick = { setZoom((zoomRatio - 0.5f).coerceAtLeast(1f)) }, enabled = cameraReady && zoomRatio > 1f && !taking) { Text("−", color = Color.White) }
                        TextButton(onClick = { setZoom((zoomRatio + 0.5f).coerceAtMost(maxZoomRatio)) }, enabled = cameraReady && zoomRatio < maxZoomRatio && !taking) { Text("+", color = Color.White) }
                    }
                    if (maxZoomRatio > 1f) {
                        Slider(
                            value = zoomRatio.coerceIn(1f, maxZoomRatio), onValueChange = { setZoom(it) },
                            valueRange = 1f..maxZoomRatio, enabled = cameraReady && !taking,
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = 0.35f))
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = onCancel, enabled = !taking, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                        Button(
                            onClick = {
                                val current = capture ?: return@Button
                                if (taking) return@Button
                                taking = true
                                error = null
                                val dir = File(context.filesDir, "photos/raw").apply { mkdirs() }
                                val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
                                val options = ImageCapture.OutputFileOptions.Builder(file).build()
                                current.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                        onCaptured(file, customText.trim())
                                    }
                                    override fun onError(exception: ImageCaptureException) {
                                        taking = false
                                        file.delete()
                                        error = "فشل التصوير: ${exception.message ?: "حاول مرة أخرى"}"
                                    }
                                })
                            }, enabled = cameraReady && !taking && error == null, modifier = Modifier.weight(1f)
                        ) { Text(if (taking) "جارٍ التصوير…" else "📷 تصوير") }
                    }
                }
                if (!cameraReady && error == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            }
        }
    }
}
