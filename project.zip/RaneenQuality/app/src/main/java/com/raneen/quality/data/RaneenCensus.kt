package com.raneen.quality.data

/**
 * ضوابط الحصر: ضوابط بدون درجة (maxScore = 0) بيتكتب فيها عدد لكل مجموعة منتجات والأعداد بتتجمع.
 * موجودة في أقسام التشغيل (منزلي، ألعاب، مفروشات، كهرباء) في آخر صفحة القسم.
 * الأدمن يقدر يعدّلها أو يزوّد عليها من شاشة الأقسام والضوابط (ضابط حصر = وزنه صفر).
 */
object CensusDefaults {
    val UNITS = listOf("home_tools", "toys_kids", "furnishings", "electrical")
    private const val NEW_MISSING_TITLE = "حصر أدوات العرض"
    private const val OLD_MISSING_TITLE = "حصر كسر وفقد أدوات التسعير"

    private val GROUPS = listOf(
        Triple("pricing", "حصر أدوات التسعير", listOf(
            "بدون شيلف", "شيلف تالف", "شيلف غير مطابق", "بدون صاين", "صاين عرض غير منفذ", "صاين عرض منتهي",
            "صاين تلف جزئي", "بدون توكر", "صاين / توكر تالف", "بدون كود", "كود تالف / كود خطأ",
            "أبديت مسمى", "بدون سعر", "سعر تالف / خطأ", "أبديت سعر"
        )),
        Triple("missing", NEW_MISSING_TITLE, listOf(
            "كسر مسطرة", "فقد مسطرة", "كسر اكليرك A6", "فقد اكليرك A6", "كسر اكليرك نص A6", "فقد اكليرك نص A6",
            "كسر سدابه", "فقد سدابه", "كسر بولسترين", "فقد بولسترين"
        ))
    )

    /** بيضيف ضوابط الحصر الناقصة. بيرجّع true لو أضاف حاجة (يعني الكتالوج اتغيّر ولازم يتبعت للسيرفر). */
    suspend fun ensure(dao: CatalogDao): Boolean {
        val unitIds = dao.allUnits().filter { it.isActive }.map { it.id }.toSet()
        val allCats = dao.allCategories()
        val cats = allCats.map { it.id }.toSet()
        var changed = false
        // تغيير الاسم القديم للي اتعمل قبل كده (لو الأدمن مغيّرش الاسم بإيده)
        allCats.filter { it.id.startsWith("cns_missing_") && it.name == OLD_MISSING_TITLE }.forEach {
            dao.upsertCategories(listOf(it.copy(name = NEW_MISSING_TITLE)))
            changed = true
        }
        for (u in UNITS) {
            if (u !in unitIds) continue
            var sort = dao.maxCategorySort(u)
            for ((key, title, items) in GROUPS) {
                val cid = "cns_${key}_$u"
                if (cid in cats) continue
                sort += 1
                dao.upsertCategories(listOf(CategoryEntity(cid, u, title, sort)))
                dao.upsertControls(items.mapIndexed { i, t ->
                    ControlEntity(
                        id = "${cid}_${i + 1}", categoryId = cid, text = t, maxScore = 0.0, penaltyPerViolation = 1.0,
                        photoRequired = false, perGroup = true, hint = null, sortOrder = i + 1
                    )
                })
                changed = true
            }
        }
        return changed
    }
}
