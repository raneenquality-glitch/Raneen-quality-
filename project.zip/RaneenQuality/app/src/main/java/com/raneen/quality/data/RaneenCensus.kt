package com.raneen.quality.data


/** بيانات حصر مرتبطة ببند المخالفة نفسه، محفوظة داخل note حتى تعمل المزامنة الحالية دون تغيير مخطط قاعدة البيانات. */
data class InlineCensusValue(val count: Int = 0, val value: Double = 0.0)

object InlineCensusData {
    private const val PREFIX = "RQ_CENSUS_V1:"

    fun parse(note: String?): Map<String, InlineCensusValue> {
        if (note.isNullOrBlank() || !note.startsWith(PREFIX)) return emptyMap()
        return try {
            val json = org.json.JSONObject(note.removePrefix(PREFIX))
            buildMap {
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val item = json.optJSONObject(key) ?: continue
                    put(key, InlineCensusValue(item.optInt("count", 0).coerceAtLeast(0), item.optDouble("value", 0.0).coerceAtLeast(0.0)))
                }
            }
        } catch (_: Exception) { emptyMap() }
    }

    fun encode(values: Map<String, InlineCensusValue>): String? {
        val json = org.json.JSONObject()
        values.forEach { (key, value) ->
            if (value.count > 0 || value.value > 0.0) json.put(key, org.json.JSONObject()
                .put("count", value.count.coerceAtLeast(0)).put("value", value.value.coerceAtLeast(0.0)))
        }
        return if (json.length() == 0) null else PREFIX + json.toString()
    }

    fun summary(note: String?): String {
        val values = parse(note)
        if (values.isEmpty()) return ""
        val labels = mapOf(
            "partial_damage" to "عدد صاين تلف جزئي",
            "no_shelf" to "عدد الشيلفات", "mismatch" to "عدم تطابق", "no_price" to "عدد الأسعار",
            "no_code" to "أكواد", "stand_offer" to "صاين عرض", "stand_price" to "صاين سعر",
            "display_ruler" to "مسطرة", "display_sadabat" to "السدابات",
            "display_acrylic" to "الاكليرك", "display_polystyrene" to "بولسترين",
            "display_half_a6_acrylic" to "اكليرك نص A6",
            "connections" to "عدد الوصلات", "ac_units" to "عدد التكييفات",
            // أسماء قديمة للاحتفاظ بقراءة تقارير الحصر السابقة دون فقد بياناتها.
            "no_stand" to "عدد بدون صاين (تسجيل قديم)",
            "offer_not_applied" to "عدد صاين عرض غير منفذ (تسجيل قديم)",
            "expired_offer" to "عدد صاين عرض منتهي (تسجيل قديم)"
        )
        val details = values.entries.mapNotNull { (key, v) ->
            val label = labels[key] ?: return@mapNotNull null
            when (key) {
                "no_code" -> if (v.count > 0 || v.value > 0.0) "$label (${v.count}) بقيمة (${String.format(java.util.Locale.US, "%.2f", v.value)} ج.م)" else null
                else -> if (v.count > 0) "$label: ${v.count}" else null
            }
        }.toMutableList()
        // تجميع الحصر المطلوب: صاين التلف الجزئي + صاين العرض + صاين السعر.
        val combined = listOf("partial_damage", "stand_offer", "stand_price").sumOf { values[it]?.count ?: 0 }
        if (combined > 0) details.add("إجمالي ($combined)")
        return details.joinToString("، ")
    }
}

/**
 * ضوابط الحصر: ضوابط بدون درجة (maxScore = 0) بيتكتب فيها عدد لكل مجموعة منتجات والأعداد بتتجمع.
 * موجودة في أقسام التشغيل (منزلي، ألعاب، مفروشات، كهرباء) في آخر صفحة القسم.
 * الأدمن يقدر يعدّلها أو يزوّد عليها من شاشة الأقسام والضوابط (ضابط حصر = وزنه صفر).
 */
object CensusDefaults {
    val UNITS = listOf("home_tools", "toys_kids", "furnishings", "electrical")
    private const val NEW_MISSING_TITLE = "حصر أدوات العرض"
    private const val OLD_MISSING_TITLE = "حصر كسر وفقد أدوات التسعير"

    private val GROUPS = listOf(
        Triple("pricing", "حصر أدوات التسعير", listOf(
            "بدون شيلف", "شيلف تالف", "شيلف غير مطابق", "بدون صاين", "صاين عرض غير منفذ", "صاين عرض منتهي",
            "صاين تلف جزئي", "بدون توكر", "صاين / توكر تالف", "بدون كود", "كود تالف / كود خطأ",
            "أبديت مسمى", "بدون سعر", "سعر تالف / خطأ", "أبديت سعر"
        )),
        Triple("missing", NEW_MISSING_TITLE, listOf(
            "كسر مسطرة", "فقد مسطرة", "كسر اكليرك A6", "فقد اكليرك A6", "كسر اكليرك نص A6", "فقد اكليرك نص A6",
            "كسر سدابه", "فقد سدابه", "كسر بولسترين", "فقد بولسترين"
        ))
    )

    /** بيضيف ضوابط الحصر الناقصة. بيرجّع true لو أضاف حاجة (يعني الكتالوج اتغيّر ولازم يتبعت للسيرفر). */
    suspend fun ensure(dao: CatalogDao): Boolean {
        val unitIds = dao.allUnits().filter { it.isActive }.map { it.id }.toSet()
        val allCats = dao.allCategories()
        val cats = allCats.map { it.id }.toSet()
        var changed = false
        // تغيير الاسم القديم للي اتعمل قبل كده (لو الأدمن مغيّرش الاسم بإيده)
        allCats.filter { it.id.startsWith("cns_missing_") && it.name == OLD_MISSING_TITLE }.forEach {
            dao.upsertCategories(listOf(it.copy(name = NEW_MISSING_TITLE)))
            changed = true
        }
        for (u in UNITS) {
            if (u !in unitIds) continue
            var sort = dao.maxCategorySort(u)
            for ((key, title, items) in GROUPS) {
                val cid = "cns_${key}_$u"
                if (cid in cats) continue
                sort += 1
                dao.upsertCategories(listOf(CategoryEntity(cid, u, title, sort)))
                dao.upsertControls(items.mapIndexed { i, t ->
                    ControlEntity(
                        id = "${cid}_${i + 1}", categoryId = cid, text = t, maxScore = 0.0, penaltyPerViolation = 1.0,
                        photoRequired = false, perGroup = true, hint = null, sortOrder = i + 1
                    )
                })
                changed = true
            }
        }
        return changed
    }
}
