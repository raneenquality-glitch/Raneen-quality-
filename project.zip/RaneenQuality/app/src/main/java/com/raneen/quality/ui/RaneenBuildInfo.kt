package com.raneen.quality.ui

/** رقم نسخة التطبيق: بيظهر في شاشة الدخول وفي رأس الصفحة الرئيسية عشان تتأكد إن الـ APK المثبّت هو الأحدث */
object BuildInfo {
    const val STAMP = "2026-11-08 · A"
}
