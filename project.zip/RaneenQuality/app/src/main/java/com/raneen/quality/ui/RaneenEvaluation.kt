package com.raneen.quality.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.raneen.quality.data.*
import com.raneen.quality.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// قوالب التقييم الجديدة مع الإبقاء على معنى القوالب القديمة للتقارير المحفوظة.
internal fun belongsToEvaluationTemplate(unit: EvaluationUnitEntity, templateId: String): Boolean {
    val id = unit.id
    return when (templateId) {
        "offline" -> (unit.templateId == "main" && !id.startsWith("digital_")) || unit.templateId == "offline"
        "smart" -> unit.templateId == "zayed"
        "digital" -> id.startsWith("digital_") ||
            (unit.templateId == "main" && !id.startsWith("digital_") && id !in setOf("furnishings", "electrical"))
        // القوالب القديمة: نفس منطق الفلترة السابق
        "zayed" -> unit.templateId == "zayed" || id.startsWith("digital_")
        "main" -> unit.templateId == "main"
        else -> unit.templateId == templateId
    }
}

internal fun evaluationTemplateLabel(templateId: String): String = when (templateId) {
    "smart", "zayed" -> "تقييم معارض سمارت"
    "digital" -> "تقييم معارض الديجيتال"
    "offline", "main" -> "تقييم المعارض الأوف لاين"
    else -> "تقييم جودة"
}

internal const val MAINTENANCE_CENSUS_CONTROL_ID = "__maintenance_census__"
internal const val MAINTENANCE_CENSUS_PREFIX = "RQ_MAINTENANCE_CENSUS_V1:"

// Repository
class InspectionRepository(db: RaneenDatabase, private val appContext: Context) {
    private val catalog = db.catalogDao()
    private val dao = db.inspectionDao()

    fun units(): Flow<List<EvaluationUnitEntity>> = catalog.observeUnits()
    fun branches(): Flow<List<BranchEntity>> = catalog.observeBranches()
    fun inspectionFlow(id: String): Flow<InspectionEntity?> = dao.observeInspection(id)
    fun allFindings(inspectionId: String): Flow<List<FindingEntity>> = dao.observeAllFindings(inspectionId)
    fun unitStates(inspectionId: String): Flow<List<InspectionUnitEntity>> = dao.observeUnitStates(inspectionId)
    fun unitPhotos(inspectionId: String, unitId: String): Flow<List<PhotoEntity>> = dao.observeUnitPhotos(inspectionId, unitId)

    /** فروع تجريبية لأول تشغيل بس — الأدمن يقدر يعدلها أو يحذفها من شاشة الفروع */
    suspend fun seedBranchesIfEmpty() {
        if (catalog.branchCount() > 0) return
        catalog.upsertBranches(listOf(
            BranchEntity("b001", "001", "فرع الفيوم", "الفيوم"),
            BranchEntity("b002", "002", "مدينة نصر", "القاهرة")
        ))
    }

    /** مسودة موجودة للمراقب على نفس الفرع/القالب/الزيارة في الشهر ده: بنكمّل عليها بدل ما نعمل تقرير تاني (منع التكرار). */
    suspend fun draftFor(branchId: String, templateId: String, visit: String, inspectorId: String): InspectionEntity? =
        dao.sameVisitCandidates(branchId, templateId, visit, "").firstOrNull {
            it.inspectorId == inspectorId && it.status == Status.DRAFT && cairoMonth(it.visitDate) == cairoMonth(System.currentTimeMillis())
        }

    suspend fun startInspection(
        branchId: String, inspectorId: String, reportNumber: String, visitNumber: String,
        selectedTemplateId: String? = null
    ): String {
        val id = UUID.randomUUID().toString()
        val branchName = catalog.branchNameById(branchId).orEmpty()
        // لو مفيش قالب مختار: نرجع للسلوك القديم (زايد أو الرئيسي حسب اسم الفرع)
        val legacyTemplate = if (branchName.contains("زايد", ignoreCase = true) || branchName.contains("zayed", ignoreCase = true)) "zayed" else "main"
        val templateId = selectedTemplateId ?: legacyTemplate
        dao.insertInspection(InspectionEntity(id, reportNumber, templateId, branchId, inspectorId, System.currentTimeMillis(), visitNumber = visitNumber))
        return id
    }

    suspend fun load(unitId: String) = Triple(catalog.groups(unitId), catalog.categories(unitId), catalog.controls(unitId))
    fun findings(inspectionId: String, unitId: String) = dao.observeFindings(inspectionId, unitId)
    suspend fun controlDefs(unitId: String) = dao.controlDefs(unitId)
    suspend fun orderedControlIds(unitId: String) = dao.orderedControlIds(unitId)

    suspend fun setNA(inspectionId: String, unitId: String, na: Boolean) =
        dao.upsertUnitState(InspectionUnitEntity(inspectionId, unitId, na))

    suspend fun unitScores(inspectionId: String): Map<String, UnitScore> = withContext(Dispatchers.IO) {
        val templateId = dao.inspection(inspectionId)?.templateId ?: "main"
        dao.activeUnits(templateId).associate { u -> u.id to scoreUnit(dao.controlDefs(u.id), dao.findingsFor(inspectionId, u.id)) }
    }

    /** X = تشغيل/إيقاف. إلغاء المخالفة بيمسح صورها كمان. (Auto Save فوري) */
    suspend fun toggleX(inspectionId: String, unitId: String, controlId: String, groupId: String, current: Int) {
        if (current > 0) {
            removePhotos(inspectionId, unitId, controlId, groupId)
            dao.decrementViolation(inspectionId, unitId, controlId, groupId)
            dao.clearNoteIfNoViolation(inspectionId, unitId, controlId, groupId)
        } else dao.tapX(inspectionId, unitId, controlId, groupId, newId = UUID.randomUUID().toString())
    }

    /** مطابق: بيمسح المخالفة بالكامل (العداد = 0) وصورها، حتى لو البند متعدد الأجزاء (bitmask) */
    suspend fun clearViolation(inspectionId: String, unitId: String, controlId: String, groupId: String) {
        mergeLegacyAreaPartGroups(inspectionId, unitId, controlId)
        removePhotos(inspectionId, unitId, controlId, groupId)
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId) ?: return
        dao.setCount(fid, 0)
        dao.setViolationNote(fid, null)
    }

    /** ضوابط الحصر: بيحفظ العدد (Auto Save). صفر = مفيش عدد. */
    suspend fun setUnitPrice(inspectionId: String, unitId: String, controlId: String, groupId: String, price: Double) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) {
            val id = UUID.randomUUID().toString()
            dao.upsertFindings(listOf(FindingEntity(id, inspectionId, unitId, controlId, groupId, 0, "PRICE:${price.coerceAtLeast(0.0)}")))
        } else dao.setFindingNote(fid, "PRICE:${price.coerceAtLeast(0.0)}")
    }

    suspend fun setViolationNote(inspectionId: String, unitId: String, controlId: String, groupId: String, note: String) {
        val clean = note.ifBlank { null }
        var fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) {
            if (clean == null) return
            // مفيش صف للبند لسه: نعمله بدل ما الملاحظة تضيع بصمت
            dao.insertFindingIfMissing(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, controlId, groupId, 0))
            fid = dao.findingId(inspectionId, unitId, controlId, groupId) ?: return
        }
        dao.setViolationNote(fid, clean)
    }

    suspend fun setInlineCensus(inspectionId: String, unitId: String, controlId: String, groupId: String, values: Map<String, InlineCensusValue>) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId) ?: return
        dao.setFindingNote(fid, InlineCensusData.encode(values))
    }

    /** حصر هيكل الفرع (الموارد البشرية): نوتة على ضابط خاص، فاضي = مسح */
    suspend fun setStructureCensus(inspectionId: String, unitId: String, json: String) {
        val note = if (json.isBlank()) null else StructureCensus.PREFIX + json
        val fid = dao.findingId(inspectionId, unitId, StructureCensus.CONTROL_ID, "")
        if (fid == null) {
            if (note != null) dao.upsertFindings(listOf(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, StructureCensus.CONTROL_ID, "", 0, note)))
        } else dao.setFindingNote(fid, note)
    }

    suspend fun setMaintenanceCensus(inspectionId: String, unitId: String, json: String) {
        val note = if (json.isBlank() || json == "[]") null else MAINTENANCE_CENSUS_PREFIX + json
        val fid = dao.findingId(inspectionId, unitId, MAINTENANCE_CENSUS_CONTROL_ID, "")
        if (fid == null) {
            if (note != null) dao.upsertFindings(listOf(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, MAINTENANCE_CENSUS_CONTROL_ID, "", 0, note)))
        } else dao.setFindingNote(fid, note)
    }

    /**
     * بند في حصر الصيانة اتعلّم "مخالف": بيتسجل مخالفة حقيقية على بند الصيانة المقابل (نفس اللي بيحصل
     * لما تدوس X على البند في الشاشة)، ومرفقات البند (صور/فيديو) بتتنقل من سجل الحصر لمخالفة البند،
     * وشرح المشكلة بيتكتب ملاحظة على المخالفة.
     */
    suspend fun markCensusViolation(inspectionId: String, unitId: String, controlId: String, problem: String, mediaIds: List<String>) {
        if (controlId.isBlank()) return
        setCount(inspectionId, unitId, controlId, "", 1)
        val targetFid = dao.findingId(inspectionId, unitId, controlId, "") ?: return
        if (mediaIds.isNotEmpty()) {
            val censusFid = dao.findingId(inspectionId, unitId, MAINTENANCE_CENSUS_CONTROL_ID, "")
            if (censusFid != null) {
                val onCensus = dao.photosOfFinding(censusFid).map { it.id }.toSet()
                mediaIds.filter { it in onCensus }.forEach { dao.movePhoto(it, targetFid) }
            }
        }
        setViolationNote(inspectionId, unitId, controlId, "", problem)
    }

    /**
     * إلغاء "مخالف" من الحصر: المرفقات بترجع لسجل الحصر (مش بتتمسح)، والمخالفة بتتصفّر وملاحظتها بتتشال.
     */
    suspend fun clearCensusViolation(inspectionId: String, unitId: String, controlId: String) {
        if (controlId.isBlank()) return
        val fid = dao.findingId(inspectionId, unitId, controlId, "") ?: return
        val censusFid = dao.findingId(inspectionId, unitId, MAINTENANCE_CENSUS_CONTROL_ID, "")
        if (censusFid != null) dao.photosOfFinding(fid).forEach { dao.movePhoto(it.id, censusFid) }
        dao.setCount(fid, 0)
        dao.setViolationNote(fid, null)
    }

    /**
     * بنود الأجزاء على مستوى القسم (6 نظافة/تخزين آمن...): لو في صفوف قديمة مسجّلة لكل مجموعة لوحدها،
     * بندمجها في صف واحد (groupId = "") بـ OR للأجزاء + ننقل الصور، وبعدها الكتابة الجديدة تشتغل عليه.
     */
    suspend fun mergeLegacyAreaPartGroups(inspectionId: String, unitId: String, controlId: String) {
        if (controlId !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) return
        val rows = dao.groupedFindingsOf(inspectionId, unitId, listOf(controlId))
        if (rows.isEmpty()) return
        val targetId = dao.findingId(inspectionId, unitId, controlId, "")
        val targetCount = targetId?.let { id -> dao.findingsFor(inspectionId, unitId).firstOrNull { it.controlId == controlId && it.groupId == "" }?.violations } ?: 0
        val merged = mergeAreaPartViolations(rows.map { it.violationCount } + targetCount)
        val keepId = targetId ?: UUID.randomUUID().toString()
        if (targetId == null) {
            dao.upsertFindings(listOf(FindingEntity(keepId, inspectionId, unitId, controlId, "", merged, null, rows.firstNotNullOfOrNull { it.violationNote?.takeIf { n -> n.isNotBlank() } })))
        } else dao.setCount(keepId, merged)
        rows.forEach { dao.movePhotos(it.id, keepId); dao.deleteFindingRow(it.id) }
    }

    suspend fun setCount(inspectionId: String, unitId: String, controlId: String, groupId: String, n: Int) {
        mergeLegacyAreaPartGroups(inspectionId, unitId, controlId)
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) {
            if (n > 0) dao.upsertFindings(listOf(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, controlId, groupId, n)))
        } else dao.setCount(fid, n)
    }

    private suspend fun removePhotos(i: String, u: String, c: String, g: String) = withContext(Dispatchers.IO) {
        val fid = dao.findingId(i, u, c, g) ?: return@withContext
        dao.photosOfFinding(fid).forEach { File(it.filePath).delete(); dao.deletePhotoRow(it.id) }
    }

    suspend fun deletePhoto(p: PhotoEntity) = withContext(Dispatchers.IO) {
        File(p.filePath).delete(); dao.deletePhotoRow(p.id)
    }

    suspend fun headerNames(inspectionId: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val i = dao.inspection(inspectionId) ?: return@withContext "" to ""
        (dao.branchName(i.branchId) ?: "") to (dao.userName(i.inspectorId) ?: "")
    }

    /** بيختم الصورة (فرع/قسم/تاريخ/وقت/مراقب)، يحفظها في مخزن التطبيق الخاص، ويربطها بالمخالفة */
    suspend fun addPhoto(
        inspectionId: String, unitId: String, controlId: String, groupId: String, raw: File, lines: List<String>, customText: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) { raw.delete(); return@withContext false }
        val out = File(File(appContext.filesDir, "photos").apply { mkdirs() }, "${UUID.randomUUID()}.jpg")
        val ok = PhotoStamper.stamp(raw, out, lines, customText)
        raw.delete()
        if (!ok) return@withContext false
        dao.insertPhoto(PhotoEntity(UUID.randomUUID().toString(), fid, out.path, System.currentTimeMillis()))
        MediaSaver.saveToGallery(appContext, out, false)       // نسخة في معرض الموبايل
        true
    }

    /**
     * فيديو مخالفة: بيتحرق عليه شريط البيانات (الفرع/القسم/الوقت/المراقب) وبيتحفظ جوه التطبيق + نسخة في المعرض.
     * الفيديو مبيترفعش للسيرفر (بيفضل على موبايل المراقب). بيرجّع: 0 فشل، 1 اتحفظ بالشريط، 2 اتحفظ من غير شريط.
     */
    suspend fun addVideo(
        inspectionId: String, unitId: String, controlId: String, groupId: String, raw: File, lines: List<String>, customText: String = ""
    ): Int {
        val fid = withContext(Dispatchers.IO) { dao.findingId(inspectionId, unitId, controlId, groupId) }
        if (fid == null || raw.length() == 0L) { raw.delete(); return 0 }
        val out = File(File(appContext.filesDir, "photos").apply { mkdirs() }, "${UUID.randomUUID()}.mp4")
        val stamped = VideoStamper.stamp(appContext, raw, out, lines, customText)
        return withContext(Dispatchers.IO) {
            if (stamped) raw.delete()
            else {
                out.delete()
                if (!raw.renameTo(out)) { raw.copyTo(out, overwrite = true); raw.delete() }
            }
            dao.insertPhoto(PhotoEntity(UUID.randomUUID().toString(), fid, out.path, System.currentTimeMillis(), "LOCAL_ONLY"))
            MediaSaver.saveToGallery(appContext, out, true)
            if (stamped) 1 else 2
        }
    }

    /** فيديو مخالفة: بيتحفظ زي الصور (جوه التطبيق + نسخة في المعرض). أقصى حجم 45MB (حد التخزين على السيرفر 50MB) */
}

// ViewModel
data class CategoryWithControls(val category: CategoryEntity, val controls: List<ControlEntity>)

data class EvalUi(
    val groups: List<ProductGroupEntity> = emptyList(),
    val selectedGroupId: String = "",
    val categories: List<CategoryWithControls> = emptyList(),
    val counts: Map<Pair<String, String>, Int> = emptyMap(),          // (controlId, groupId) → عدد المخالفات
    val findingIds: Map<Pair<String, String>, String> = emptyMap(),   // (controlId, groupId) → findingId
    val unitPrices: Map<Pair<String, String>, Double> = emptyMap(),
    val violationNotes: Map<Pair<String, String>, String> = emptyMap(),
    val censusCounts: Map<Pair<String, String>, Map<String, InlineCensusValue>> = emptyMap(),
    val maintenanceCensusJson: String = "",
    val maintenanceCensusFindingId: String = "",
    val structureCensusJson: String = "",
    val losses: Map<String, Double> = emptyMap(),        // controlId → إجمالي الخصم (الوزن الأصلي ما بيتغيّرش)
    val displayNo: Map<String, Int> = emptyMap(),        // ترقيم متسلسل لأوراق مدير المعرض
    val photos: Map<String, List<PhotoEntity>> = emptyMap(),          // findingId → صور
    val editable: Boolean = false,
    val managerEdit: Boolean = false,   // مدير بيعدّل: النتائج والملاحظات بس — الصور والفيديو للمراقب
    val score: UnitScore? = null
)

class EvaluationViewModel(
    private val repo: InspectionRepository,
    private val inspectionId: String,
    private val unitId: String,
    private val unitName: String,
    private val role: String = Roles.INSPECTOR,
    private val afterEdit: suspend () -> Unit = {},   // للمدير: يعلّم التقرير للرفع بعد كل تعديل
    private val userId: String = ""
) : ViewModel() {

    private val selectedGroup = MutableStateFlow("")
    private val structure = MutableStateFlow(Triple(
        emptyList<ProductGroupEntity>(), emptyList<CategoryEntity>(), emptyList<ControlEntity>()
    ))
    private var defs: List<ControlDef> = emptyList()
    private var displayNo: Map<String, Int> = emptyMap()

    init {
        viewModelScope.launch {
            val (g, c, k) = repo.load(unitId)
            defs = repo.controlDefs(unitId).map { def ->
                // البندان الاستثنائيان: قيمة العداد نفسها هي مقدار الخصم المختار (1..5).
                if (def.id == "security_i14" || def.id == "cameras_i11") def.copy(penaltyPerViolation = 1.0) else def
            }
            if (unitId in RENUMBER_UNITS) displayNo = repo.orderedControlIds(unitId).withIndex().associate { (i, id) -> id to i + 1 }
            // الخدمات والاستلامات: الأقسام اتنقلت جوه "حدد الجزء المخالف" في كل بند، فمفيش مبدّل مجموعات فوق الصفحة
            val shownGroups = if (unitId in NO_GROUP_SWITCH_UNITS) emptyList() else g
            structure.value = Triple(shownGroups, c, k)
            selectedGroup.value = shownGroups.firstOrNull()?.id ?: ""
        }
    }

    val ui: StateFlow<EvalUi> = combine(
        structure, selectedGroup, repo.findings(inspectionId, unitId),
        repo.unitPhotos(inspectionId, unitId), repo.inspectionFlow(inspectionId)
    ) { (groups, cats, controls), sel, findings, photos, insp ->
        val scoreInput = findings.map { FindingIn(it.controlId, it.groupId, it.violationCount) }
        EvalUi(
            groups = groups,
            selectedGroupId = sel,
            categories = cats.map { c -> CategoryWithControls(c, controls.filter { it.categoryId == c.id }) },
            counts = findings.associate { (it.controlId to it.groupId) to it.violationCount }.let { base ->
                // بنود الأجزاء على مستوى القسم: العرض بيدمج أي صفوف قديمة (OR) عشان الشاشة تطابق الدرجة
                base + GROUP_INDEPENDENT_AREA_PART_CONTROLS.mapNotNull { id ->
                    val rows = findings.filter { it.controlId == id }
                    if (rows.isEmpty()) null else (id to "") to mergeAreaPartViolations(rows.map { it.violationCount })
                }
            },
            findingIds = findings.associate { (it.controlId to it.groupId) to it.id },
            unitPrices = findings.mapNotNull { f -> f.note?.takeIf { it.startsWith("PRICE:") }?.removePrefix("PRICE:")?.toDoubleOrNull()?.let { (f.controlId to f.groupId) to it } }.toMap(),
            violationNotes = findings.associate { (it.controlId to it.groupId) to (it.violationNote ?: "") },
            censusCounts = findings.associate { (it.controlId to it.groupId) to InlineCensusData.parse(it.note) },
            losses = defs.associate { d ->
                val rows = findings.filter { it.controlId == d.id }.map { it.violationCount }
                d.id to controlLoss(d, if (d.id in AREA_PART_CONTROLS) mergeAreaPartViolations(rows) else rows.sum())
            },
            displayNo = displayNo,
            maintenanceCensusFindingId = findings.firstOrNull { it.controlId == MAINTENANCE_CENSUS_CONTROL_ID }?.id.orEmpty(),
            maintenanceCensusJson = findings.firstOrNull { it.controlId == MAINTENANCE_CENSUS_CONTROL_ID }?.note?.removePrefix(MAINTENANCE_CENSUS_PREFIX).orEmpty(),
            structureCensusJson = findings.firstOrNull { it.controlId == StructureCensus.CONTROL_ID }?.note?.removePrefix(StructureCensus.PREFIX).orEmpty(),
            photos = photos.groupBy { it.findingId },
            // زيارة المستخدم نفسه (مراقب أو مدير منطقة عامل زيارة) بتتعامل كزيارة مراقب مش كتعديل مدير
            editable = insp != null && Status.editableBy(if (insp.inspectorId == userId) Roles.INSPECTOR else role, insp.status),
            managerEdit = role != Roles.INSPECTOR && !(insp != null && insp.inspectorId == userId),
            score = if (defs.isEmpty()) null else scoreUnit(defs, scoreInput)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EvalUi())

    fun selectGroup(id: String) { selectedGroup.value = id }

    fun onX(control: ControlEntity) {
        val state = ui.value
        if (!state.editable) return
        val groupId = if (control.perGroup && control.id !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) state.selectedGroupId else ""
        val current = state.counts[control.id to groupId] ?: 0
        viewModelScope.launch { repo.toggleX(inspectionId, unitId, control.id, groupId, current); afterEdit() }
    }

    fun onCompliant(control: ControlEntity) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch { repo.clearViolation(inspectionId, unitId, control.id, groupId); afterEdit() }
    }

    fun setUnitPrice(control: ControlEntity, price: Double) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch { repo.setUnitPrice(inspectionId, unitId, control.id, groupId, price); afterEdit() }
    }

    // كتابات الملاحظات بتتنفذ بالترتيب بالظبط (Mutex عادل FIFO)، فنص قديم مايكتبش فوق نص أحدث
    private val noteWriteLock = Mutex()

    /**
     * groupIdOverride: المجموعة اللي الملاحظة تخصها وقت الكتابة. لازم تتبعت من الشاشة، لأن الحفظ بيحصل أحيانًا
     * وقت ما الصف بيختفي (تغيير المجموعة) وساعتها selectedGroupId يكون اتغيّر بالفعل.
     */
    fun setViolationNote(control: ControlEntity, note: String, groupIdOverride: String? = null) {
        val st = ui.value
        if (!st.editable) return
        val groupId = groupIdOverride
            ?: if (control.perGroup && control.id !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch {
            // NonCancellable: لو المراقب طلع من الشاشة والـ ViewModel اتقفل، آخر نص لازم يتكتب برضه
            withContext(NonCancellable) {
                noteWriteLock.withLock { repo.setViolationNote(inspectionId, unitId, control.id, groupId, note) }
                afterEdit()
            }
        }
    }

    fun setInlineCensus(control: ControlEntity, key: String, count: Int? = null, value: Double? = null) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) st.selectedGroupId else ""
        val pair = control.id to groupId
        val values = st.censusCounts[pair].orEmpty().toMutableMap()
        val old = values[key] ?: InlineCensusValue()
        values[key] = old.copy(count = count?.coerceAtLeast(0) ?: old.count, value = value?.coerceAtLeast(0.0) ?: old.value)
        viewModelScope.launch { repo.setInlineCensus(inspectionId, unitId, control.id, groupId, values); afterEdit() }
    }

    /**
     * حفظ حصر الهيكل + الحالة: "مخالف" بيسجّل مخالفة على بند عجز الهيكل (hr_i11) وسببها العجز خارج الفترة،
     * و"غير مخالف" بيمسحها (زي ما تدوس مطابق على البند).
     */
    fun saveStructureCensus(json: String, violation: Boolean, reason: String) {
        val st = ui.value
        if (!st.editable) return
        val cid = StructureCensus.violationControlId(unitId)
        val hasControl = st.categories.any { c -> c.controls.any { it.id == cid } }
        viewModelScope.launch {
            repo.setStructureCensus(inspectionId, unitId, json)
            if (hasControl) {
                if (violation) {
                    repo.setCount(inspectionId, unitId, cid, "", 1)
                    repo.setViolationNote(inspectionId, unitId, cid, "", reason)
                } else repo.clearViolation(inspectionId, unitId, cid, "")
            }
            afterEdit()
        }
    }

    fun saveMaintenanceCensus(json: String) {
        val st = ui.value
        if (!st.editable) return
        viewModelScope.launch {
            repo.setMaintenanceCensus(inspectionId, unitId, json)
            afterEdit()
        }
    }

    /**
     * بند حصر اتعلّم "مخالف": مخالفة حقيقية على بند الصيانة المقابل + نقل مرفقات البند + الشرح في الملاحظات.
     */
    fun markCensusViolation(controlId: String, problem: String, mediaIds: List<String>, json: String) {
        if (!ui.value.editable) return
        viewModelScope.launch {
            repo.setMaintenanceCensus(inspectionId, unitId, json)
            repo.markCensusViolation(inspectionId, unitId, controlId, problem, mediaIds)
            afterEdit()
        }
    }

    /** إلغاء "مخالف" من الحصر: المرفقات ترجع للحصر والمخالفة تتصفّر */
    fun clearCensusViolation(controlId: String, json: String) {
        if (!ui.value.editable) return
        viewModelScope.launch {
            repo.setMaintenanceCensus(inspectionId, unitId, json)
            repo.clearCensusViolation(inspectionId, unitId, controlId)
            afterEdit()
        }
    }

    /** ملاحظة المخالفة من داخل الحصر (البند اللي اتحوّل لمخالفة) */
    fun setCensusNote(controlId: String, note: String) {
        if (!ui.value.editable) return
        viewModelScope.launch {
            withContext(NonCancellable) {
                noteWriteLock.withLock { repo.setViolationNote(inspectionId, unitId, controlId, "", note) }
                afterEdit()
            }
        }
    }

    fun setCount(control: ControlEntity, n: Int) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in GROUP_INDEPENDENT_AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch { repo.setCount(inspectionId, unitId, control.id, groupId, n); afterEdit() }
    }

    /** سطور شريط البيانات: الفرع، القسم (+ المجموعة)، التاريخ والوقت، المراقب */
    private suspend fun stampLines(groupId: String, controlId: String, whenMs: Long = System.currentTimeMillis(), source: String? = null): List<String> {
        val (branch, inspector) = repo.headerNames(inspectionId)
        val now = Date(whenMs)
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(now)
        val place = ui.value.groups.firstOrNull { it.id == groupId }?.name
        val cw = ui.value.categories.firstOrNull { c -> c.controls.any { it.id == controlId } }
        val ctl = cw?.controls?.firstOrNull { it.id == controlId }
        // مكان المخالفة: القسم + المجموعة + رقم البند والكاتجري
        return listOfNotNull(
            "الفرع: $branch",
            "القسم: $unitName" + if (place != null) " — $place" else "",
            if (ctl != null && cw != null) "المخالفة: بند ${ctl.sortOrder} — ${cw.category.name}" else null,
            if (controlId == MAINTENANCE_CENSUS_CONTROL_ID) "مرفق حصر الصيانة" else null,
            "التاريخ: $d   الوقت: $t",
            source,                                   // "مصدر الصورة: من المعرض..." (بس للصور المختارة من المعرض)
            "المراقب: $inspector"
        )
    }

    fun addPhoto(controlId: String, groupId: String, raw: File, customText: String = "") {
        viewModelScope.launch {
            repo.addPhoto(inspectionId, unitId, controlId, groupId, raw, stampLines(groupId, controlId), customText)
        }
    }

    /**
     * صورة اتختارت من المعرض: بتتختم بوقت الالتقاط الأصلي (لو معروف) + سطر يوضّح إنها من المعرض.
     * لو وقت الالتقاط مجهول بنكتب ده صراحة، ووقت الإضافة بيبقى هو الوقت المسجّل.
     */
    fun addGalleryPhoto(controlId: String, groupId: String, raw: File, takenMs: Long?, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val source = if (takenMs != null) "مصدر الصورة: من المعرض (وقت الالتقاط الأصلي)"
            else "مصدر الصورة: من المعرض (وقت الالتقاط غير معروف، الوقت أعلاه وقت الإضافة)"
            val ok = repo.addPhoto(inspectionId, unitId, controlId, groupId, raw,
                stampLines(groupId, controlId, takenMs ?: System.currentTimeMillis(), source))
            onResult(ok)   // قبل كده لو الإضافة فشلت الصورة كانت بتختفي من غير أي رسالة
        }
    }

    /**
     * فيديو اتختار من المعرض: بيتحرق عليه نفس شريط البيانات + سطر "من المعرض" بوقت التصوير الأصلي، وبيتحفظ زي الفيديو المسجّل.
     * onDone: 0 فشل، 1 اتحفظ بالشريط، 2 اتحفظ من غير شريط.
     */
    fun addGalleryVideo(controlId: String, groupId: String, raw: File, takenMs: Long, onDone: (Int) -> Unit) {
        viewModelScope.launch {
            val source = "مصدر الفيديو: من المعرض (وقت التصوير الأصلي)"
            onDone(repo.addVideo(inspectionId, unitId, controlId, groupId, raw, stampLines(groupId, controlId, takenMs, source)))
        }
    }

    /** فيديو + الصور اللي اتاخدت وقت التسجيل (كل واحدة بتتختم بوقتها الفعلي) */
    fun addVideo(controlId: String, groupId: String, raw: File, snaps: List<File>, customText: String = "", onDone: (Int) -> Unit) {
        viewModelScope.launch {
            val r = repo.addVideo(inspectionId, unitId, controlId, groupId, raw, stampLines(groupId, controlId, raw.lastModified().takeIf { it > 0 } ?: System.currentTimeMillis()), customText)
            for (s in snaps) {
                repo.addPhoto(inspectionId, unitId, controlId, groupId, s, stampLines(groupId, controlId, s.lastModified().takeIf { it > 0 } ?: System.currentTimeMillis()), customText)
            }
            onDone(r)
        }
    }

    fun deletePhoto(p: PhotoEntity) {
        if (!ui.value.editable || ui.value.managerEdit) return
        viewModelScope.launch { repo.deletePhoto(p) }
    }

    class Factory(
        private val repo: InspectionRepository, private val inspectionId: String,
        private val unitId: String, private val unitName: String,
        private val role: String = Roles.INSPECTOR, private val afterEdit: suspend () -> Unit = {}, private val userId: String = ""
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            EvaluationViewModel(repo, inspectionId, unitId, unitName, role, afterEdit, userId) as T
    }
}
