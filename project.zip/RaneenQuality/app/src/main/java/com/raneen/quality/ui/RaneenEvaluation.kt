package com.raneen.quality.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.raneen.quality.data.*
import com.raneen.quality.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ───────────── Repository ─────────────
class InspectionRepository(db: RaneenDatabase, private val appContext: Context) {
    private val catalog = db.catalogDao()
    private val dao = db.inspectionDao()

    fun units(): Flow<List<EvaluationUnitEntity>> = catalog.observeUnits()
    fun branches(): Flow<List<BranchEntity>> = catalog.observeBranches()
    fun inspectionFlow(id: String): Flow<InspectionEntity?> = dao.observeInspection(id)
    fun allFindings(inspectionId: String): Flow<List<FindingEntity>> = dao.observeAllFindings(inspectionId)
    fun unitStates(inspectionId: String): Flow<List<InspectionUnitEntity>> = dao.observeUnitStates(inspectionId)
    fun unitPhotos(inspectionId: String, unitId: String): Flow<List<PhotoEntity>> = dao.observeUnitPhotos(inspectionId, unitId)

    /** فروع تجريبية لأول تشغيل بس — الأدمن يقدر يعدلها أو يحذفها من شاشة الفروع */
    suspend fun seedBranchesIfEmpty() {
        if (catalog.branchCount() > 0) return
        catalog.upsertBranches(listOf(
            BranchEntity("b001", "001", "فرع الفيوم", "الفيوم"),
            BranchEntity("b002", "002", "مدينة نصر", "القاهرة")
        ))
    }

    suspend fun startInspection(branchId: String, inspectorId: String, reportNumber: String): String {
        val id = UUID.randomUUID().toString()
        dao.insertInspection(InspectionEntity(id, reportNumber, "main", branchId, inspectorId, System.currentTimeMillis()))
        return id
    }

    suspend fun load(unitId: String) = Triple(catalog.groups(unitId), catalog.categories(unitId), catalog.controls(unitId))
    fun findings(inspectionId: String, unitId: String) = dao.observeFindings(inspectionId, unitId)
    suspend fun controlDefs(unitId: String) = dao.controlDefs(unitId)

    suspend fun setNA(inspectionId: String, unitId: String, na: Boolean) =
        dao.upsertUnitState(InspectionUnitEntity(inspectionId, unitId, na))

    suspend fun unitScores(inspectionId: String): Map<String, UnitScore> = withContext(Dispatchers.IO) {
        dao.activeUnits().associate { u -> u.id to scoreUnit(dao.controlDefs(u.id), dao.findingsFor(inspectionId, u.id)) }
    }

    /** X = تشغيل/إيقاف. إلغاء المخالفة بيمسح صورها كمان. (Auto Save فوري) */
    suspend fun toggleX(inspectionId: String, unitId: String, controlId: String, groupId: String, current: Int) {
        if (current > 0) {
            removePhotos(inspectionId, unitId, controlId, groupId)
            dao.decrementViolation(inspectionId, unitId, controlId, groupId)
        } else dao.tapX(inspectionId, unitId, controlId, groupId, newId = UUID.randomUUID().toString())
    }

    /** ضوابط الحصر: بيحفظ العدد (Auto Save). صفر = مفيش عدد. */
    suspend fun setCount(inspectionId: String, unitId: String, controlId: String, groupId: String, n: Int) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) {
            if (n > 0) dao.upsertFindings(listOf(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, controlId, groupId, n)))
        } else dao.setCount(fid, n)
    }

    private suspend fun removePhotos(i: String, u: String, c: String, g: String) = withContext(Dispatchers.IO) {
        val fid = dao.findingId(i, u, c, g) ?: return@withContext
        dao.photosOfFinding(fid).forEach { File(it.filePath).delete(); dao.deletePhotoRow(it.id) }
    }

    suspend fun deletePhoto(p: PhotoEntity) = withContext(Dispatchers.IO) {
        File(p.filePath).delete(); dao.deletePhotoRow(p.id)
    }

    suspend fun headerNames(inspectionId: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val i = dao.inspection(inspectionId) ?: return@withContext "" to ""
        (dao.branchName(i.branchId) ?: "") to (dao.userName(i.inspectorId) ?: "")
    }

    /** بيختم الصورة (فرع/قسم/تاريخ/وقت/مراقب)، يحفظها في مخزن التطبيق الخاص، ويربطها بالمخالفة */
    suspend fun addPhoto(
        inspectionId: String, unitId: String, controlId: String, groupId: String, raw: File, lines: List<String>
    ): Boolean = withContext(Dispatchers.IO) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) { raw.delete(); return@withContext false }
        val out = File(File(appContext.filesDir, "photos").apply { mkdirs() }, "${UUID.randomUUID()}.jpg")
        val ok = PhotoStamper.stamp(raw, out, lines)
        raw.delete()
        if (!ok) return@withContext false
        dao.insertPhoto(PhotoEntity(UUID.randomUUID().toString(), fid, out.path, System.currentTimeMillis()))
        true
    }
}

// ───────────── ViewModel ─────────────
data class CategoryWithControls(val category: CategoryEntity, val controls: List<ControlEntity>)

data class EvalUi(
    val groups: List<ProductGroupEntity> = emptyList(),
    val selectedGroupId: String = "",
    val categories: List<CategoryWithControls> = emptyList(),
    val counts: Map<Pair<String, String>, Int> = emptyMap(),          // (controlId, groupId) → عدد المخالفات
    val findingIds: Map<Pair<String, String>, String> = emptyMap(),   // (controlId, groupId) → findingId
    val photos: Map<String, List<PhotoEntity>> = emptyMap(),          // findingId → صور
    val editable: Boolean = false,
    val score: UnitScore? = null
)

class EvaluationViewModel(
    private val repo: InspectionRepository,
    private val inspectionId: String,
    private val unitId: String,
    private val unitName: String
) : ViewModel() {

    private val selectedGroup = MutableStateFlow("")
    private val structure = MutableStateFlow(Triple(
        emptyList<ProductGroupEntity>(), emptyList<CategoryEntity>(), emptyList<ControlEntity>()
    ))
    private var defs: List<ControlDef> = emptyList()

    init {
        viewModelScope.launch {
            val (g, c, k) = repo.load(unitId)
            defs = repo.controlDefs(unitId)
            structure.value = Triple(g, c, k)
            selectedGroup.value = g.firstOrNull()?.id ?: ""
        }
    }

    val ui: StateFlow<EvalUi> = combine(
        structure, selectedGroup, repo.findings(inspectionId, unitId),
        repo.unitPhotos(inspectionId, unitId), repo.inspectionFlow(inspectionId)
    ) { (groups, cats, controls), sel, findings, photos, insp ->
        val scoreInput = findings.map { FindingIn(it.controlId, it.groupId, it.violationCount) }
        EvalUi(
            groups = groups,
            selectedGroupId = sel,
            categories = cats.map { c -> CategoryWithControls(c, controls.filter { it.categoryId == c.id }) },
            counts = findings.associate { (it.controlId to it.groupId) to it.violationCount },
            findingIds = findings.associate { (it.controlId to it.groupId) to it.id },
            photos = photos.groupBy { it.findingId },
            editable = insp != null && Status.editable(insp.status),
            score = if (defs.isEmpty()) null else scoreUnit(defs, scoreInput)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EvalUi())

    fun selectGroup(id: String) { selectedGroup.value = id }

    fun onX(control: ControlEntity) {
        val state = ui.value
        if (!state.editable) return
        val groupId = if (control.perGroup) state.selectedGroupId else ""
        val current = state.counts[control.id to groupId] ?: 0
        viewModelScope.launch { repo.toggleX(inspectionId, unitId, control.id, groupId, current) }
    }

    fun setCount(control: ControlEntity, n: Int) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup) st.selectedGroupId else ""
        viewModelScope.launch { repo.setCount(inspectionId, unitId, control.id, groupId, n) }
    }

    fun addPhoto(controlId: String, groupId: String, raw: File) {
        viewModelScope.launch {
            val (branch, inspector) = repo.headerNames(inspectionId)
            val now = Date()
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(now)
            val lines = listOf("الفرع: $branch", "القسم: $unitName", "التاريخ: $d   الوقت: $t", "المراقب: $inspector")
            repo.addPhoto(inspectionId, unitId, controlId, groupId, raw, lines)
        }
    }

    fun deletePhoto(p: PhotoEntity) {
        if (!ui.value.editable) return
        viewModelScope.launch { repo.deletePhoto(p) }
    }

    class Factory(
        private val repo: InspectionRepository, private val inspectionId: String,
        private val unitId: String, private val unitName: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            EvaluationViewModel(repo, inspectionId, unitId, unitName) as T
    }
}
