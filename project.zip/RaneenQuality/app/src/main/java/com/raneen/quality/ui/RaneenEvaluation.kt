package com.raneen.quality.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.raneen.quality.data.*
import com.raneen.quality.domain.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

// ───────────── Repository ─────────────
class InspectionRepository(db: RaneenDatabase) {
    private val catalog = db.catalogDao()
    private val dao = db.inspectionDao()

    fun units(): Flow<List<EvaluationUnitEntity>> = catalog.observeUnits()
    fun branches(): Flow<List<BranchEntity>> = catalog.observeBranches()

    // فروع تجريبية لحد ما نعمل شاشة الأدمن (الفيوم من الإكسيل، مدينة نصر من المواصفات)
    suspend fun seedBranchesIfEmpty() {
        if (catalog.branchCount() > 0) return
        catalog.upsertBranches(listOf(
            BranchEntity("b001", "001", "فرع الفيوم", "الفيوم"),
            BranchEntity("b002", "002", "مدينة نصر", "القاهرة")
        ))
    }

    suspend fun startInspection(branchId: String, inspectorId: String, reportNumber: String): String {
        val id = UUID.randomUUID().toString()
        dao.insertInspection(
            InspectionEntity(id, reportNumber, "main", branchId, inspectorId, System.currentTimeMillis())
        )
        return id
    }

    suspend fun load(unitId: String) = Triple(
        catalog.groups(unitId), catalog.categories(unitId), catalog.controls(unitId)
    )

    fun findings(inspectionId: String, unitId: String) = dao.observeFindings(inspectionId, unitId)

    suspend fun controlDefs(unitId: String) = dao.controlDefs(unitId)

    /** X = تشغيل/إيقاف. لو فيه مخالفة نلغيها، لو مفيش نسجلها (وده بيحفظ فورًا = Auto Save). */
    suspend fun toggleX(inspectionId: String, unitId: String, controlId: String, groupId: String, current: Int) {
        if (current > 0) dao.decrementViolation(inspectionId, unitId, controlId, groupId)
        else dao.tapX(inspectionId, unitId, controlId, groupId, newId = UUID.randomUUID().toString())
    }
}

// ───────────── ViewModel ─────────────
data class CategoryWithControls(val category: CategoryEntity, val controls: List<ControlEntity>)

data class EvalUi(
    val groups: List<ProductGroupEntity> = emptyList(),
    val selectedGroupId: String = "",
    val categories: List<CategoryWithControls> = emptyList(),
    val counts: Map<Pair<String, String>, Int> = emptyMap(),   // (controlId, groupId) → عدد المخالفات
    val score: UnitScore? = null
)

class EvaluationViewModel(
    private val repo: InspectionRepository,
    private val inspectionId: String,
    private val unitId: String
) : ViewModel() {

    private val selectedGroup = MutableStateFlow("")
    private val structure = MutableStateFlow(Triple(
        emptyList<ProductGroupEntity>(), emptyList<CategoryEntity>(), emptyList<ControlEntity>()
    ))
    private var defs: List<ControlDef> = emptyList()

    init {
        viewModelScope.launch {
            val (g, c, k) = repo.load(unitId)
            defs = repo.controlDefs(unitId)
            structure.value = Triple(g, c, k)
            selectedGroup.value = g.firstOrNull()?.id ?: ""
        }
    }

    val ui: StateFlow<EvalUi> = combine(
        structure, selectedGroup, repo.findings(inspectionId, unitId)
    ) { (groups, cats, controls), sel, findings ->
        val scoreInput = findings.map { FindingIn(it.controlId, it.groupId, it.violationCount) }
        EvalUi(
            groups = groups,
            selectedGroupId = sel,
            categories = cats.map { c -> CategoryWithControls(c, controls.filter { it.categoryId == c.id }) },
            counts = findings.associate { (it.controlId to it.groupId) to it.violationCount },
            score = if (defs.isEmpty()) null else scoreUnit(defs, scoreInput)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EvalUi())

    fun selectGroup(id: String) { selectedGroup.value = id }

    fun onX(control: ControlEntity) {
        val state = ui.value
        // الضابط الـ perGroup بيتسجل على المجموعة المختارة، وغيره على "" (وحدة كاملة)
        val groupId = if (control.perGroup) state.selectedGroupId else ""
        val current = state.counts[control.id to groupId] ?: 0
        viewModelScope.launch { repo.toggleX(inspectionId, unitId, control.id, groupId, current) }
    }

    class Factory(
        private val repo: InspectionRepository, private val inspectionId: String, private val unitId: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            EvaluationViewModel(repo, inspectionId, unitId) as T
    }
}
