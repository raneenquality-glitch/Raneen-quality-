package com.raneen.quality.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.raneen.quality.data.*
import com.raneen.quality.domain.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// قوالب التقييم الجديدة مع الإبقاء على معنى القوالب القديمة للتقارير المحفوظة.
internal fun belongsToEvaluationTemplate(unit: EvaluationUnitEntity, templateId: String): Boolean {
    val id = unit.id
    return when (templateId) {
        "offline" -> (unit.templateId == "main" && !id.startsWith("digital_")) || unit.templateId == "offline"
        "smart" -> unit.templateId == "zayed"
        "digital" -> id.startsWith("digital_") ||
            (unit.templateId == "main" && !id.startsWith("digital_") && id !in setOf("furnishings", "electrical"))
        // القوالب القديمة: نفس منطق الفلترة السابق
        "zayed" -> unit.templateId == "zayed" || id.startsWith("digital_")
        "main" -> unit.templateId == "main"
        else -> unit.templateId == templateId
    }
}

internal fun evaluationTemplateLabel(templateId: String): String = when (templateId) {
    "smart", "zayed" -> "تقييم معارض سمارت"
    "digital" -> "تقييم معارض الديجيتال"
    "offline", "main" -> "تقييم المعارض الأوف لاين"
    else -> "تقييم جودة"
}

internal const val MAINTENANCE_CENSUS_CONTROL_ID = "__maintenance_census__"
internal const val MAINTENANCE_CENSUS_PREFIX = "RQ_MAINTENANCE_CENSUS_V1:"

// Repository
class InspectionRepository(db: RaneenDatabase, private val appContext: Context) {
    private val catalog = db.catalogDao()
    private val dao = db.inspectionDao()

    fun units(): Flow<List<EvaluationUnitEntity>> = catalog.observeUnits()
    fun branches(): Flow<List<BranchEntity>> = catalog.observeBranches()
    fun inspectionFlow(id: String): Flow<InspectionEntity?> = dao.observeInspection(id)
    fun allFindings(inspectionId: String): Flow<List<FindingEntity>> = dao.observeAllFindings(inspectionId)
    fun unitStates(inspectionId: String): Flow<List<InspectionUnitEntity>> = dao.observeUnitStates(inspectionId)
    fun unitPhotos(inspectionId: String, unitId: String): Flow<List<PhotoEntity>> = dao.observeUnitPhotos(inspectionId, unitId)

    /** فروع تجريبية لأول تشغيل بس — الأدمن يقدر يعدلها أو يحذفها من شاشة الفروع */
    suspend fun seedBranchesIfEmpty() {
        if (catalog.branchCount() > 0) return
        catalog.upsertBranches(listOf(
            BranchEntity("b001", "001", "فرع الفيوم", "الفيوم"),
            BranchEntity("b002", "002", "مدينة نصر", "القاهرة")
        ))
    }

    suspend fun startInspection(
        branchId: String, inspectorId: String, reportNumber: String, visitNumber: String,
        selectedTemplateId: String? = null
    ): String {
        val id = UUID.randomUUID().toString()
        val branchName = catalog.branchNameById(branchId).orEmpty()
        // لو مفيش قالب مختار: نرجع للسلوك القديم (زايد أو الرئيسي حسب اسم الفرع)
        val legacyTemplate = if (branchName.contains("زايد", ignoreCase = true) || branchName.contains("zayed", ignoreCase = true)) "zayed" else "main"
        val templateId = selectedTemplateId ?: legacyTemplate
        dao.insertInspection(InspectionEntity(id, reportNumber, templateId, branchId, inspectorId, System.currentTimeMillis(), visitNumber = visitNumber))
        return id
    }

    suspend fun load(unitId: String) = Triple(catalog.groups(unitId), catalog.categories(unitId), catalog.controls(unitId))
    fun findings(inspectionId: String, unitId: String) = dao.observeFindings(inspectionId, unitId)
    suspend fun controlDefs(unitId: String) = dao.controlDefs(unitId)
    suspend fun orderedControlIds(unitId: String) = dao.orderedControlIds(unitId)

    suspend fun setNA(inspectionId: String, unitId: String, na: Boolean) =
        dao.upsertUnitState(InspectionUnitEntity(inspectionId, unitId, na))

    suspend fun unitScores(inspectionId: String): Map<String, UnitScore> = withContext(Dispatchers.IO) {
        val templateId = dao.inspection(inspectionId)?.templateId ?: "main"
        dao.activeUnits(templateId).associate { u -> u.id to scoreUnit(dao.controlDefs(u.id), dao.findingsFor(inspectionId, u.id)) }
    }

    /** X = تشغيل/إيقاف. إلغاء المخالفة بيمسح صورها كمان. (Auto Save فوري) */
    suspend fun toggleX(inspectionId: String, unitId: String, controlId: String, groupId: String, current: Int) {
        if (current > 0) {
            removePhotos(inspectionId, unitId, controlId, groupId)
            dao.decrementViolation(inspectionId, unitId, controlId, groupId)
        } else dao.tapX(inspectionId, unitId, controlId, groupId, newId = UUID.randomUUID().toString())
    }

    /** ضوابط الحصر: بيحفظ العدد (Auto Save). صفر = مفيش عدد. */
    suspend fun setUnitPrice(inspectionId: String, unitId: String, controlId: String, groupId: String, price: Double) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) {
            val id = UUID.randomUUID().toString()
            dao.upsertFindings(listOf(FindingEntity(id, inspectionId, unitId, controlId, groupId, 0, "PRICE:${price.coerceAtLeast(0.0)}")))
        } else dao.setFindingNote(fid, "PRICE:${price.coerceAtLeast(0.0)}")
    }

    suspend fun setViolationNote(inspectionId: String, unitId: String, controlId: String, groupId: String, note: String) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId) ?: return
        dao.setViolationNote(fid, note.ifBlank { null })
    }

    suspend fun setInlineCensus(inspectionId: String, unitId: String, controlId: String, groupId: String, values: Map<String, InlineCensusValue>) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId) ?: return
        dao.setFindingNote(fid, InlineCensusData.encode(values))
    }

    suspend fun setMaintenanceCensus(inspectionId: String, unitId: String, json: String) {
        val note = if (json.isBlank() || json == "[]") null else MAINTENANCE_CENSUS_PREFIX + json
        val fid = dao.findingId(inspectionId, unitId, MAINTENANCE_CENSUS_CONTROL_ID, "")
        if (fid == null) {
            if (note != null) dao.upsertFindings(listOf(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, MAINTENANCE_CENSUS_CONTROL_ID, "", 0, note)))
        } else dao.setFindingNote(fid, note)
    }

    suspend fun setCount(inspectionId: String, unitId: String, controlId: String, groupId: String, n: Int) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) {
            if (n > 0) dao.upsertFindings(listOf(FindingEntity(UUID.randomUUID().toString(), inspectionId, unitId, controlId, groupId, n)))
        } else dao.setCount(fid, n)
    }

    private suspend fun removePhotos(i: String, u: String, c: String, g: String) = withContext(Dispatchers.IO) {
        val fid = dao.findingId(i, u, c, g) ?: return@withContext
        dao.photosOfFinding(fid).forEach { File(it.filePath).delete(); dao.deletePhotoRow(it.id) }
    }

    suspend fun deletePhoto(p: PhotoEntity) = withContext(Dispatchers.IO) {
        File(p.filePath).delete(); dao.deletePhotoRow(p.id)
    }

    suspend fun headerNames(inspectionId: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val i = dao.inspection(inspectionId) ?: return@withContext "" to ""
        (dao.branchName(i.branchId) ?: "") to (dao.userName(i.inspectorId) ?: "")
    }

    /** بيختم الصورة (فرع/قسم/تاريخ/وقت/مراقب)، يحفظها في مخزن التطبيق الخاص، ويربطها بالمخالفة */
    suspend fun addPhoto(
        inspectionId: String, unitId: String, controlId: String, groupId: String, raw: File, lines: List<String>, customText: String = ""
    ): Boolean = withContext(Dispatchers.IO) {
        val fid = dao.findingId(inspectionId, unitId, controlId, groupId)
        if (fid == null) { raw.delete(); return@withContext false }
        val out = File(File(appContext.filesDir, "photos").apply { mkdirs() }, "${UUID.randomUUID()}.jpg")
        val ok = PhotoStamper.stamp(raw, out, lines, customText)
        raw.delete()
        if (!ok) return@withContext false
        dao.insertPhoto(PhotoEntity(UUID.randomUUID().toString(), fid, out.path, System.currentTimeMillis()))
        MediaSaver.saveToGallery(appContext, out, false)       // نسخة في معرض الموبايل
        true
    }

    /**
     * فيديو مخالفة: بيتحرق عليه شريط البيانات (الفرع/القسم/الوقت/المراقب) وبيتحفظ جوه التطبيق + نسخة في المعرض.
     * الفيديو مبيترفعش للسيرفر (بيفضل على موبايل المراقب). بيرجّع: 0 فشل، 1 اتحفظ بالشريط، 2 اتحفظ من غير شريط.
     */
    suspend fun addVideo(
        inspectionId: String, unitId: String, controlId: String, groupId: String, raw: File, lines: List<String>, customText: String = ""
    ): Int {
        val fid = withContext(Dispatchers.IO) { dao.findingId(inspectionId, unitId, controlId, groupId) }
        if (fid == null || raw.length() == 0L) { raw.delete(); return 0 }
        val out = File(File(appContext.filesDir, "photos").apply { mkdirs() }, "${UUID.randomUUID()}.mp4")
        val stamped = VideoStamper.stamp(appContext, raw, out, lines, customText)
        return withContext(Dispatchers.IO) {
            if (stamped) raw.delete()
            else {
                out.delete()
                if (!raw.renameTo(out)) { raw.copyTo(out, overwrite = true); raw.delete() }
            }
            dao.insertPhoto(PhotoEntity(UUID.randomUUID().toString(), fid, out.path, System.currentTimeMillis(), "LOCAL_ONLY"))
            MediaSaver.saveToGallery(appContext, out, true)
            if (stamped) 1 else 2
        }
    }

    /** فيديو مخالفة: بيتحفظ زي الصور (جوه التطبيق + نسخة في المعرض). أقصى حجم 45MB (حد التخزين على السيرفر 50MB) */
}

// ViewModel
data class CategoryWithControls(val category: CategoryEntity, val controls: List<ControlEntity>)

data class EvalUi(
    val groups: List<ProductGroupEntity> = emptyList(),
    val selectedGroupId: String = "",
    val categories: List<CategoryWithControls> = emptyList(),
    val counts: Map<Pair<String, String>, Int> = emptyMap(),          // (controlId, groupId) → عدد المخالفات
    val findingIds: Map<Pair<String, String>, String> = emptyMap(),   // (controlId, groupId) → findingId
    val unitPrices: Map<Pair<String, String>, Double> = emptyMap(),
    val violationNotes: Map<Pair<String, String>, String> = emptyMap(),
    val censusCounts: Map<Pair<String, String>, Map<String, InlineCensusValue>> = emptyMap(),
    val maintenanceCensusJson: String = "",
    val losses: Map<String, Double> = emptyMap(),        // controlId → إجمالي الخصم (الوزن الأصلي ما بيتغيّرش)
    val displayNo: Map<String, Int> = emptyMap(),        // ترقيم متسلسل لأوراق مدير المعرض
    val photos: Map<String, List<PhotoEntity>> = emptyMap(),          // findingId → صور
    val editable: Boolean = false,
    val managerEdit: Boolean = false,   // مدير بيعدّل: النتائج والملاحظات بس — الصور والفيديو للمراقب
    val score: UnitScore? = null
)

class EvaluationViewModel(
    private val repo: InspectionRepository,
    private val inspectionId: String,
    private val unitId: String,
    private val unitName: String,
    private val role: String = Roles.INSPECTOR,
    private val afterEdit: suspend () -> Unit = {},   // للمدير: يعلّم التقرير للرفع بعد كل تعديل
    private val userId: String = ""
) : ViewModel() {

    private val selectedGroup = MutableStateFlow("")
    private val structure = MutableStateFlow(Triple(
        emptyList<ProductGroupEntity>(), emptyList<CategoryEntity>(), emptyList<ControlEntity>()
    ))
    private var defs: List<ControlDef> = emptyList()
    private var displayNo: Map<String, Int> = emptyMap()

    init {
        viewModelScope.launch {
            val (g, c, k) = repo.load(unitId)
            defs = repo.controlDefs(unitId).map { def ->
                // البندان الاستثنائيان: قيمة العداد نفسها هي مقدار الخصم المختار (1..5).
                if (def.id == "security_i14" || def.id == "cameras_i11") def.copy(penaltyPerViolation = 1.0) else def
            }
            if (unitId in RENUMBER_UNITS) displayNo = repo.orderedControlIds(unitId).withIndex().associate { (i, id) -> id to i + 1 }
            structure.value = Triple(g, c, k)
            selectedGroup.value = g.firstOrNull()?.id ?: ""
        }
    }

    val ui: StateFlow<EvalUi> = combine(
        structure, selectedGroup, repo.findings(inspectionId, unitId),
        repo.unitPhotos(inspectionId, unitId), repo.inspectionFlow(inspectionId)
    ) { (groups, cats, controls), sel, findings, photos, insp ->
        val scoreInput = findings.map { FindingIn(it.controlId, it.groupId, it.violationCount) }
        EvalUi(
            groups = groups,
            selectedGroupId = sel,
            categories = cats.map { c -> CategoryWithControls(c, controls.filter { it.categoryId == c.id }) },
            counts = findings.associate { (it.controlId to it.groupId) to it.violationCount },
            findingIds = findings.associate { (it.controlId to it.groupId) to it.id },
            unitPrices = findings.mapNotNull { f -> f.note?.takeIf { it.startsWith("PRICE:") }?.removePrefix("PRICE:")?.toDoubleOrNull()?.let { (f.controlId to f.groupId) to it } }.toMap(),
            violationNotes = findings.associate { (it.controlId to it.groupId) to (it.violationNote ?: "") },
            censusCounts = findings.associate { (it.controlId to it.groupId) to InlineCensusData.parse(it.note) },
            losses = defs.associate { d -> d.id to controlLoss(d, findings.filter { it.controlId == d.id }.sumOf { it.violationCount }) },
            displayNo = displayNo,
            maintenanceCensusJson = findings.firstOrNull { it.controlId == MAINTENANCE_CENSUS_CONTROL_ID }?.note?.removePrefix(MAINTENANCE_CENSUS_PREFIX).orEmpty(),
            photos = photos.groupBy { it.findingId },
            // زيارة المستخدم نفسه (مراقب أو مدير منطقة عامل زيارة) بتتعامل كزيارة مراقب مش كتعديل مدير
            editable = insp != null && Status.editableBy(if (insp.inspectorId == userId) Roles.INSPECTOR else role, insp.status),
            managerEdit = role != Roles.INSPECTOR && !(insp != null && insp.inspectorId == userId),
            score = if (defs.isEmpty()) null else scoreUnit(defs, scoreInput)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EvalUi())

    fun selectGroup(id: String) { selectedGroup.value = id }

    fun onX(control: ControlEntity) {
        val state = ui.value
        if (!state.editable) return
        val groupId = if (control.perGroup && control.id !in AREA_PART_CONTROLS) state.selectedGroupId else ""
        val current = state.counts[control.id to groupId] ?: 0
        viewModelScope.launch { repo.toggleX(inspectionId, unitId, control.id, groupId, current); afterEdit() }
    }

    fun setUnitPrice(control: ControlEntity, price: Double) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch { repo.setUnitPrice(inspectionId, unitId, control.id, groupId, price); afterEdit() }
    }

    fun setViolationNote(control: ControlEntity, note: String) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch { repo.setViolationNote(inspectionId, unitId, control.id, groupId, note); afterEdit() }
    }

    fun setInlineCensus(control: ControlEntity, key: String, count: Int? = null, value: Double? = null) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in AREA_PART_CONTROLS) st.selectedGroupId else ""
        val pair = control.id to groupId
        val values = st.censusCounts[pair].orEmpty().toMutableMap()
        val old = values[key] ?: InlineCensusValue()
        values[key] = old.copy(count = count?.coerceAtLeast(0) ?: old.count, value = value?.coerceAtLeast(0.0) ?: old.value)
        viewModelScope.launch { repo.setInlineCensus(inspectionId, unitId, control.id, groupId, values); afterEdit() }
    }

    fun saveMaintenanceCensus(json: String) {
        val st = ui.value
        if (!st.editable) return
        viewModelScope.launch {
            repo.setMaintenanceCensus(inspectionId, unitId, json)
            afterEdit()
        }
    }

    fun setCount(control: ControlEntity, n: Int) {
        val st = ui.value
        if (!st.editable) return
        val groupId = if (control.perGroup && control.id !in AREA_PART_CONTROLS) st.selectedGroupId else ""
        viewModelScope.launch { repo.setCount(inspectionId, unitId, control.id, groupId, n); afterEdit() }
    }

    /** سطور شريط البيانات: الفرع، القسم (+ المجموعة)، التاريخ والوقت، المراقب */
    private suspend fun stampLines(groupId: String, controlId: String, whenMs: Long = System.currentTimeMillis(), source: String? = null): List<String> {
        val (branch, inspector) = repo.headerNames(inspectionId)
        val now = Date(whenMs)
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(now)
        val place = ui.value.groups.firstOrNull { it.id == groupId }?.name
        val cw = ui.value.categories.firstOrNull { c -> c.controls.any { it.id == controlId } }
        val ctl = cw?.controls?.firstOrNull { it.id == controlId }
        // مكان المخالفة: القسم + المجموعة + رقم البند والكاتجري
        return listOfNotNull(
            "الفرع: $branch",
            "القسم: $unitName" + if (place != null) " — $place" else "",
            if (ctl != null && cw != null) "المخالفة: بند ${ctl.sortOrder} — ${cw.category.name}" else null,
            "التاريخ: $d   الوقت: $t",
            source,                                   // "مصدر الصورة: من المعرض..." (بس للصور المختارة من المعرض)
            "المراقب: $inspector"
        )
    }

    fun addPhoto(controlId: String, groupId: String, raw: File, customText: String = "") {
        viewModelScope.launch {
            repo.addPhoto(inspectionId, unitId, controlId, groupId, raw, stampLines(groupId, controlId), customText)
        }
    }

    /**
     * صورة اتختارت من المعرض: بتتختم بوقت الالتقاط الأصلي (لو معروف) + سطر يوضّح إنها من المعرض.
     * لو وقت الالتقاط مجهول بنكتب ده صراحة، ووقت الإضافة بيبقى هو الوقت المسجّل.
     */
    fun addGalleryPhoto(controlId: String, groupId: String, raw: File, takenMs: Long?, onResult: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val source = if (takenMs != null) "مصدر الصورة: من المعرض (وقت الالتقاط الأصلي)"
            else "مصدر الصورة: من المعرض (وقت الالتقاط غير معروف، الوقت أعلاه وقت الإضافة)"
            val ok = repo.addPhoto(inspectionId, unitId, controlId, groupId, raw,
                stampLines(groupId, controlId, takenMs ?: System.currentTimeMillis(), source))
            onResult(ok)   // قبل كده لو الإضافة فشلت الصورة كانت بتختفي من غير أي رسالة
        }
    }

    /** فيديو + الصور اللي اتاخدت وقت التسجيل (كل واحدة بتتختم بوقتها الفعلي) */
    fun addVideo(controlId: String, groupId: String, raw: File, snaps: List<File>, customText: String = "", onDone: (Int) -> Unit) {
        viewModelScope.launch {
            val r = repo.addVideo(inspectionId, unitId, controlId, groupId, raw, stampLines(groupId, controlId, raw.lastModified().takeIf { it > 0 } ?: System.currentTimeMillis()), customText)
            for (s in snaps) {
                repo.addPhoto(inspectionId, unitId, controlId, groupId, s, stampLines(groupId, controlId, s.lastModified().takeIf { it > 0 } ?: System.currentTimeMillis()), customText)
            }
            onDone(r)
        }
    }

    fun deletePhoto(p: PhotoEntity) {
        if (!ui.value.editable || ui.value.managerEdit) return
        viewModelScope.launch { repo.deletePhoto(p) }
    }

    class Factory(
        private val repo: InspectionRepository, private val inspectionId: String,
        private val unitId: String, private val unitName: String,
        private val role: String = Roles.INSPECTOR, private val afterEdit: suspend () -> Unit = {}, private val userId: String = ""
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            EvaluationViewModel(repo, inspectionId, unitId, unitName, role, afterEdit, userId) as T
    }
}
