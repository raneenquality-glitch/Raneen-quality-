package com.raneen.quality.domain

// دوال نقية (بدون Room أو Android) → سهل تتعمل لها Unit Test

// ───────────── مدخلات ─────────────
data class ControlDef(
    val id: String,
    val categoryId: String,
    val maxScore: Double,              // وزن البند
    val penaltyPerViolation: Double    // 1 عادي، 2 للبنود المضاعفة
)

data class FindingIn(
    val controlId: String,
    val groupId: String,
    val violations: Int
)

// ───────────── مخرجات ─────────────
data class CategoryScore(val planned: Double, val actual: Double)

data class UnitScore(
    val planned: Double,                          // مجموع أوزان البنود (المفروض 100)
    val actual: Double,                           // بعد الخصم
    val percent: Double,                          // actual / planned × 100
    val byCategory: Map<String, CategoryScore>
)

// ───────────── 1) درجة بند واحد ─────────────
/**
 * الخصم = مجموع المخالفات (على كل مجموعات المنتجات) × عقوبة المخالفة الواحدة،
 * بحد أقصى وزن البند (القسم مايخسرش أكتر من درجة البند).
 * مثال: بند 17 (وزن 4، عقوبة 2): مخالفتين → 4 → يخسر البند كامل ✔ (زي ملاحظة الإكسيل)
 */
fun controlLoss(control: ControlDef, violations: Int): Double {
    if (violations <= 0) return 0.0
    // في هذه البنود قيمة violations تحفظ الاختيار: رقم خصم مباشر أو bitmask للأجزاء المختارة.
    val selectedPartPenalty = when (control.id) {
        "services_admin_i5", "services_admin_i7", "services_admin_i8", "services_admin_i9" ->
            ((if ((violations and 1) != 0) 4 else 0) + (if ((violations and 2) != 0) 4 else 0)).toDouble()
        "services_admin_i6" -> ((if ((violations and 1) != 0) 1 else 0) + (if ((violations and 2) != 0) 1 else 0)).toDouble()
        "maintenance_i13", "branch_manager_i4", "branch_manager_i5", "branch_manager_i9" ->
            ((if ((violations and 1) != 0) 2 else 0) + (if ((violations and 2) != 0) 2 else 0)).toDouble()
        "branch_manager_i1", "branch_manager_i3" ->
            ((if ((violations and 1) != 0) 1 else 0) + (if ((violations and 2) != 0) 1 else 0) +
             (if ((violations and 4) != 0) 1 else 0) + (if ((violations and 8) != 0) 1 else 0)).toDouble()
        "maintenance_i3", "branch_manager_i14", "security_i14", "cameras_i11" -> violations.toDouble()
        else -> return minOf(control.maxScore, violations * control.penaltyPerViolation)
    }
    return minOf(control.maxScore, selectedPartPenalty)
}

// ───────────── 2) درجة وحدة (قسم أو إدارة) ─────────────
fun scoreUnit(
    controls: List<ControlDef>,
    findings: List<FindingIn>
): UnitScore {
    // نجمع المخالفات لكل ضابط عبر كل المجموعات
    val violationsByControl = findings.groupBy { it.controlId }
        .mapValues { (_, list) -> list.sumOf { it.violations } }

    val byCategory = controls.groupBy { it.categoryId }.mapValues { (_, list) ->
        val planned = list.sumOf { it.maxScore }
        val loss = list.sumOf { controlLoss(it, violationsByControl[it.id] ?: 0) }
        CategoryScore(planned, planned - loss)
    }

    val planned = byCategory.values.sumOf { it.planned }
    val actual = byCategory.values.sumOf { it.actual }
    val percent = if (planned > 0) actual / planned * 100 else 0.0

    return UnitScore(planned, actual, percent, byCategory)
}

// ───────────── 3) التقييم النهائي لكل نوع (kind) ─────────────
/** null = الوحدة N/A (زي الأثاث في الإكسيل) → بيتستبعد من المتوسط بدل ما يتحسب صفر */
fun kindAverage(unitPercents: List<Double?>): Double? {
    val applicable = unitPercents.filterNotNull()
    return if (applicable.isEmpty()) null else applicable.average()
}
