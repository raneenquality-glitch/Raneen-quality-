package com.raneen.quality.domain

// دوال نقية (بدون Room أو Android) → سهل تتعمل لها Unit Test

// مدخلات
data class ControlDef(
    val id: String,
    val categoryId: String,
    val maxScore: Double,              // وزن البند
    val penaltyPerViolation: Double    // 1 عادي، 2 للبنود المضاعفة
)

data class FindingIn(
    val controlId: String,
    val groupId: String,
    val violations: Int
)

// مخرجات
data class CategoryScore(val planned: Double, val actual: Double)

data class UnitScore(
    val planned: Double,                          // مجموع أوزان البنود (المفروض 100)
    val actual: Double,                           // بعد الخصم
    val percent: Double,                          // actual / planned × 100
    val byCategory: Map<String, CategoryScore>
)

// بنود الخدمات 1 و3 و4 (نظافة المخزن / الأرضيات / الحوائط): تحديد المنطقة المخالفة (منزلي، الألعاب، المفروشات، الكهرباء)
// كل منطقة مخالفة بتخصم درجتين. القيمة المخزّنة = bitmask للمناطق (1،2،4،8) + علم 16.
// من غير العلم (تقارير قديمة) القيمة عدد مخالفات المجموعات ق1-ق4 وبتتحسب بالطريقة القديمة.
const val AREA_PARTS_FLAG = 16
const val AREA_PART_PENALTY = 2.0
val AREA_PART_CONTROLS = setOf(
    "services_admin_i1", "services_admin_i3", "services_admin_i4",           // الخدمات (أوف لاين)
    "zayed_services_i2", "zayed_services_i3",                                 // الخدمات (زايد): الأرضيات / الحوائط والأسقف
    "zayed_branch_manager_i3"                                                 // مدير المعرض (زايد): الإجراءات المستندية
)
/** خصم كل منطقة مختارة: درجتين في بنود الخدمات، ودرجة في الإجراءات المستندية (4 مناطق = وزن 4) */
fun areaPartPenalty(controlId: String): Double = if (controlId == "zayed_branch_manager_i3") 1.0 else AREA_PART_PENALTY
/** أوراق مدير المعرض: الترقيم المعروض متسلسل من 1 على البنود الفعّالة */
val RENUMBER_UNITS = setOf("branch_manager", "zayed_branch_manager")

/** رقم بدون كسور لو صحيح (4) وإلا برقم عشري واحد (2.5) */
fun scoreNum(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else "%.1f".format(d)

/** السطر الموحّد في كل الشاشات والملفات: الوزن | الخصم | المتبقي */
fun itemScoreText(weight: Double, deducted: Double): String =
    "الوزن: ${scoreNum(weight)} | الخصم: ${scoreNum(deducted)} | المتبقي: ${scoreNum(weight - deducted)}"

// 1) درجة بند واحد
/**
 * الخصم = مجموع المخالفات (على كل مجموعات المنتجات) × عقوبة المخالفة الواحدة،
 * بحد أقصى وزن البند (القسم مايخسرش أكتر من درجة البند).
 * مثال: بند 17 (وزن 4، عقوبة 2): مخالفتين → 4 → يخسر البند كامل ✔ (زي ملاحظة الإكسيل)
 */
fun controlLoss(control: ControlDef, violations: Int): Double {
    if (violations <= 0) return 0.0
    // في هذه البنود قيمة violations تحفظ الاختيار: رقم خصم مباشر أو bitmask للأجزاء المختارة.
    val selectedPartPenalty = when (control.id) {
        "services_admin_i5", "services_admin_i7", "services_admin_i8", "services_admin_i9" -> {
            // تقارير قديمة كانت بتخزّن الأجزاء 4 / 8 / 12 بدل 1 / 2 / 3: نفكها عشان نتايجها القديمة ما تتغيّرش
            val m = if (violations == 4 || violations == 8 || violations == 12) violations shr 2 else violations
            ((if ((m and 1) != 0) 4 else 0) + (if ((m and 2) != 0) 4 else 0)).toDouble()
        }
        "services_admin_i6" -> ((if ((violations and 1) != 0) 1 else 0) + (if ((violations and 2) != 0) 1 else 0)).toDouble()
        "zayed_services_i4", "zayed_services_i5", "zayed_services_i6", "zayed_services_i7", "zayed_services_i8",
        "zayed_branch_manager_i4", "zayed_branch_manager_i5", "zayed_branch_manager_i9" ->
            ((if ((violations and 1) != 0) control.maxScore / 2.0 else 0.0) + (if ((violations and 2) != 0) control.maxScore / 2.0 else 0.0))
        "maintenance_i13", "branch_manager_i4", "branch_manager_i5", "branch_manager_i9" ->
            ((if ((violations and 1) != 0) 2 else 0) + (if ((violations and 2) != 0) 2 else 0)).toDouble()
        "branch_manager_i1", "branch_manager_i3" ->
            ((if ((violations and 1) != 0) 1 else 0) + (if ((violations and 2) != 0) 1 else 0) +
             (if ((violations and 4) != 0) 1 else 0) + (if ((violations and 8) != 0) 1 else 0)).toDouble()
        "services_admin_i1", "services_admin_i3", "services_admin_i4", "zayed_services_i2", "zayed_services_i3", "zayed_branch_manager_i3" ->
            if ((violations and AREA_PARTS_FLAG) != 0) areaPartPenalty(control.id) * Integer.bitCount(violations and 15)
            else return minOf(control.maxScore, violations * control.penaltyPerViolation)
        "maintenance_i3", "branch_manager_i14", "security_i14", "cameras_i11" -> violations.toDouble()
        else -> return minOf(control.maxScore, violations * control.penaltyPerViolation)
    }
    return minOf(control.maxScore, selectedPartPenalty)
}

// 2) درجة وحدة (قسم أو إدارة)
fun scoreUnit(
    controls: List<ControlDef>,
    findings: List<FindingIn>
): UnitScore {
    // نجمع المخالفات لكل ضابط عبر كل المجموعات
    val violationsByControl = findings.groupBy { it.controlId }
        .mapValues { (_, list) -> list.sumOf { it.violations } }

    val byCategory = controls.groupBy { it.categoryId }.mapValues { (_, list) ->
        val planned = list.sumOf { it.maxScore }
        val loss = list.sumOf { controlLoss(it, violationsByControl[it.id] ?: 0) }
        CategoryScore(planned, planned - loss)
    }

    val planned = byCategory.values.sumOf { it.planned }
    val actual = byCategory.values.sumOf { it.actual }
    val percent = if (planned > 0) actual / planned * 100 else 0.0

    return UnitScore(planned, actual, percent, byCategory)
}

// 3) التقييم النهائي لكل نوع (kind)
/** null = الوحدة N/A (زي الأثاث في الإكسيل) → بيتستبعد من المتوسط بدل ما يتحسب صفر */
fun kindAverage(unitPercents: List<Double?>): Double? {
    val applicable = unitPercents.filterNotNull()
    return if (applicable.isEmpty()) null else applicable.average()
}
