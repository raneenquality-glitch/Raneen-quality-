package com.raneen.quality.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.ExifInterface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/**
 * بيحرق شريط البيانات (الفرع / القسم / التاريخ والوقت / المراقب) جوه بيكسلات الصورة نفسها.
 * الصورة بتتحفظ في مخزن التطبيق الخاص، ومفيش في التطبيق أي طريقة لتعديل الشريط أو الصورة.
 */
object PhotoStamper {
    /** أقصى ضلع للصورة المحفوظة (كانت 4096): جودة كويسة وحجم صغير عشان الرفع على نت المراقب */
    private const val MAX_LONG_SIDE = 1920
    /** جودة JPEG (كانت 92) */
    private const val JPEG_QUALITY = 80

    fun stamp(raw: File, out: File, lines: List<String>, customText: String = ""): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(raw.path, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_LONG_SIDE) sample *= 2
            val decoded = BitmapFactory.decodeFile(raw.path, BitmapFactory.Options().apply { inSampleSize = sample; inMutable = true })
                ?: return false

            val degrees = when (ExifInterface(raw.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val upright = if (degrees != 0f)
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(degrees) }, true)
                    .also { if (it !== decoded) decoded.recycle() }
            else decoded
            // مفيش تصغير: الصورة بتتحفظ بدقتها الأصلية (الحد الأقصى MAX_LONG_SIDE). بنتجنب نسخ زيادة عشان الذاكرة.
            val bmp = if (upright.isMutable && upright.config == Bitmap.Config.ARGB_8888) upright
                      else upright.copy(Bitmap.Config.ARGB_8888, true).also { upright.recycle() }

            val canvas = Canvas(bmp)
            val pad = bmp.width * 0.025f
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = bmp.width / 26f
                typeface = Typeface.DEFAULT_BOLD
            }
            val textWidth = (bmp.width - 2 * pad).toInt()
            // النص الذي يكتبه المراقب يظهر أعلى الصورة، بينما يظل شريط البيانات التلقائي أسفلها كما هو.
            if (customText.isNotBlank()) {
                val customPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = bmp.width / 25f
                    typeface = Typeface.DEFAULT_BOLD
                }
                val customLayout = StaticLayout.Builder.obtain(customText.trim(), 0, customText.trim().length, customPaint, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
                val topHeight = customLayout.height.toFloat() + pad * 2
                canvas.drawRect(0f, 0f, bmp.width.toFloat(), topHeight, Paint().apply { color = Color.argb(190, 0, 0, 0) })
                canvas.save(); canvas.translate(pad, pad); customLayout.draw(canvas); canvas.restore()
            }
            val layouts = lines.map {
                StaticLayout.Builder.obtain(it, 0, it.length, paint, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
            }
            val total = layouts.sumOf { it.height }.toFloat() + pad * 2
            val bg = Paint().apply { color = Color.argb(179, 0, 0, 0) }
            canvas.drawRect(0f, bmp.height - total, bmp.width.toFloat(), bmp.height.toFloat(), bg)
            var y = bmp.height - total + pad
            for (l in layouts) {
                canvas.save()
                canvas.translate(pad, y)
                l.draw(canvas)
                canvas.restore()
                y += l.height
            }

            out.parentFile?.mkdirs()
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, it) }
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** نسخة خفيفة للرفع بس (الأصل على الموبايل ما بيتلمسش). لو فشل بنرجع الأصل عشان المزامنة ما تقفش. */
    fun uploadCopy(src: File, out: File, maxSide: Int = 1920, quality: Int = 75): File {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(src.path, b)
            if (maxOf(b.outWidth, b.outHeight) <= maxSide && src.length() < 1_500_000) return src
            var sample = 1
            while (maxOf(b.outWidth, b.outHeight) / (sample * 2) >= maxSide) sample *= 2
            val bmp = BitmapFactory.decodeFile(src.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return src
            val r = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
            val scaled = if (r < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * r).toInt(), (bmp.height * r).toInt(), true) else bmp
            FileOutputStream(out).use { scaled.compress(Bitmap.CompressFormat.JPEG, quality, it) }
            if (scaled !== bmp) bmp.recycle()
            scaled.recycle()
            out
        } catch (t: Throwable) { src }
    }
}
