package com.raneen.quality.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.ExifInterface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/**
 * بيحرق شريط البيانات (الفرع / القسم / التاريخ والوقت / المراقب) جوه بيكسلات الصورة نفسها.
 * الصورة بتتحفظ في مخزن التطبيق الخاص، ومفيش في التطبيق أي طريقة لتعديل الشريط أو الصورة.
 */
object PhotoStamper {
    fun stamp(raw: File, out: File, lines: List<String>, customText: String = ""): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(raw.path, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
            val decoded = BitmapFactory.decodeFile(raw.path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return false

            val degrees = when (ExifInterface(raw.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val upright = if (degrees != 0f)
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(degrees) }, true)
            else decoded
            // تصغير لحد 1024 بكسل عشان التخزين (الشريط بيتحرق بعد التصغير فيفضل واضح)
            val longSide = maxOf(upright.width, upright.height)
            val sized = if (longSide > 1024) {
                val k = 1024f / longSide
                Bitmap.createScaledBitmap(upright, (upright.width * k).toInt(), (upright.height * k).toInt(), true)
            } else upright
            val bmp = sized.copy(Bitmap.Config.ARGB_8888, true)

            val canvas = Canvas(bmp)
            val pad = bmp.width * 0.025f
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = bmp.width / 26f
                typeface = Typeface.DEFAULT_BOLD
            }
            val textWidth = (bmp.width - 2 * pad).toInt()
            // النص الذي يكتبه المراقب يظهر أعلى الصورة، بينما يظل شريط البيانات التلقائي أسفلها كما هو.
            if (customText.isNotBlank()) {
                val customPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = bmp.width / 25f
                    typeface = Typeface.DEFAULT_BOLD
                }
                val customLayout = StaticLayout.Builder.obtain(customText.trim(), 0, customText.trim().length, customPaint, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
                val topHeight = customLayout.height.toFloat() + pad * 2
                canvas.drawRect(0f, 0f, bmp.width.toFloat(), topHeight, Paint().apply { color = Color.argb(190, 0, 0, 0) })
                canvas.save(); canvas.translate(pad, pad); customLayout.draw(canvas); canvas.restore()
            }
            val layouts = lines.map {
                StaticLayout.Builder.obtain(it, 0, it.length, paint, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
            }
            val total = layouts.sumOf { it.height }.toFloat() + pad * 2
            val bg = Paint().apply { color = Color.argb(179, 0, 0, 0) }
            canvas.drawRect(0f, bmp.height - total, bmp.width.toFloat(), bmp.height.toFloat(), bg)
            var y = bmp.height - total + pad
            for (l in layouts) {
                canvas.save()
                canvas.translate(pad, y)
                l.draw(canvas)
                canvas.restore()
                y += l.height
            }

            out.parentFile?.mkdirs()
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 70, it) }
            true
        } catch (t: Throwable) {
            false
        }
    }
}
