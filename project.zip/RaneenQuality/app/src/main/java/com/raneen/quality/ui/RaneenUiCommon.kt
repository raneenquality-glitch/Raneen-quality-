package com.raneen.quality.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.PhotoEntity
import com.raneen.quality.data.Status
import com.raneen.quality.data.SyncRepository
import androidx.compose.ui.Alignment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** رقم الزيارة في الشهر (الفرع بيتزار مرتين) */
fun visitLabel(n: String?): String? = when (n) { "1" -> "الزيارة الأولى"; "2" -> "الزيارة الثانية"; else -> null }

fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(Date(ms))
fun fmtScore(d: Double): String = String.format(Locale.US, "%.1f", d)
fun fmtPct(d: Double?): String = if (d == null) "—" else String.format(Locale.US, "%.1f%%", d)
fun fmtWeight(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else String.format(Locale.US, "%.1f", d)

fun statusColor(s: String): Color = when (s) {
    Status.DRAFT -> Color(0xFF757575)
    Status.SUBMITTED -> Color(0xFF283593)
    Status.REVIEWED -> Color(0xFF6A1B9A)
    Status.RETURNED -> Color(0xFFC62828)
    Status.FINAL -> Color(0xFF1D7A4D)
    else -> Color.Gray
}

/** مؤشر حالة (مفعّل/معطّل) بنقطة ملوّنة — بيتستخدم في قوائم الفروع والمستخدمين */
@Composable
fun ActiveBadge(active: Boolean) {
    val c = if (active) Color(0xFF1D7A4D) else MaterialTheme.colorScheme.error
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.12f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(6.dp))
        Text(if (active) "مفعّل" else "معطّل", color = c, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun StatusChip(status: String) {
    val c = statusColor(status)
    Text(
        Status.short(status), color = Color.White, style = MaterialTheme.typography.labelMedium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c).padding(horizontal = 10.dp, vertical = 3.dp)
    )
}

private fun decodeSampled(path: String, sample: Int): ImageBitmap? =
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()

fun isVideo(path: String): Boolean = path.endsWith(".mp4", ignoreCase = true)

fun playVideo(ctx: Context, path: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (e: Exception) {
        Toast.makeText(ctx, "تعذّر تشغيل الفيديو", Toast.LENGTH_LONG).show()
    }
}

private fun videoFrame(path: String): ImageBitmap? = try {
    val r = MediaMetadataRetriever()
    r.setDataSource(path)
    val f = r.getFrameAtTime(0)
    r.release()
    f?.let { Bitmap.createScaledBitmap(it, 160, maxOf(1, (160f * it.height / it.width).toInt()), true).asImageBitmap() }
} catch (e: Exception) {
    null
}

@Composable
fun Thumb(path: String, size: Dp, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { if (isVideo(path)) videoFrame(path) else decodeSampled(path, 8) }
    }
    Box(Modifier.size(size).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE0E0E0)).clickable(onClick = onClick)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (isVideo(path)) Text("▶", color = Color.White, modifier = Modifier.align(Alignment.Center), style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun PhotoDialog(photo: PhotoEntity, canDelete: Boolean, onDelete: () -> Unit, onClose: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, photo.filePath) { value = withContext(Dispatchers.IO) { decodeSampled(photo.filePath, 2) } }
    var confirm by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        text = {
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
            else CircularProgressIndicator()
        },
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } },
        dismissButton = {
            if (canDelete) TextButton(onClick = { if (confirm) onDelete() else confirm = true }) {
                Text(if (confirm) "تأكيد الحذف" else "حذف الصورة", color = MaterialTheme.colorScheme.error)
            }
        }
    )
}

/** شريط حالة المزامنة + زرار "مزامنة الآن" */
@Composable
fun SyncBar(sync: SyncRepository) {
    val s by sync.status.collectAsState()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(s, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        TextButton(onClick = { sync.kick() }) { Text("مزامنة الآن") }
    }
}

// ───────────── ترتيب الفروع وبحثها ─────────────

/** تطبيع عربي للبحث: يشيل التشكيل ويوحّد الألف والتاء المربوطة والياء */
fun normArabic(t: String): String = t.lowercase()
    .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    .replace('ة', 'ه').replace('ى', 'ي').trim()

/** الفروع مرتبة برقم الفرع (رقميًا: 2 قبل 10)، والفروع اللي رقمها مش رقم تيجي في الآخر */
fun List<com.raneen.quality.data.BranchEntity>.sortedByBranchNumber(): List<com.raneen.quality.data.BranchEntity> =
    sortedWith(
        compareBy<com.raneen.quality.data.BranchEntity> { b -> b.code.filter { it.isDigit() }.toLongOrNull() ?: Long.MAX_VALUE }
            .thenBy { it.code.lowercase() }
            .thenBy { it.name }
    )

/** بحث بالاسم أو رقم الفرع أو المنطقة */
fun List<com.raneen.quality.data.BranchEntity>.filterByQuery(q: String): List<com.raneen.quality.data.BranchEntity> {
    val n = normArabic(q)
    if (n.isEmpty()) return this
    return filter { normArabic(it.name).contains(n) || it.code.lowercase().contains(n) || normArabic(it.region).contains(n) }
}
