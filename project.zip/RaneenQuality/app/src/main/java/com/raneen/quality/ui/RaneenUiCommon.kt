package com.raneen.quality.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.PhotoEntity
import com.raneen.quality.data.Status
import com.raneen.quality.data.SyncRepository
import androidx.compose.ui.Alignment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(Date(ms))
fun fmtScore(d: Double): String = String.format(Locale.US, "%.1f", d)
fun fmtPct(d: Double?): String = if (d == null) "—" else String.format(Locale.US, "%.1f%%", d)
fun fmtWeight(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else String.format(Locale.US, "%.1f", d)

fun statusColor(s: String): Color = when (s) {
    Status.DRAFT -> Color(0xFF757575)
    Status.SUBMITTED -> Color(0xFF1565C0)
    Status.REVIEWED -> Color(0xFF6A1B9A)
    Status.RETURNED -> Color(0xFFC62828)
    Status.FINAL -> Color(0xFF1D7A4D)
    else -> Color.Gray
}

@Composable
fun StatusChip(status: String) {
    val c = statusColor(status)
    Text(
        Status.short(status), color = Color.White, style = MaterialTheme.typography.labelMedium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c).padding(horizontal = 10.dp, vertical = 3.dp)
    )
}

private fun decodeSampled(path: String, sample: Int): ImageBitmap? =
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()

@Composable
fun Thumb(path: String, size: Dp, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) { value = withContext(Dispatchers.IO) { decodeSampled(path, 8) } }
    Box(Modifier.size(size).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE0E0E0)).clickable(onClick = onClick)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
fun PhotoDialog(photo: PhotoEntity, canDelete: Boolean, onDelete: () -> Unit, onClose: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, photo.filePath) { value = withContext(Dispatchers.IO) { decodeSampled(photo.filePath, 2) } }
    var confirm by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        text = {
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
            else CircularProgressIndicator()
        },
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } },
        dismissButton = {
            if (canDelete) TextButton(onClick = { if (confirm) onDelete() else confirm = true }) {
                Text(if (confirm) "تأكيد الحذف" else "حذف الصورة", color = MaterialTheme.colorScheme.error)
            }
        }
    )
}

/** شريط حالة المزامنة + زرار "مزامنة الآن" */
@Composable
fun SyncBar(sync: SyncRepository) {
    val s by sync.status.collectAsState()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(s, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        TextButton(onClick = { sync.kick() }) { Text("مزامنة الآن") }
    }
}
