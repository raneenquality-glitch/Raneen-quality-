package com.raneen.quality.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.AuthRepository
import com.raneen.quality.data.CatalogAdminRepository
import com.raneen.quality.data.EvaluationUnitEntity
import com.raneen.quality.data.LoginResult
import com.raneen.quality.data.Roles
import com.raneen.quality.data.SyncRepository
import com.raneen.quality.data.UserEntity
import kotlinx.coroutines.launch

// تسجيل الدخول: مفيش أي حساب ظاهر
@Composable
fun LoginScreen(auth: AuthRepository, onSuccess: (UserEntity) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // خلفية فاتحة ناعمة + كارت مركزي نظيف
    Column(
        Modifier.fillMaxSize().background(Color.White).padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "رنين", style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Text(
                    "Raneen Quality", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "إدارة الجودة بشركة رنين", style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(28.dp))
                OutlinedTextField(
                    value = username, onValueChange = { username = it }, singleLine = true,
                    label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, singleLine = true,
                    label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "إخفاء" else "إظهار") } },
                    shape = RoundedCornerShape(14.dp)
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(20.dp))
                Button(
                    enabled = !busy && username.isNotBlank() && password.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                    shape = RoundedCornerShape(14.dp),
                    onClick = {
                        scope.launch {
                            busy = true; error = null
                            when (val r = auth.login(username, password)) {
                                is LoginResult.Success -> onSuccess(r.user)
                                LoginResult.Invalid -> error = "اسم المستخدم أو كلمة المرور غير صحيحة"
                                LoginResult.Disabled -> error = "الحساب معطّل. تواصل مع مدير النظام"
                                is LoginResult.Locked -> error = "محاولات كثيرة. حاول بعد ${r.seconds} ثانية"
                            }
                            busy = false
                        }
                    }
                ) { Text("تسجيل الدخول", style = MaterialTheme.typography.titleMedium) }
                Spacer(Modifier.height(10.dp))
                Text("نسخة التطبيق: ${BuildInfo.STAMP}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// تغيير كلمة المرور (إجباري أول دخول)
@Composable
fun ChangePasswordScreen(auth: AuthRepository, user: UserEntity, onDone: (UserEntity) -> Unit, onLogout: () -> Unit) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("تغيير كلمة المرور", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أهلًا ${user.name}. لازم تختار كلمة مرور جديدة قبل ما تكمل.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = p1, onValueChange = { p1 = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("كلمة المرور الجديدة (${AuthRepository.MIN_PASSWORD} أحرف على الأقل)") },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = p2, onValueChange = { p2 = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation()
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(modifier = Modifier.fillMaxWidth(), enabled = !busy, onClick = {
            when {
                p1.length < AuthRepository.MIN_PASSWORD -> error = "كلمة المرور لازم ${AuthRepository.MIN_PASSWORD} أحرف على الأقل"
                p1 != p2 -> error = "كلمتا المرور غير متطابقتين"
                p1.equals(user.username, ignoreCase = true) -> error = "كلمة المرور لازم تختلف عن اسم المستخدم"
                else -> scope.launch {
                    busy = true
                    val r = auth.changePassword(user, p1)
                    busy = false
                    if (r.user != null) onDone(r.user) else error = r.error
                }
            }
        }) { Text("حفظ ومتابعة") }
        TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("خروج") }
    }
}

// الرئيسية حسب الدور
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHome(user: UserEntity, sync: SyncRepository, onNavigate: (String) -> Unit, onLogout: () -> Unit, unread: Int = 0) {
    val syncStatus by sync.status.collectAsState()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { RaneenTopBar(title = { Text("لوحة مدير النظام", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = onLogout) { Text("خروج") } }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // بطاقة الترحيب + المزامنة
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(Color.White).border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(22.dp)).padding(18.dp)
            ) {
                Text("أهلاً، ${user.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text(Roles.label(user.role), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(syncStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    TextButton(onClick = { sync.kick() }) { Text("مزامنة الآن", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
                }
            }

            Text("إدارة النظام", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile("المستخدمون", "إضافة وتعديل وحذف الحسابات", Icons.Filled.Person, Modifier.weight(1f).fillMaxHeight()) { onNavigate("users") }
                HomeTile("الفروع", "بيانات الفروع وتفعيلها", Icons.Filled.Home, Modifier.weight(1f).fillMaxHeight()) { onNavigate("branchAdmin") }
            }
            HomeTile("الأقسام والضوابط", "تعديل الأقسام والبنود والأوزان", Icons.Filled.Settings, Modifier.fillMaxWidth()) { onNavigate("catalog") }

            Text("المتابعة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            HomeTile("التقارير", "كل الزيارات والاعتماد", Icons.Filled.DateRange, Modifier.fillMaxWidth()) { onNavigate("reports") }
        }
    }
}

/** بلاطة لوحة التحكم: أيقونة + عنوان + سطر توضيح. (الارتفاع بيتحدد بالمحتوى، مش بيتمدّد على الشاشة) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeTile(title: String, desc: String, icon: ImageVector, modifier: Modifier, badge: Int = 0, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            BadgedBox(badge = { if (badge > 0) Badge { Text(if (badge > 99) "99+" else badge.toString()) } }) {
                Icon(
                    icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(50.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)).padding(12.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleHome(user: UserEntity, message: String, onLogout: () -> Unit) {
    Scaffold(topBar = {
        RaneenTopBar(title = { Text("إدارة الجودة بشركة رنين") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Text(message)
        }
    }
}

// إدارة المستخدمين (للأدمن)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersScreen(auth: AuthRepository, admin: CatalogAdminRepository, actor: UserEntity, onBack: () -> Unit) {
    val users by remember { auth.users() }.collectAsState(initial = emptyList())
    val allUnits by remember { admin.units() }.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<UserEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<UserEntity?>(null) }
    var deleteError by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("ALL") }      // ALL | ACTIVE | OFF
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)

    val activeN = users.count { it.isActive }
    val shown = users.filter { u ->
        (when (filter) { "ACTIVE" -> u.isActive; "OFF" -> !u.isActive; else -> true }) &&
            (query.isBlank() || u.name.contains(query.trim(), ignoreCase = true) || u.username.contains(query.trim(), ignoreCase = true))
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { RaneenTopBar(title = { Text("المستخدمون") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { adding = true }) { Text("+ إضافة مستخدم") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true, label = { Text("ابحث بالاسم أو اسم المستخدم") },
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text("الكل (${users.size})") }, shape = RoundedCornerShape(12.dp))
                    FilterChip(selected = filter == "ACTIVE", onClick = { filter = "ACTIVE" }, label = { Text("مفعّل ($activeN)") }, shape = RoundedCornerShape(12.dp))
                    FilterChip(selected = filter == "OFF", onClick = { filter = "OFF" }, label = { Text("موقوف (${users.size - activeN})") }, shape = RoundedCornerShape(12.dp))
                }
            }
            if (shown.isEmpty()) item {
                Text("مفيش مستخدمين مطابقين.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(shown, key = { it.id }) { u ->
                Card(
                    Modifier.fillMaxWidth().clickable { editing = u },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = if (u.isActive) Color.White else Color(0xFFF1F1F1)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            Modifier.size(46.dp).clip(CircleShape)
                                .background(if (u.isActive) MaterialTheme.colorScheme.primaryContainer else Color(0xFFE0E0E0)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                (u.name.trim().firstOrNull() ?: '؟').toString(), fontWeight = FontWeight.Bold,
                                color = if (u.isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Text(u.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${u.username} · ${Roles.label(u.role)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            ActiveBadge(u.isActive)
                            // الحذف النهائي متاح للحسابات الموقوفة بس
                            if (!u.isActive && u.id != actor.id) TextButton(onClick = { deleteError = null; deleting = u }, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)) {
                                Text("🗑 حذف", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }
        }
    }
    if (adding) UserDialog(null, auth, actor, allUnits) { adding = false }
    editing?.let { UserDialog(it, auth, actor, allUnits, onRequestDelete = { u -> deleteError = null; deleting = u }) { editing = null } }

    deleting?.let { u ->
        AlertDialog(
            onDismissRequest = { if (!busy) { deleting = null; deleteError = null } },
            title = { Text("حذف ${u.name} نهائيًا؟") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("حساب (${u.username}) هيتمسح من النظام ومش هينفع ترجعه.")
                    Text("لو الحساب عنده زيارات مسجّلة، مش هيتمسح وبيفضل موقوف عشان سجل التقارير يفضل سليم.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    deleteError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        val e = auth.deleteUser(actor, u)
                        busy = false
                        if (e == null) { deleting = null; deleteError = null } else deleteError = e
                    }
                }) { Text(if (busy) "جاري الحذف…" else "حذف نهائي", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { deleting = null; deleteError = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun UserDialog(
    initial: UserEntity?, auth: AuthRepository, actor: UserEntity, units: List<EvaluationUnitEntity>,
    onRequestDelete: ((UserEntity) -> Unit)? = null, onClose: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var username by remember { mutableStateOf(initial?.username ?: "") }
    var role by remember { mutableStateOf(initial?.role ?: Roles.INSPECTOR) }
    var active by remember { mutableStateOf(initial?.isActive ?: true) }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    // مشاهد الإدارة: الوحدات المسموحة (بتتحمّل من السيرفر، ولو التحميل فشل ما بنكتبش فوقها)
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var unitsLoaded by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(initial?.id, role) {
        if (initial != null && role == Roles.VIEWER && !unitsLoaded) {
            auth.viewerUnits(initial.id)?.let { selected = it.toSet(); unitsLoaded = true }
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "إضافة مستخدم" else "تعديل ${initial.username}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") }, singleLine = true)
                if (initial == null)
                    OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("اسم المستخدم (إنجليزي): مثال ahmed.fayoum") }, singleLine = true)
                Text("الدور")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Roles.all.forEach { r ->
                        FilterChip(selected = role == r, onClick = { role = r }, label = { Text(Roles.label(r)) })
                    }
                }
                if (role == Roles.VIEWER) {
                    Text("الوحدات اللي يشوفها المشاهد", fontWeight = FontWeight.Bold)
                    if (initial == null) {
                        Text("احفظ المستخدم الأول، وبعدين افتحه تاني وحدد وحداته.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else if (!unitsLoaded) {
                        Text("جاري تحميل الوحدات…", style = MaterialTheme.typography.bodySmall)
                    } else {
                        // اختيارات جاهزة: بتحدد وحدات الإدارة كلها بضغطة (والأدمن يقدر يعدّل بعدها)
                        val presets = listOf(
                            "إدارة العمليات (الكل)" to null,
                            "الكاشير وخدمة العملاء" to setOf("customer_service", "cashier", "zayed_customer_service"),
                            "الأمن والكاميرات" to setOf("security", "cameras", "zayed_security"),
                            "الصيانة والتكييفات" to setOf("maintenance", "ac_maintenance", "zayed_maintenance", "zayed_air_conditioning"),
                            "الاستلامات" to setOf("receiving_fmc"),
                            "الموارد البشرية" to setOf("hr", "zayed_hr")
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            presets.forEach { (label, ids) ->
                                AssistChip(onClick = {
                                    val all = units.filter { it.isActive }.map { it.id }
                                    selected = if (ids == null) all.toSet() else all.filter { it in ids }.toSet()
                                }, label = { Text(label) })
                            }
                        }
                        units.filter { it.isActive }.sortedWith(compareBy({ it.templateId }, { it.kind }, { it.sortOrder })).forEach { u ->
                            Row(
                                Modifier.fillMaxWidth().clickable { selected = if (u.id in selected) selected - u.id else selected + u.id },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = u.id in selected, onCheckedChange = { selected = if (it) selected + u.id else selected - u.id })
                                Column {
                                    Text(u.name)
                                    Text(evaluationTemplateLabel(u.templateId) + " · " + (if (u.kind == "ADMINISTRATION") "إدارة" else "قسم"),
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        Text("المختار: ${selected.size}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (initial != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = active, onCheckedChange = { active = it })
                    Spacer(Modifier.width(8.dp)); Text("الحساب مفعّل")
                }
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, singleLine = true,
                    label = { Text(if (initial == null) "كلمة المرور (${AuthRepository.MIN_PASSWORD} أحرف على الأقل)" else "كلمة مرور جديدة (اتركها فاضية للإبقاء)") },
                    visualTransformation = PasswordVisualTransformation()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (initial != null && !initial.isActive && initial.id != actor.id && onRequestDelete != null) {
                    TextButton(onClick = { onClose(); onRequestDelete(initial) }) {
                        Text("🗑 حذف الحساب نهائيًا", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    var e = if (initial == null) auth.addUser(actor, name, username, role, password)
                            else auth.updateUser(actor, initial.id, name, role, active, password)
                    // الدور اتحفظ الأول (لازم يبقى VIEWER على السيرفر)، وبعدين الوحدات
                    if (e == null && initial != null && role == Roles.VIEWER && unitsLoaded) {
                        e = auth.setViewerUnits(actor, initial.id, selected.toList())
                    }
                    if (e == null) onClose() else error = e
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}
