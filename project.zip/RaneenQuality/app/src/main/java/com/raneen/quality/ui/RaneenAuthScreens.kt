package com.raneen.quality.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.AuthRepository
import com.raneen.quality.data.LoginResult
import com.raneen.quality.data.Roles
import com.raneen.quality.data.UserEntity
import kotlinx.coroutines.launch

// ───────────── تسجيل الدخول: مفيش أي حساب ظاهر ─────────────
@Composable
fun LoginScreen(auth: AuthRepository, onSuccess: (UserEntity) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("رنين", style = MaterialTheme.typography.displayMedium, color = Color(0xFFC8102E), fontWeight = FontWeight.Bold)
        Text("Raneen Quality", style = MaterialTheme.typography.titleMedium)
        Text("إدارة الجودة بشركة رنين", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = username, onValueChange = { username = it }, singleLine = true,
            label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it }, singleLine = true,
            label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "إخفاء" else "إظهار") } }
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !busy && username.isNotBlank() && password.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    busy = true; error = null
                    when (val r = auth.login(username, password)) {
                        is LoginResult.Success -> onSuccess(r.user)
                        LoginResult.Invalid -> error = "اسم المستخدم أو كلمة المرور غير صحيحة"
                        LoginResult.Disabled -> error = "الحساب معطّل. تواصل مع مدير النظام"
                        is LoginResult.Locked -> error = "محاولات كثيرة. حاول بعد ${r.seconds} ثانية"
                    }
                    busy = false
                }
            }
        ) { Text("تسجيل الدخول") }
    }
}

// ───────────── تغيير كلمة المرور (إجباري أول دخول) ─────────────
@Composable
fun ChangePasswordScreen(auth: AuthRepository, user: UserEntity, onDone: (UserEntity) -> Unit, onLogout: () -> Unit) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("تغيير كلمة المرور", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أهلًا ${user.name}. لازم تختار كلمة مرور جديدة قبل ما تكمل.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = p1, onValueChange = { p1 = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("كلمة المرور الجديدة (${AuthRepository.MIN_PASSWORD} أحرف على الأقل)") },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = p2, onValueChange = { p2 = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation()
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(modifier = Modifier.fillMaxWidth(), onClick = {
            when {
                p1.length < AuthRepository.MIN_PASSWORD -> error = "كلمة المرور لازم ${AuthRepository.MIN_PASSWORD} أحرف على الأقل"
                p1 != p2 -> error = "كلمتا المرور غير متطابقتين"
                p1.equals(user.username, ignoreCase = true) -> error = "كلمة المرور لازم تختلف عن اسم المستخدم"
                else -> scope.launch { onDone(auth.changePassword(user, p1)) }
            }
        }) { Text("حفظ ومتابعة") }
        TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("خروج") }
    }
}

// ───────────── الرئيسية حسب الدور ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHome(user: UserEntity, onNavigate: (String) -> Unit, onLogout: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("لوحة مدير النظام") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = { onNavigate("users") }, modifier = Modifier.fillMaxWidth()) { Text("المستخدمون") }
            Button(onClick = { onNavigate("branchAdmin") }, modifier = Modifier.fillMaxWidth()) { Text("الفروع") }
            Button(onClick = { onNavigate("catalog") }, modifier = Modifier.fillMaxWidth()) { Text("الأقسام والضوابط") }
            Button(onClick = { onNavigate("reports") }, modifier = Modifier.fillMaxWidth()) { Text("التقارير") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleHome(user: UserEntity, message: String, onLogout: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("إدارة الجودة بشركة رنين") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Text(message)
        }
    }
}

// ───────────── إدارة المستخدمين (للأدمن) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersScreen(auth: AuthRepository, actor: UserEntity, onBack: () -> Unit) {
    val users by remember { auth.users() }.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<UserEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = { TopAppBar(title = { Text("المستخدمون") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { adding = true }) { Text("+ إضافة مستخدم") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.id }) { u ->
                Card(Modifier.fillMaxWidth().clickable { editing = u }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(u.name, style = MaterialTheme.typography.titleMedium)
                            Text("${u.username} · ${Roles.label(u.role)}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (u.isActive) "مفعّل" else "معطّل", color = if (u.isActive) Color(0xFF1D7A4D) else MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
    if (adding) UserDialog(null, auth, actor) { adding = false }
    editing?.let { UserDialog(it, auth, actor) { editing = null } }
}

@Composable
private fun UserDialog(initial: UserEntity?, auth: AuthRepository, actor: UserEntity, onClose: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var username by remember { mutableStateOf(initial?.username ?: "") }
    var role by remember { mutableStateOf(initial?.role ?: Roles.INSPECTOR) }
    var active by remember { mutableStateOf(initial?.isActive ?: true) }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "إضافة مستخدم" else "تعديل ${initial.username}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") }, singleLine = true)
                if (initial == null)
                    OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("اسم المستخدم") }, singleLine = true)
                Text("الدور")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Roles.all.forEach { r ->
                        FilterChip(selected = role == r, onClick = { role = r }, label = { Text(Roles.label(r)) })
                    }
                }
                if (initial != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = active, onCheckedChange = { active = it })
                    Spacer(Modifier.width(8.dp)); Text("الحساب مفعّل")
                }
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, singleLine = true,
                    label = { Text(if (initial == null) "كلمة المرور (${AuthRepository.MIN_PASSWORD} أحرف على الأقل)" else "كلمة مرور جديدة (اتركها فاضية للإبقاء)") },
                    visualTransformation = PasswordVisualTransformation()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val e = if (initial == null) auth.addUser(actor, name, username, role, password)
                            else auth.updateUser(actor, initial.id, name, role, active, password)
                    if (e == null) onClose() else error = e
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}
