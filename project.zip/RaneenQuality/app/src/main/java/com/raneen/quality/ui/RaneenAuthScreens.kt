package com.raneen.quality.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.AuthRepository
import com.raneen.quality.data.LoginResult
import com.raneen.quality.data.Roles
import com.raneen.quality.data.SyncRepository
import com.raneen.quality.data.UserEntity
import kotlinx.coroutines.launch

// ───────────── تسجيل الدخول: مفيش أي حساب ظاهر ─────────────
@Composable
fun LoginScreen(auth: AuthRepository, onSuccess: (UserEntity) -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // خلفية فاتحة ناعمة + كارت مركزي نظيف
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "رنين", style = MaterialTheme.typography.displayMedium,
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Text(
                    "Raneen Quality", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.tertiary
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "إدارة الجودة بشركة رنين", style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(28.dp))
                OutlinedTextField(
                    value = username, onValueChange = { username = it }, singleLine = true,
                    label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, singleLine = true,
                    label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { TextButton(onClick = { show = !show }) { Text(if (show) "إخفاء" else "إظهار") } },
                    shape = RoundedCornerShape(14.dp)
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(20.dp))
                Button(
                    enabled = !busy && username.isNotBlank() && password.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                    shape = RoundedCornerShape(14.dp),
                    onClick = {
                        scope.launch {
                            busy = true; error = null
                            when (val r = auth.login(username, password)) {
                                is LoginResult.Success -> onSuccess(r.user)
                                LoginResult.Invalid -> error = "اسم المستخدم أو كلمة المرور غير صحيحة"
                                LoginResult.Disabled -> error = "الحساب معطّل. تواصل مع مدير النظام"
                                is LoginResult.Locked -> error = "محاولات كثيرة. حاول بعد ${r.seconds} ثانية"
                            }
                            busy = false
                        }
                    }
                ) { Text("تسجيل الدخول", style = MaterialTheme.typography.titleMedium) }
            }
        }
    }
}

// ───────────── تغيير كلمة المرور (إجباري أول دخول) ─────────────
@Composable
fun ChangePasswordScreen(auth: AuthRepository, user: UserEntity, onDone: (UserEntity) -> Unit, onLogout: () -> Unit) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("تغيير كلمة المرور", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أهلًا ${user.name}. لازم تختار كلمة مرور جديدة قبل ما تكمل.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = p1, onValueChange = { p1 = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("كلمة المرور الجديدة (${AuthRepository.MIN_PASSWORD} أحرف على الأقل)") },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = p2, onValueChange = { p2 = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation()
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(modifier = Modifier.fillMaxWidth(), enabled = !busy, onClick = {
            when {
                p1.length < AuthRepository.MIN_PASSWORD -> error = "كلمة المرور لازم ${AuthRepository.MIN_PASSWORD} أحرف على الأقل"
                p1 != p2 -> error = "كلمتا المرور غير متطابقتين"
                p1.equals(user.username, ignoreCase = true) -> error = "كلمة المرور لازم تختلف عن اسم المستخدم"
                else -> scope.launch {
                    busy = true
                    val r = auth.changePassword(user, p1)
                    busy = false
                    if (r.user != null) onDone(r.user) else error = r.error
                }
            }
        }) { Text("حفظ ومتابعة") }
        TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("خروج") }
    }
}

// ───────────── الرئيسية حسب الدور ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHome(user: UserEntity, sync: SyncRepository, onNavigate: (String) -> Unit, onLogout: () -> Unit, unread: Int = 0) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("لوحة مدير النظام") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.bodyMedium)
            SyncBar(sync)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile("المستخدمون", Icons.Filled.Person, Modifier.weight(1f)) { onNavigate("users") }
                HomeTile("الفروع", Icons.Filled.Home, Modifier.weight(1f)) { onNavigate("branchAdmin") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile("الأقسام والضوابط", Icons.Filled.Settings, Modifier.weight(1f)) { onNavigate("catalog") }
                HomeTile("التقارير", Icons.Filled.DateRange, Modifier.weight(1f)) { onNavigate("reports") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeTile(if (unread > 0) "الرسائل ($unread)" else "الرسائل", Icons.Filled.Email, Modifier.weight(1f)) { onNavigate("chats") }
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** بلاطة لوحة التحكم: أيقونة داخل دايرة بلون النيلي + عنوان */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeTile(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier.heightIn(min = 120.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(52.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp)).padding(12.dp)
            )
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleHome(user: UserEntity, message: String, onLogout: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("إدارة الجودة بشركة رنين") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } })
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Text(message)
        }
    }
}

// ───────────── إدارة المستخدمين (للأدمن) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersScreen(auth: AuthRepository, actor: UserEntity, onBack: () -> Unit) {
    val users by remember { auth.users() }.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<UserEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = { TopAppBar(title = { Text("المستخدمون") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { adding = true }) { Text("+ إضافة مستخدم") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.id }) { u ->
                Card(Modifier.fillMaxWidth().clickable { editing = u }, shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(u.name, style = MaterialTheme.typography.titleMedium)
                            Text("${u.username} · ${Roles.label(u.role)}", style = MaterialTheme.typography.bodySmall)
                        }
                        ActiveBadge(u.isActive)
                    }
                }
            }
        }
    }
    if (adding) UserDialog(null, auth, actor) { adding = false }
    editing?.let { UserDialog(it, auth, actor) { editing = null } }
}

@Composable
private fun UserDialog(initial: UserEntity?, auth: AuthRepository, actor: UserEntity, onClose: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var username by remember { mutableStateOf(initial?.username ?: "") }
    var role by remember { mutableStateOf(initial?.role ?: Roles.INSPECTOR) }
    var active by remember { mutableStateOf(initial?.isActive ?: true) }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "إضافة مستخدم" else "تعديل ${initial.username}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("الاسم") }, singleLine = true)
                if (initial == null)
                    OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("اسم المستخدم (إنجليزي): مثال ahmed.fayoum") }, singleLine = true)
                Text("الدور")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Roles.all.forEach { r ->
                        FilterChip(selected = role == r, onClick = { role = r }, label = { Text(Roles.label(r)) })
                    }
                }
                if (initial != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = active, onCheckedChange = { active = it })
                    Spacer(Modifier.width(8.dp)); Text("الحساب مفعّل")
                }
                OutlinedTextField(
                    value = password, onValueChange = { password = it }, singleLine = true,
                    label = { Text(if (initial == null) "كلمة المرور (${AuthRepository.MIN_PASSWORD} أحرف على الأقل)" else "كلمة مرور جديدة (اتركها فاضية للإبقاء)") },
                    visualTransformation = PasswordVisualTransformation()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val e = if (initial == null) auth.addUser(actor, name, username, role, password)
                            else auth.updateUser(actor, initial.id, name, role, active, password)
                    if (e == null) onClose() else error = e
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}
