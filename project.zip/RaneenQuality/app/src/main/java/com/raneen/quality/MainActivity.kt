package com.raneen.quality

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.raneen.quality.data.*
import com.raneen.quality.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as RaneenApp
        setContent { MaterialTheme { RaneenRoot(app.db) } }
    }
}

/**
 * التنقل: route واحد بيحدد الشاشة. زرار الرجوع بيطلع خطوة حسب parentOf.
 * home → (branches | units → eval | detail | users | branchAdmin | catalog → unitEdit | reports → detail)
 */
@Composable
fun RaneenRoot(db: RaneenDatabase) {
    val context = LocalContext.current
    val appCtx = context.applicationContext
    val repo = remember { InspectionRepository(db, appCtx) }
    val reports = remember { ReportRepository(db, appCtx) }
    val auth = remember { AuthRepository(db.userDao()) }
    val admin = remember { CatalogAdminRepository(db, SeedLoader(appCtx, db)) }

    var ready by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf<UserEntity?>(null) }
    var route by rememberSaveable { mutableStateOf("home") }
    var detailBack by rememberSaveable { mutableStateOf("home") }
    var inspectionId by rememberSaveable { mutableStateOf<String?>(null) }
    var unitId by rememberSaveable { mutableStateOf<String?>(null) }
    var unitName by rememberSaveable { mutableStateOf("") }
    var editUnitId by rememberSaveable { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        SeedLoader(context, db).seedIfEmpty()
        repo.seedBranchesIfEmpty()
        auth.seedAdminIfEmpty()
        ready = true
    }

    fun reset() { route = "home"; detailBack = "home"; inspectionId = null; unitId = null; editUnitId = null }
    fun logout() { user = null; reset() }

    BackHandler(enabled = user != null && route != "home") {
        route = when (route) {
            "eval" -> "units"
            "detail" -> detailBack
            "unitEdit" -> "catalog"
            else -> "home"
        }
    }

    val u = user
    val iid = inspectionId
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        when {
            !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            u == null -> LoginScreen(auth) { user = it; reset() }
            u.mustChangePassword -> ChangePasswordScreen(auth, u, { user = it }, { logout() })
            else -> when (route) {
                // ───────── الأدمن ─────────
                "users" -> UsersScreen(auth, u) { route = "home" }
                "branchAdmin" -> BranchesScreen(admin) { route = "home" }
                "catalog" -> CatalogScreen(admin, { id, _ -> editUnitId = id; route = "unitEdit" }) { route = "home" }
                "unitEdit" -> UnitEditScreen(admin, editUnitId ?: "") { route = "catalog" }
                "reports" -> ReportsListScreen("التقارير", u, reports, "رجوع", { route = "home" }) {
                    inspectionId = it.id; detailBack = "reports"; route = "detail"
                }

                // ───────── المراقب ─────────
                "branches" -> BranchPickerScreen(repo, u.id, { route = "home" }) { id -> inspectionId = id; route = "units" }
                "units" -> if (iid == null) { reset() } else UnitsScreen(
                    u, repo, reports, iid,
                    onOpen = { id, name -> unitId = id; unitName = name; route = "eval" },
                    onReview = { detailBack = "units"; route = "detail" },
                    onDeleted = { reset() }
                )
                "eval" -> {
                    val uid = unitId
                    if (iid == null || uid == null) reset() else EvaluationScreen(repo, iid, uid, unitName)
                }

                // ───────── تفاصيل التقرير (كل الأدوار) ─────────
                "detail" -> if (iid == null) { reset() } else ReportDetailScreen(
                    u, reports, iid,
                    onBack = { route = detailBack },
                    onEdit = { route = "units" },
                    onChanged = { detailBack = "home" }
                )

                // ───────── الرئيسية حسب الدور ─────────
                else -> when (u.role) {
                    Roles.ADMIN -> AdminHome(u, { route = it }, { logout() })
                    Roles.INSPECTOR -> InspectorHome(
                        u, reports, onNew = { route = "branches" },
                        onOpen = {
                            inspectionId = it.id
                            if (Status.editable(it.status)) route = "units" else { detailBack = "home"; route = "detail" }
                        },
                        onLogout = { logout() }
                    )
                    else -> ReportsListScreen("إدارة الجودة بشركة رنين", u, reports, "خروج", { logout() }) {
                        inspectionId = it.id; detailBack = "home"; route = "detail"
                    }
                }
            }
        }
    }
}
