package com.raneen.quality

import android.Manifest
import android.os.Build
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.ui.graphics.Shape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.flow.flowOf
import com.raneen.quality.data.*
import com.raneen.quality.ui.*

class MainActivity : ComponentActivity() {
    /** محادثة مطلوب فتحها (جاية من الضغط على إشعار شات) */
    private val pendingChatPeer = mutableStateOf<String?>(null)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingChatPeer.value = intent.getStringExtra(ChatPush.EXTRA_PEER)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_Raneen)   // نخرج من ثيم السبلاش الأحمر لثيم التطبيق العادي
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) pendingChatPeer.value = intent?.getStringExtra(ChatPush.EXTRA_PEER)
        val app = application as RaneenApp
        setContent {
            // هوية رنين (قاعدة 60-30-10): أبيض/رمادي فاتح 60% — رمادي غامق للنصوص 30% — أحمر البراند 10% (أزرار، شريط علوي، أيقونات نشطة)
            val raneenScheme = lightColorScheme(
                primary = Color(0xFFE10003),              // أحمر رنين (أغمق شوية من لون اللوجو عشان وضوح النص الأبيض)
                onPrimary = Color(0xFFFFFFFF),
                primaryContainer = Color(0xFFFDE8E8),
                onPrimaryContainer = Color(0xFF7A0002),
                secondary = Color(0xFF424242),            // رمادي غامق
                onSecondary = Color(0xFFFFFFFF),
                secondaryContainer = Color(0xFFEEEEEE),
                onSecondaryContainer = Color(0xFF212121),
                tertiary = Color(0xFFE10003),             // نفس الأحمر (مفيش لون ثالث — الـ Accent هو الأحمر)
                onTertiary = Color(0xFFFFFFFF),
                tertiaryContainer = Color(0xFFFDE8E8),
                onTertiaryContainer = Color(0xFF7A0002),
                background = Color(0xFFF9F9F9),           // خلفية فاتحة
                onBackground = Color(0xFF212121),
                surface = Color(0xFFFFFFFF),
                onSurface = Color(0xFF212121),            // عناوين غامقة
                surfaceVariant = Color(0xFFF0F0F0),
                surfaceContainerLowest = Color(0xFFFFFFFF),
                surfaceContainerLow = Color(0xFFFFFFFF),
                surfaceContainer = Color(0xFFFFFFFF),
                surfaceContainerHigh = Color(0xFFF5F5F5),
                surfaceContainerHighest = Color(0xFFFFFFFF), // الكروت بيضاء
                onSurfaceVariant = Color(0xFF666666),     // نص الجسم رمادي متوسط
                outline = Color(0xFFBDBDBD),
                outlineVariant = Color(0xFFE0E0E0),
                error = Color(0xFFB00020),
                onError = Color(0xFFFFFFFF)
            )
            MaterialTheme(
                colorScheme = raneenScheme,
                shapes = Shapes(
                    extraSmall = RoundedCornerShape(8.dp),
                    small = RoundedCornerShape(12.dp),
                    medium = RoundedCornerShape(16.dp),
                    large = RoundedCornerShape(22.dp),
                    extraLarge = RoundedCornerShape(28.dp)
                )
            ) { RaneenRoot(app.db, pendingChatPeer) }
        }
    }
}

/**
 * التنقل: route واحد بيحدد الشاشة. زرار الرجوع بيطلع خطوة حسب parentOf.
 * home → (branches | units → eval | detail | users | branchAdmin | catalog → unitEdit | reports → detail)
 */
@Composable
fun RaneenRoot(db: RaneenDatabase, pendingChatPeer: MutableState<String?>) {
    val context = LocalContext.current
    val appCtx = context.applicationContext
    val remote = remember { SupabaseRemote(appCtx) }
    val sync = remember { SyncRepository(db, remote, appCtx) }
    val repo = remember { InspectionRepository(db, appCtx) }
    val reports = remember { ReportRepository(db, appCtx, remote, sync) }
    val auth = remember { AuthRepository(db.userDao(), remote) { sync.refreshProfiles() } }
    val admin = remember { CatalogAdminRepository(db, SeedLoader(appCtx, db), sync) }
    val chat = remember { ChatRepository(db, appCtx, sync.chatSync) }

    var ready by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf<UserEntity?>(null) }
    var route by rememberSaveable { mutableStateOf("home") }
    var detailBack by rememberSaveable { mutableStateOf("home") }
    var inspectionId by rememberSaveable { mutableStateOf<String?>(null) }
    var unitId by rememberSaveable { mutableStateOf<String?>(null) }
    var unitName by rememberSaveable { mutableStateOf("") }
    var editUnitId by rememberSaveable { mutableStateOf<String?>(null) }
    var chatPeerId by rememberSaveable { mutableStateOf<String?>(null) }
    // الضغط على إشعار شات: افتح المحادثة (بعد ما المستخدم يكون مسجّل دخول)
    val wantedPeer = pendingChatPeer.value
    LaunchedEffect(wantedPeer, user?.id) {
        if (wantedPeer != null && user != null) { chatPeerId = wantedPeer; route = "chat"; pendingChatPeer.value = null }
    }
    // عدّاد الرسائل غير المقروءة (للشارة على الشاشة الرئيسية)
    val unread by remember(user?.id) { user?.let { chat.unreadTotal(it.id) } ?: flowOf(0) }.collectAsState(initial = 0)

    LaunchedEffect(Unit) {
        SeedLoader(context, db).seedIfEmpty()
        auth.cleanupLegacySeed()
        ready = true
    }

    // المزامنة بتشتغل طول ما فيه مستخدم داخل (ومعاه جلسة سيرفر)، وبتقف عند الخروج
    val signedIn = user
    LaunchedEffect(signedIn?.id, signedIn?.mustChangePassword) {
        if (signedIn != null && !signedIn.mustChangePassword) {
            sync.start(signedIn)
            BackgroundSync.schedule(appCtx)
        } else sync.stop()
    }

    // إذن التنبيهات (أندرويد 13+)
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(signedIn?.id) {
        if (signedIn != null && Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun goChats() { route = "chats" }
    fun reset() { route = "home"; detailBack = "home"; inspectionId = null; unitId = null; editUnitId = null }
    fun logout() { sync.stop(); BackgroundSync.cancel(appCtx); PushRegistrar.logoutAsync(appCtx, remote) { auth.logout() }; user = null; reset() }

    BackHandler(enabled = user != null && route != "home") {
        route = when (route) {
            "eval" -> "units"
            "detail" -> detailBack
            "unitEdit" -> "catalog"
            "chat", "chatPeer" -> "chats"
            else -> "home"
        }
    }

    val u = user
    val iid = inspectionId
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        when {
            !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            u == null -> LoginScreen(auth) { user = it; reset() }
            u.mustChangePassword -> ChangePasswordScreen(auth, u, { user = it }, { logout() })
            else -> when (route) {
                // ───────── الأدمن ─────────
                "users" -> UsersScreen(auth, u) { route = "home" }
                "branchAdmin" -> BranchesScreen(admin) { route = "home" }
                "catalog" -> CatalogScreen(admin, { id, _ -> editUnitId = id; route = "unitEdit" }) { route = "home" }
                "unitEdit" -> UnitEditScreen(admin, editUnitId ?: "") { route = "catalog" }
                "reports" -> ReportsListScreen("التقارير", u, reports, sync, "رجوع", { route = "home" }) {
                    inspectionId = it.id; detailBack = "reports"; route = "detail"
                }

                // ───────── المراقب ─────────
                "branches" -> BranchPickerScreen(repo, u.id, { route = "home" }) { id -> inspectionId = id; route = "units" }
                "units" -> if (iid == null) { reset() } else UnitsScreen(
                    u, repo, reports, iid,
                    onOpen = { id, name -> unitId = id; unitName = name; route = "eval" },
                    onReview = { detailBack = "units"; route = "detail" },
                    onDeleted = { reset() }
                )
                "eval" -> {
                    val uid = unitId
                    if (iid == null || uid == null) reset() else EvaluationScreen(repo, iid, uid, unitName, u, reports)
                }

                // ───────── الرسائل (كل الأدوار) ─────────
                "chats" -> ChatListScreen(u, chat, { route = "home" }, { chatPeerId = it; route = "chat" }, { route = "chatPeer" })
                "chatPeer" -> PeerPickerScreen(u, chat, { route = "chats" }) { chatPeerId = it; route = "chat" }
                "chat" -> { val pid = chatPeerId; if (pid == null) goChats() else ChatScreen(u, chat, pid) { route = "chats" } }

                // ───────── تفاصيل التقرير (كل الأدوار) ─────────
                "detail" -> if (iid == null) { reset() } else ReportDetailScreen(
                    u, reports, iid,
                    onBack = { route = detailBack },
                    onEdit = { route = "units" },
                    onChanged = { detailBack = "home" }
                )

                // ───────── الرئيسية حسب الدور ─────────
                else -> when (u.role) {
                    Roles.ADMIN -> AdminHome(u, sync, { route = it }, { logout() }, unread = unread)
                    Roles.INSPECTOR -> InspectorHome(
                        u, reports, sync, onNew = { route = "branches" },
                        unread = unread, onChat = { route = "chats" },
                        onOpen = {
                            inspectionId = it.id
                            if (Status.editable(it.status)) route = "units" else { detailBack = "home"; route = "detail" }
                        },
                        onLogout = { logout() }
                    )
                    else -> ReportsListScreen("إدارة الجودة بشركة رنين", u, reports, sync, "خروج", { logout() }, unread = unread, onChat = { route = "chats" }) {
                        inspectionId = it.id; detailBack = "home"; route = "detail"
                    }
                }
            }
        }
    }
}
