package com.raneen.quality

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.AuthRepository
import com.raneen.quality.data.EvaluationUnitEntity
import com.raneen.quality.data.Roles
import com.raneen.quality.data.UserEntity
import com.raneen.quality.data.RaneenDatabase
import com.raneen.quality.data.SeedLoader
import com.raneen.quality.ui.AdminHome
import com.raneen.quality.ui.ChangePasswordScreen
import com.raneen.quality.ui.EvaluationScreen
import com.raneen.quality.ui.LoginScreen
import com.raneen.quality.ui.RoleHome
import com.raneen.quality.ui.UsersScreen
import com.raneen.quality.ui.InspectionRepository
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as RaneenApp
        setContent { MaterialTheme { RaneenRoot(app.db) } }
    }
}

/** الدخول → (تغيير كلمة المرور لو إجباري) → الرئيسية حسب الدور. زرار الرجوع بيطلع خطوة. */
@Composable
fun RaneenRoot(db: RaneenDatabase) {
    val context = LocalContext.current
    val repo = remember { InspectionRepository(db) }
    val auth = remember { AuthRepository(db.userDao()) }
    var ready by remember { mutableStateOf(false) }
    var user by remember { mutableStateOf<UserEntity?>(null) }
    var adminPage by remember { mutableStateOf("home") }
    var inspectionId by rememberSaveable { mutableStateOf<String?>(null) }
    var unitId by rememberSaveable { mutableStateOf<String?>(null) }
    var unitName by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) {
        SeedLoader(context, db).seedIfEmpty()
        repo.seedBranchesIfEmpty()
        auth.seedAdminIfEmpty()
        ready = true
    }

    fun logout() { user = null; adminPage = "home"; inspectionId = null; unitId = null }

    val u = user
    val iid = inspectionId
    val uid = unitId
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        when {
            !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            u == null -> LoginScreen(auth) { user = it }
            u.mustChangePassword -> ChangePasswordScreen(auth, u, { user = it }, { logout() })
            u.role == Roles.ADMIN ->
                if (adminPage == "users") UsersScreen(auth, u) { adminPage = "home" }
                else AdminHome(u, { adminPage = "users" }, { logout() })
            u.role == Roles.INSPECTOR -> when {
                iid == null -> HomeScreen(repo, u.id, { logout() }) { inspectionId = it }
                uid == null -> {
                    BackHandler { inspectionId = null }
                    UnitsScreen(repo) { id, name -> unitId = id; unitName = name }
                }
                else -> {
                    BackHandler { unitId = null }
                    EvaluationScreen(repo, iid, uid, unitName)
                }
            }
            else -> RoleHome(u, "شاشة مراجعة التقارير واعتمادها هتتبني في الخطوة الجاية.") { logout() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(repo: InspectionRepository, inspectorId: String, onLogout: () -> Unit, onStarted: (String) -> Unit) {
    val branches by remember(repo) { repo.branches() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    Scaffold(topBar = { TopAppBar(title = { Text("إدارة الجودة بشركة رنين") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } }) }) { padding ->
        LazyColumn(
            Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("اختر الفرع لبدء زيارة تفتيش", style = MaterialTheme.typography.titleMedium) }
            items(branches, key = { it.id }) { b ->
                Card(
                    Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            val number = "RQ-2026-" + (System.currentTimeMillis() % 1_000_000).toString().padStart(6, '0')
                            onStarted(repo.startInspection(b.id, inspectorId, number))
                        }
                    }
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(b.name, style = MaterialTheme.typography.titleMedium)
                        Text("${b.code} - ${b.region}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitsScreen(repo: InspectionRepository, onOpen: (String, String) -> Unit) {
    val units by remember(repo) { repo.units() }.collectAsState(initial = emptyList())
    val sections = units.filter { it.kind == "SECTION" }
    val admins = units.filter { it.kind == "ADMINISTRATION" }
    Scaffold(topBar = { TopAppBar(title = { Text("اختر القسم أو الإدارة") }) }) { padding ->
        LazyColumn(
            Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("الأقسام", style = MaterialTheme.typography.titleMedium) }
            items(sections, key = { it.id }) { UnitCard(it, onOpen) }
            item { Spacer(Modifier.height(8.dp)); Text("الإدارات المساعدة", style = MaterialTheme.typography.titleMedium) }
            items(admins, key = { it.id }) { UnitCard(it, onOpen) }
        }
    }
}

@Composable
private fun UnitCard(u: EvaluationUnitEntity, onOpen: (String, String) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onOpen(u.id, u.name) }) {
        Text(u.name, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge)
    }
}
