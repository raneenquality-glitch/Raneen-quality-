package com.raneen.quality.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** المقعد اللي المراقب حجزه في الزيارة (محلي على الجهاز): OPERATIONAL = الأقسام التشغيلية، SUPPORT = الإدارات المساعدة، BOTH = زيارة منفردة. */
object SeatStore {
    private var prefs: android.content.SharedPreferences? = null
    fun init(ctx: Context) { if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("raneen_seats", Context.MODE_PRIVATE) }
    fun getOrNull(inspectionId: String): String? = prefs?.getString(inspectionId, null)
    fun set(inspectionId: String, seat: String) { prefs?.edit()?.putString(inspectionId, seat)?.apply() }
    fun clear(inspectionId: String) { prefs?.edit()?.remove(inspectionId)?.apply() }
    /** هل القسم ده ضمن المقعد؟ (من غير مقعد = كل الأقسام زي الأول) */
    fun allows(seat: String?, unitKind: String): Boolean = when (seat) {
        "OPERATIONAL" -> unitKind == "SECTION"
        "SUPPORT" -> unitKind == "ADMINISTRATION"
        else -> true
    }
    fun label(seat: String): String = when (seat) {
        "OPERATIONAL" -> "الأقسام التشغيلية"
        "SUPPORT" -> "الإدارات المساعدة"
        else -> "الاتنين (زيارة منفردة)"
    }
}

data class SeatInfo(val seat: String, val holderName: String, val mine: Boolean, val submitted: Boolean)

/** حجز المقاعد على السيرفر: مقعد واحد لكل مراقب في الزيارة، ومفيش مراقب تالت. */
object VisitSeats {
    private fun body(branchId: String, templateId: String, visit: String) =
        JSONObject().put("p_branch_id", branchId).put("p_template_id", templateId).put("p_visit_number", visit)

    fun status(remote: SupabaseRemote, branchId: String, templateId: String, visit: String): Result<List<SeatInfo>> = try {
        val a = JSONArray(remote.rpc("visit_seats_status", body(branchId, templateId, visit).toString()))
        Result.success((0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            SeatInfo(o.getString("seat"), o.optString("holderName", ""), o.optBoolean("mine", false), o.optBoolean("submitted", false))
        })
    } catch (e: Exception) { Result.failure(e) }

    /** null = اتحجز بنجاح، غير كده رسالة الخطأ بالعربي */
    fun claim(remote: SupabaseRemote, branchId: String, templateId: String, visit: String, seat: String): String? = try {
        remote.rpc("claim_visit_seat", body(branchId, templateId, visit).put("p_seat", seat).toString())
        null
    } catch (e: ApiException) {
        when {
            e.body.contains("seat_taken") -> {
                val who = Regex("seat_taken: ([^\"\\\\]*)").find(e.body)?.groupValues?.get(1)?.trim().orEmpty()
                if (who.isBlank()) "المقعد ده اتحجز لمراقب تاني." else "المقعد ده ماسكه $who."
            }
            e.body.contains("not allowed") -> "غير مصرّح لك بحجز مقعد."
            else -> "تعذّر حجز المقعد (${e.code}). حاول تاني."
        }
    } catch (e: Exception) { "محتاج اتصال بالإنترنت عشان تحجز دورك في الزيارة." }

    fun release(remote: SupabaseRemote, branchId: String, templateId: String, visit: String, seat: String) {
        runCatching { remote.rpc("release_visit_seat", body(branchId, templateId, visit).put("p_seat", seat).toString()) }
    }
}
