package com.raneen.quality.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** المقعد اللي المراقب حجزه في الزيارة (محلي على الجهاز): OPERATIONAL = الأقسام التشغيلية، SUPPORT = الإدارات المساعدة، BOTH = زيارة منفردة. */
object SeatStore {
    private var prefs: android.content.SharedPreferences? = null
    fun init(ctx: Context) { if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("raneen_seats", Context.MODE_PRIVATE) }
    fun getOrNull(inspectionId: String): String? = prefs?.getString(inspectionId, null)
    fun set(inspectionId: String, seat: String) { prefs?.edit()?.putString(inspectionId, seat)?.apply() }
    fun clear(inspectionId: String) { prefs?.edit()?.remove(inspectionId)?.apply() }

    /** فك مقعد فشل (مفيش نت): بيتخزن ويتعاد مع المزامنة. الشكل: branch|template|visit|seat */
    private const val PENDING_KEY = "__pending_release"
    fun pendingReleases(): Set<String> = prefs?.getStringSet(PENDING_KEY, emptySet()) ?: emptySet()
    fun queueRelease(branchId: String, templateId: String, visit: String, seat: String) {
        prefs?.edit()?.putStringSet(PENDING_KEY, HashSet(pendingReleases() + "$branchId|$templateId|$visit|$seat"))?.apply()
    }
    fun dropRelease(entry: String) { prefs?.edit()?.putStringSet(PENDING_KEY, HashSet(pendingReleases() - entry))?.apply() }
    /** هل القسم ده ضمن المقعد؟ (من غير مقعد = كل الأقسام زي الأول) */
    fun allows(seat: String?, unitKind: String): Boolean = when (seat) {
        "OPERATIONAL" -> unitKind == "SECTION"
        "SUPPORT" -> unitKind == "ADMINISTRATION"
        else -> true
    }
    fun label(seat: String): String = when (seat) {
        "OPERATIONAL" -> "الأقسام التشغيلية"
        "SUPPORT" -> "الإدارات المساعدة"
        else -> "الاتنين (زيارة منفردة)"
    }
}

data class SeatInfo(val seat: String, val holderName: String, val mine: Boolean, val submitted: Boolean) {
    val holder: String get() = holderName.ifBlank { "مراقب تاني" }
}

/** مقعد محجوز ولسه ماترفعش عليه تقرير (للأدمن والمديرين عشان يلغوه). */
data class OpenSeat(
    val branchId: String, val branchName: String, val templateId: String, val month: String,
    val visit: String, val seat: String, val holderName: String, val createdAt: String
)

/** حجز المقاعد على السيرفر: مقعد واحد لكل مراقب في الزيارة، ومفيش مراقب تالت. */
object VisitSeats {
    private fun body(branchId: String, templateId: String, visit: String) =
        JSONObject().put("p_branch_id", branchId).put("p_template_id", templateId).put("p_visit_number", visit)

    fun status(remote: SupabaseRemote, branchId: String, templateId: String, visit: String): Result<List<SeatInfo>> = try {
        val a = JSONArray(remote.rpc("visit_seats_status", body(branchId, templateId, visit).toString()))
        Result.success((0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            SeatInfo(o.getString("seat"), if (o.isNull("holderName")) "" else o.optString("holderName"), o.optBoolean("mine", false), o.optBoolean("submitted", false))
        })
    } catch (e: Exception) { Result.failure(e) }

    /** null = اتحجز بنجاح، غير كده رسالة الخطأ بالعربي */
    fun claim(remote: SupabaseRemote, branchId: String, templateId: String, visit: String, seat: String): String? = try {
        remote.rpc("claim_visit_seat", body(branchId, templateId, visit).put("p_seat", seat).toString())
        null
    } catch (e: ApiException) {
        when {
            e.body.contains("seat_taken") -> {
                val who = Regex("seat_taken: ([^\"\\\\]*)").find(e.body)?.groupValues?.get(1)?.trim().orEmpty()
                if (who.isBlank()) "المقعد ده اتحجز لمراقب تاني." else "المقعد ده ماسكه $who."
            }
            e.body.contains("not allowed") -> "غير مصرّح لك بحجز مقعد."
            else -> "تعذّر حجز المقعد (${e.code}). حاول تاني."
        }
    } catch (e: Exception) { "محتاج اتصال بالإنترنت عشان تحجز دورك في الزيارة." }

    /** true = اتفك. false = فشل (لازم المنادي يحط الفك في طابور الإعادة). */
    fun release(remote: SupabaseRemote, branchId: String, templateId: String, visit: String, seat: String): Boolean =
        runCatching { remote.rpc("release_visit_seat", body(branchId, templateId, visit).put("p_seat", seat).toString()) }.isSuccess

    /** للطابور: true = خلاص مفيش داعي نعيد (اتفك، أو السيرفر رفض رفض نهائي زي "مش مقعدك"). false = مشكلة اتصال/سيرفر، نعيد بعدين. */
    fun releaseSettled(remote: SupabaseRemote, branchId: String, templateId: String, visit: String, seat: String): Boolean = try {
        remote.rpc("release_visit_seat", body(branchId, templateId, visit).put("p_seat", seat).toString()); true
    } catch (e: ApiException) { e.code in 400..499 && e.code != 401 && e.code != 408 && e.code != 429 } catch (e: Exception) { false }

    /** المقاعد المحجوزة اللي لسه ماترفعش عليها تقرير (المديرين والأدمن بس بيشوفوها بسبب صلاحيات السيرفر). */
    fun listOpen(remote: SupabaseRemote): Result<List<JSONObject>> = try {
        // مقعد "مفتوح" = من غير تقرير، أو مربوط بتقرير مش موجود على السيرفر (مقعد معلّق). قبل كده كان بيعرض اللي inspection_id فاضي بس،
        // فالمقعد المربوط بتقرير مش موجود كان بيبان للمراقب "محجوز" ومايبانش للمدير.
        val a = JSONArray(remote.get("/rest/v1/visit_seats?select=*&order=created_at.asc&limit=1000"))
        val all = (0 until a.length()).map { a.getJSONObject(it) }
        fun linked(o: JSONObject): String? = if (o.isNull("inspection_id")) null else o.optString("inspection_id").takeIf { it.isNotBlank() && it != "null" }
        val ids = all.mapNotNull { linked(it) }.distinct()
        val existing = HashSet<String>()
        val checked = try {
            ids.chunked(40).forEach { ch ->
                val r = JSONArray(remote.get("/rest/v1/reports?select=id&id=in.(${ch.joinToString(",")})"))
                for (i in 0 until r.length()) existing += r.getJSONObject(i).getString("id")
            }
            true
        } catch (e: Exception) { false }
        Result.success(all.filter { o -> val id = linked(o); id == null || (checked && id !in existing) })
    } catch (e: Exception) { Result.failure(e) }

    /** إلغاء مقعد (أدمن / مدير منطقة / مدير إدارة). null = تمام، غير كده رسالة الخطأ */
    fun cancel(remote: SupabaseRemote, seat: OpenSeat): String? = try {
        remote.rpc("release_visit_seat", body(seat.branchId, seat.templateId, seat.visit).put("p_seat", seat.seat).put("p_month", seat.month).toString())
        null
    } catch (e: ApiException) {
        when {
            e.body.contains("already submitted") -> "الجزء ده اتبعت خلاص، مينفعش يتلغي."
            e.body.contains("not allowed") -> "غير مصرّح لك بإلغاء المقاعد."
            else -> "تعذّر الإلغاء (${e.code})."
        }
    } catch (e: Exception) { "محتاج اتصال بالإنترنت." }
}
