package com.raneen.quality.data

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

// ───────────── الداتابيز ─────────────
// لو عندك @Database موجودة في المشروع: انقل الكيانات والـ DAOs لها بدل ما تعمل كلاس جديد.
@Database(
    entities = [
        TemplateEntity::class, EvaluationUnitEntity::class, ProductGroupEntity::class,
        CategoryEntity::class, ControlEntity::class, BranchEntity::class,
        InspectionEntity::class, InspectionUnitEntity::class, UserEntity::class,
        FindingEntity::class, PhotoEntity::class, AuditEntity::class, ChatMessageEntity::class
    ],
    version = 5,
    exportSchema = true   // بيطلّع ملف schemas/<version>.json عشان نقدر نراجع كل Migration
)
abstract class RaneenDatabase : RoomDatabase() {
    abstract fun catalogDao(): CatalogDao
    abstract fun inspectionDao(): InspectionDao
    abstract fun userDao(): UserDao
    abstract fun chatDao(): ChatDao
}

// ───────────── تحميل الـ seed ─────────────
/**
 * بيقرا assets/raneen_seed.json ويملأ: templates / evaluation_units / product_groups /
 * categories / controls. بيشتغل مرة واحدة (لو جدول الضوابط فاضي).
 * الكل جوه transaction واحدة: يا كله يتكتب يا مفيش حاجة (مفيش seed نصّه).
 *
 * محتاج dependency:  androidx.room:room-ktx  (withTransaction)
 */
class SeedLoader(
    private val context: Context,
    private val db: RaneenDatabase
) {
    companion object {
        private const val ASSET = "raneen_seed.json"
        private const val TEMPLATE_ID = "main"   // قالب "تقرير الجودة" الأساسي
    }

    suspend fun seedIfEmpty() = withContext(Dispatchers.IO) {
        if (db.catalogDao().controlCount() > 0) {
            addMissingSeedUnits()
            return@withContext
        }
        load()
    }

    /** استرجاع الكتالوج الأصلي: بيمسح الأقسام/الضوابط الحالية (بما فيها تعديلات الأدمن) ويحمّل الـ seed من الأول */
    suspend fun reseed() = withContext(Dispatchers.IO) {
        val dao = db.catalogDao()
        db.withTransaction {
            dao.wipeControls(); dao.wipeCategories(); dao.wipeGroups(); dao.wipeUnits(); dao.wipeTemplates()
        }
        load()
    }

    /** يضيف الوحدات الجديدة فقط من seed بدون استبدال أي تعديل إداري قائم. */
    private suspend fun addMissingSeedUnits() {
        val dao = db.catalogDao()
        val root = JSONObject(context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() })
        val all = root.getJSONArray("units")
        val known = dao.allUnitIds().toSet()
        val missingRoot = JSONObject().put("units", org.json.JSONArray())
        val missing = missingRoot.getJSONArray("units")
        for (i in 0 until all.length()) {
            val unit = all.getJSONObject(i)
            if (unit.getString("id") !in known) missing.put(unit)
        }
        if (missing.length() == 0) {
            refreshRequestedSeedControls()
            return
        }
        // Reuse the same parser by loading a temporary JSON asset is avoided; parse only the missing units here.
        val unitList = mutableListOf<EvaluationUnitEntity>()
        val groupList = mutableListOf<ProductGroupEntity>()
        val categoryList = mutableListOf<CategoryEntity>()
        val controlList = mutableListOf<ControlEntity>()
        for (i in 0 until missing.length()) {
            val u = missing.getJSONObject(i); val unitId = u.getString("id")
            unitList += EvaluationUnitEntity(unitId, u.optString("templateId", TEMPLATE_ID), u.getString("name"), u.getString("kind"), u.optString("scoringMode", "X_COUNT"), u.optInt("sortOrder", 0))
            val groups = u.optJSONArray("groups")
            if (groups != null) for (g in 0 until groups.length()) groupList += ProductGroupEntity("${unitId}_g${g+1}", unitId, groups.getString(g), g)
            val cats = u.getJSONArray("categories")
            for (c in 0 until cats.length()) { val o=cats.getJSONObject(c); categoryList += CategoryEntity(o.getString("id"), unitId, o.getString("name"), o.optInt("sort",0)) }
            val controls = u.getJSONArray("controls")
            for (k in 0 until controls.length()) { val o=controls.getJSONObject(k); controlList += ControlEntity(o.getString("id"),o.getString("categoryId"),o.getString("text"),o.getDouble("maxScore"),o.optDouble("penaltyPerViolation",1.0),o.optBoolean("photoRequired",true),o.optBoolean("perGroup",false),if(o.isNull("hint")) null else o.optString("hint"),o.optInt("no",k+1)) }
        }
        val templates = mutableListOf(TemplateEntity(TEMPLATE_ID, "تقرير الجودة"), TemplateEntity("zayed", "تقييم فرع زايد"))
        db.withTransaction { dao.upsertTemplates(templates); dao.upsertUnits(unitList); dao.upsertGroups(groupList); dao.upsertCategories(categoryList); dao.upsertControls(controlList) }
        refreshRequestedSeedControls()
    }

    /** يحدّث فقط البنود التي تغيّرت مواصفاتها في هذا الإصدار، حتى تظهر التعديلات على الأجهزة التي لديها قاعدة بيانات سابقة. */
    private suspend fun refreshRequestedSeedControls() {
        val requestedIds = setOf(
            *(1..22).map { "maintenance_i$it" }.toTypedArray(),
            *(1..8).map { "ac_maintenance_i$it" }.toTypedArray(),
            "branch_manager_i4", "branch_manager_i5", "branch_manager_i9", "branch_manager_i13",
            "zayed_branch_manager_i4", "zayed_branch_manager_i5", "zayed_branch_manager_i9", "zayed_branch_manager_i13",
            "zayed_services_i4", "zayed_services_i5", "zayed_services_i6", "zayed_services_i7", "zayed_services_i8"
        )
        val root = JSONObject(context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() })
        val units = root.getJSONArray("units")
        val updates = mutableListOf<ControlEntity>()
        for (i in 0 until units.length()) {
            val controls = units.getJSONObject(i).getJSONArray("controls")
            for (j in 0 until controls.length()) {
                val o = controls.getJSONObject(j)
                if (o.getString("id") !in requestedIds) continue
                updates += ControlEntity(
                    id = o.getString("id"), categoryId = o.getString("categoryId"), text = o.getString("text"),
                    maxScore = o.getDouble("maxScore"), penaltyPerViolation = o.optDouble("penaltyPerViolation", 1.0),
                    photoRequired = o.optBoolean("photoRequired", true), perGroup = o.optBoolean("perGroup", false),
                    hint = if (o.isNull("hint")) null else o.optString("hint"), sortOrder = o.optInt("no", j + 1)
                )
            }
        }
        if (updates.isNotEmpty()) db.catalogDao().upsertControls(updates)
    }

    private suspend fun load() {
        val dao = db.catalogDao()

        val json = context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(json)
        val templates = root.optJSONArray("templates")
        val units = root.getJSONArray("units")

        val unitList = mutableListOf<EvaluationUnitEntity>()
        val groupList = mutableListOf<ProductGroupEntity>()
        val categoryList = mutableListOf<CategoryEntity>()
        val controlList = mutableListOf<ControlEntity>()

        for (i in 0 until units.length()) {
            val u = units.getJSONObject(i)
            val unitId = u.getString("id")

            unitList += EvaluationUnitEntity(
                id = unitId,
                templateId = u.optString("templateId", TEMPLATE_ID),
                name = u.getString("name"),
                kind = u.getString("kind"),
                scoringMode = u.getString("scoringMode"),
                sortOrder = u.getInt("sortOrder")
            )

            // المجموعات: مجموعات منتجات (الأقسام) أو ق1–ق4 (الخدمات). الإدارات المساعدة مفيهاش.
            val groups = u.optJSONArray("groups")
            if (groups != null) for (g in 0 until groups.length()) {
                groupList += ProductGroupEntity(
                    id = "${unitId}_g${g + 1}", unitId = unitId,
                    name = groups.getString(g), sortOrder = g
                )
            }

            val cats = u.getJSONArray("categories")
            for (c in 0 until cats.length()) {
                val o = cats.getJSONObject(c)
                categoryList += CategoryEntity(
                    id = o.getString("id"), unitId = unitId,
                    name = o.getString("name"), sortOrder = o.getInt("sort")
                )
            }

            val controls = u.getJSONArray("controls")
            for (k in 0 until controls.length()) {
                val o = controls.getJSONObject(k)
                controlList += ControlEntity(
                    id = o.getString("id"),
                    categoryId = o.getString("categoryId"),
                    text = o.getString("text"),
                    maxScore = o.getDouble("maxScore"),
                    penaltyPerViolation = o.getDouble("penaltyPerViolation"),
                    photoRequired = o.getBoolean("photoRequired"),
                    perGroup = o.getBoolean("perGroup"),
                    hint = if (o.isNull("hint")) null else o.getString("hint"),
                    sortOrder = o.getInt("no")
                )
            }
        }

        // الترتيب مهم بسبب الـ Foreign Keys: القالب → الوحدات → المجموعات/الكاتجري → الضوابط
        db.withTransaction {
            val templateList = mutableListOf(TemplateEntity(TEMPLATE_ID, "تقرير الجودة"))
            if (templates != null) for (ti in 0 until templates.length()) {
                val t = templates.getJSONObject(ti)
                templateList += TemplateEntity(t.getString("id"), t.getString("name"), t.optBoolean("isActive", true))
            }
            templateList += unitList.map { TemplateEntity(it.templateId, if (it.templateId == "zayed") "تقييم فرع زايد" else "تقرير الجودة") }.distinctBy { it.id }
            dao.upsertTemplates(templateList.distinctBy { it.id })
            dao.upsertUnits(unitList)
            dao.upsertGroups(groupList)
            dao.upsertCategories(categoryList)
            dao.upsertControls(controlList)
        }
        CensusDefaults.ensure(dao)
    }
}
