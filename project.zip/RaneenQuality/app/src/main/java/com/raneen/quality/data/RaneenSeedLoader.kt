package com.raneen.quality.data

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

// ───────────── الداتابيز ─────────────
// لو عندك @Database موجودة في المشروع: انقل الكيانات والـ DAOs لها بدل ما تعمل كلاس جديد.
@Database(
    entities = [
        TemplateEntity::class, EvaluationUnitEntity::class, ProductGroupEntity::class,
        CategoryEntity::class, ControlEntity::class, BranchEntity::class,
        InspectionEntity::class, InspectionUnitEntity::class, UserEntity::class,
        FindingEntity::class, PhotoEntity::class, AuditEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class RaneenDatabase : RoomDatabase() {
    abstract fun catalogDao(): CatalogDao
    abstract fun inspectionDao(): InspectionDao
    abstract fun userDao(): UserDao
}

// ───────────── تحميل الـ seed ─────────────
/**
 * بيقرا assets/raneen_seed.json ويملأ: templates / evaluation_units / product_groups /
 * categories / controls. بيشتغل مرة واحدة (لو جدول الضوابط فاضي).
 * الكل جوه transaction واحدة: يا كله يتكتب يا مفيش حاجة (مفيش seed نصّه).
 *
 * محتاج dependency:  androidx.room:room-ktx  (withTransaction)
 */
class SeedLoader(
    private val context: Context,
    private val db: RaneenDatabase
) {
    companion object {
        private const val ASSET = "raneen_seed.json"
        private const val TEMPLATE_ID = "main"   // قالب "تقرير الجودة" الأساسي
    }

    suspend fun seedIfEmpty() = withContext(Dispatchers.IO) {
        if (db.catalogDao().controlCount() > 0) return@withContext
        load()
    }

    /** استرجاع الكتالوج الأصلي: بيمسح الأقسام/الضوابط الحالية (بما فيها تعديلات الأدمن) ويحمّل الـ seed من الأول */
    suspend fun reseed() = withContext(Dispatchers.IO) {
        val dao = db.catalogDao()
        db.withTransaction {
            dao.wipeControls(); dao.wipeCategories(); dao.wipeGroups(); dao.wipeUnits(); dao.wipeTemplates()
        }
        load()
    }

    private suspend fun load() {
        val dao = db.catalogDao()

        val json = context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val units = JSONObject(json).getJSONArray("units")

        val unitList = mutableListOf<EvaluationUnitEntity>()
        val groupList = mutableListOf<ProductGroupEntity>()
        val categoryList = mutableListOf<CategoryEntity>()
        val controlList = mutableListOf<ControlEntity>()

        for (i in 0 until units.length()) {
            val u = units.getJSONObject(i)
            val unitId = u.getString("id")

            unitList += EvaluationUnitEntity(
                id = unitId,
                templateId = TEMPLATE_ID,
                name = u.getString("name"),
                kind = u.getString("kind"),
                scoringMode = u.getString("scoringMode"),
                sortOrder = u.getInt("sortOrder")
            )

            // المجموعات: مجموعات منتجات (الأقسام) أو ق1–ق4 (الخدمات). الإدارات المساعدة مفيهاش.
            val groups = u.optJSONArray("groups")
            if (groups != null) for (g in 0 until groups.length()) {
                groupList += ProductGroupEntity(
                    id = "${unitId}_g${g + 1}", unitId = unitId,
                    name = groups.getString(g), sortOrder = g
                )
            }

            val cats = u.getJSONArray("categories")
            for (c in 0 until cats.length()) {
                val o = cats.getJSONObject(c)
                categoryList += CategoryEntity(
                    id = o.getString("id"), unitId = unitId,
                    name = o.getString("name"), sortOrder = o.getInt("sort")
                )
            }

            val controls = u.getJSONArray("controls")
            for (k in 0 until controls.length()) {
                val o = controls.getJSONObject(k)
                controlList += ControlEntity(
                    id = o.getString("id"),
                    categoryId = o.getString("categoryId"),
                    text = o.getString("text"),
                    maxScore = o.getDouble("maxScore"),
                    penaltyPerViolation = o.getDouble("penaltyPerViolation"),
                    photoRequired = o.getBoolean("photoRequired"),
                    perGroup = o.getBoolean("perGroup"),
                    hint = if (o.isNull("hint")) null else o.getString("hint"),
                    sortOrder = o.getInt("no")
                )
            }
        }

        // الترتيب مهم بسبب الـ Foreign Keys: القالب → الوحدات → المجموعات/الكاتجري → الضوابط
        db.withTransaction {
            dao.upsertTemplates(listOf(TemplateEntity(TEMPLATE_ID, "تقرير الجودة")))
            dao.upsertUnits(unitList)
            dao.upsertGroups(groupList)
            dao.upsertCategories(categoryList)
            dao.upsertControls(controlList)
        }
    }
}
