package com.raneen.quality.data

import android.content.Context
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * اختيار صورة المخالفة من معرض الموبايل (بدل تصويرها تاني).
 * عشان مصداقية التقرير: الصورة بتتختم بنفس شريط البيانات + سطر "مصدر الصورة: من المعرض"،
 * والوقت المكتوب هو وقت الالتقاط الأصلي (من بيانات الصورة EXIF) مش وقت الاختيار.
 */
object GalleryImport {
    /** أقدم عمر مسموح لصورة من المعرض (24 ساعة). غيّر الرقم هنا لو السياسة اتغيّرت. */
    const val MAX_AGE_HOURS = 24
    const val MAX_AGE_MS = MAX_AGE_HOURS * 3_600_000L

    /** بينسخ الصورة المختارة لملف مؤقت ويقرا وقت التقاطها. الوقت null لو الصورة مفيهاش بيانات (سكرين شوت/واتساب...). */
    fun copyWithTakenTime(ctx: Context, uri: Uri): Pair<File, Long?>? = try {
        val dir = File(ctx.cacheDir, "cap").apply { mkdirs() }
        val f = File(dir, "gal_${System.currentTimeMillis()}.jpg")
        val copied = ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        if (copied == null || f.length() == 0L) { f.delete(); null }
        else {
            val ex = ExifInterface(f.path)
            val s = ex.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: ex.getAttribute(ExifInterface.TAG_DATETIME)
            val t = s?.let { try { SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(it)?.time } catch (e: Exception) { null } }
            f to t
        }
    } catch (e: Exception) { null }
}
