package com.raneen.quality.data

import android.content.Context
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * اختيار صورة المخالفة من معرض الموبايل (بدل تصويرها تاني).
 * عشان مصداقية التقرير: الصورة بتتختم بنفس شريط البيانات + سطر "مصدر الصورة: من المعرض"،
 * والوقت المكتوب هو وقت الالتقاط الأصلي (من بيانات الصورة EXIF) مش وقت الاختيار.
 */
object GalleryImport {
    /** أقدم عمر مسموح لصورة من المعرض (24 ساعة). غيّر الرقم هنا لو السياسة اتغيّرت. */
    const val MAX_AGE_HOURS = 24
    const val MAX_AGE_MS = MAX_AGE_HOURS * 3_600_000L

    private fun mediaStoreTaken(ctx: Context, uri: Uri): Long? = try {
        ctx.contentResolver.query(uri, arrayOf(android.provider.MediaStore.Images.Media.DATE_TAKEN), null, null, null)?.use { c ->
            val i = c.getColumnIndex(android.provider.MediaStore.Images.Media.DATE_TAKEN)
            if (c.moveToFirst() && i >= 0 && !c.isNull(i)) c.getLong(i).takeIf { it > 0 } else null
        }
    } catch (e: Exception) { null }

    /** بينسخ الصورة المختارة لملف مؤقت ويقرا وقت التقاطها. الوقت null لو الصورة مفيهاش بيانات (سكرين شوت/واتساب...). */
    fun copyWithTakenTime(ctx: Context, uri: Uri): Pair<File, Long?>? = try {
        val dir = File(ctx.cacheDir, "cap").apply { mkdirs() }
        val f = File(dir, "gal_${System.currentTimeMillis()}.jpg")
        val copied = ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        if (copied == null || f.length() == 0L) { f.delete(); null }
        else {
            val ex = ExifInterface(f.path)
            val s = ex.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                ?: ex.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED)
                ?: ex.getAttribute(ExifInterface.TAG_DATETIME)
            val exifTime = s?.let { try { SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(it)?.time } catch (e: Exception) { null } }
            // لو الصورة من غير EXIF (بعض أجهزة/معارض الموبايل بتشيله) بنقرا وقت الالتقاط اللي سجّله الموبايل نفسه
            // نختار أحدث وقت التقاط من المصدرين (EXIF ووقت التقاط الموبايل)، عشان صورة لسه متصوّرة ما تترفضش بسبب EXIF قديم أو ناقص
            f to listOfNotNull(exifTime, mediaStoreTaken(ctx, uri)).maxOrNull()
        }
    } catch (e: Exception) { null }
}
