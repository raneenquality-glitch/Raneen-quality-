package com.raneen.quality.data

import androidx.room.*
import com.raneen.quality.domain.ControlDef
import com.raneen.quality.domain.FindingIn
import kotlinx.coroutines.flow.Flow

@Dao
interface InspectionDao {

    // ───────── ضغطة X ─────────
    // خطوتين داخل transaction: نضمن وجود الصف، وبعدين نزوّد العداد ذريًا (آمن مع الأوفلاين).

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFindingIfMissing(f: FindingEntity): Long

    @Query(
        """UPDATE findings SET violationCount = violationCount + 1
           WHERE inspectionId = :inspectionId AND unitId = :unitId
             AND controlId = :controlId AND groupId = :groupId"""
    )
    suspend fun incrementViolation(inspectionId: String, unitId: String, controlId: String, groupId: String)

    /** ضغطة "تراجع": العداد مايقلش عن صفر */
    @Query(
        """UPDATE findings SET violationCount = MAX(violationCount - 1, 0)
           WHERE inspectionId = :inspectionId AND unitId = :unitId
             AND controlId = :controlId AND groupId = :groupId"""
    )
    suspend fun decrementViolation(inspectionId: String, unitId: String, controlId: String, groupId: String)

    @Transaction
    suspend fun tapX(inspectionId: String, unitId: String, controlId: String, groupId: String, newId: String) {
        insertFindingIfMissing(FindingEntity(newId, inspectionId, unitId, controlId, groupId, 0))
        incrementViolation(inspectionId, unitId, controlId, groupId)
    }

    // ───────── مدخلات دالة الحساب ─────────

    /** ضوابط القسم الفعّالة → ControlDef (بيدخل مباشرة في scoreUnit) */
    @Query(
        """SELECT c.id AS id, c.categoryId AS categoryId, c.maxScore AS maxScore,
                  c.penaltyPerViolation AS penaltyPerViolation
           FROM controls c JOIN categories g ON g.id = c.categoryId
           WHERE g.unitId = :unitId AND c.isActive = 1 AND g.isActive = 1"""
    )
    suspend fun controlDefs(unitId: String): List<ControlDef>

    @Query(
        """SELECT controlId, groupId, violationCount AS violations FROM findings
           WHERE inspectionId = :inspectionId AND unitId = :unitId"""
    )
    suspend fun findingsFor(inspectionId: String, unitId: String): List<FindingIn>

    // ───────── واجهة المستخدم (Flow للتحديث اللحظي) ─────────

    @Query("SELECT * FROM findings WHERE inspectionId = :inspectionId AND unitId = :unitId")
    fun observeFindings(inspectionId: String, unitId: String): Flow<List<FindingEntity>>

    @Query("SELECT * FROM inspection_units WHERE inspectionId = :inspectionId")
    fun observeUnitStates(inspectionId: String): Flow<List<InspectionUnitEntity>>

    @Upsert
    suspend fun upsertUnitState(s: InspectionUnitEntity)

    @Insert
    suspend fun insertInspection(i: InspectionEntity)

    @Insert
    suspend fun insertPhoto(p: PhotoEntity)

    // ───────── الصور ─────────
    @Query("SELECT id FROM findings WHERE inspectionId = :i AND unitId = :u AND controlId = :c AND groupId = :g LIMIT 1")
    suspend fun findingId(i: String, u: String, c: String, g: String): String?

    @Query("SELECT * FROM photos WHERE findingId = :findingId")
    suspend fun photosOfFinding(findingId: String): List<PhotoEntity>

    @Query("DELETE FROM photos WHERE id = :id")
    suspend fun deletePhotoRow(id: String)

    @Query("SELECT p.* FROM photos p JOIN findings f ON f.id = p.findingId WHERE f.inspectionId = :i AND f.unitId = :u ORDER BY p.capturedAt")
    fun observeUnitPhotos(i: String, u: String): Flow<List<PhotoEntity>>

    @Query("SELECT p.* FROM photos p JOIN findings f ON f.id = p.findingId WHERE f.inspectionId = :i ORDER BY p.capturedAt")
    suspend fun photosOfInspection(i: String): List<PhotoEntity>

    @Query("SELECT * FROM findings WHERE inspectionId = :i")
    fun observeAllFindings(i: String): Flow<List<FindingEntity>>

    // ───────── الزيارات والتقارير ─────────
    @Query("SELECT * FROM inspections WHERE id = :id")
    suspend fun inspection(id: String): InspectionEntity?

    @Query("SELECT * FROM inspections WHERE id = :id")
    fun observeInspection(id: String): Flow<InspectionEntity?>

    @Query("UPDATE inspections SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("DELETE FROM inspections WHERE id = :id")
    suspend fun deleteInspection(id: String)

    @Query("DELETE FROM audit_log WHERE inspectionId = :id")
    suspend fun deleteAudit(id: String)

    @Insert
    suspend fun insertAudit(a: AuditEntity)

    @Query("SELECT * FROM audit_log WHERE inspectionId = :id ORDER BY at")
    fun observeAudit(id: String): Flow<List<AuditEntity>>

    @Query("SELECT * FROM inspection_units WHERE inspectionId = :id")
    suspend fun unitStates(id: String): List<InspectionUnitEntity>

    @Query("SELECT name FROM branches WHERE id = :id")
    suspend fun branchName(id: String): String?

    @Query("SELECT name FROM users WHERE id = :id")
    suspend fun userName(id: String): String?

    @Query("SELECT * FROM evaluation_units WHERE isActive = 1 ORDER BY sortOrder")
    suspend fun activeUnits(): List<EvaluationUnitEntity>

    @Query("""SELECT f.id AS findingId, f.unitId AS unitId, u.name AS unitName, c.id AS controlId,
                     c.sortOrder AS controlNo, c.text AS controlText, g.name AS categoryName,
                     pg.name AS groupName, f.violationCount AS cnt, c.photoRequired AS photoRequired
              FROM findings f
              JOIN controls c ON c.id = f.controlId
              JOIN categories g ON g.id = c.categoryId
              JOIN evaluation_units u ON u.id = f.unitId
              LEFT JOIN product_groups pg ON pg.id = f.groupId
              WHERE f.inspectionId = :i AND f.violationCount > 0 AND c.maxScore > 0
              ORDER BY u.sortOrder, g.sortOrder, c.sortOrder""")
    suspend fun violations(i: String): List<ViolationRow>

    @Query("""SELECT i.id AS id, i.reportNumber AS reportNumber, COALESCE(b.name, '') AS branchName,
                     COALESCE(u.name, '') AS inspectorName, i.visitDate AS visitDate, i.status AS status,
                     i.syncState AS syncState, i.inspectorId AS inspectorId, i.visitNumber AS visitNumber
              FROM inspections i
              LEFT JOIN branches b ON b.id = i.branchId
              LEFT JOIN users u ON u.id = i.inspectorId
              ORDER BY i.visitDate DESC""")
    fun observeReportRows(): Flow<List<ReportRow>>

    // ───────── المزامنة ─────────
    @Query("SELECT * FROM inspections WHERE syncState = 'PENDING'")
    suspend fun pendingInspections(): List<InspectionEntity>

    @Query("UPDATE inspections SET syncState = :s WHERE id = :id")
    suspend fun setSync(id: String, s: String)

    @Query("SELECT * FROM findings WHERE inspectionId = :i")
    suspend fun findingsOf(i: String): List<FindingEntity>

    @Query("UPDATE photos SET syncState = :s WHERE id = :id")
    suspend fun setPhotoSync(id: String, s: String)

    @Query("""SELECT p.id AS photoId, p.filePath AS filePath, f.inspectionId AS inspectionId, i.inspectorId AS inspectorId
              FROM photos p JOIN findings f ON f.id = p.findingId JOIN inspections i ON i.id = f.inspectionId
              WHERE p.syncState = 'REMOTE' AND p.filePath NOT LIKE '%.mp4' LIMIT 20""")
    suspend fun remotePhotos(): List<RemotePhoto>

    @Query("SELECT COUNT(*) FROM audit_log WHERE inspectionId = :id")
    suspend fun auditCount(id: String): Int

    @Upsert suspend fun upsertInspection(i: InspectionEntity)
    @Upsert suspend fun upsertUnitStates(list: List<InspectionUnitEntity>)
    @Upsert suspend fun upsertFindings(list: List<FindingEntity>)
    @Upsert suspend fun upsertPhotos(list: List<PhotoEntity>)
    @Upsert suspend fun upsertAudits(list: List<AuditEntity>)

    // ───────── حذف الصور + التنبيهات ─────────
    @Query("""SELECT p.id AS photoId, p.filePath AS filePath, f.inspectionId AS inspectionId, i.inspectorId AS inspectorId
              FROM photos p JOIN findings f ON f.id = p.findingId JOIN inspections i ON i.id = f.inspectionId
              WHERE p.capturedAt < :cutoff AND p.syncState != 'PURGED' AND i.inspectorId != :me
                AND i.status NOT IN ('DRAFT', 'RETURNED') AND i.syncState != 'PENDING' LIMIT 200""")
    suspend fun expiredPhotos(cutoff: Long, me: String): List<RemotePhoto>

    @Query("UPDATE photos SET syncState = 'PURGED' WHERE syncState = 'REMOTE' AND findingId IN (SELECT id FROM findings WHERE inspectionId = :id)")
    suspend fun markRemoteGone(id: String)

    @Query("SELECT id, reportNumber, inspectorId FROM inspections WHERE status = :status")
    suspend fun refsByStatus(status: String): List<InspRef>

    @Query("SELECT id, reportNumber, inspectorId FROM inspections WHERE status = 'RETURNED' AND inspectorId = :me")
    suspend fun returnedFor(me: String): List<InspRef>

    // ───────── ضوابط الحصر (أعداد من غير درجة) ─────────
    @Query("UPDATE findings SET violationCount = :n WHERE id = :id")
    suspend fun setCount(id: String, n: Int)

    @Query("""SELECT f.unitId AS unitId, u.name AS unitName, g.name AS categoryName, c.id AS controlId,
                     c.text AS controlText, c.sortOrder AS controlNo, f.violationCount AS cnt
              FROM findings f
              JOIN controls c ON c.id = f.controlId
              JOIN categories g ON g.id = c.categoryId
              JOIN evaluation_units u ON u.id = f.unitId
              LEFT JOIN product_groups pg ON pg.id = f.groupId
              WHERE f.inspectionId = :i AND f.violationCount > 0 AND c.maxScore <= 0
              ORDER BY u.sortOrder, g.sortOrder, c.sortOrder, pg.sortOrder""")
    suspend fun censusRows(i: String): List<CensusRowData>
}

data class ViolationRow(
    val findingId: String, val unitId: String, val unitName: String,
    val controlId: String, val controlNo: Int, val controlText: String,
    val categoryName: String, val groupName: String?, val cnt: Int, val photoRequired: Boolean
)

data class CensusRowData(
    val unitId: String, val unitName: String, val categoryName: String,
    val controlId: String, val controlText: String, val controlNo: Int, val cnt: Int
)

data class InspRef(val id: String, val reportNumber: String, val inspectorId: String)

data class RemotePhoto(val photoId: String, val filePath: String, val inspectionId: String, val inspectorId: String)

data class ReportRow(
    val id: String, val reportNumber: String, val branchName: String, val inspectorName: String,
    val visitDate: Long, val status: String, val syncState: String, val inspectorId: String,
    val visitNumber: String? = null
)


@Dao
interface CatalogDao {
    @Upsert suspend fun upsertTemplates(list: List<TemplateEntity>)
    @Upsert suspend fun upsertUnits(list: List<EvaluationUnitEntity>)
    @Upsert suspend fun upsertGroups(list: List<ProductGroupEntity>)
    @Upsert suspend fun upsertCategories(list: List<CategoryEntity>)
    @Upsert suspend fun upsertControls(list: List<ControlEntity>)

    @Query("SELECT * FROM evaluation_units WHERE isActive = 1 ORDER BY sortOrder")
    fun observeUnits(): Flow<List<EvaluationUnitEntity>>

    @Query("SELECT * FROM product_groups WHERE unitId = :unitId AND isActive = 1 ORDER BY sortOrder")
    suspend fun groups(unitId: String): List<ProductGroupEntity>

    @Query("SELECT * FROM categories WHERE unitId = :unitId AND isActive = 1 ORDER BY sortOrder")
    suspend fun categories(unitId: String): List<CategoryEntity>

    @Query("""SELECT c.* FROM controls c JOIN categories g ON g.id = c.categoryId
           WHERE g.unitId = :unitId AND c.isActive = 1 ORDER BY g.sortOrder, c.sortOrder""")
    suspend fun controls(unitId: String): List<ControlEntity>

    @Query("SELECT * FROM branches WHERE isActive = 1 ORDER BY name")
    fun observeBranches(): Flow<List<BranchEntity>>

    @Upsert suspend fun upsertBranches(list: List<BranchEntity>)

    @Query("SELECT COUNT(*) FROM branches")
    suspend fun branchCount(): Int

    @Query("SELECT COUNT(*) FROM controls")
    suspend fun controlCount(): Int

    // ───────── إدارة الكتالوج (الأدمن) ─────────
    @Query("SELECT * FROM evaluation_units WHERE id = :id")
    fun observeUnit(id: String): Flow<EvaluationUnitEntity?>

    @Query("SELECT * FROM product_groups WHERE unitId = :u AND isActive = 1 ORDER BY sortOrder")
    fun observeGroups(u: String): Flow<List<ProductGroupEntity>>

    @Query("SELECT * FROM categories WHERE unitId = :u AND isActive = 1 ORDER BY sortOrder")
    fun observeCategories(u: String): Flow<List<CategoryEntity>>

    @Query("""SELECT c.* FROM controls c JOIN categories g ON g.id = c.categoryId
              WHERE g.unitId = :u AND c.isActive = 1 AND g.isActive = 1 ORDER BY g.sortOrder, c.sortOrder""")
    fun observeControls(u: String): Flow<List<ControlEntity>>

    @Query("""SELECT SUM(c.maxScore) FROM controls c JOIN categories g ON g.id = c.categoryId
              WHERE g.unitId = :u AND c.isActive = 1 AND g.isActive = 1""")
    fun observeWeightSum(u: String): Flow<Double?>

    @Query("SELECT * FROM branches ORDER BY name")
    fun observeAllBranches(): Flow<List<BranchEntity>>

    @Query("SELECT COUNT(*) FROM inspections WHERE branchId = :id")
    suspend fun inspectionsOfBranch(id: String): Int

    @Query("SELECT COUNT(*) FROM branches WHERE code = :code AND id != :id")
    suspend fun codeTaken(code: String, id: String): Int

    @Query("DELETE FROM branches WHERE id = :id")
    suspend fun deleteBranch(id: String)

    @Query("UPDATE controls SET isActive = 0 WHERE id = :id") suspend fun hideControl(id: String)
    @Query("UPDATE controls SET isActive = 0 WHERE categoryId = :id") suspend fun hideControlsOfCategory(id: String)
    @Query("UPDATE categories SET isActive = 0 WHERE id = :id") suspend fun hideCategory(id: String)
    @Query("UPDATE product_groups SET isActive = 0 WHERE id = :id") suspend fun hideGroup(id: String)
    @Query("UPDATE controls SET isActive = 0 WHERE categoryId IN (SELECT id FROM categories WHERE unitId = :id)")
    suspend fun hideControlsOfUnit(id: String)
    @Query("UPDATE categories SET isActive = 0 WHERE unitId = :id") suspend fun hideCategoriesOfUnit(id: String)
    @Query("UPDATE product_groups SET isActive = 0 WHERE unitId = :id") suspend fun hideGroupsOfUnit(id: String)
    @Query("UPDATE evaluation_units SET isActive = 0 WHERE id = :id") suspend fun hideUnit(id: String)

    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM controls WHERE categoryId IN (SELECT id FROM categories WHERE unitId = :u)")
    suspend fun maxControlNo(u: String): Int
    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM categories WHERE unitId = :u") suspend fun maxCategorySort(u: String): Int
    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM product_groups WHERE unitId = :u") suspend fun maxGroupSort(u: String): Int
    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM evaluation_units") suspend fun maxUnitSort(): Int

    @Query("DELETE FROM controls") suspend fun wipeControls()
    @Query("DELETE FROM categories") suspend fun wipeCategories()
    @Query("DELETE FROM product_groups") suspend fun wipeGroups()
    @Query("DELETE FROM evaluation_units") suspend fun wipeUnits()
    @Query("DELETE FROM templates") suspend fun wipeTemplates()

    // ───────── للمزامنة (بتشمل المخفي كمان) ─────────
    @Query("SELECT * FROM evaluation_units") suspend fun allUnits(): List<EvaluationUnitEntity>
    @Query("SELECT * FROM product_groups") suspend fun allGroups(): List<ProductGroupEntity>
    @Query("SELECT * FROM categories") suspend fun allCategories(): List<CategoryEntity>
    @Query("SELECT * FROM controls") suspend fun allControls(): List<ControlEntity>
    @Query("SELECT * FROM branches") suspend fun allBranches(): List<BranchEntity>
    @Query("DELETE FROM branches") suspend fun wipeBranches()
}
