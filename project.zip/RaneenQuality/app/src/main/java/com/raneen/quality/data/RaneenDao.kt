package com.raneen.quality.data

import androidx.room.*
import com.raneen.quality.domain.ControlDef
import com.raneen.quality.domain.FindingIn
import kotlinx.coroutines.flow.Flow

@Dao
interface InspectionDao {

    // ───────── ضغطة X ─────────
    // خطوتين داخل transaction: نضمن وجود الصف، وبعدين نزوّد العداد ذريًا (آمن مع الأوفلاين).

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertFindingIfMissing(f: FindingEntity): Long

    @Query(
        """UPDATE findings SET violationCount = violationCount + 1
           WHERE inspectionId = :inspectionId AND unitId = :unitId
             AND controlId = :controlId AND groupId = :groupId"""
    )
    suspend fun incrementViolation(inspectionId: String, unitId: String, controlId: String, groupId: String)

    /** ضغطة "تراجع": العداد مايقلش عن صفر */
    @Query(
        """UPDATE findings SET violationCount = MAX(violationCount - 1, 0)
           WHERE inspectionId = :inspectionId AND unitId = :unitId
             AND controlId = :controlId AND groupId = :groupId"""
    )
    suspend fun decrementViolation(inspectionId: String, unitId: String, controlId: String, groupId: String)

    @Transaction
    suspend fun tapX(inspectionId: String, unitId: String, controlId: String, groupId: String, newId: String) {
        insertFindingIfMissing(FindingEntity(newId, inspectionId, unitId, controlId, groupId, 0))
        incrementViolation(inspectionId, unitId, controlId, groupId)
    }

    // ───────── مدخلات دالة الحساب ─────────

    /** ضوابط القسم الفعّالة → ControlDef (بيدخل مباشرة في scoreUnit) */
    @Query(
        """SELECT c.id AS id, c.categoryId AS categoryId, c.maxScore AS maxScore,
                  c.penaltyPerViolation AS penaltyPerViolation
           FROM controls c JOIN categories g ON g.id = c.categoryId
           WHERE g.unitId = :unitId AND c.isActive = 1 AND g.isActive = 1"""
    )
    suspend fun controlDefs(unitId: String): List<ControlDef>

    @Query(
        """SELECT controlId, groupId, violationCount AS violations FROM findings
           WHERE inspectionId = :inspectionId AND unitId = :unitId"""
    )
    suspend fun findingsFor(inspectionId: String, unitId: String): List<FindingIn>

    // ───────── واجهة المستخدم (Flow للتحديث اللحظي) ─────────

    @Query("SELECT * FROM findings WHERE inspectionId = :inspectionId AND unitId = :unitId")
    fun observeFindings(inspectionId: String, unitId: String): Flow<List<FindingEntity>>

    @Query("SELECT * FROM inspection_units WHERE inspectionId = :inspectionId")
    fun observeUnitStates(inspectionId: String): Flow<List<InspectionUnitEntity>>

    @Upsert
    suspend fun upsertUnitState(s: InspectionUnitEntity)

    @Insert
    suspend fun insertInspection(i: InspectionEntity)

    @Insert
    suspend fun insertPhoto(p: PhotoEntity)
}

@Dao
interface CatalogDao {
    @Upsert suspend fun upsertTemplates(list: List<TemplateEntity>)
    @Upsert suspend fun upsertUnits(list: List<EvaluationUnitEntity>)
    @Upsert suspend fun upsertGroups(list: List<ProductGroupEntity>)
    @Upsert suspend fun upsertCategories(list: List<CategoryEntity>)
    @Upsert suspend fun upsertControls(list: List<ControlEntity>)

    @Query("SELECT * FROM evaluation_units WHERE isActive = 1 ORDER BY sortOrder")
    fun observeUnits(): Flow<List<EvaluationUnitEntity>>

    @Query("SELECT * FROM product_groups WHERE unitId = :unitId AND isActive = 1 ORDER BY sortOrder")
    suspend fun groups(unitId: String): List<ProductGroupEntity>

    @Query("SELECT * FROM categories WHERE unitId = :unitId AND isActive = 1 ORDER BY sortOrder")
    suspend fun categories(unitId: String): List<CategoryEntity>

    @Query("""SELECT c.* FROM controls c JOIN categories g ON g.id = c.categoryId
           WHERE g.unitId = :unitId AND c.isActive = 1 ORDER BY g.sortOrder, c.sortOrder""")
    suspend fun controls(unitId: String): List<ControlEntity>

    @Query("SELECT * FROM branches WHERE isActive = 1 ORDER BY name")
    fun observeBranches(): Flow<List<BranchEntity>>

    @Upsert suspend fun upsertBranches(list: List<BranchEntity>)

    @Query("SELECT COUNT(*) FROM branches")
    suspend fun branchCount(): Int

    @Query("SELECT COUNT(*) FROM controls")
    suspend fun controlCount(): Int
}
