package com.raneen.quality.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

/** ألوان الحالات في مكان واحد (نفس القيم اللي كانت متكررة في أكتر من ملف). */
object RaneenColors {
    val Ok = Color(0xFF1D7A4D)
    val OkSoft = Color(0xFFE3F4EA)
    val Warn = Color(0xFFEF6C00)
    val WarnSoft = Color(0xFFFFF3E0)
    val Danger = Color(0xFFC62828)
    val DangerSoft = Color(0xFFFFEBEE)
    val Neutral = Color(0xFF757575)
    val Slate = Color(0xFF455A64)
}

/** حالة فاضية موحدة: أيقونة + جملة. */
@Composable
fun EmptyState(text: String, icon: String = "🗂️", modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(icon, style = MaterialTheme.typography.displaySmall)
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
    }
}

/** تحميل موحد: مؤشر بحجم واحد + جملة اختيارية. */
@Composable
fun LoadingState(text: String = "", modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        CircularProgressIndicator(Modifier.size(28.dp))
        if (text.isNotBlank()) Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

/** خطأ موحد: جملة + زرار إعادة المحاولة. */
@Composable
fun ErrorState(text: String, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("⚠️", style = MaterialTheme.typography.headlineMedium)
        Text(text, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        if (onRetry != null) OutlinedButton(onClick = onRetry) { Text("إعادة المحاولة") }
    }
}
