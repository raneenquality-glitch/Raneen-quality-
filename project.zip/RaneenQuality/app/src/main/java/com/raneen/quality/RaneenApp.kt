package com.raneen.quality

import android.app.Application
import androidx.room.Room
import com.raneen.quality.data.MIGRATION_3_4
import com.raneen.quality.data.MIGRATION_4_5
import com.raneen.quality.data.RaneenDatabase

class RaneenApp : Application() {
    override fun onCreate() { super.onCreate(); com.raneen.quality.data.SeatStore.init(this) }

    // داتابيز واحدة للتطبيق كله.
    // قاعدة مهمة: أي مرة نرفع فيها version في RaneenDatabase لازم نضيف Migration (من الإصدار القديم للجديد) هنا.
    // مفيش مسح تلقائي بعد كده — لو نسيت، التطبيق هيقف عند الفتح على جهازك أنت الأول (وده أحسن من إن مراقب يخسر مسودات).
    val db: RaneenDatabase by lazy {
        Room.databaseBuilder(this, RaneenDatabase::class.java, "raneen.db")
            .addMigrations(MIGRATION_3_4, MIGRATION_4_5) // يحافظ على الزيارات ويضيف ملاحظات المخالفات
            .fallbackToDestructiveMigrationFrom(1, 2)   // نسخ قديمة جدًا قبل الإطلاق بس
            .build()
    }
}
