package com.raneen.quality

import android.app.Application
import androidx.room.Room
import com.raneen.quality.data.MIGRATION_3_4
import com.raneen.quality.data.MIGRATION_4_5
import com.raneen.quality.data.RaneenDatabase

class RaneenApp : Application() {
    // داتابيز واحدة للتطبيق كله. destructive migration مؤقتًا أثناء التطوير (قبل الإصدار لازم Migration حقيقي)
    val db: RaneenDatabase by lazy {
        Room.databaseBuilder(this, RaneenDatabase::class.java, "raneen.db")
            .addMigrations(MIGRATION_3_4, MIGRATION_4_5) // يحافظ على الزيارات ويضيف ملاحظات المخالفات
            .fallbackToDestructiveMigration()
            .build()
    }
}
