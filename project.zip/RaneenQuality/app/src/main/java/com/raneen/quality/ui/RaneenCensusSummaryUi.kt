package com.raneen.quality.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.*
import java.util.Locale

private fun money(v: Double) = String.format(Locale.US, "%.2f", v)

/** أيقونة الحصر المجمّع: بتفتح جداول الحصر اللي اتجمعت تلقائيًا من المخالفات. */
@Composable
fun CensusSummaryCard(summary: CensusSummary, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Card(modifier.fillMaxWidth().clickable { open = true }, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Text("📊", style = MaterialTheme.typography.titleLarge)
            }
            Column(Modifier.weight(1f)) {
                Text("الحصر المجمّع", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(
                    "مخالفات الأسعار (${summary.priceTotal}) · أدوات العرض (${summary.displayTotalCount})" +
                        (if (summary.maintenance.isNotEmpty()) " · الصيانة والتكييفات" else ""),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text("بيتجمع تلقائي من المخالفات ويظهر في آخر التقرير", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text("الحصر المجمّع") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { CensusSummaryBody(summary) } },
        confirmButton = { TextButton(onClick = { open = false }) { Text("إغلاق") } }
    )
}

@Composable
fun CensusSummaryBody(summary: CensusSummary) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // ── حصر مخالفات الأسعار
        Text("أعداد مخالفات الأسعار", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        var last = ""
        summary.price.forEach { r ->
            TRow(listOf(if (r.group != last) r.group else "", r.label, r.valueText), listOf(1.2f, 1.6f, 1f), bold = false)
            last = r.group
        }
        TRow(listOf("الإجمالي", "", summary.priceTotal.toString()), listOf(1.2f, 1.6f, 1f), bold = true, bg = Color(0xFFFFF59D))
        HorizontalDivider()
        // ── حصر أدوات العرض
        Text("أعداد مخالفات أدوات العرض ووسائل العرض", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        TRow(listOf("النوع", "العدد", "قيمة القطعة", "الإجمالي"), listOf(1.6f, 0.8f, 1f, 1f), bold = true, bg = MaterialTheme.colorScheme.surfaceVariant)
        summary.display.forEach { d -> TRow(listOf(d.label, d.count.toString(), money(d.pieceValue), money(d.total)), listOf(1.6f, 0.8f, 1f, 1f)) }
        TRow(listOf("الإجمالي", summary.displayTotalCount.toString(), "", money(summary.displayTotalValue)), listOf(1.6f, 0.8f, 1f, 1f), bold = true, bg = Color(0xFFFFF59D))
        // ── حصر الصيانة / التكييفات
        summary.maintenance.forEach { b ->
            HorizontalDivider()
            Text("${b.title} — ${b.unitName}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text("عدد البنود: ${b.rows.size} · المخالفة: ${b.violated}", style = MaterialTheme.typography.bodySmall)
            if (b.shown.isEmpty()) Text("مفيش بنود مخالفة.", style = MaterialTheme.typography.bodySmall)
            b.shown.forEach { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(r.item, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                        Text("الحالة: ${r.state} · ${r.status} · ${r.escalation}", style = MaterialTheme.typography.bodySmall)
                        if (r.problem.isNotBlank()) Text("المشكلة: ${r.problem}", style = MaterialTheme.typography.bodySmall)
                        val extra = listOfNotNull(r.count.takeIf { it > 0 }?.let { "العدد: $it" }, r.faultDate.takeIf { it.isNotBlank() }?.let { "تاريخ العطل: $it" }, r.ticket.takeIf { it.isNotBlank() }?.let { "تيكت: $it" })
                        if (extra.isNotEmpty()) Text(extra.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TRow(cells: List<String>, weights: List<Float>, bold: Boolean = false, bg: Color = Color.Transparent) {
    Row(Modifier.fillMaxWidth().background(bg, RoundedCornerShape(6.dp)).padding(vertical = 5.dp, horizontal = 6.dp)) {
        cells.forEachIndexed { i, t ->
            Text(
                t, modifier = Modifier.weight(weights[i]), fontWeight = if (bold || i == 0) FontWeight.Bold else FontWeight.Normal,
                style = MaterialTheme.typography.bodyMedium, textAlign = if (i == 0) TextAlign.Start else TextAlign.Center
            )
        }
    }
}
