package com.raneen.quality.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/**
 * بيحرق شريط البيانات (الفرع / القسم / التاريخ والوقت / المراقب) جوه الفيديو نفسه (إعادة ترميز).
 * لو فشل، المستدعي بيحتفظ بالفيديو الأصلي من غير شريط.
 */
@OptIn(UnstableApi::class)
object VideoStamper {
    /** آخر سبب فشل (للتشخيص بيظهر في رسالة الخطأ) */
    @Volatile var lastError: String? = null


    private fun frameSize(f: File): Pair<Int, Int>? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            w to h
        } catch (e: Exception) {
            null
        } finally {
            r.release()
        }
    }

    /** صورة شفافة بحجم إطار الفيديو بالظبط، والشريط مرسوم في آخرها */
    private fun overlayBitmap(w: Int, h: Int, lines: List<String>): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val pad = w * 0.025f
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = maxOf(minOf(w, h) / 22f, 14f)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tw = (w - 2 * pad).toInt()
        val layouts = lines.map {
            StaticLayout.Builder.obtain(it, 0, it.length, paint, tw)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL).build()
        }
        val total = layouts.sumOf { it.height }.toFloat() + pad * 2
        canvas.drawRect(0f, h - total, w.toFloat(), h.toFloat(), Paint().apply { color = Color.argb(179, 0, 0, 0) })
        var y = h - total + pad
        for (l in layouts) {
            canvas.save(); canvas.translate(pad, y); l.draw(canvas); canvas.restore()
            y += l.height
        }
        return bmp
    }

    suspend fun stamp(ctx: Context, raw: File, out: File, lines: List<String>): Boolean = withContext(Dispatchers.Main) {
        try {
            lastError = null
            val (w, h) = frameSize(raw) ?: run { lastError = "FRAME_SIZE_UNKNOWN"; return@withContext false }
            if (w.toLong() * h > 3840L * 2160L) { lastError = "VIDEO_TOO_LARGE"; return@withContext false }
            val overlay = BitmapOverlay.createStaticBitmapOverlay(overlayBitmap(w, h, lines))
            val effects = Effects(emptyList(), listOf<Effect>(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))))
            val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(raw))).setEffects(effects).build()
            out.parentFile?.mkdirs()
            suspendCancellableCoroutine<Boolean> { cont ->
                val encoder = DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(2_000_000).build())
                    .build()
                val t = Transformer.Builder(ctx)
                    .setEncoderFactory(encoder)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(true)
                        }
                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            lastError = exportException.errorCodeName + (exportException.message?.let { ": " + it.take(60) } ?: "")
                            if (cont.isActive) cont.resume(false)
                        }
                    })
                    .build()
                cont.invokeOnCancellation { t.cancel() }
                t.start(item, out.absolutePath)
            }
        } catch (e: Throwable) {
            lastError = e.javaClass.simpleName + (e.message?.let { ": " + it.take(60) } ?: "")
            false
        }
    }
}
