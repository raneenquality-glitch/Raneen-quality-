package com.raneen.quality.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import android.view.WindowManager
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream

/** هل الملف فيديو سليم قابل للتشغيل (له مدة)؟ بنستخدمه بس لو التسجيل خلص بخطأ قابل للاسترداد */
private fun isPlayableVideo(file: File): Boolean = try {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(file.path)
        (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) > 0L
    } finally { r.release() }
} catch (_: Exception) { false }

private val PauseAmber = Color(0xFFFFB300)

private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

/**
 * تسجيل فيديو من جوه التطبيق بمدة مفتوحة. وإنت بتصوّر تقدر تلتقط صور بزرار 📷،
 * والصور بتتحط على نفس المخالفة بنفس شريط البيانات.
 */
@Composable
fun VideoRecorderDialog(onFinished: (videoPath: String, snapshots: List<String>, customText: String) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    var hasCam by remember { mutableStateOf(granted(context, Manifest.permission.CAMERA)) }
    var hasAudio by remember { mutableStateOf(granted(context, Manifest.permission.RECORD_AUDIO)) }
    var asked by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasCam = granted(context, Manifest.permission.CAMERA)
        hasAudio = granted(context, Manifest.permission.RECORD_AUDIO)
        asked = true
    }
    LaunchedEffect(Unit) {
        if (!hasCam || !hasAudio) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) else asked = true
    }
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)
    ) {
        val hostView = LocalView.current
        DisposableEffect(hostView) {
            val window = (hostView.parent as? DialogWindowProvider)?.window
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        }
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            when {
                hasCam -> RecorderContent(withAudio = hasAudio, onFinished = onFinished, onCancel = onCancel)
                asked -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("محتاج إذن الكاميرا عشان تصوّر فيديو. فعّله من إعدادات التطبيق.", color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onCancel) { Text("رجوع") }
                }
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
        }
    }
}

@Composable
private fun RecorderContent(withAudio: Boolean, onFinished: (String, List<String>, String) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE   // عشان لقطة الصورة أثناء التسجيل تشتغل على كل الأجهزة
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var selectedQuality by remember { mutableStateOf(Quality.HD) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var flashOn by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var maxZoomRatio by remember { mutableFloatStateOf(1f) }
    var rec by remember { mutableStateOf<Recording?>(null) }
    var paused by remember { mutableStateOf(false) }               // التسجيل متوقف مؤقتًا (نفس الملف لسه مفتوح)
    var transitioning by remember { mutableStateOf(false) }        // أمر إيقاف مؤقت/استئناف اتبعت ولسه ما اتأكدش
    var elapsedBeforeMs by remember { mutableLongStateOf(0L) }     // مدة التسجيل قبل آخر إيقاف مؤقت
    var segmentStartMs by remember { mutableLongStateOf(0L) }      // بداية المقطع الجاري (بعد آخر استئناف)
    var startedAtMs by remember { mutableLongStateOf(0L) }
    var audioMuted by rememberSaveable { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(0) }
    val snaps = remember { mutableStateListOf<String>() }
    var error by remember { mutableStateOf<String?>(null) }
    var customText by rememberSaveable { mutableStateOf("") }
    var showReasonInput by rememberSaveable { mutableStateOf(false) }
    val settings = remember { CameraSettingsState() }
    var focusPoint by remember { mutableStateOf<Offset?>(null) }

    DisposableEffect(lensFacing, selectedQuality) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(selectedQuality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                    .build()
                val vc = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                val cam = provider.bindToLifecycle(owner, selector, preview, vc)
                boundCamera = cam
                hasFlash = cam.cameraInfo.hasFlashUnit()
                flashOn = false
                maxZoomRatio = (cam.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f).coerceAtLeast(1f)
                zoomRatio = 1f
                settings.resetForCamera()
                videoCapture = vc
            } catch (e: Exception) {
                error = "تعذّر فتح الكاميرا"
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            try { boundCamera?.cameraControl?.enableTorch(false) } catch (e: Exception) { /* تجاهل */ }
            try { rec?.stop() } catch (e: Exception) { /* تجاهل */ }
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (e: Exception) { /* تجاهل */ }
        }
    }

    // المؤقّت بيتحسب من ساعة النظام (مش من عدّاد بيتأخر)، ويقف تمامًا وقت الإيقاف المؤقت ويكمل من نفس المدة.
    LaunchedEffect(rec, paused) {
        if (rec == null) { seconds = 0; return@LaunchedEffect }
        while (true) {
            val ms = elapsedBeforeMs + if (paused) 0L else SystemClock.elapsedRealtime() - segmentStartMs
            seconds = (ms / 1000L).toInt()
            if (paused) break
            delay(250)
        }
    }
    // لو أمر الإيقاف المؤقت/الاستئناف ماتأكدش من CameraX نرجّع الزرار يشتغل تاني
    LaunchedEffect(transitioning) { if (transitioning) { delay(2500); transitioning = false } }

    // التطبيق راح للخلفية / الشاشة اتقفلت أثناء التسجيل (حتى وهو متوقف مؤقتًا): نوقف ونحفظ اللي اتسجل بدل ما يضيع.
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) { try { rec?.stop() } catch (_: Exception) { /* تجاهل */ } }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    fun startRec() {
        if (rec != null) return                       // مفيش جلسة تسجيل تانية فوق الجارية
        val vc = videoCapture ?: return
        val dir = File(context.cacheDir, "cap").apply { mkdirs() }
        val file = File(dir, "rec_${System.currentTimeMillis()}.mp4")
        val opts = FileOutputOptions.Builder(file).build()
        try {
            var pending = vc.output.prepareRecording(context, opts)
            if (withAudio) pending = pending.withAudioEnabled()
            // خط الأساس للمؤقت قبل ما ندي أمر البدء
            elapsedBeforeMs = 0L
            segmentStartMs = SystemClock.elapsedRealtime()
            startedAtMs = segmentStartMs
            paused = false
            transitioning = false
            rec = pending.start(ContextCompat.getMainExecutor(context)) { ev ->
                when (ev) {
                    // إيقاف مؤقت: نفس الجلسة ونفس الملف، والمؤقت بيقف
                    is VideoRecordEvent.Pause -> {
                        elapsedBeforeMs += SystemClock.elapsedRealtime() - segmentStartMs
                        paused = true
                        transitioning = false
                    }
                    // استئناف: بنكمل في نفس الملف والمؤقت بيكمل من المدة اللي قبله
                    is VideoRecordEvent.Resume -> {
                        segmentStartMs = SystemClock.elapsedRealtime()
                        paused = false
                        transitioning = false
                    }
                    is VideoRecordEvent.Finalize -> {
                        rec = null
                        paused = false
                        transitioning = false
                        // بدون حد زمني: التسجيل بيكمل لحد ما المراقب يوقفه أو المساحة تخلص. لو المساحة خلصت الفيديو المسجّل لحد اللحظة دي سليم ونحفظه.
                        val storageFull = ev.error == VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE ||
                            ev.error == VideoRecordEvent.Finalize.ERROR_FILE_SIZE_LIMIT_REACHED
                        // مقاطعات تانية بتسيب ملف سليم (الكاميرا اتقفلت / وصلنا لحد المدة): نحفظه بس بعد ما نتأكد إنه بيتشغّل
                        val interrupted = ev.error == VideoRecordEvent.Finalize.ERROR_SOURCE_INACTIVE ||
                            ev.error == VideoRecordEvent.Finalize.ERROR_DURATION_LIMIT_REACHED
                        val hasData = file.exists() && file.length() > 0L
                        if (!ev.hasError() || ((storageFull || interrupted) && hasData && isPlayableVideo(file))) {
                            if (storageFull) android.widget.Toast.makeText(context, "المساحة امتلأت — تم إيقاف التسجيل وحفظ ما تم تسجيله", android.widget.Toast.LENGTH_LONG).show()
                            else if (interrupted) android.widget.Toast.makeText(context, "تم إيقاف التسجيل — تم حفظ ما تم تسجيله", android.widget.Toast.LENGTH_LONG).show()
                            onFinished(file.path, snaps.toList(), customText.trim())
                        } else { file.delete(); error = "تعذّر حفظ الفيديو (${ev.error})" }
                    }
                    else -> Unit
                }
            }
            if (withAudio && audioMuted) { try { rec?.mute(true) } catch (_: Exception) { } }
        } catch (e: Exception) {
            error = "تعذّر بدء التسجيل: ${e.localizedMessage ?: "تحقق من الصلاحيات ومساحة التخزين"}"
        }
    }

    // إيقاف مؤقت: Recording.pause() — نفس الجلسة، مفيش ملف جديد
    fun pauseRec() {
        val r = rec ?: return
        if (paused || transitioning) return
        error = null
        transitioning = true
        try { r.pause() } catch (_: Exception) { transitioning = false; error = "تعذّر إيقاف التسجيل مؤقتًا" }
    }

    // استئناف: Recording.resume() — بيكمل في نفس الملف
    fun resumeRec() {
        val r = rec ?: return
        if (!paused || transitioning) return
        error = null
        transitioning = true
        try { r.resume() } catch (_: Exception) { transitioning = false; error = "تعذّر استئناف التسجيل" }
    }

    // إيقاف نهائي وحفظ (بيشتغل وهو جاري أو متوقف مؤقتًا). تجاهل ضغطة عرضية في أول 0.8 ثانية بعد البدء.
    fun stopRec() {
        val r = rec ?: return
        if (SystemClock.elapsedRealtime() - startedAtMs < 800L) return
        try { r.stop() } catch (_: Exception) { /* تجاهل */ }
    }

    fun setZoom(value: Float) {
        val max = maxZoomRatio.coerceAtLeast(1f)
        val next = value.coerceIn(1f, max)
        boundCamera?.cameraControl?.setZoomRatio(next)
        zoomRatio = next
    }

    fun toggleAudio() {
        if (!withAudio) { error = "إذن الميكروفون غير متاح"; return }
        val next = !audioMuted
        try { rec?.mute(next); audioMuted = next } catch (_: Exception) { error = "تعذّر تغيير صوت الفيديو" }
    }

    fun focusAt(x: Float, y: Float) {
        val cam = boundCamera ?: return
        focusPoint = Offset(x, y)
        try {
            val point = previewView.meteringPointFactory.createPoint(x, y)
            cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
        } catch (_: Exception) { }
    }

    fun toggleFlash() {
        val cam = boundCamera ?: return
        if (!hasFlash) {
            error = "الفلاش غير مدعوم في الكاميرا دي"
            return
        }
        val next = !flashOn
        try {
            cam.cameraControl.enableTorch(next)
            flashOn = next
        } catch (e: Exception) {
            error = "تعذّر تغيير حالة الفلاش: ${e.localizedMessage ?: "حاول مرة أخرى"}"
        }
    }

    fun snap() {
        val bmp = previewView.bitmap
        if (bmp == null) {
            error = "استنى لحظة لحد ما معاينة الكاميرا تجهز"
            return
        }
        val f = File(File(context.cacheDir, "cap").apply { mkdirs() }, "snap_${System.currentTimeMillis()}.jpg")
        try {
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            snaps.add(f.path)
        } catch (e: Exception) {
            error = "تعذّر التقاط الصورة"
        }
    }

    // واجهة نظيفة: المعاينة فقط + مؤقت + زر تسجيل واضح. (ختم البيانات على الصور/الفيديو بيتم في VideoStamper ومش بنلمسه هنا)
    KeepScreenOn()
    ApplyCameraSettings(settings, boundCamera)
    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().cameraGestures(onZoomBy = { setZoom(zoomRatio * it) }, onTap = { focusAt(it.x, it.y) }))
        if (settings.grid) CameraGrid()
        FocusRing(focusPoint) { focusPoint = null }
        DraggableInfoBar()
        // السبب اختياري: لا يظهر حقل الكتابة إلا إذا طلبه المراقب، لتبقى المعاينة واضحة.
        Column(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 70.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!showReasonInput) {
                ReasonPill(onClick = { showReasonInput = true }, enabled = rec == null)
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.Black.copy(alpha = 0.68f), shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("سبب يظهر أعلى الفيديو والصور", color = Color.White, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showReasonInput = false; customText = "" }, enabled = rec == null) {
                                Text("إخفاء", color = Color.White)
                            }
                        }
                        OutlinedTextField(
                            value = customText,
                            onValueChange = { customText = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("اكتب السبب أو اتركه فارغًا") },
                            minLines = 1, maxLines = 3, enabled = rec == null,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color.White, unfocusedBorderColor = Color.LightGray,
                                cursorColor = Color.White, focusedLabelColor = Color.White,
                                unfocusedLabelColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        }
        // شريط علوي عائم (فلاش + تبديل الكاميرا)، ويفضل متاح أثناء تسجيل الفيديو.
        Box(Modifier.align(Alignment.TopCenter)) {
            CameraTopBar {
                CameraPill(if (flashOn) "⚡ تشغيل" else "⚡ إيقاف", onClick = { toggleFlash() }, enabled = hasFlash, compact = true)
                CameraPill(
                    if (lensFacing == CameraSelector.LENS_FACING_BACK) "🔄 أمامية" else "🔄 خلفية",
                    onClick = { if (rec == null) lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK },
                    enabled = rec == null && videoCapture != null, compact = true
                )
                if (withAudio) CameraPill(if (audioMuted) "🔇 مكتوم" else "🎤 يعمل", onClick = { toggleAudio() }, compact = true)
                CameraPill("⚙ إعدادات", onClick = { settings.open = !settings.open }, compact = true)
            }
        }
        CameraSettingsPanel(settings, boundCamera, Modifier.align(Alignment.TopCenter).padding(top = 64.dp))
        // اختيار جودة الفيديو؛ إعادة تهيئة الكاميرا لا تتم أثناء التسجيل.
        if (settings.open && rec == null) {
            Column(
                Modifier.align(Alignment.TopCenter).padding(start = 12.dp, top = 350.dp, end = 12.dp)
                    .fillMaxWidth().background(Color(0xE6111111), RoundedCornerShape(14.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("جودة الفيديو", color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CameraPill("SD", onClick = { selectedQuality = Quality.SD }, enabled = selectedQuality != Quality.SD, compact = true)
                    CameraPill("HD", onClick = { selectedQuality = Quality.HD }, enabled = selectedQuality != Quality.HD, compact = true)
                    CameraPill("Full HD", onClick = { selectedQuality = Quality.FHD }, enabled = selectedQuality != Quality.FHD, compact = true)
                }
                Text("الجودة المختارة قد يتم خفضها تلقائيًا إذا لم يدعمها الهاتف.", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            // المؤقت الفوري داخل كبسولة شبه شفافة
            Row(
                Modifier.padding(bottom = 8.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (rec != null) {
                    if (paused) PauseBars(PauseAmber) else Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFE53935)))
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    if (rec != null) (if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, (seconds / 60) % 60, seconds % 60) else "%02d:%02d".format(seconds / 60, seconds % 60)) else "جاهز للتسجيل — مدة مفتوحة",
                    color = if (rec != null && paused) PauseAmber else Color.White, style = MaterialTheme.typography.titleMedium
                )
                if (rec != null && paused) {
                    Spacer(Modifier.width(8.dp))
                    Text("متوقف مؤقتًا", color = PauseAmber, style = MaterialTheme.typography.labelLarge)
                }
            }
            // تلميح واضح للفرق بين الأزرار التلاتة
            if (rec != null) {
                Text(
                    if (paused) "التسجيل متوقف — «استئناف» بيكمل في نفس الفيديو، والمربع الأحمر بيحفظ"
                    else "جاري التسجيل — «إيقاف مؤقت» للاستراحة، والمربع الأحمر للإيقاف والحفظ",
                    color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 6.dp, start = 16.dp, end = 16.dp)
                )
            }
            if (snaps.isNotEmpty()) Text("صور ملتقطة: ${snaps.size}", color = Color.White, modifier = Modifier.padding(bottom = 6.dp))
            error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(bottom = 6.dp)) }
            // التحكم في الزوم متاح قبل التسجيل وأثناءه.
            ZoomBadge(zoomRatio, Modifier.padding(bottom = 8.dp))
            CameraBottomBar(
                cancel = {
                    if (rec == null) CameraCancelButton(onClick = { snaps.forEach { File(it).delete() }; onCancel() })
                    else PauseResumeButton(paused = paused, enabled = !transitioning, onClick = { if (paused) resumeRec() else pauseRec() })
                },
                center = { RecordButton(recording = rec != null, enabled = rec != null || videoCapture != null) { if (rec == null) startRec() else stopRec() } },
                end = {
                    if (rec != null) {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))
                                .clickable { snap() }.semantics { contentDescription = "التقاط صورة" },
                            contentAlignment = Alignment.Center
                        ) { Text("📷", style = MaterialTheme.typography.titleLarge) }
                    }
                }
            )
        }
    }
}

/** شرطتين = إيقاف مؤقت (مرسومتين بدل رمز نصي عشان يظهروا نفسهم على كل الأجهزة) */
@Composable
private fun PauseBars(color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(2) { Box(Modifier.size(width = 4.dp, height = 14.dp).background(color, RoundedCornerShape(1.dp))) }
    }
}

/**
 * إيقاف مؤقت ⇄ استئناف لنفس التسجيل (مش إيقاف نهائي). الإيقاف والحفظ بالمربع الأحمر في النص.
 * أبيض شفاف = "إيقاف مؤقت"، كهرماني = "استئناف" (التسجيل متوقف حاليًا).
 */
@Composable
private fun PauseResumeButton(paused: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val bg = if (paused) PauseAmber else Color.White.copy(alpha = 0.25f)
    val fg = if (paused) Color.Black else Color.White
    Row(
        Modifier.height(48.dp).clip(RoundedCornerShape(24.dp))
            .background(bg.copy(alpha = if (enabled) bg.alpha else bg.alpha * 0.5f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp)
            .semantics { contentDescription = if (paused) "استئناف التسجيل" else "إيقاف التسجيل مؤقتًا" },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (paused) Text("▶", color = fg, style = MaterialTheme.typography.titleMedium) else PauseBars(fg)
        Text(if (paused) "استئناف" else "إيقاف مؤقت", color = fg, style = MaterialTheme.typography.labelLarge)
    }
}

/** زر التسجيل: حلقة بيضاء + دايرة حمراء (بيتحول لمربع أثناء التسجيل = إيقاف وحفظ) */
@Composable
private fun RecordButton(recording: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val inner by animateDpAsState(if (recording) 28.dp else 56.dp, label = "recInner")
    Box(
        Modifier.size(76.dp).border(4.dp, Color.White, CircleShape).padding(6.dp).clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { contentDescription = if (recording) "إيقاف وحفظ" else "ابدأ التسجيل" },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(inner)
                .clip(if (recording) RoundedCornerShape(6.dp) else CircleShape)
                .background(Color(0xFFE53935).copy(alpha = if (enabled) 1f else 0.4f))
        )
    }
}
