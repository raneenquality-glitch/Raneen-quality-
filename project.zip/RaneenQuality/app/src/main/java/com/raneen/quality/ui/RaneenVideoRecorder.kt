package com.raneen.quality.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream

private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

/**
 * تسجيل فيديو من جوه التطبيق (أقصى 3 دقايق). وإنت بتصوّر تقدر تلتقط صور بزرار 📷،
 * والصور بتتحط على نفس المخالفة بنفس شريط البيانات.
 */
@Composable
fun VideoRecorderDialog(onFinished: (videoPath: String, snapshots: List<String>) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    var hasCam by remember { mutableStateOf(granted(context, Manifest.permission.CAMERA)) }
    var hasAudio by remember { mutableStateOf(granted(context, Manifest.permission.RECORD_AUDIO)) }
    var asked by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasCam = granted(context, Manifest.permission.CAMERA)
        hasAudio = granted(context, Manifest.permission.RECORD_AUDIO)
        asked = true
    }
    LaunchedEffect(Unit) {
        if (!hasCam || !hasAudio) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) else asked = true
    }
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            when {
                hasCam -> RecorderContent(withAudio = hasAudio, onFinished = onFinished, onCancel = onCancel)
                asked -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("محتاج إذن الكاميرا عشان تصوّر فيديو. فعّله من إعدادات التطبيق.", color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onCancel) { Text("رجوع") }
                }
                else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
        }
    }
}

@Composable
private fun RecorderContent(withAudio: Boolean, onFinished: (String, List<String>) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE   // عشان لقطة الصورة أثناء التسجيل تشتغل على كل الأجهزة
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var rec by remember { mutableStateOf<Recording?>(null) }
    var seconds by remember { mutableStateOf(0) }
    val snaps = remember { mutableStateListOf<String>() }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.HD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                    .build()
                val vc = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, vc)
                videoCapture = vc
            } catch (e: Exception) {
                error = "تعذّر فتح الكاميرا"
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            try { rec?.stop() } catch (e: Exception) { /* تجاهل */ }
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (e: Exception) { /* تجاهل */ }
        }
    }

    LaunchedEffect(rec) {
        seconds = 0
        while (rec != null) { delay(1000); seconds++ }
    }

    fun startRec() {
        val vc = videoCapture ?: return
        val dir = File(context.cacheDir, "cap").apply { mkdirs() }
        val file = File(dir, "rec_${System.currentTimeMillis()}.mp4")
        val opts = FileOutputOptions.Builder(file).setDurationLimitMillis(180_000L).build()
        try {
            var pending = vc.output.prepareRecording(context, opts)
            if (withAudio) pending = pending.withAudioEnabled()
            rec = pending.start(ContextCompat.getMainExecutor(context)) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    rec = null
                    if (!ev.hasError()) onFinished(file.path, snaps.toList())
                    else { file.delete(); error = "تعذّر حفظ الفيديو (${ev.error})" }
                }
            }
        } catch (e: Exception) {
            error = "تعذّر بدء التسجيل"
        }
    }

    fun snap() {
        val bmp = previewView.bitmap ?: return
        val f = File(File(context.cacheDir, "cap").apply { mkdirs() }, "snap_${System.currentTimeMillis()}.jpg")
        try {
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            snaps.add(f.path)
        } catch (e: Exception) {
            error = "تعذّر التقاط الصورة"
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                if (rec != null) "● تسجيل  %02d:%02d".format(seconds / 60, seconds % 60) else "جاهز للتسجيل (أقصى 3 دقايق)",
                color = Color.White, style = MaterialTheme.typography.titleMedium
            )
            if (snaps.isNotEmpty()) Text("صور ملتقطة: ${snaps.size}", color = Color.White)
            error?.let { Text(it, color = Color(0xFFFF8A80)) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (rec == null) {
                    OutlinedButton(onClick = { snaps.forEach { File(it).delete() }; onCancel() }) { Text("إلغاء", color = Color.White) }
                    Button(onClick = { startRec() }, enabled = videoCapture != null) { Text("● ابدأ التسجيل") }
                } else {
                    Button(onClick = { rec?.stop() }) { Text("■ إيقاف وحفظ") }
                    Button(onClick = { snap() }) { Text("📷 صورة") }
                }
            }
        }
    }
}
