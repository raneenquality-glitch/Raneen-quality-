package com.raneen.quality.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raneen.quality.data.ControlEntity

/** شاشة تقييم وحدة واحدة (قسم / إدارة). الاستخدام: EvaluationScreen(repo, inspectionId, unitId, unitName) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaluationScreen(
    repo: InspectionRepository,
    inspectionId: String,
    unitId: String,
    unitName: String
) {
    val vm: EvaluationViewModel = viewModel(
        key = "$inspectionId/$unitId",
        factory = EvaluationViewModel.Factory(repo, inspectionId, unitId)
    )
    val ui by vm.ui.collectAsStateWithLifecycle()

    // واجهة عربية RTL
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(unitName) },
                    actions = {
                        ui.score?.let {
                            Text(
                                "%.1f / %.0f".format(it.actual, it.planned),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(12.dp)) {

                // اختيار المجموعة (مجموعات المنتجات / ق1–ق4) — بتظهر لو الوحدة ليها مجموعات
                if (ui.groups.isNotEmpty()) item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ui.groups, key = { it.id }) { g ->
                            FilterChip(
                                selected = g.id == ui.selectedGroupId,
                                onClick = { vm.selectGroup(g.id) },
                                label = { Text(g.name) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                ui.categories.forEach { cw ->
                    val catScore = ui.score?.byCategory?.get(cw.category.id)
                    item(key = "cat_${cw.category.id}") {
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(cw.category.name, style = MaterialTheme.typography.titleMedium)
                            catScore?.let { Text("%.1f / %.0f".format(it.actual, it.planned)) }
                        }
                    }
                    items(cw.controls, key = { it.id }) { control ->
                        val groupId = if (control.perGroup) ui.selectedGroupId else ""
                        val count = ui.counts[control.id to groupId] ?: 0
                        ControlRow(control, count > 0) { vm.onX(control) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlRow(control: ControlEntity, violated: Boolean, onX: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onX),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            // ☐ / ☒ X  (بند 14 في المواصفات)
            Text(if (violated) "☒ X" else "☐", fontWeight = FontWeight.Bold,
                color = if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${control.sortOrder}. ${control.text}")
                control.hint?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text("${control.maxScore.toInt()}", style = MaterialTheme.typography.labelLarge)
        }
    }
}
