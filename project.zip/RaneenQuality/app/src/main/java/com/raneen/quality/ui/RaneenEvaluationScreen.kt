package com.raneen.quality.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raneen.quality.data.ControlEntity
import com.raneen.quality.data.PhotoEntity
import com.raneen.quality.domain.matchesQuery
import java.io.File

/**
 * شاشة تقييم وحدة واحدة (قسم / إدارة).
 * - الضغط على الضابط = X (مخالفة) وبيفتح الكاميرا فورًا لو الضابط بيطلب صورة.
 * - الصورة بتتختم بالفرع/القسم/التاريخ/الوقت/المراقب وبتتحفظ جوه التطبيق (المراقب مش بيقدر يعدلها).
 * - البحث بيطابق اسم الكاتجري ونص الضابط والملاحظة ورقم البند (من غير تشكيل/همزات).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaluationScreen(
    repo: InspectionRepository,
    inspectionId: String,
    unitId: String,
    unitName: String
) {
    val vm: EvaluationViewModel = viewModel(
        key = "$inspectionId/$unitId",
        factory = EvaluationViewModel.Factory(repo, inspectionId, unitId, unitName)
    )
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var pending by rememberSaveable { mutableStateOf<String?>(null) }   // "controlId|groupId|rawPath"
    var preview by remember { mutableStateOf<PhotoEntity?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val parts = pending?.split("|", limit = 3)
        pending = null
        if (parts != null && parts.size == 3) {
            if (ok) vm.addPhoto(parts[0], parts[1], File(parts[2])) else File(parts[2]).delete()
        }
    }

    fun startCapture(controlId: String, groupId: String) {
        try {
            val dir = File(context.cacheDir, "cap").apply { mkdirs() }
            val raw = File(dir, "raw_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", raw)
            pending = "$controlId|$groupId|${raw.path}"
            launcher.launch(uri)
        } catch (e: Exception) {
            pending = null
            Toast.makeText(context, "تعذّر فتح الكاميرا", Toast.LENGTH_LONG).show()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(unitName) },
                    actions = {
                        ui.score?.let {
                            Text(
                                "%.1f / %.0f".format(it.actual, it.planned),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                if (!ui.editable) {
                    Text(
                        "التقرير للعرض فقط — مينفعش التعديل بعد الإرسال.",
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("بحث في الضوابط") },
                    trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("مسح") } },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp)) {

                    // اختيار المجموعة (مجموعات المنتجات / ق1–ق4)
                    if (ui.groups.isNotEmpty()) item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ui.groups, key = { it.id }) { g ->
                                FilterChip(
                                    selected = g.id == ui.selectedGroupId,
                                    onClick = { vm.selectGroup(g.id) },
                                    label = { Text(g.name) }
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    var anyShown = false
                    ui.categories.forEach { cw ->
                        val shown = if (query.isBlank()) cw.controls
                        else cw.controls.filter { matchesQuery(query, cw.category.name, it.text, it.hint, it.sortOrder.toString()) }
                        if (shown.isEmpty()) return@forEach
                        anyShown = true
                        val catScore = ui.score?.byCategory?.get(cw.category.id)
                        item(key = "cat_${cw.category.id}") {
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(cw.category.name, style = MaterialTheme.typography.titleMedium)
                                catScore?.let { Text("%.1f / %.0f".format(it.actual, it.planned)) }
                            }
                        }
                        items(shown, key = { it.id }) { control ->
                            val groupId = if (control.perGroup) ui.selectedGroupId else ""
                            val count = ui.counts[control.id to groupId] ?: 0
                            val fid = ui.findingIds[control.id to groupId]
                            val photos = if (fid != null) ui.photos[fid].orEmpty() else emptyList()
                            ControlRow(
                                control = control, violated = count > 0, editable = ui.editable, photos = photos,
                                onToggle = {
                                    val wasViolated = count > 0
                                    vm.onX(control)
                                    if (!wasViolated && control.photoRequired) startCapture(control.id, groupId)
                                },
                                onAddPhoto = { startCapture(control.id, groupId) },
                                onOpenPhoto = { preview = it }
                            )
                        }
                    }
                    if (!anyShown && query.isNotBlank()) item {
                        Text("مفيش نتائج للبحث ده", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        preview?.let { p ->
            PhotoDialog(p, ui.editable, onDelete = { vm.deletePhoto(p); preview = null }, onClose = { preview = null })
        }
    }
}

@Composable
private fun ControlRow(
    control: ControlEntity, violated: Boolean, editable: Boolean, photos: List<PhotoEntity>,
    onToggle: () -> Unit, onAddPhoto: () -> Unit, onOpenPhoto: (PhotoEntity) -> Unit
) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(enabled = editable, onClick = onToggle),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // ☐ / ☒ X  (بند 14 في المواصفات)
                Text(if (violated) "☒ X" else "☐", fontWeight = FontWeight.Bold,
                    color = if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${control.sortOrder}. ${control.text}")
                    control.hint?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(fmtWeight(control.maxScore), style = MaterialTheme.typography.labelLarge)
            }
            if (violated) {
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos, key = { it.id }) { p -> Thumb(p.filePath, 64.dp) { onOpenPhoto(p) } }
                    }
                } else if (control.photoRequired) {
                    Text("⚠ الضابط ده محتاج صورة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                if (editable) TextButton(onClick = onAddPhoto) { Text("📷 ${if (photos.isEmpty()) "تصوير" else "صورة إضافية"}") }
            }
        }
    }
}
