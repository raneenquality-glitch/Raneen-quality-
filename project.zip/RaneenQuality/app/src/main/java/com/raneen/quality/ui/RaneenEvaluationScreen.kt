package com.raneen.quality.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raneen.quality.data.ControlEntity
import com.raneen.quality.data.GalleryImport
import com.raneen.quality.data.PhotoEntity
import com.raneen.quality.data.VideoStamper
import com.raneen.quality.domain.matchesQuery
import java.io.File

/**
 * شاشة تقييم وحدة واحدة (قسم / إدارة).
 * - الضغط على الضابط = X (مخالفة) وبيفتح الكاميرا فورًا لو الضابط بيطلب صورة.
 * - الصورة بتتختم بالفرع/القسم/التاريخ/الوقت/المراقب وبتتحفظ جوه التطبيق (المراقب مش بيقدر يعدلها).
 * - البحث بيطابق اسم الكاتجري ونص الضابط والملاحظة ورقم البند (من غير تشكيل/همزات).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaluationScreen(
    repo: InspectionRepository,
    inspectionId: String,
    unitId: String,
    unitName: String
) {
    val vm: EvaluationViewModel = viewModel(
        key = "$inspectionId/$unitId",
        factory = EvaluationViewModel.Factory(repo, inspectionId, unitId, unitName)
    )
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var pending by rememberSaveable { mutableStateOf<String?>(null) }   // "controlId|groupId|rawPath"
    var preview by remember { mutableStateOf<PhotoEntity?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val parts = pending?.split("|", limit = 3)
        pending = null
        if (parts != null && parts.size == 3) {
            if (ok) vm.addPhoto(parts[0], parts[1], File(parts[2])) else File(parts[2]).delete()
        }
    }

    var stamping by remember { mutableStateOf(false) }
    var recordingFor by remember { mutableStateOf<Pair<String, String>?>(null) }   // (controlId, groupId)

    fun startVideo(controlId: String, groupId: String) { recordingFor = controlId to groupId }

    // الكاميرا معمول لها إذن في الـ manifest، فلازم الإذن يتطلب قبل فتح كاميرا الصور بالـ Intent
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            camPerm.launch(Manifest.permission.CAMERA)
        }
    }

    // ───── صورة من المعرض (بدل التصوير من جديد) ─────
    val scope = rememberCoroutineScope()
    var galleryTarget by rememberSaveable { mutableStateOf<String?>(null) }           // "controlId|groupId"
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val parts = galleryTarget?.split("|", limit = 2)
        galleryTarget = null
        if (uri != null && parts != null && parts.size == 2) scope.launch {
            val res = withContext(Dispatchers.IO) { GalleryImport.copyWithTakenTime(context, uri) }
            val taken = res?.second
            when {
                res == null -> Toast.makeText(context, "تعذّر قراءة الصورة", Toast.LENGTH_LONG).show()
                taken != null && System.currentTimeMillis() - taken > GalleryImport.MAX_AGE_MS -> {
                    res.first.delete()
                    Toast.makeText(context, "الصورة دي أقدم من ${GalleryImport.MAX_AGE_HOURS} ساعة. اختار صورة أحدث أو صوّر من جديد", Toast.LENGTH_LONG).show()
                }
                else -> vm.addGalleryPhoto(parts[0], parts[1], res.first, taken)
            }
        }
    }

    fun startGallery(controlId: String, groupId: String) {
        galleryTarget = "$controlId|$groupId"
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    fun startCapture(controlId: String, groupId: String) {
        try {
            val dir = File(context.cacheDir, "cap").apply { mkdirs() }
            val raw = File(dir, "raw_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", raw)
            pending = "$controlId|$groupId|${raw.path}"
            launcher.launch(uri)
        } catch (e: Exception) {
            pending = null
            Toast.makeText(context, "تعذّر فتح الكاميرا", Toast.LENGTH_LONG).show()
        }
    }

    // الضوابط اللي المراقب راجعها (مطابق أو مخالف). المخالفات بتتحسب تلقائيًا من البيانات؛ ده بس عشان "مطابق" يتحسب في شريط التقدم.
    val reviewed = rememberSaveable(
        inspectionId, unitId,
        saver = listSaver<SnapshotStateList<String>, String>(save = { it.toList() }, restore = { it.toMutableStateList() })
    ) { mutableStateListOf<String>() }

    // شاشة الأقسام (مربعات) ← بنود القسم. null = شاشة المربعات
    var openCat by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(enabled = openCat != null) { openCat = null }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(unitName) },
                    actions = {
                        ui.score?.let {
                            Text(
                                "%.1f / %.0f".format(it.actual, it.planned),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                // ───────── شريط التقدم: نسبة الضوابط اللي اتراجعت ─────────
                val scoredIds = ui.categories.flatMap { cw -> cw.controls.filter { it.maxScore > 0 }.map { it.id } }
                val violatedIds = ui.counts.filter { it.value > 0 }.keys.map { it.first }.toSet()
                val doneCount = scoredIds.count { it in violatedIds || it in reviewed }
                val progress = if (scoredIds.isEmpty()) 0f else doneCount.toFloat() / scoredIds.size
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("تقدّم التقييم", style = MaterialTheme.typography.labelLarge)
                        Text("$doneCount / ${scoredIds.size}  ·  ${(progress * 100).toInt()}%",
                            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.primaryContainer
                    )
                }
                if (!ui.editable) {
                    Text(
                        "التقرير للعرض فقط — مينفعش التعديل بعد الإرسال.",
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("بحث في الضوابط") },
                    trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("مسح") } },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp)) {

                    val searching = query.isNotBlank()
                    val inGrid = !searching && openCat == null

                    // اختيار المجموعة (مجموعات المنتجات / ق1–ق4) — جوه القسم وفي البحث بس
                    if (ui.groups.isNotEmpty() && !inGrid) item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ui.groups, key = { it.id }) { g ->
                                FilterChip(
                                    selected = g.id == ui.selectedGroupId,
                                    onClick = { vm.selectGroup(g.id) },
                                    label = { Text(g.name) }
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    var anyShown = false

                    // ───────── شاشة الأقسام: مربع لكل قسم بحالته ─────────
                    if (inGrid) {
                        val tiles = ui.categories.mapNotNull { cw ->
                            val sc = cw.controls.filter { it.maxScore > 0 }
                            if (sc.isEmpty()) null else cw to sc
                        }
                        items(tiles.chunked(2), key = { row -> "tiles_${row.first().first.category.id}" }) { row ->
                            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                row.forEach { (cw, sc) ->
                                    CategoryTile(
                                        name = cw.category.name, total = sc.size,
                                        reviewed = sc.count { it.id in violatedIds || it.id in reviewed },
                                        violations = sc.count { it.id in violatedIds },
                                        modifier = Modifier.weight(1f), onClick = { openCat = cw.category.id }
                                    )
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        if (ui.categories.any { cw -> cw.controls.any { it.maxScore <= 0 } }) item(key = "tile_census") {
                            CategoryTile(
                                name = "ضوابط الحصر", total = 0, reviewed = 0, violations = 0,
                                statusOverride = "اكتب الأعداد لكل مجموعة", modifier = Modifier.fillMaxWidth(),
                                onClick = { openCat = CENSUS_ID }
                            )
                        }
                    }

                    ui.categories.forEach { cw ->
                        if (inGrid || (!searching && openCat != cw.category.id)) return@forEach
                        val scored = cw.controls.filter { it.maxScore > 0 }   // ضوابط الحصر (وزنها صفر) بتتعرض في آخر الصفحة
                        val shown = if (query.isBlank()) scored
                        else scored.filter { matchesQuery(query, cw.category.name, it.text, it.hint, it.sortOrder.toString()) }
                        if (shown.isEmpty()) return@forEach
                        anyShown = true
                        val catScore = ui.score?.byCategory?.get(cw.category.id)
                        item(key = "cat_${cw.category.id}") {
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (!searching) TextButton(onClick = { openCat = null }) { Text("→ الأقسام") }
                                Text(cw.category.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                catScore?.let { Text("%.1f / %.0f".format(it.actual, it.planned)) }
                            }
                        }
                        items(shown, key = { it.id }) { control ->
                            val groupId = if (control.perGroup) ui.selectedGroupId else ""
                            val count = ui.counts[control.id to groupId] ?: 0
                            val fid = ui.findingIds[control.id to groupId]
                            val photos = if (fid != null) ui.photos[fid].orEmpty() else emptyList()
                            // قيم الأجزاء هنا bit flags وليست درجات الخصم؛ حساب الخصم الفعلي في RaneenScoring.kt
                            val serviceParts = when (control.id) {
                                "services_admin_i5" -> listOf("حريمي" to 1, "رجالي" to 2)
                                "services_admin_i6" -> listOf("حريمي" to 1, "رجالي" to 2)
                                "services_admin_i7" -> listOf("المدخل" to 1, "المخرج" to 2)
                                "services_admin_i8" -> listOf("النظافة" to 1, "الترتيب" to 2)
                                "services_admin_i9" -> listOf("المنطقة المحيطة" to 1, "الواجهات الزجاجية" to 2)
                                "maintenance_i13" -> listOf("الصيانة" to 1, "الدهان" to 2)
                                "branch_manager_i1", "branch_manager_i3" -> listOf("منزلي" to 1, "الألعاب" to 2, "المفروشات" to 4, "الكهرباء" to 8)
                                "branch_manager_i4", "branch_manager_i5", "branch_manager_i9" -> listOf("الجزء الأول" to 1, "الجزء الثاني" to 2)
                                else -> emptyList()
                            }
                            val penaltyOptions = when (control.id) {
                                "security_i14", "cameras_i11" -> (1..5).toList()
                                "maintenance_i3" -> listOf(2, 5, 7)
                                "branch_manager_i14" -> listOf(2, 4, 6, 8)
                                else -> emptyList()
                            }
                            val hasVariablePenalty = penaltyOptions.isNotEmpty()
                            ControlRow(
                                control = control, violated = count > 0, editable = ui.editable, photos = photos,
                                variablePenalty = hasVariablePenalty, selectedPenalty = count, penaltyOptions = penaltyOptions,
                                serviceParts = serviceParts,
                                onSelectPenalty = { selected ->
                                    val next = if (selected == count) 0 else selected
                                    vm.setCount(control, next)
                                },
                                onToggleServicePart = { partValue ->
                                    val next = if ((count and partValue) != 0) count and partValue.inv() else count or partValue
                                    vm.setCount(control, next)
                                },
                                reviewed = control.id in reviewed,
                                onCompliant = {
                                    if (control.id !in reviewed) reviewed.add(control.id)
                                    // نفس منطق الإلغاء القديم: لو كانت مخالفة بنرجّعها مطابقة
                                    if (count > 0) { if (hasVariablePenalty) vm.setCount(control, 0) else vm.onX(control) }
                                },
                                onNonCompliant = {
                                    if (control.id !in reviewed) reviewed.add(control.id)
                                    // بنسجّل المخالفة، وأزرار "صوّر / من المعرض" بتظهر تحت البند على طول
                                    if (count == 0) vm.onX(control)
                                },
                                onAddPhoto = { startCapture(control.id, groupId) },
                                onAddGallery = { startGallery(control.id, groupId) },
                                onAddVideo = { startVideo(control.id, groupId) },
                                onOpenPhoto = { p -> if (isVideo(p.filePath)) playVideo(context, p.filePath) else preview = p }
                            )
                        }
                    }
                    // ───────── ضوابط الحصر ─────────
                    val censusCats = ui.categories.mapNotNull { cw ->
                        val cs = cw.controls.filter { it.maxScore <= 0 }
                        val sh = if (query.isBlank()) cs else cs.filter { matchesQuery(query, cw.category.name, it.text, "حصر") }
                        if (sh.isEmpty()) null else cw.category to sh
                    }
                    if (censusCats.isNotEmpty() && (searching || openCat == CENSUS_ID)) {
                        anyShown = true
                        item(key = "census_title") {
                            Column(Modifier.padding(top = 8.dp, bottom = 4.dp)) {
                                if (!searching) TextButton(onClick = { openCat = null }) { Text("→ الأقسام") }
                                Text("ضوابط الحصر", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                Text("اكتب العدد لكل مجموعة منتجات، والأعداد بتتجمع لوحدها (من غير درجات).",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        val groupIds = ui.groups.map { it.id }
                        censusCats.forEach { (cat, list) ->
                            item(key = "census_cat_${cat.id}") {
                                Text(cat.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                            }
                            itemsIndexed(list, key = { _, c -> c.id }) { idx, control ->
                                CensusInputRow(
                                    no = control.sortOrder, control = control, groupIds = groupIds, counts = ui.counts,
                                    unitPrices = ui.unitPrices, currentGroup = ui.selectedGroupId, editable = ui.editable,
                                    onSet = { n -> vm.setCount(control, n) }, onSetPrice = { price -> vm.setUnitPrice(control, price) }
                                )
                            }
                        }
                    }
                    if (!anyShown && query.isNotBlank()) item {
                        Text("مفيش نتائج للبحث ده", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        recordingFor?.let { (cid, gid) ->
            VideoRecorderDialog(
                onFinished = { path, snaps ->
                    recordingFor = null
                    stamping = true
                    vm.addVideo(cid, gid, File(path), snaps.map { File(it) }) { result ->
                        stamping = false
                        when (result) {
                            0 -> Toast.makeText(context, "الفيديو ماتحفظش", Toast.LENGTH_LONG).show()
                            2 -> Toast.makeText(context, "الفيديو اتحفظ من غير الشريط. السبب: ${VideoStamper.lastError ?: "غير معروف"} — ابعتلي الكود ده", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onCancel = { recordingFor = null }
            )
        }
        if (stamping) AlertDialog(
            onDismissRequest = {},
            title = { Text("جاري إضافة الشريط على الفيديو") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("ممكن ياخد دقيقة أو اتنين للفيديو الطويل. متقفلش التطبيق.")
                }
            },
            confirmButton = {}
        )
        preview?.let { p ->
            PhotoDialog(p, ui.editable, onDelete = { vm.deletePhoto(p); preview = null }, onClose = { preview = null })
        }
    }
}

@Composable
private fun ControlRow(
    control: ControlEntity, violated: Boolean, editable: Boolean, photos: List<PhotoEntity>,
    variablePenalty: Boolean = false, selectedPenalty: Int = 0, penaltyOptions: List<Int> = (1..5).toList(), onSelectPenalty: (Int) -> Unit = {},
    serviceParts: List<Pair<String, Int>> = emptyList(), onToggleServicePart: (Int) -> Unit = {},
    reviewed: Boolean, onCompliant: () -> Unit, onNonCompliant: () -> Unit,
    onAddPhoto: () -> Unit, onAddGallery: () -> Unit, onAddVideo: () -> Unit, onOpenPhoto: (PhotoEntity) -> Unit
) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // ☐ / ☒ X  (بند 14 في المواصفات)
                Text(if (violated) "☒ X" else "☐", fontWeight = FontWeight.Bold,
                    color = if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${control.sortOrder}. ${control.text}")
                    control.hint?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(fmtWeight(control.maxScore), style = MaterialTheme.typography.labelLarge)
            }
            // ───────── اختيار النتيجة بالشرائح (Chips) ─────────
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ResultChip("مطابق", selected = !violated && reviewed, enabled = editable,
                    tint = Color(0xFF1D7A4D), icon = Icons.Filled.Check, onClick = onCompliant)
                // الضوابط ذات الخصم المتغيّر بتتحدد بأزرار الخصم تحت، فمفيش شريحة "مخالف" ليها
                if (!variablePenalty) ResultChip("مخالف", selected = violated, enabled = editable,
                    tint = MaterialTheme.colorScheme.error, icon = Icons.Filled.Close, onClick = onNonCompliant)
            }
            if (serviceParts.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("حدد الجزء المخالف (كل جزء بخصمه)", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    serviceParts.forEach { (label, value) ->
                        val selected = (selectedPenalty and value) != 0
                        if (selected) Button(onClick = { if (editable) onToggleServicePart(value) }, enabled = editable, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)) { Text("✓ $label") }
                        else OutlinedButton(onClick = { if (editable) onToggleServicePart(value) }, enabled = editable, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)) { Text("□ $label") }
                    }
                }
                if (selectedPenalty > 0) {
                    val partPenalty = when (control.id) {
                        "services_admin_i5", "services_admin_i7", "services_admin_i8", "services_admin_i9" -> 4
                        "services_admin_i6" -> 1
                        "maintenance_i13", "branch_manager_i4", "branch_manager_i5", "branch_manager_i9" -> 2
                        "branch_manager_i1", "branch_manager_i3" -> 1
                        else -> (control.maxScore / 2).toInt()
                    }
                    val totalPenalty = serviceParts.filter { (selectedPenalty and it.second) != 0 }.sumOf { partPenalty }
                    Text("الخصم المحدد: $totalPenalty ${if (totalPenalty == 1) "درجة" else "درجات"}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            }
            if (variablePenalty) {
                Spacer(Modifier.height(8.dp))
                Text("حدد مقدار الخصم", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    penaltyOptions.forEach { penalty ->
                        val isSelected = selectedPenalty == penalty
                        val label = if (penalty == 1) "1 درجة" else "$penalty درجات"
                        if (isSelected) {
                            Button(onClick = { if (editable) onSelectPenalty(penalty) }, enabled = editable,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), modifier = Modifier.weight(1f)) { Text(label) }
                        } else {
                            OutlinedButton(onClick = { if (editable) onSelectPenalty(penalty) }, enabled = editable,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), modifier = Modifier.weight(1f)) { Text(label) }
                        }
                    }
                }
                if (selectedPenalty > 0) {
                    val shownPenalty = if (control.id == "maintenance_i3") selectedPenalty else selectedPenalty
                    Text("الخصم المحدد: $shownPenalty ${if (shownPenalty == 1) "درجة" else "درجات"}",
                        color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            }
            if (violated) {
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos, key = { it.id }) { p -> Thumb(p.filePath, 64.dp) { onOpenPhoto(p) } }
                    }
                } else if (control.photoRequired) {
                    Text("⚠ الضابط ده محتاج صورة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                if (editable && violated) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(onClick = onAddPhoto, modifier = Modifier.weight(1.2f), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("📷 ${if (photos.isEmpty()) "صوّر" else "إضافية"}")
                    }
                    OutlinedButton(onClick = onAddGallery, modifier = Modifier.weight(1.2f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("🖼 من المعرض") }
                    OutlinedButton(onClick = onAddVideo, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("🎥 فيديو") }
                }
            }
        }
    }
}

private const val CENSUS_ID = "__census__"

/** مربع قسم: لونه بيقول الحالة (أخضر = كله مطابق، أحمر = فيه مخالفات، رمادي = لسه) */
@Composable
private fun CategoryTile(
    name: String, total: Int, reviewed: Int, violations: Int,
    modifier: Modifier = Modifier, statusOverride: String? = null, onClick: () -> Unit
) {
    val green = Color(0xFF1D7A4D)
    val done = total > 0 && reviewed >= total && violations == 0
    val (bg, fg) = when {
        violations > 0 -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.error
        done -> Color(0xFFE3F4EA) to green
        else -> MaterialTheme.colorScheme.surface to MaterialTheme.colorScheme.onSurfaceVariant
    }
    val status = statusOverride ?: when {
        violations > 0 -> "⚠ $violations مخالفة"
        done -> "✓ مطابق"
        reviewed > 0 -> "$reviewed / $total اتراجع"
        else -> "لسه ما اتراجعتش"
    }
    Column(
        modifier.heightIn(min = 96.dp).clip(RoundedCornerShape(16.dp)).background(bg)
            .border(1.dp, if (violations > 0 || done) Color.Transparent else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 3, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Text(status, style = MaterialTheme.typography.labelLarge, color = fg, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RowScope.ResultChip(
    label: String, selected: Boolean, enabled: Boolean, tint: Color, icon: ImageVector, onClick: () -> Unit
) {
    FilterChip(
        selected = selected, onClick = onClick, enabled = enabled,
        label = { Text(label, fontWeight = FontWeight.SemiBold) },
        leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
        shape = RoundedCornerShape(12.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = tint.copy(alpha = 0.14f),
            selectedLabelColor = tint,
            selectedLeadingIconColor = tint
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = enabled, selected = selected,
            borderColor = MaterialTheme.colorScheme.outlineVariant, selectedBorderColor = tint
        ),
        modifier = Modifier.weight(1f).height(44.dp)   // 44dp = هدف لمس مريح
    )
}

/** صف ضابط حصر: خانة عدد للمجموعة المختارة + المجموع على كل المجموعات: (2+2+2) = 6 */
@Composable
private fun CensusInputRow(
    no: Int, control: ControlEntity, groupIds: List<String>, counts: Map<Pair<String, String>, Int>,
    unitPrices: Map<Pair<String, String>, Double>, currentGroup: String, editable: Boolean,
    onSet: (Int) -> Unit, onSetPrice: (Double) -> Unit
) {
    val gid = if (control.perGroup) currentGroup else ""
    val current = counts[control.id to gid] ?: 0
    val parts = (if (control.perGroup) groupIds else listOf("")).map { counts[control.id to it] ?: 0 }.filter { it > 0 }
    val total = parts.sum()
    val price = unitPrices[control.id to gid] ?: 0.0
    val pricedItem = isPricedCensusItem(control.text)
    var text by remember(control.id, gid, current) { mutableStateOf(if (current > 0) current.toString() else "") }
    var priceText by remember(control.id, gid, price) { mutableStateOf(if (price > 0) price.toString().removeSuffix(".0") else "") }
    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("$no. ${control.text}")
                if (total > 0) {
                    Text(
                        if (parts.size > 1) "(${parts.joinToString("+")}) = $total" else "المجموع: $total",
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
            OutlinedTextField(
                value = text,
                onValueChange = { v ->
                    val d = v.filter { it.isDigit() }.take(6)
                    text = d
                    onSet(d.toIntOrNull() ?: 0)
                },
                enabled = editable, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                placeholder = { Text("0") },
                modifier = Modifier.width(96.dp), label = { Text("الكمية") }
            )
            if (pricedItem) {
                OutlinedTextField(
                    value = priceText, onValueChange = { v ->
                        val d = v.filter { it.isDigit() || it == '.' }.take(10)
                        priceText = d
                        onSetPrice(d.toDoubleOrNull() ?: 0.0)
                    }, enabled = editable, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    placeholder = { Text("سعر الوحدة") }, label = { Text("سعر الوحدة ج.م") },
                    modifier = Modifier.width(140.dp)
                )
                val amount = (if (control.perGroup) groupIds else listOf("")).sumOf { groupId ->
                    (counts[control.id to groupId] ?: 0) * (unitPrices[control.id to groupId] ?: 0.0)
                }
                Text("إجمالي قيمة كل المجموعات: ${"%.2f".format(amount)} ج.م", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            }
        }
    }
}

private fun isPricedCensusItem(text: String): Boolean {
    val t = text.replace(" ", "")
    return t.contains("بدونكود") || t.contains("كودتالف") || t.contains("كودخطأ") || t.contains("أبديتمسمى") || t.contains("ابديتمسمى")
}
