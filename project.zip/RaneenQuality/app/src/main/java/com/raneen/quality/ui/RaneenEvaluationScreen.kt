package com.raneen.quality.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raneen.quality.data.ControlEntity
import com.raneen.quality.data.PhotoEntity
import com.raneen.quality.data.VideoStamper
import com.raneen.quality.domain.matchesQuery
import java.io.File

/**
 * شاشة تقييم وحدة واحدة (قسم / إدارة).
 * - الضغط على الضابط = X (مخالفة) وبيفتح الكاميرا فورًا لو الضابط بيطلب صورة.
 * - الصورة بتتختم بالفرع/القسم/التاريخ/الوقت/المراقب وبتتحفظ جوه التطبيق (المراقب مش بيقدر يعدلها).
 * - البحث بيطابق اسم الكاتجري ونص الضابط والملاحظة ورقم البند (من غير تشكيل/همزات).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaluationScreen(
    repo: InspectionRepository,
    inspectionId: String,
    unitId: String,
    unitName: String
) {
    val vm: EvaluationViewModel = viewModel(
        key = "$inspectionId/$unitId",
        factory = EvaluationViewModel.Factory(repo, inspectionId, unitId, unitName)
    )
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var pending by rememberSaveable { mutableStateOf<String?>(null) }   // "controlId|groupId|rawPath"
    var preview by remember { mutableStateOf<PhotoEntity?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val parts = pending?.split("|", limit = 3)
        pending = null
        if (parts != null && parts.size == 3) {
            if (ok) vm.addPhoto(parts[0], parts[1], File(parts[2])) else File(parts[2]).delete()
        }
    }

    var stamping by remember { mutableStateOf(false) }
    var recordingFor by remember { mutableStateOf<Pair<String, String>?>(null) }   // (controlId, groupId)

    fun startVideo(controlId: String, groupId: String) { recordingFor = controlId to groupId }

    // الكاميرا معمول لها إذن في الـ manifest، فلازم الإذن يتطلب قبل فتح كاميرا الصور بالـ Intent
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            camPerm.launch(Manifest.permission.CAMERA)
        }
    }

    fun startCapture(controlId: String, groupId: String) {
        try {
            val dir = File(context.cacheDir, "cap").apply { mkdirs() }
            val raw = File(dir, "raw_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", raw)
            pending = "$controlId|$groupId|${raw.path}"
            launcher.launch(uri)
        } catch (e: Exception) {
            pending = null
            Toast.makeText(context, "تعذّر فتح الكاميرا", Toast.LENGTH_LONG).show()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(unitName) },
                    actions = {
                        ui.score?.let {
                            Text(
                                "%.1f / %.0f".format(it.actual, it.planned),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                if (!ui.editable) {
                    Text(
                        "التقرير للعرض فقط — مينفعش التعديل بعد الإرسال.",
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("بحث في الضوابط") },
                    trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("مسح") } },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp)) {

                    // اختيار المجموعة (مجموعات المنتجات / ق1–ق4)
                    if (ui.groups.isNotEmpty()) item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ui.groups, key = { it.id }) { g ->
                                FilterChip(
                                    selected = g.id == ui.selectedGroupId,
                                    onClick = { vm.selectGroup(g.id) },
                                    label = { Text(g.name) }
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    var anyShown = false
                    ui.categories.forEach { cw ->
                        val scored = cw.controls.filter { it.maxScore > 0 }   // ضوابط الحصر (وزنها صفر) بتتعرض في آخر الصفحة
                        val shown = if (query.isBlank()) scored
                        else scored.filter { matchesQuery(query, cw.category.name, it.text, it.hint, it.sortOrder.toString()) }
                        if (shown.isEmpty()) return@forEach
                        anyShown = true
                        val catScore = ui.score?.byCategory?.get(cw.category.id)
                        item(key = "cat_${cw.category.id}") {
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(cw.category.name, style = MaterialTheme.typography.titleMedium)
                                catScore?.let { Text("%.1f / %.0f".format(it.actual, it.planned)) }
                            }
                        }
                        items(shown, key = { it.id }) { control ->
                            val groupId = if (control.perGroup) ui.selectedGroupId else ""
                            val count = ui.counts[control.id to groupId] ?: 0
                            val fid = ui.findingIds[control.id to groupId]
                            val photos = if (fid != null) ui.photos[fid].orEmpty() else emptyList()
                            ControlRow(
                                control = control, violated = count > 0, editable = ui.editable, photos = photos,
                                onToggle = {
                                    val wasViolated = count > 0
                                    vm.onX(control)
                                    if (!wasViolated && control.photoRequired) startCapture(control.id, groupId)
                                },
                                onAddPhoto = { startCapture(control.id, groupId) },
                                onAddVideo = { startVideo(control.id, groupId) },
                                onOpenPhoto = { p -> if (isVideo(p.filePath)) playVideo(context, p.filePath) else preview = p }
                            )
                        }
                    }
                    // ───────── ضوابط الحصر ─────────
                    val censusCats = ui.categories.mapNotNull { cw ->
                        val cs = cw.controls.filter { it.maxScore <= 0 }
                        val sh = if (query.isBlank()) cs else cs.filter { matchesQuery(query, cw.category.name, it.text, "حصر") }
                        if (sh.isEmpty()) null else cw.category to sh
                    }
                    if (censusCats.isNotEmpty()) {
                        anyShown = true
                        item(key = "census_title") {
                            Column(Modifier.padding(top = 20.dp, bottom = 4.dp)) {
                                Text("ضوابط الحصر", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                                Text("اكتب العدد لكل مجموعة منتجات، والأعداد بتتجمع لوحدها (من غير درجات).",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        val groupIds = ui.groups.map { it.id }
                        censusCats.forEach { (cat, list) ->
                            item(key = "census_cat_${cat.id}") {
                                Text(cat.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                            }
                            itemsIndexed(list, key = { _, c -> c.id }) { idx, control ->
                                CensusInputRow(
                                    no = idx + 1, control = control, groupIds = groupIds, counts = ui.counts,
                                    currentGroup = ui.selectedGroupId, editable = ui.editable,
                                    onSet = { n -> vm.setCount(control, n) }
                                )
                            }
                        }
                    }
                    if (!anyShown && query.isNotBlank()) item {
                        Text("مفيش نتائج للبحث ده", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        recordingFor?.let { (cid, gid) ->
            VideoRecorderDialog(
                onFinished = { path, snaps ->
                    recordingFor = null
                    stamping = true
                    vm.addVideo(cid, gid, File(path), snaps.map { File(it) }) { result ->
                        stamping = false
                        when (result) {
                            0 -> Toast.makeText(context, "الفيديو ماتحفظش", Toast.LENGTH_LONG).show()
                            2 -> Toast.makeText(context, "الفيديو اتحفظ من غير الشريط. السبب: ${VideoStamper.lastError ?: "غير معروف"} — ابعتلي الكود ده", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onCancel = { recordingFor = null }
            )
        }
        if (stamping) AlertDialog(
            onDismissRequest = {},
            title = { Text("جاري إضافة الشريط على الفيديو") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("ممكن ياخد دقيقة أو اتنين للفيديو الطويل. متقفلش التطبيق.")
                }
            },
            confirmButton = {}
        )
        preview?.let { p ->
            PhotoDialog(p, ui.editable, onDelete = { vm.deletePhoto(p); preview = null }, onClose = { preview = null })
        }
    }
}

@Composable
private fun ControlRow(
    control: ControlEntity, violated: Boolean, editable: Boolean, photos: List<PhotoEntity>,
    onToggle: () -> Unit, onAddPhoto: () -> Unit, onAddVideo: () -> Unit, onOpenPhoto: (PhotoEntity) -> Unit
) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(enabled = editable, onClick = onToggle),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // ☐ / ☒ X  (بند 14 في المواصفات)
                Text(if (violated) "☒ X" else "☐", fontWeight = FontWeight.Bold,
                    color = if (violated) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${control.sortOrder}. ${control.text}")
                    control.hint?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(fmtWeight(control.maxScore), style = MaterialTheme.typography.labelLarge)
            }
            if (violated) {
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos, key = { it.id }) { p -> Thumb(p.filePath, 64.dp) { onOpenPhoto(p) } }
                    }
                } else if (control.photoRequired) {
                    Text("⚠ الضابط ده محتاج صورة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                if (editable) Row {
                    TextButton(onClick = onAddPhoto) { Text("📷 ${if (photos.isEmpty()) "تصوير" else "صورة إضافية"}") }
                    TextButton(onClick = onAddVideo) { Text("🎥 فيديو") }
                }
            }
        }
    }
}

/** صف ضابط حصر: خانة عدد للمجموعة المختارة + المجموع على كل المجموعات: (2+2+2) = 6 */
@Composable
private fun CensusInputRow(
    no: Int, control: ControlEntity, groupIds: List<String>, counts: Map<Pair<String, String>, Int>,
    currentGroup: String, editable: Boolean, onSet: (Int) -> Unit
) {
    val gid = if (control.perGroup) currentGroup else ""
    val current = counts[control.id to gid] ?: 0
    val parts = (if (control.perGroup) groupIds else listOf("")).map { counts[control.id to it] ?: 0 }.filter { it > 0 }
    val total = parts.sum()
    var text by remember(control.id, gid, current) { mutableStateOf(if (current > 0) current.toString() else "") }
    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("$no. ${control.text}")
                if (total > 0) {
                    Text(
                        if (parts.size > 1) "(${parts.joinToString("+")}) = $total" else "المجموع: $total",
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            OutlinedTextField(
                value = text,
                onValueChange = { v ->
                    val d = v.filter { it.isDigit() }.take(6)
                    text = d
                    onSet(d.toIntOrNull() ?: 0)
                },
                enabled = editable, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                placeholder = { Text("0") },
                modifier = Modifier.width(96.dp)
            )
        }
    }
}
