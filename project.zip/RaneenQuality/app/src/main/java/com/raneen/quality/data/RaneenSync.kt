package com.raneen.quality.data

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * المزامنة مع Supabase. التطبيق بيشتغل أوفلاين دايمًا، والمزامنة بتحصل لما فيه إنترنت:
 *  - الأدمن: بيرفع الكتالوج (فروع/أقسام/ضوابط) لو اتعدّل
 *  - الكل: بينزّل الكتالوج والمستخدمين والتقارير
 *  - المراقب: بيرفع الصور والتقارير المُرسلة (syncState = PENDING)
 *  - المديرين: بينزّلوا صور التقارير
 */
/** امتداد ملف الوسائط (jpg للصور، mp4 للفيديو) */
private fun ext(path: String): String = File(path).extension.ifBlank { "jpg" }

class SyncRepository(
    private val db: RaneenDatabase,
    private val remote: SupabaseRemote,
    private val appContext: Context
) {
    private val ins = db.inspectionDao()
    private val cat = db.catalogDao()
    private val users = db.userDao()
    private val prefs = appContext.getSharedPreferences("raneen_sync", Context.MODE_PRIVATE)

    val status = MutableStateFlow("لم تتم مزامنة بعد")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val kicks = Channel<Unit>(Channel.CONFLATED)
    private val mutex = Mutex()

    fun markCatalogDirty() { prefs.edit().putBoolean("catalog_dirty", true).apply() }
    private fun catalogDirty() = prefs.getBoolean("catalog_dirty", false)

    fun start(user: UserEntity) {
        stop()
        job = scope.launch {
            while (isActive) {
                syncAll(user)
                withTimeoutOrNull(60_000) { kicks.receive() }
            }
        }
    }

    fun stop() { job?.cancel(); job = null }

    /** مزامنة فورية (بعد إرسال تقرير / تعديل كتالوج / زرار "مزامنة الآن") */
    fun kick() { kicks.trySend(Unit) }

    /** مزامنة كاملة مرة واحدة (بتتنادى من الحلقة ومن الشغل الخلفي) */
    suspend fun syncAll(user: UserEntity) = mutex.withLock {
        if (remote.session()?.userId != user.id) {
            status.value = "أوفلاين — سجّل دخول بإنترنت عشان المزامنة تشتغل"
            return@withLock
        }
        status.value = "جاري المزامنة..."
        var firstError: String? = null
        // كل خطوة لوحدها: لو خطوة فشلت (خطأ من السيرفر) الباقي يكمّل. مفيش إنترنت = نوقف كله.
        suspend fun step(block: suspend () -> Unit) {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: NetworkException) {
                throw e
            } catch (e: ApiException) {
                if (firstError == null) {
                    val msg = try { JSONObject(e.body).optString("message") } catch (ex: Exception) { "" }
                    firstError = if (e.code == 401) "انتهت الجلسة — سجّل دخول تاني" else "(${e.code}) ${msg.take(80)}"
                }
            } catch (e: Exception) {
                if (firstError == null) firstError = "خطأ غير متوقع"
            }
        }
        try {
            if (user.role == Roles.ADMIN) step { pushCatalogIfNeeded() }
            if (user.role == Roles.INSPECTOR) step { pushReports(user) }
            step { pullCatalog() }
            if (user.role == Roles.ADMIN) step {
                if (CensusDefaults.ensure(cat)) { markCatalogDirty(); kick() }   // ضوابط الحصر الجديدة تتبعت لكل الأجهزة
            }
            step { pullProfilesInner() }
            step { pullReports() }
            step { downloadPhotos() }
            if (user.role == Roles.DEPT_MANAGER || user.role == Roles.ADMIN) step { sweepApprovedFromCloud() }
            step { notifyPending(user) }
            status.value = firstError?.let { "تمت المزامنة مع خطأ: $it" }
                ?: ("تمت المزامنة " + SimpleDateFormat("HH:mm", Locale.US).format(Date()))
        } catch (e: CancellationException) {
            throw e
        } catch (e: NetworkException) {
            status.value = "أوفلاين — هتتزامن لما الإنترنت يرجع"
        } catch (e: Exception) {
            status.value = "تعذّرت المزامنة"
        }
    }

    /** بعد ما الأدمن يضيف/يعدّل مستخدم */
    suspend fun refreshProfiles() {
        try { pullProfilesInner() } catch (e: CancellationException) { throw e } catch (e: Exception) { /* هتتزامن في الدورة الجاية */ }
    }

    // ───────────── الكتالوج ─────────────
    private suspend fun pushCatalogIfNeeded() {
        val dirty = catalogDirty()
        val serverEmpty = !dirty && JSONArray(remote.get("/rest/v1/catalog_items?select=id&limit=1")).length() == 0
        if (dirty || serverEmpty) {
            pushCatalog()
            prefs.edit().putBoolean("catalog_dirty", false).apply()
        }
    }

    private suspend fun pushCatalog() {
        val items = JSONArray()
        fun add(kind: String, id: String, d: JSONObject) { items.put(JSONObject().put("kind", kind).put("id", id).put("data", d)) }
        cat.allBranches().forEach {
            add("branch", it.id, JSONObject().put("id", it.id).put("code", it.code).put("name", it.name)
                .put("region", it.region).put("isActive", it.isActive))
        }
        cat.allUnits().forEach {
            add("unit", it.id, JSONObject().put("id", it.id).put("templateId", it.templateId).put("name", it.name)
                .put("kind", it.kind).put("scoringMode", it.scoringMode).put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        cat.allGroups().forEach {
            add("group", it.id, JSONObject().put("id", it.id).put("unitId", it.unitId).put("name", it.name)
                .put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        cat.allCategories().forEach {
            add("category", it.id, JSONObject().put("id", it.id).put("unitId", it.unitId).put("name", it.name)
                .put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        cat.allControls().forEach {
            add("control", it.id, JSONObject().put("id", it.id).put("categoryId", it.categoryId).put("text", it.text)
                .put("maxScore", it.maxScore).put("penaltyPerViolation", it.penaltyPerViolation)
                .put("photoRequired", it.photoRequired).put("perGroup", it.perGroup)
                .put("hint", it.hint ?: JSONObject.NULL).put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        remote.rpc("replace_catalog", JSONObject().put("items", items).toString())
    }

    private suspend fun pullCatalog() {
        if (catalogDirty()) return                      // عندي تعديلات لسه مترفعتش — متدوسش عليها
        val text = remote.get("/rest/v1/catalog_items?select=kind,id,data&order=kind,id")
        val arr = JSONArray(text)
        if (arr.length() == 0) return                   // السيرفر فاضي — سيب الكتالوج المحلي
        val sig = text.hashCode().toString() + ":" + text.length
        if (prefs.getString("catalog_sig", null) == sig) return   // مفيش تغيير

        val branches = ArrayList<BranchEntity>()
        val units = ArrayList<EvaluationUnitEntity>()
        val groups = ArrayList<ProductGroupEntity>()
        val cats = ArrayList<CategoryEntity>()
        val controls = ArrayList<ControlEntity>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val d = o.getJSONObject("data")
            when (o.getString("kind")) {
                "branch" -> branches += BranchEntity(d.getString("id"), d.getString("code"), d.getString("name"),
                    d.optString("region", ""), d.optBoolean("isActive", true))
                "unit" -> units += EvaluationUnitEntity(d.getString("id"), d.getString("templateId"), d.getString("name"),
                    d.getString("kind"), d.optString("scoringMode", "X_COUNT"), d.optInt("sortOrder", 0), d.optBoolean("isActive", true))
                "group" -> groups += ProductGroupEntity(d.getString("id"), d.getString("unitId"), d.getString("name"),
                    d.optInt("sortOrder", 0), d.optBoolean("isActive", true))
                "category" -> cats += CategoryEntity(d.getString("id"), d.getString("unitId"), d.getString("name"),
                    d.optInt("sortOrder", 0), d.optBoolean("isActive", true))
                "control" -> controls += ControlEntity(
                    d.getString("id"), d.getString("categoryId"), d.getString("text"), d.getDouble("maxScore"),
                    d.optDouble("penaltyPerViolation", 1.0), d.optBoolean("photoRequired", true), d.optBoolean("perGroup", false),
                    if (d.isNull("hint")) null else d.optString("hint").ifBlank { null },
                    d.optInt("sortOrder", 0), d.optBoolean("isActive", true)
                )
            }
        }
        db.withTransaction {
            cat.upsertTemplates(listOf(TemplateEntity("main", "تقرير الجودة")))
            cat.wipeControls(); cat.wipeCategories(); cat.wipeGroups(); cat.wipeUnits(); cat.wipeBranches()
            cat.upsertUnits(units); cat.upsertGroups(groups); cat.upsertCategories(cats)
            cat.upsertControls(controls); cat.upsertBranches(branches)
        }
        prefs.edit().putString("catalog_sig", sig).apply()
    }

    // ───────────── المستخدمين ─────────────
    private suspend fun pullProfilesInner() {
        val arr = JSONArray(remote.get("/rest/v1/profiles?select=id,username,name,role,is_active,must_change"))
        if (arr.length() == 0) return
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            val username = o.getString("username")
            val key = username.trim().lowercase()
            val ex = users.byId(id)
            users.deleteDupes(key, id)
            users.upsert(
                UserEntity(
                    id = id, name = o.getString("name"), username = username, usernameKey = key,
                    role = o.getString("role"),
                    passwordHash = ex?.passwordHash ?: "", salt = ex?.salt ?: "",
                    iterations = ex?.iterations ?: PasswordHasher.ITERATIONS,
                    mustChangePassword = o.optBoolean("must_change", false),
                    isActive = o.optBoolean("is_active", true)
                )
            )
            ids += id
        }
        users.deleteNotIn(ids)
    }

    // ───────────── التقارير (المراقب بيرفع) ─────────────
    private suspend fun pushReports(user: UserEntity) {
        for (insp in ins.pendingInspections().filter { it.inspectorId == user.id }) {
            val findings = ins.findingsOf(insp.id)
            val photos = ins.photosOfInspection(insp.id)
            // الصور الأول
            for (p in photos) {
                if (p.syncState == "SYNCED") continue
                val f = File(p.filePath)
                if (!f.exists()) continue
                remote.upload("${user.id}/${insp.id}/${p.id}.${ext(p.filePath)}", f)
                ins.setPhotoSync(p.id, "SYNCED")
            }
            val unitsArr = JSONArray()
            ins.unitStates(insp.id).forEach { unitsArr.put(JSONObject().put("unitId", it.unitId).put("isNA", it.isNA)) }
            val findingsArr = JSONArray()
            findings.forEach {
                findingsArr.put(JSONObject().put("id", it.id).put("unitId", it.unitId).put("controlId", it.controlId)
                    .put("groupId", it.groupId).put("violationCount", it.violationCount))
            }
            val photosArr = JSONArray()
            photos.forEach { photosArr.put(JSONObject().put("id", it.id).put("findingId", it.findingId).put("capturedAt", it.capturedAt).put("ext", ext(it.filePath))) }
            val data = JSONObject()
                .put("inspection", JSONObject().put("id", insp.id).put("reportNumber", insp.reportNumber)
                    .put("templateId", insp.templateId).put("branchId", insp.branchId)
                    .put("inspectorId", insp.inspectorId).put("visitDate", insp.visitDate)
                    .put("visitNumber", insp.visitNumber ?: ""))
                .put("units", unitsArr).put("findings", findingsArr).put("photos", photosArr)
            try {
                remote.rpc(
                    "submit_report",
                    JSONObject().put("p_id", insp.id).put("p_report_number", insp.reportNumber)
                        .put("p_branch_id", insp.branchId).put("p_data", data).toString()
                )
                ins.setSync(insp.id, "SYNCED")
            } catch (e: ApiException) {
                if (e.body.contains("locked")) ins.setSync(insp.id, "SYNCED") else throw e
            }
        }
    }

    // ───────────── التقارير (تنزيل) ─────────────
    private suspend fun pullReports() {
        val arr = JSONArray(remote.get("/rest/v1/reports?select=id,inspector_id,report_number,branch_id,status,data,audit&order=updated_at.desc&limit=200"))
        for (i in 0 until arr.length()) {
            try { importOrUpdate(arr.getJSONObject(i)) } catch (e: org.json.JSONException) { /* تقرير بشكل غير متوقع — نتخطاه */ }
        }
    }

    private suspend fun importOrUpdate(o: JSONObject) {
        val id = o.getString("id")
        val status = o.getString("status")
        val auditArr = o.getJSONArray("audit")
        val audits = ArrayList<AuditEntity>()
        for (k in 0 until auditArr.length()) {
            val a = auditArr.getJSONObject(k)
            audits += AuditEntity(
                a.getString("id"), id, a.getString("action"), a.optString("actorName", ""), a.optString("actorRole", ""),
                if (a.isNull("note")) null else a.optString("note").ifBlank { null }, a.getLong("at")
            )
        }
        val local = ins.inspection(id)
        if (local == null) {
            val d = o.getJSONObject("data")
            val i = d.getJSONObject("inspection")
            val units = ArrayList<InspectionUnitEntity>()
            d.getJSONArray("units").let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let { units += InspectionUnitEntity(id, it.getString("unitId"), it.optBoolean("isNA", false)) } }
            val findings = ArrayList<FindingEntity>()
            d.getJSONArray("findings").let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let {
                findings += FindingEntity(it.getString("id"), id, it.getString("unitId"), it.getString("controlId"),
                    it.optString("groupId", ""), it.optInt("violationCount", 0))
            } }
            val photoDir = File(appContext.filesDir, "photos")
            val photos = ArrayList<PhotoEntity>()
            d.getJSONArray("photos").let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let {
                val pid = it.getString("id")
                val taken = it.optLong("capturedAt", 0L)
                val gone = status == Status.FINAL        // بعد الاعتماد النهائي الصور اتمسحت من السحابة
                val e = it.optString("ext", "jpg").ifBlank { "jpg" }
                photos += PhotoEntity(pid, it.getString("findingId"), File(photoDir, "$pid.$e").path, taken, if (gone) "PURGED" else "REMOTE")
            } }
            db.withTransaction {
                ins.upsertInspection(
                    InspectionEntity(id, i.getString("reportNumber"), i.getString("templateId"), i.getString("branchId"),
                        i.getString("inspectorId"), i.getLong("visitDate"),
                        visitNumber = i.optString("visitNumber", "").ifBlank { null }, status = status, syncState = "SYNCED")
                )
                ins.upsertUnitStates(units); ins.upsertFindings(findings); ins.upsertPhotos(photos)
                ins.deleteAudit(id); ins.upsertAudits(audits)
            }
        } else if (local.syncState != "PENDING" && (local.status != status || ins.auditCount(id) != audits.size)) {
            db.withTransaction {
                ins.setStatus(id, status); ins.setSync(id, "SYNCED")
                ins.deleteAudit(id); ins.upsertAudits(audits)
                if (status == Status.FINAL) ins.markRemoteGone(id)
            }
        }
    }

    private suspend fun downloadPhotos() {
        for (r in ins.remotePhotos()) {
            try {
                remote.download("${r.inspectorId}/${r.inspectionId}/${r.photoId}.${ext(r.filePath)}", File(r.filePath))
                ins.setPhotoSync(r.photoId, "SYNCED")
            } catch (e: ApiException) {
                ins.setPhotoSync(r.photoId, "MISSING")   // مش موجودة على السيرفر — منحاولش تاني
            }
        }
    }

    /** تنزيل فيديو واحد عند الطلب (الفيديو مبيتنزّلش تلقائي عشان نقل البيانات المجاني محدود) */
    suspend fun downloadMedia(inspectorId: String, inspectionId: String, p: PhotoEntity): String? = withContext(Dispatchers.IO) {
        try {
            remote.download("$inspectorId/$inspectionId/${p.id}.${ext(p.filePath)}", File(p.filePath))
            ins.setPhotoSync(p.id, "SYNCED")
            null
        } catch (e: NetworkException) {
            "محتاج إنترنت لتنزيل الفيديو"
        } catch (e: ApiException) {
            if (e.code == 404 || e.code == 400) { ins.setPhotoSync(p.id, "MISSING"); "الفيديو مش موجود على السيرفر" }
            else "تعذّر التنزيل (${e.code})"
        }
    }

    /** قبل الاعتماد النهائي: لازم كل صور التقرير تكون على الموبايل (لأنها هتتمسح من السحابة بعد الاعتماد) */
    suspend fun ensurePhotos(inspectionId: String): String? = withContext(Dispatchers.IO) {
        val insp = ins.inspection(inspectionId) ?: return@withContext "التقرير غير موجود"
        for (p in ins.photosOfInspection(inspectionId)) {
            if (p.syncState != "REMOTE") continue
            try {
                remote.download("${insp.inspectorId}/$inspectionId/${p.id}.${ext(p.filePath)}", File(p.filePath))
                ins.setPhotoSync(p.id, "SYNCED")
            } catch (e: NetworkException) {
                return@withContext "محتاج إنترنت عشان تتنزّل كل الصور قبل الاعتماد النهائي"
            } catch (e: ApiException) {
                if (e.code == 404 || e.code == 400) ins.setPhotoSync(p.id, "MISSING")
                else return@withContext "تعذّر تنزيل الصور من السيرفر (${e.code})"
            }
        }
        null
    }

    // ───────────── الصور: السحابة لحد الاعتماد النهائي، ونسخ الموبايلات من غير مدة ─────────────
    /** بعد الاعتماد النهائي: مدير الإدارة/الأدمن بيمسحوا صور التقرير من السحابة (نسخة المراقب بتفضل على موبايله) */
    private suspend fun sweepApprovedFromCloud() {
        val done = (prefs.getStringSet("cloud_cleared", emptySet()) ?: emptySet()).toMutableSet()
        var n = 0
        for (r in ins.refsByStatus(Status.FINAL)) {
            if (r.id in done) continue
            if (n++ >= 5) break
            for (p in ins.photosOfInspection(r.id)) remote.deleteObject("${r.inspectorId}/${r.id}/${p.id}.${ext(p.filePath)}")
            ins.markRemoteGone(r.id)
            done += r.id
            prefs.edit().putStringSet("cloud_cleared", HashSet(done)).apply()
        }
    }

    // ───────────── التنبيهات ─────────────
    private suspend fun notifyPending(user: UserEntity) {
        val rows = when (user.role) {
            Roles.AREA_MANAGER -> ins.refsByStatus(Status.SUBMITTED)
            Roles.DEPT_MANAGER -> ins.refsByStatus(Status.REVIEWED)
            Roles.INSPECTOR -> ins.returnedFor(user.id)
            else -> emptyList()
        }
        val key = "notified_${user.id}"
        val old = prefs.getStringSet(key, emptySet()) ?: emptySet()
        val fresh = rows.filter { it.id !in old }
        if (fresh.isNotEmpty()) {
            if (user.role == Roles.INSPECTOR) {
                Notifier.post(appContext, 1001, "تقرير اترجّع للتعديل", "التقرير ${fresh.first().reportNumber} محتاج تعديل منك")
            } else {
                val more = if (fresh.size > 1) " (و${fresh.size - 1} غيره)" else ""
                Notifier.post(appContext, 1001, "تقارير جديدة محتاجة إجراء", "التقرير ${fresh.first().reportNumber}$more")
            }
        }
        prefs.edit().putStringSet(key, rows.map { it.id }.toHashSet()).apply()
    }

}
