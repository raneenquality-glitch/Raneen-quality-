package com.raneen.quality.data

import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * المزامنة مع Supabase. التطبيق بيشتغل أوفلاين دايمًا، والمزامنة بتحصل لما فيه إنترنت:
 *  - الأدمن: بيرفع الكتالوج (فروع/أقسام/ضوابط) لو اتعدّل
 *  - الكل: بينزّل الكتالوج والمستخدمين والتقارير
 *  - المراقب: بيرفع الصور والتقارير المُرسلة (syncState = PENDING)
 *  - المديرين: بينزّلوا صور التقارير
 */
/** امتداد ملف الوسائط (jpg للصور، mp4 للفيديو) */
private fun ext(path: String): String = File(path).extension.ifBlank { "jpg" }

/** بيتفعّل لما ترقية السيرفر (مديرو المعارض) تتأكد */
object ExhibitionFlag { val ready = MutableStateFlow(false) }

class SyncRepository(
    private val db: RaneenDatabase,
    private val remote: SupabaseRemote,
    private val appContext: Context
) {
    private val ins = db.inspectionDao()
    private val cat = db.catalogDao()
    private val users = db.userDao()
    private val prefs = appContext.getSharedPreferences("raneen_sync", Context.MODE_PRIVATE)

    val status = MutableStateFlow("لم تتم مزامنة بعد")
    /** حالة رفع تعديلات الكتالوج (للأدمن): "" = مفيش تعديل معلّق */
    val catalogState = MutableStateFlow("")
    val catalogFailed = MutableStateFlow(false)
    /** الأدمن يطلب آخر نسخة من السيرفر (بيتجاهل تعديلاته المعلّقة) */
    fun requestLatestCatalog() { prefs.edit().putBoolean("catalog_force_pull", true).apply(); kick() }
    fun catalogPending(): Boolean = prefs.getBoolean("catalog_dirty", false)
    val chatSync = ChatSync(db, remote, appContext)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val kicks = Channel<Unit>(Channel.CONFLATED)
    private val mutex = Mutex()

    // علم "فيه تعديلات لسه مترفعتش" + رقم نسخة بيزيد مع كل تعديل: عشان تعديل بيحصل أثناء الرفع/السحب ما يتمسحش
    @Synchronized fun markCatalogDirty() { catalogFailed.value = false; catalogState.value = "⏳ تعديل الكتالوج لسه ما اترفعش للسيرفر"; prefs.edit().putBoolean("catalog_dirty", true).putLong("catalog_ver", catalogVer() + 1).apply() }
    private fun catalogDirty() = prefs.getBoolean("catalog_dirty", false)
    private fun catalogVer() = prefs.getLong("catalog_ver", 0L)

    fun start(user: UserEntity) {
        stop()
        job = scope.launch {
            while (isActive) {
                syncAll(user)
                withTimeoutOrNull(60_000) { kicks.receive() }
            }
        }
    }

    fun stop() { job?.cancel(); job = null }

    /** مزامنة فورية (بعد إرسال تقرير / تعديل كتالوج / زرار "مزامنة الآن") */
    fun kick() { kicks.trySend(Unit) }

    /** مزامنة كاملة مرة واحدة (بتتنادى من الحلقة ومن الشغل الخلفي) */
    suspend fun syncAll(user: UserEntity) = mutex.withLock {
        if (remote.session()?.userId != user.id) {
            status.value = "أوفلاين — سجّل دخول بإنترنت عشان المزامنة تشتغل"
            if (catalogDirty()) { catalogFailed.value = true; catalogState.value = "✖ تعديل الكتالوج ما اترفعش — سجّل دخول بإنترنت (الجلسة مش شغالة)" }
            return@withLock
        }
        status.value = "جاري المزامنة..."
        remote.lastB2Error = null
        if (!prefs.getBoolean("photos_purged_restore_v1", false)) {
            // صور تقارير معتمدة من أقل من 30 يوم اتعلّمت "اتمسحت" بالغلط → ترجع تتنزّل وتظهر
            ins.restorePurgedWithinKeep(System.currentTimeMillis() - CLOUD_KEEP_DAYS * 24L * 3600_000L)
            prefs.edit().putBoolean("photos_purged_restore_v1", true).apply()
        }
        if (!prefs.getBoolean("photos_missing_reset_v1", false)) {
            ins.resetMissingPhotos()   // صور اتعلّمت "غير متاحة" بسبب خطأ مؤقت قبل كده
            prefs.edit().putBoolean("photos_missing_reset_v1", true).apply()
        }
        if (prefs.getBoolean("catalog_force_pull", false)) {
            prefs.edit().putBoolean("catalog_force_pull", false).putBoolean("catalog_dirty", false).remove("catalog_sig").apply()
            catalogFailed.value = false; catalogState.value = ""
        } else if (catalogDirty() && catalogState.value.isEmpty()) catalogState.value = "⏳ تعديل الكتالوج لسه ما اترفعش للسيرفر"
        var firstError: String? = null
        // كل خطوة لوحدها: لو خطوة فشلت (خطأ من السيرفر) الباقي يكمّل. مفيش إنترنت = نوقف كله.
        suspend fun step(block: suspend () -> Unit) {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: NetworkException) {
                throw e
            } catch (e: ApiException) {
                ErrorLog.w("sync", e, "code=${e.code}")
                if (firstError == null) {
                    val msg = try { JSONObject(e.body).optString("message") } catch (ex: Exception) { "" }
                    firstError = if (e.code == 401) "انتهت الجلسة — سجّل دخول تاني" else "(${e.code}) ${msg.take(80)}"
                }
            } catch (e: Exception) {
                ErrorLog.w("sync", e)
                if (firstError == null) firstError = "خطأ غير متوقع"
            }
        }
        try {
            if (user.role == Roles.ADMIN) step { pushSeedPatchesIfPending() }
            if (user.role == Roles.ADMIN) step { pushCatalogIfNeeded() }
            if (canInspect(user.role)) step { withContext(Dispatchers.IO) { retryPendingSeatReleases(user.id) } }
            if (canInspect(user.role)) step { pushReports(user) }      // المراقب ومدير المنطقة (زياراته هو بس)
            if (!Roles.readOnly(user.role)) step { withContext(Dispatchers.IO) { remote.kickTransfer() } }   // ينقل الملفات الجديدة لـ B2 في الخلفية
            if (user.role == Roles.AREA_MANAGER || user.role == Roles.DEPT_MANAGER) step { pushManagerEdits() }
            step { pullCatalog() }
            if (user.role == Roles.ADMIN) step { probeExhibition() }
            if (user.role == Roles.ADMIN) step {
                if (CensusDefaults.ensure(cat)) { markCatalogDirty(); kick() }   // ضوابط الحصر الجديدة تتبعت لكل الأجهزة
            }
            step { pullProfilesInner() }
            if (Roles.readOnly(user.role)) {
                // مشاهد الإدارة: التقارير المعتمدة (جزء إدارته بس) من دالة السيرفر، والصور بتتنزّل عند فتح التقرير بس
                step { pullViewerReports(user.role) }
            } else {
                step { pullReports(user.id) }
                step { downloadPhotos() }
            }
            // مسح الملفات من السحابة بقى على السيرفر بس (بعد التأكد من النقل وبفترة الاحتفاظ)، فالتطبيق ما بيمسحش حاجة
            step { notifyPending(user) }
            // شات الفريق: للمراقب ومدير المنطقة ونائب مدير الإدارة بس
            if (ChatAccess.allowed(user.role)) {
                step { withContext(Dispatchers.IO) { PushRegistrar.register(appContext, remote, user.id) } }
                step { chatSync.syncOnce(user.id) }
            }
            status.value = firstError?.let { "تمت المزامنة مع خطأ: $it" }
                ?: remote.lastB2Error?.let { "اتزامنت (التخزين الاحتياطي اشتغل): $it" }
                ?: ("تمت المزامنة " + SimpleDateFormat("HH:mm", Locale.US).format(Date()))
        } catch (e: CancellationException) {
            throw e
        } catch (e: NetworkException) {
            status.value = "أوفلاين — هتتزامن لما الإنترنت يرجع"
        } catch (e: Exception) {
            status.value = "تعذّرت المزامنة"
        }
    }

    /** بعد ما الأدمن يضيف/يعدّل مستخدم */
    suspend fun refreshProfiles() {
        try { pullProfilesInner() } catch (e: CancellationException) { throw e } catch (e: Exception) { /* هتتزامن في الدورة الجاية */ }
    }

    // مديرو المعارض (الأدمن)
    /** بيتأكد إن ترقية السيرفر اتعملت (الجدول موجود). لحد كده الشاشة مخفية. */
    val exhibitionReady get() = ExhibitionFlag.ready
    suspend fun probeExhibition() {
        ExhibitionFlag.ready.value = try { remote.get("/rest/v1/exhibition_branches?select=user_id&limit=1"); true }
            catch (e: CancellationException) { throw e } catch (e: Exception) { false }
    }
    /** مدير -> فروعه. بترمي استثناء لو فشل. */
    suspend fun exhibitionAssignments(): Pair<List<Triple<String, String, String>>, Map<String, Set<String>>> = withContext(Dispatchers.IO) {
        val ps = JSONArray(remote.get("/rest/v1/profiles?select=id,name,username&role=eq.EXHIBITION_MANAGER&order=name"))
        val managers = (0 until ps.length()).map { ps.getJSONObject(it) }.map { Triple(it.getString("id"), it.getString("name"), it.getString("username")) }
        val rows = JSONArray(remote.get("/rest/v1/exhibition_branches?select=user_id,branch_id&limit=5000"))
        val map = HashMap<String, MutableSet<String>>()
        for (i in 0 until rows.length()) { val o = rows.getJSONObject(i); map.getOrPut(o.getString("user_id")) { HashSet() }.add(o.getString("branch_id")) }
        managers to map
    }
    /** null = اتحفظ، غير كده نص سبب الفشل */
    suspend fun saveExhibitionBranches(userId: String, branchIds: Set<String>): String? = withContext(Dispatchers.IO) {
        try {
            val arr = JSONArray(); branchIds.forEach { arr.put(it) }
            remote.rpc("set_exhibition_branches", JSONObject().put("p_user", userId).put("p_branches", arr).toString()); null
        } catch (e: CancellationException) { throw e
        } catch (e: ApiException) { (try { JSONObject(e.body).optString("message") } catch (x: Exception) { "" }).ifBlank { "(${e.code})" }
        } catch (e: Exception) { "مفيش اتصال" }
    }

    // الكتالوج
    /**
     * أول مزامنة للأدمن بعد تحديث فيه تصحيحات كتالوج (أوزان/خصم تقييم زايد...): بنجيب نسخة السيرفر الأول
     * (عشان آخر تعديلاته ما تضيعش)، نرجّع التصحيحات فوقها، ونعلّم الكتالوج للرفع — فباقي الأجهزة تستلمه.
     * لو حصل خطأ (نت مثلًا) العلم بيفضل ويتعاد المحاولة في المزامنة الجاية.
     */
    private suspend fun pushSeedPatchesIfPending() {
        val sp = appContext.getSharedPreferences(SeedLoader.PREFS, Context.MODE_PRIVATE)
        if (!sp.getBoolean(SeedLoader.KEY_PUSH_PENDING, false)) return
        if (!catalogDirty()) {                      // مفيش تعديلات محلية معلّقة → نسخة السيرفر هي الأحدث
            prefs.edit().remove("catalog_sig").apply()   // نجبر السحب حتى لو نفس التوقيع
            pullCatalog()
        }
        SeedLoader(appContext, db).reapplyPatches()
        markCatalogDirty()
        sp.edit().putBoolean(SeedLoader.KEY_PUSH_PENDING, false).apply()
    }

    private suspend fun pushCatalogIfNeeded() {
        val dirty = catalogDirty()
        val v0 = catalogVer()
        val serverEmpty = !dirty && JSONArray(remote.get("/rest/v1/catalog_items?select=id&limit=1")).length() == 0
        if (dirty || serverEmpty) {
            try { pushCatalog() } catch (e: CancellationException) { throw e } catch (e: Exception) {
                val why = if (e is ApiException) (try { JSONObject(e.body).optString("message") } catch (x: Exception) { "" }).ifBlank { "(${e.code})" } else "مفيش اتصال"
                catalogFailed.value = true; catalogState.value = "✖ تعديل الكتالوج ما اترفعش: ${why.take(80)}"
                throw e
            }
            // نمسح العلم بس لو مفيش تعديل جديد اتعمل أثناء الرفع، وإلا الرفعة الجاية تبعته (قبل كده كان بيتمسح ويرجع للقديم)
            synchronized(this) { if (catalogVer() == v0) { prefs.edit().putBoolean("catalog_dirty", false).apply(); catalogFailed.value = false; catalogState.value = "✔ اتحفظ على السيرفر " + SimpleDateFormat("HH:mm", Locale.US).format(Date()) } }
        }
    }

    private suspend fun pushCatalog() {
        val items = JSONArray()
        fun add(kind: String, id: String, d: JSONObject) { items.put(JSONObject().put("kind", kind).put("id", id).put("data", d)) }
        cat.allBranches().forEach {
            add("branch", it.id, JSONObject().put("id", it.id).put("code", it.code).put("name", it.name)
                .put("region", it.region).put("isActive", it.isActive))
        }
        cat.allUnits().forEach {
            add("unit", it.id, JSONObject().put("id", it.id).put("templateId", it.templateId).put("name", it.name)
                .put("kind", it.kind).put("scoringMode", it.scoringMode).put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        cat.allGroups().forEach {
            add("group", it.id, JSONObject().put("id", it.id).put("unitId", it.unitId).put("name", it.name)
                .put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        cat.allCategories().forEach {
            add("category", it.id, JSONObject().put("id", it.id).put("unitId", it.unitId).put("name", it.name)
                .put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        cat.allControls().forEach {
            add("control", it.id, JSONObject().put("id", it.id).put("categoryId", it.categoryId).put("text", it.text)
                .put("maxScore", it.maxScore).put("penaltyPerViolation", it.penaltyPerViolation)
                .put("photoRequired", it.photoRequired).put("perGroup", it.perGroup)
                .put("hint", it.hint ?: JSONObject.NULL).put("sortOrder", it.sortOrder).put("isActive", it.isActive))
        }
        remote.rpc("replace_catalog", JSONObject().put("items", items).toString())
    }

    private suspend fun pullCatalog() {
        if (catalogDirty()) return                      // عندي تعديلات لسه مترفعتش — متدوسش عليها
        val v0 = catalogVer()
        val arr = fetchCatalogRows()
        val text = arr.toString()
        if (arr.length() == 0) return                   // السيرفر فاضي — سيب الكتالوج المحلي
        val sig = text.hashCode().toString() + ":" + text.length
        if (prefs.getString("catalog_sig", null) == sig) return   // مفيش تغيير

        val branches = ArrayList<BranchEntity>()
        val units = ArrayList<EvaluationUnitEntity>()
        val groups = ArrayList<ProductGroupEntity>()
        val cats = ArrayList<CategoryEntity>()
        val controls = ArrayList<ControlEntity>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val d = o.getJSONObject("data")
            when (o.getString("kind")) {
                "branch" -> branches += BranchEntity(d.getString("id"), d.getString("code"), d.getString("name"),
                    d.optString("region", ""), d.optBoolean("isActive", true))
                "unit" -> units += EvaluationUnitEntity(d.getString("id"), d.getString("templateId"), CatalogFixups.unitName(d.getString("id"), d.getString("name"), d.getString("kind")),
                    d.getString("kind"), d.optString("scoringMode", "X_COUNT"), d.optInt("sortOrder", 0), d.optBoolean("isActive", true))
                "group" -> groups += ProductGroupEntity(d.getString("id"), d.getString("unitId"), d.getString("name"),
                    d.optInt("sortOrder", 0), d.optBoolean("isActive", true))
                "category" -> cats += CategoryEntity(d.getString("id"), d.getString("unitId"), d.getString("name"),
                    d.optInt("sortOrder", 0), d.optBoolean("isActive", true))
                "control" -> controls += ControlEntity(
                    d.getString("id"), d.getString("categoryId"), d.getString("text"), d.getDouble("maxScore"),
                    d.optDouble("penaltyPerViolation", 1.0), d.optBoolean("photoRequired", true), d.optBoolean("perGroup", false),
                    CatalogFixups.controlHint(d.getString("id"), if (d.isNull("hint")) null else d.optString("hint").ifBlank { null }),
                    d.optInt("sortOrder", 0), d.optBoolean("isActive", true)
                )
            }
        }
        var applied = false
        db.withTransaction {
            // الأدمن عدّل أثناء التحميل؟ ما نمسحش تعديله بنسخة السيرفر القديمة
            if (catalogDirty() || catalogVer() != v0) return@withTransaction
            cat.upsertTemplates(listOf(TemplateEntity("main", "تقرير الجودة")))
            cat.wipeControls(); cat.wipeCategories(); cat.wipeGroups(); cat.wipeUnits(); cat.wipeBranches()
            cat.upsertUnits(units); cat.upsertGroups(groups); cat.upsertCategories(cats)
            cat.upsertControls(controls); cat.upsertBranches(branches)
            applied = true
        }
        if (applied) prefs.edit().putString("catalog_sig", sig).apply()
    }

    /** الكتالوج كله بصفحات: السيرفر بيقصّ الرد الواحد عند ~1000 صف، وكتالوج مقصوص كان بيتكتب فوق المحلي وبيرجّع الإعدادات */
    private fun fetchCatalogRows(): JSONArray {
        val all = JSONArray()
        var offset = 0
        while (true) {
            val page = JSONArray(remote.get("/rest/v1/catalog_items?select=kind,id,data&order=kind,id&limit=1000&offset=$offset"))
            if (page.length() == 0) break
            for (i in 0 until page.length()) all.put(page.get(i))
            offset += page.length()
        }
        return all
    }

    // المستخدمين
    private suspend fun pullProfilesInner() {
        val arr = JSONArray(remote.get("/rest/v1/profiles?select=id,username,name,role,is_active,must_change"))
        if (arr.length() == 0) return
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            val username = o.getString("username")
            val key = username.trim().lowercase()
            val ex = users.byId(id)
            users.deleteDupes(key, id)
            users.upsert(
                UserEntity(
                    id = id, name = o.getString("name"), username = username, usernameKey = key,
                    role = o.getString("role"),
                    passwordHash = ex?.passwordHash ?: "", salt = ex?.salt ?: "",
                    iterations = ex?.iterations ?: PasswordHasher.ITERATIONS,
                    mustChangePassword = o.optBoolean("must_change", false),
                    isActive = o.optBoolean("is_active", true)
                )
            )
            ids += id
        }
        users.deleteNotIn(ids)
    }

    // التقارير (المراقب بيرفع)
    /** المقعد بتاع المراقب في الزيارة دي من السيرفر (مقعد واحد = الجزء ده، مقعدين = BOTH). null = مفيش مقعد مسجّل. ممكن يرمي NetworkException. */
    private fun recoverSeat(insp: InspectionEntity, me: String): String? {
        val v = insp.visitNumber ?: return null
        val month = cairoMonth(insp.visitDate)
        val rows = JSONArray(remote.get("/rest/v1/visit_seats?select=seat&branch_id=eq.${insp.branchId}&template_id=eq.${insp.templateId}&visit_number=eq.$v&inspector_id=eq.$me&visit_month=eq.$month"))
        val seats = (0 until rows.length()).map { rows.getJSONObject(it).optString("seat") }.filter { it.isNotBlank() }
        val seat = when { seats.size >= 2 -> "BOTH"; seats.size == 1 -> seats[0]; else -> null }
        if (seat != null) SeatStore.set(insp.id, seat)
        return seat
    }

    /** إعادة فك المقاعد اللي فشل فكها. بتتخطى المقعد لو المراقب عنده تقرير شغّال على نفس الزيارة (عشان ما نفكش مقعد اتحجز تاني). */
    private suspend fun retryPendingSeatReleases(me: String) {
        for (e in SeatStore.pendingReleases()) {
            val p = e.split("|")
            if (p.size != 4) { SeatStore.dropRelease(e); continue }
            val active = ins.sameVisitCandidates(p[0], p[1], p[2], "").any { it.inspectorId == me && (it.status == Status.DRAFT || it.syncState == "PENDING") }
            if (active || VisitSeats.releaseSettled(remote, p[0], p[1], p[2], p[3])) SeatStore.dropRelease(e)
        }
    }

    private suspend fun pushReports(user: UserEntity) {
        var seatErr: ApiException? = null
        val unitKind = cat.allUnits().associate { it.id to it.kind }
        for (insp in ins.pendingInspections().filter { it.inspectorId == user.id }) {
            // تقرير فشل رفعه بخطأ من السيرفر: نستنى شوية قبل المحاولة الجاية (بدل ما نكرّر كل دقيقة)
            if (UploadBackoff.blocked(insp.id)) continue
            try {
                // المقعد: السيرفر بيرفض أي قسم برا المقعد، فنبعت بس أقسام المقعد (البيانات المحلية ما بتتمسحش)
                // لو المقعد مش محفوظ على الجهاز (بيانات اتمسحت/جهاز تاني): نسترجعه من السيرفر بدل ما نبعت كل الأقسام
                val seat = SeatStore.getOrNull(insp.id) ?: recoverSeat(insp, user.id)
                fun inSeat(unitId: String) = unitKind[unitId]?.let { SeatStore.allows(seat, it) } ?: true
                val findings = ins.findingsOf(insp.id).filter { inSeat(it.unitId) }
                val keep = findings.map { it.id }.toSet()
                val photos = ins.photosOfInspection(insp.id).filter { it.findingId in keep }

                // الصور الأول: 3 مع بعض، ونسخة خفيفة للرفع (الأصل يفضل على الموبايل)
                val todo = photos.filter { it.syncState != "SYNCED" && File(it.filePath).exists() }
                val gate = Semaphore(3)
                val done = AtomicInteger(0)
                coroutineScope {
                    todo.map { p ->
                        async(Dispatchers.IO) {
                            gate.withPermit {
                                val src = File(p.filePath)
                                val isVideo = src.extension.equals("mp4", true)
                                val toSend = if (isVideo) src else PhotoStamper.uploadCopy(src, File(appContext.cacheDir, "up_${p.id}.jpg"))
                                try {
                                    remote.upload("${user.id}/${insp.id}/${p.id}.${ext(p.filePath)}", toSend)
                                } finally {
                                    if (toSend !== src) toSend.delete()
                                }
                                ins.setPhotoSync(p.id, "SYNCED")   // لو انقطع، اللي اترفع مش بيتعاد
                                status.value = "جاري رفع الصور ${done.incrementAndGet()}/${todo.size}"
                            }
                        }
                    }.awaitAll()
                }

                val data = buildReportData(insp, findings, photos, seat, unitKind)
                try {
                    remote.rpc(
                        "submit_report",
                        JSONObject().put("p_id", insp.id).put("p_report_number", insp.reportNumber)
                            .put("p_branch_id", insp.branchId).put("p_data", data).toString()
                    )
                    ins.setSync(insp.id, "SYNCED")
                    UploadBackoff.clear(insp.id)
                } catch (e: ApiException) {
                    if (e.body.contains("locked")) { ins.setSync(insp.id, "SYNCED"); UploadBackoff.clear(insp.id) } else throw e
                }
            } catch (e: ApiException) {
                // تقرير مرفوض بسبب المقعد ما يوقفش باقي التقارير
                if (e.body.contains("outside your seat")) { if (seatErr == null) seatErr = e }
                else { if (e.code != 401) UploadBackoff.fail(insp.id); ErrorLog.w("pushReport", e, "code=${e.code}"); throw e }
            } catch (e: CancellationException) {
                throw e
            } catch (e: NetworkException) {
                throw e
            } catch (e: Exception) {
                UploadBackoff.fail(insp.id); ErrorLog.w("pushReport", e); throw e
            }
        }
        seatErr?.let { throw it }   // عشان الخطأ يفضل ظاهر في الحالة
    }

    /** نفس شكل البيانات اللي بيتخزن على السيرفر (المراقب بيرفعه، والمدير بيبعت منه units/findings بس عند التعديل) */
    private suspend fun buildReportData(
        insp: InspectionEntity, findings: List<FindingEntity>, photos: List<PhotoEntity>,
        seat: String? = null, unitKind: Map<String, String> = emptyMap()
    ): JSONObject {
        val unitsArr = JSONArray()
        ins.unitStates(insp.id).filter { u -> unitKind[u.unitId]?.let { SeatStore.allows(seat, it) } ?: true }.forEach { unitsArr.put(JSONObject().put("unitId", it.unitId).put("isNA", it.isNA)) }
        val findingsArr = JSONArray()
        findings.forEach {
            findingsArr.put(JSONObject().put("id", it.id).put("unitId", it.unitId).put("controlId", it.controlId)
                .put("groupId", it.groupId).put("violationCount", it.violationCount).put("note", it.note ?: JSONObject.NULL)
                .put("violationNote", it.violationNote ?: JSONObject.NULL))
        }
        val photosArr = JSONArray()
        photos.forEach { photosArr.put(JSONObject().put("id", it.id).put("findingId", it.findingId).put("capturedAt", it.capturedAt).put("ext", ext(it.filePath))) }
        return JSONObject()
            .put("inspection", JSONObject().put("id", insp.id).put("reportNumber", insp.reportNumber)
                .put("templateId", insp.templateId).put("branchId", insp.branchId)
                .put("inspectorId", insp.inspectorId).put("visitDate", insp.visitDate)
                .put("visitNumber", insp.visitNumber ?: "").put("notes", insp.notes ?: ""))
            .put("units", unitsArr).put("findings", findingsArr).put("photos", photosArr)
    }

    /** تعديلات المدير (مدير منطقة/إدارة) قبل الاعتماد النهائي — بتتبعت لدالة السيرفر manager_edit_report */
    private suspend fun pushManagerEdits() {
        for (insp in ins.pendingManagerEdits()) {
            val data = buildReportData(insp, ins.findingsOf(insp.id), ins.photosOfInspection(insp.id))
            try {
                remote.rpc("manager_edit_report", JSONObject().put("p_id", insp.id).put("p_data", data).toString())
                ins.setSync(insp.id, "SYNCED")
            } catch (e: ApiException) {
                // التقرير اتقفل/اتغيّرت حالته على السيرفر: نبطّل نحاول، والسحب الجاي هيجيب النسخة الحالية
                if (e.body.contains("locked") || e.body.contains("not allowed")) ins.setSync(insp.id, "SYNCED") else throw e
            }
        }
    }

    // التقارير (تنزيل)
    /**
     * سحب تدريجي: بنجيب بس التقارير اللي اتغيّرت بعد آخر مرة (updated_at) بدل كل التقارير كل دورة.
     * المؤشر (cursor) مابيتقدّمش لو تقرير اتخطّى (لسه عليه تعديل محلي معلّق) عشان نرجع له في الدورة الجاية.
     * وكل 6 ساعات (أو لو الداتابيز المحلية فاضية) بنعمل سحب كامل كشبكة أمان.
     */
    private suspend fun pullReports(uid: String) {
        val curKey = "pull_cur_$uid"; val fullKey = "pull_full_$uid"
        val now = System.currentTimeMillis()
        val full = now - prefs.getLong(fullKey, 0L) > 6L * 3600_000L || ins.inspectionCount() == 0
        var fetchFrom: String? = if (full) null else prefs.getString(curKey, null)
        var saved: String? = fetchFrom
        var blocked = false
        val page = 100
        while (true) {
            val filter = fetchFrom?.let { "&updated_at=gt." + java.net.URLEncoder.encode(it, "UTF-8") } ?: ""
            val arr = JSONArray(remote.get("/rest/v1/reports?select=id,inspector_id,report_number,branch_id,status,data,audit,updated_at$filter&order=updated_at.asc&limit=$page"))
            if (arr.length() == 0) break
            var last: String? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ok = try { importOrUpdate(o) } catch (e: org.json.JSONException) { true /* شكل غير متوقع — نتخطاه */ }
                o.optString("updated_at").takeIf { it.isNotBlank() }?.let { last = it }
                if (!ok) blocked = true
                if (!blocked) last?.let { saved = it }
            }
            if (arr.length() < page || last == null || last == fetchFrom) break
            fetchFrom = last
        }
        saved?.let { prefs.edit().putString(curKey, it).apply() }
        if (full && !blocked) prefs.edit().putLong(fullKey, now).apply()
    }

    /** ids التقارير اللي وصلت للمشاهد من السيرفر (المعتمدة وجزء إدارته بس). أي تقرير تاني على الموبايل (مثلًا من مستخدم قبله) مش بيظهر له. */
    fun viewerReportIds(userId: String): Set<String> = prefs.getStringSet("viewer_ids_$userId", emptySet()) ?: emptySet()

    /** مشاهد الإدارة: بيسحب التقارير المعتمدة نهائيًا، السيرفر بيفلتر على وحدات المشاهد بس */
    private suspend fun pullViewerReports(role: String = Roles.VIEWER) {
        val fn = if (role == Roles.EXHIBITION_MANAGER) "exhibition_reports" else "viewer_reports"
        val uid = remote.session()?.userId ?: return
        val idsKey = "viewer_ids_$uid"
        val ids = HashSet(prefs.getStringSet(idsKey, emptySet()) ?: emptySet())
        val curKey = (if (role == Roles.EXHIBITION_MANAGER) "exh_cur_v1_" else "viewer_cur_v2_") + uid   // v2: إعادة سحب كامل مرة واحدة بعد إصلاح دالة السيرفر
        var since: String? = prefs.getString(curKey, null)
        while (true) {
            val body = JSONObject().put("p_limit", 100).apply { if (since != null) put("p_since", since) }
            val arr = JSONArray(remote.rpc(fn, body.toString()))
            if (arr.length() == 0) break
            var last: String? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                o.put("audit", JSONArray())      // السيرفر مبيبعتش سجل المراجعة للمشاهد
                try {
                    importOrUpdate(o, viewer = true)
                    ids.add(o.getString("id"))
                    prefs.edit().putStringSet(idsKey, HashSet(ids)).apply()
                } catch (e: org.json.JSONException) { /* شكل غير متوقع — نتخطاه */ }
                o.optString("updated_at").takeIf { it.isNotBlank() }?.let { last = it }
            }
            if (last == null || last == since) break
            since = last
            prefs.edit().putString(curKey, last).apply()
            if (arr.length() < 100) break
        }
    }

    /** بيرجّع false لو التقرير اتخطّى لأن عليه تعديل محلي لسه ماترفعش (عشان المؤشر ما يعدّيهوش) */
    private suspend fun importOrUpdate(o: JSONObject, viewer: Boolean = false): Boolean {
        val id = o.getString("id")
        val status = o.getString("status")
        val auditArr = o.getJSONArray("audit")
        val audits = ArrayList<AuditEntity>()
        for (k in 0 until auditArr.length()) {
            val a = auditArr.getJSONObject(k)
            audits += AuditEntity(
                a.getString("id"), id, a.getString("action"), a.optString("actorName", ""), a.optString("actorRole", ""),
                if (a.isNull("note")) null else a.optString("note").ifBlank { null }, a.getLong("at")
            )
        }
        val local = ins.inspection(id)
        if (local != null && (local.syncState == "PENDING" || local.syncState == "PENDING_EDIT")) return false
        if (local == null) {
            val d = o.getJSONObject("data")
            val i = d.getJSONObject("inspection")
            val units = ArrayList<InspectionUnitEntity>()
            d.getJSONArray("units").let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let { units += InspectionUnitEntity(id, it.getString("unitId"), it.optBoolean("isNA", false)) } }
            val findings = ArrayList<FindingEntity>()
            d.getJSONArray("findings").let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let {
                findings += FindingEntity(it.getString("id"), id, it.getString("unitId"), it.getString("controlId"),
                    it.optString("groupId", ""), it.optInt("violationCount", 0), if (it.isNull("note")) null else it.optString("note"),
                    if (it.isNull("violationNote")) null else it.optString("violationNote"))
            } }
            val photoDir = File(appContext.filesDir, "photos")
            val photos = ArrayList<PhotoEntity>()
            d.getJSONArray("photos").let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let {
                val pid = it.getString("id")
                val taken = it.optLong("capturedAt", 0L)
                // الصور بتفضل على السحابة 30 يوم بعد الاعتماد النهائي: التعليم "اتمسحت" مابيتمش من التطبيق، مش وقت الاستيراد
                val gone = false
                val e = it.optString("ext", "jpg").ifBlank { "jpg" }
                photos += PhotoEntity(pid, it.getString("findingId"), File(photoDir, "$pid.$e").path, taken, if (gone) "PURGED" else "REMOTE")
            } }
            db.withTransaction {
                ins.upsertInspection(
                    InspectionEntity(id, i.getString("reportNumber"), i.getString("templateId"), i.getString("branchId"),
                        i.getString("inspectorId"), i.getLong("visitDate"),
                        visitNumber = i.optString("visitNumber", "").ifBlank { null }, status = status, notes = i.optString("notes", "").ifBlank { null }, syncState = "SYNCED")
                )
                ins.upsertUnitStates(units); ins.upsertFindings(findings); ins.upsertPhotos(photos)
                ins.deleteAudit(id); ins.upsertAudits(audits)
            }
        } else if (local.syncState != "PENDING" && local.syncState != "PENDING_EDIT" && (local.status != status || ins.auditCount(id) != audits.size || contentDiffers(id, o))) {
            // لو حد (مدير) عدّل المحتوى: ننزّل النتائج المعدّلة (upsert بنفس الـ ids — الصور المحلية متتلمسش)
            val d = o.optJSONObject("data")
            val freshFindings = ArrayList<FindingEntity>()
            val freshUnits = ArrayList<InspectionUnitEntity>()
            d?.optJSONArray("findings")?.let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let {
                freshFindings += FindingEntity(it.getString("id"), id, it.getString("unitId"), it.getString("controlId"),
                    it.optString("groupId", ""), it.optInt("violationCount", 0), if (it.isNull("note")) null else it.optString("note"),
                    if (it.isNull("violationNote")) null else it.optString("violationNote"))
            } }
            d?.optJSONArray("units")?.let { a -> for (k in 0 until a.length()) a.getJSONObject(k).let { freshUnits += InspectionUnitEntity(id, it.getString("unitId"), it.optBoolean("isNA", false)) } }
            db.withTransaction {
                ins.setStatus(id, status); ins.setSync(id, "SYNCED")
                ins.deleteAudit(id); ins.upsertAudits(audits)
                if (freshFindings.isNotEmpty()) ins.upsertFindings(freshFindings)
                if (freshUnits.isNotEmpty()) ins.upsertUnitStates(freshUnits)
                // (اتشال: كان بيعلّم الصور "اتمسحت" لحظة الاعتماد النهائي رغم إنها لسه على السحابة 30 يوم)
            }
        }
        return true
    }

    /** هل محتوى النتائج على السيرفر مختلف عن المحلي؟ (تعديل مدير من غير تغيير الحالة أو الـ audit) */
    private suspend fun contentDiffers(id: String, o: JSONObject): Boolean {
        val arr = o.optJSONObject("data")?.optJSONArray("findings") ?: return false
        val remote = HashSet<String>()
        for (k in 0 until arr.length()) arr.getJSONObject(k).let {
            remote += listOf(it.getString("id"), it.optInt("violationCount", 0),
                if (it.isNull("note")) "" else it.optString("note"),
                if (it.isNull("violationNote")) "" else it.optString("violationNote")).joinToString("\u0001")
        }
        val localSet = ins.findingsOf(id).map { listOf(it.id, it.violationCount, it.note.orEmpty(), it.violationNote.orEmpty()).joinToString("\u0001") }.toHashSet()
        return !localSet.containsAll(remote)
    }

    /** محاولة تانية بعد ثانية لو الخطأ مؤقت (ضغط على الوظيفة أو السيرفر) — التوازي ممكن يسبّب ده */
    private suspend fun downloadWithRetry(path: String, file: File) {
        try { remote.download(path, file) }
        catch (e: ApiException) {
            if (e.code in PERMANENT_CODES) throw e
            kotlinx.coroutines.delay(1000)
            remote.download(path, file)
        }
    }

    private suspend fun downloadPhotos() = coroutineScope {
        val gate = Semaphore(DOWNLOAD_PARALLEL)
        val remotes = ins.remotePhotos()
        withContext(Dispatchers.IO) { remote.prefetchUrls(remotes.map { "${it.inspectorId}/${it.inspectionId}/${it.photoId}.${ext(it.filePath)}" }) }
        remotes.map { r ->
            async {
                gate.withPermit {
                    try {
                        downloadWithRetry("${r.inspectorId}/${r.inspectionId}/${r.photoId}.${ext(r.filePath)}", File(r.filePath))
                        ins.setPhotoSync(r.photoId, "SYNCED")
                    } catch (e: ApiException) {
                        // "ناقصة" بس لو السيرفر قال صراحة إنها مش موجودة/مش مسموحة. أي خطأ مؤقت (ضغط/5xx/429) يتعاد في المزامنة الجاية.
                        if (e.code in PERMANENT_CODES) ins.setPhotoSync(r.photoId, "MISSING")
                    }
                }
            }
        }.awaitAll()
        Unit
    }

    /**
     * تنزيل مجموعة صور بالتوازي (قبل كده واحدة ورا واحدة، وكل صورة بتطلب رابط من الوظيفة الأول = بطيء جدًا).
     * بيرجّع رسالة خطأ أو null. onProgress بيتنادى كل 8 صور عشان الشاشة تعرض اللي نزل أول بأول.
     */
    private suspend fun downloadParallel(
        inspectorId: String, inspectionId: String, list: List<PhotoEntity>,
        netMsg: String, failMsg: (Int) -> String, missingCodes: Set<Int>, onProgress: () -> Unit = {}
    ): String? = coroutineScope {
        val gate = Semaphore(DOWNLOAD_PARALLEL)
        val done = AtomicInteger(0)
        withContext(Dispatchers.IO) { remote.prefetchUrls(list.map { "$inspectorId/$inspectionId/${it.id}.${ext(it.filePath)}" }) }
        var noNet = false
        var err: String? = null
        list.map { p ->
            async {
                gate.withPermit {
                    if (noNet) return@withPermit
                    try {
                        downloadWithRetry("$inspectorId/$inspectionId/${p.id}.${ext(p.filePath)}", File(p.filePath))
                        ins.setPhotoSync(p.id, "SYNCED")
                        if (done.incrementAndGet() % 8 == 0) onProgress()
                    } catch (e: NetworkException) {
                        noNet = true
                    } catch (e: ApiException) {
                        if (e.code in missingCodes) ins.setPhotoSync(p.id, "MISSING") else err = failMsg(e.code)
                    }
                }
            }
        }.awaitAll()
        if (noNet) netMsg else err
    }

    /** تنزيل فيديو واحد عند الطلب (الفيديو مبيتنزّلش تلقائي عشان نقل البيانات المجاني محدود) */
    suspend fun downloadMedia(inspectorId: String, inspectionId: String, p: PhotoEntity): String? = withContext(Dispatchers.IO) {
        try {
            remote.download("$inspectorId/$inspectionId/${p.id}.${ext(p.filePath)}", File(p.filePath))
            ins.setPhotoSync(p.id, "SYNCED")
            null
        } catch (e: NetworkException) {
            "محتاج إنترنت لتنزيل الفيديو"
        } catch (e: ApiException) {
            if (e.code == 404 || e.code == 400) { ins.setPhotoSync(p.id, "MISSING"); "الفيديو مش موجود على السيرفر" }
            else "تعذّر التنزيل (${e.code})"
        }
    }

    /** حالة ملفات التقرير على السيرفر (رفع / نقل للأرشيف / إعادة محاولة) لعرضها في شاشة التقرير */
    suspend fun mediaStatus(inspectionId: String): String? = withContext(Dispatchers.IO) {
        try {
            val o = JSONObject(remote.rpc("media_status", JSONObject().put("p_inspection", inspectionId).toString()))
            val total = o.optInt("total")
            if (total == 0) return@withContext null
            val parts = arrayListOf("الملفات: $total مرفوعة")
            if (o.optInt("archived") > 0) parts += "${o.optInt("archived")} محفوظة في الأرشيف"
            if (o.optInt("pending") > 0) parts += "${o.optInt("pending")} في انتظار النقل"
            if (o.optInt("failed") > 0) parts += "${o.optInt("failed")} بيعيد المحاولة"
            if (o.optInt("expired") > 0) parts += "${o.optInt("expired")} مؤرشفة (الأدمن يسترجعها)"
            parts.joinToString(" · ")
        } catch (e: Exception) { null }
    }

    /** مشاهد الإدارة: بنزّل صور (مش فيديو) التقرير المفتوح بس، والفيديو بيتنزّل لما يتضغط عليه */
    suspend fun ensureImages(inspectionId: String, onProgress: () -> Unit = {}): String? = withContext(Dispatchers.IO) {
        val insp = ins.inspection(inspectionId) ?: return@withContext "التقرير غير موجود"
        val todo = ins.photosOfInspection(inspectionId).filter { it.syncState == "REMOTE" && !ext(it.filePath).equals("mp4", true) }
        downloadParallel(insp.inspectorId, inspectionId, todo, "محتاج إنترنت عشان تتنزّل الصور",
            { c -> "تعذّر تنزيل بعض الصور ($c)" }, setOf(404, 400, 403), onProgress)
    }

    /** قبل الاعتماد النهائي: لازم كل صور التقرير تكون على الموبايل (لأنها هتتمسح من السحابة بعد الاعتماد) */
    suspend fun ensurePhotos(inspectionId: String): String? = withContext(Dispatchers.IO) {
        val insp = ins.inspection(inspectionId) ?: return@withContext "التقرير غير موجود"
        val todo = ins.photosOfInspection(inspectionId).filter { it.syncState == "REMOTE" }
        downloadParallel(insp.inspectorId, inspectionId, todo, "محتاج إنترنت عشان تتنزّل كل الصور قبل الاعتماد النهائي",
            { c -> "تعذّر تنزيل الصور من السيرفر ($c)" }, setOf(404, 400))
    }

    /** عدد الأيام اللي صور التقرير بتفضل فيها على السحابة بعد الاعتماد النهائي */
    private companion object { const val CLOUD_KEEP_DAYS = 30; const val DOWNLOAD_PARALLEL = 4; val PERMANENT_CODES = setOf(400, 403, 404) }

    // التنبيهات
    private suspend fun notifyPending(user: UserEntity) {
        val rows = when (user.role) {
            Roles.AREA_MANAGER -> ins.refsByStatus(Status.SUBMITTED)
            Roles.DEPT_MANAGER -> ins.refsByStatus(Status.REVIEWED)
            Roles.INSPECTOR -> ins.returnedFor(user.id)
            else -> emptyList()
        }
        val key = "notified_${user.id}"
        val old = prefs.getStringSet(key, emptySet()) ?: emptySet()
        val fresh = rows.filter { it.id !in old }
        if (fresh.isNotEmpty()) {
            if (user.role == Roles.INSPECTOR) {
                Notifier.post(appContext, 1001, "تقرير اترجّع للتعديل", "التقرير ${fresh.first().reportNumber} محتاج تعديل منك")
            } else {
                val more = if (fresh.size > 1) " (و${fresh.size - 1} غيره)" else ""
                Notifier.post(appContext, 1001, "تقارير جديدة محتاجة إجراء", "التقرير ${fresh.first().reportNumber}$more")
            }
        }
        prefs.edit().putStringSet(key, rows.map { it.id }.toHashSet()).apply()
    }

}
