package com.raneen.quality.data

import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.raneen.quality.R
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** تصدير التقرير: PDF / Word (.docx) / Excel (.xlsx) — التلاتة فيهم الصور المتاحة على الجهاز. */
object ReportExporter {
    const val MIME_PDF = "application/pdf"
    const val MIME_DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    private val RED = Color.rgb(200, 16, 46)
    private val RED_SOFT = Color.rgb(253, 236, 239)
    private val DARK = Color.rgb(34, 34, 34)
    private val GRAY = Color.rgb(110, 110, 110)
    private val LIGHT = Color.rgb(245, 245, 245)
    private val LINE = Color.rgb(225, 225, 225)
    private val GREEN = Color.rgb(29, 122, 77)
    private val ORANGE = Color.rgb(224, 138, 0)
    private val BLUE = Color.rgb(21, 101, 192)
    private val PURPLE = Color.rgb(106, 27, 154)

    private fun fmt(t: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t))
    private fun pct(v: Double?) = if (v == null) "—" else String.format(Locale.US, "%.1f%%", v)
    private fun num(v: Double) = String.format(Locale.US, "%.1f", v)
    private fun scoreColor(p: Double?) = when { p == null -> GRAY; p >= 90 -> GREEN; p >= 75 -> ORANGE; else -> RED }
    private fun hex(c: Int) = String.format("%02X%02X%02X", Color.red(c), Color.green(c), Color.blue(c))
    private fun statusColor(s: String) = when (s) {
        Status.SUBMITTED -> BLUE; Status.REVIEWED -> PURPLE; Status.RETURNED -> RED; Status.FINAL -> GREEN; else -> GRAY
    }
    private fun visitTxt(r: ReportData): String? = when (r.inspection.visitNumber) { "1" -> "الزيارة الأولى"; "2" -> "الزيارة الثانية"; else -> null }
    private fun groupLabel(v: ViolationRow) = if (v.groupName.isNullOrBlank()) "" else " (${v.groupName})"

    private val operationsOrder = listOf(
        "قسم الأدوات المنزلية", "قسم الألعاب ومستلزمات الأطفال", "قسم المفروشات",
        "قسم الكهرباء", "قسم الخدمات وعمال التحميل", "قسم مدير المعرض"
    )
    private val supportOrder = listOf(
        "إدارة خدمة العملاء", "إدارة الكاشير", "إدارة الكاميرات", "إدارة الأمن",
        "إدارة الاستلامات", "إدارة الصيانة", "إدارة التكييفات", "إدارة الموارد البشرية"
    )
    private fun orderIndex(name: String, kind: String): Int {
        val normalized = name.replace("إ", "ا").replace("أ", "ا").replace("آ", "ا").replace(" ", "")
        val list = if (kind == "SECTION") operationsOrder else supportOrder
        return list.indexOfFirst { target ->
            val t = target.replace("إ", "ا").replace("أ", "ا").replace("آ", "ا").replace(" ", "")
            normalized.contains(t) || t.contains(normalized)
        }.let { if (it < 0) Int.MAX_VALUE else it }
    }
    private fun orderedUnits(r: ReportData, kind: String) = r.units.filter { it.unit.kind == kind }
        .sortedWith(compareBy<UnitLine>({ orderIndex(it.unit.name, kind) }, { it.unit.sortOrder }, { it.unit.name }))
    private fun orderedViolations(r: ReportData) = r.violations.sortedWith(
        compareBy<ViolationRow>({ if (r.units.firstOrNull { u -> u.unit.id == it.unitId }?.unit?.kind == "ADMINISTRATION") 1 else 0 },
            { orderIndex(it.unitName, if (r.units.firstOrNull { u -> u.unit.id == it.unitId }?.unit?.kind == "ADMINISTRATION") "ADMINISTRATION" else "SECTION") },
            { it.unitName }, { it.controlNo })
    )
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun outFile(ctx: Context, r: ReportData, ext: String): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        return File(dir, "Raneen_${r.inspection.reportNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")}.$ext")
    }

    /** صور المخالفة اللي موجودة فعلًا على الجهاز */
    private fun mediaFiles(r: ReportData, v: ViolationRow): List<File> =
        r.photosByFinding[v.findingId].orEmpty().map { File(it.filePath) }.filter { it.exists() }

    private fun photoFiles(r: ReportData, v: ViolationRow): List<File> = mediaFiles(r, v).filter { !it.name.endsWith(".mp4", true) }

    private fun videoCount(r: ReportData, v: ViolationRow): Int = mediaFiles(r, v).count { it.name.endsWith(".mp4", true) }

    private fun hasGonePhotos(r: ReportData, v: ViolationRow): Boolean =
        r.photosByFinding[v.findingId].orEmpty().isNotEmpty() && mediaFiles(r, v).isEmpty()

    /**
     * الصورة اللي بتتحط جوه Word/Excel: نسخة أصغر (ضلع أقصى 1600px، جودة 85) عشان الملف ما يبقاش مئات الميجا والذاكرة ما تخلصش.
     * الصور الأصلية بدقتها الكاملة بتفضل في ملف الـ ZIP (وفي الـ PDF).
     */
    private fun embedBytes(f: File): ByteArray {
        val (w, h) = bounds(f) ?: return f.readBytes()
        var sample = 1
        while (maxOf(w, h) / (sample * 2) >= 1600) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return f.readBytes()
        return try {
            java.io.ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
        } finally { bmp.recycle() }
    }

    private fun bounds(f: File): Pair<Int, Int>? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        return if (o.outWidth > 0 && o.outHeight > 0) o.outWidth to o.outHeight else null
    }

    // ═════════════════════ PDF ═════════════════════
    private class Pdf(private val doc: PdfDocument, private val regular: Typeface, private val boldFace: Typeface, private val logo: Bitmap?, private val reportNumber: String) {
        val w = 595
        val h = 842
        val m = 32
        val cw = w - 2 * m
        private var n = 1
        private var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create())
        var y = 100f
        private val canvas: Canvas get() = page.canvas
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

        init { drawHeader() }

        private fun drawHeader() {
            rect(0f, 0f, w.toFloat(), 76f, RED)
            draw(layout("تقرير جودة", 22f, true, Color.WHITE, 300), (w - m - 300).toFloat(), 12f)
            draw(layout("شركة رنين — إدارة الجودة", 10f, false, Color.rgb(255, 220, 226), 300), (w - m - 300).toFloat(), 43f)
            draw(layout(reportNumber, 9f, true, Color.WHITE, 190, Layout.Alignment.ALIGN_OPPOSITE), m.toFloat(), 28f)
            logo?.let { bmp ->
                val target = RectF((w - m - 48).toFloat(), 10f, (w - m).toFloat(), 58f)
                canvas.drawBitmap(bmp, null, target, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            }
        }

        fun rect(x: Float, yy: Float, ww: Float, hh: Float, color: Int, r: Float = 0f) {
            fill.style = Paint.Style.FILL; fill.color = color
            if (r > 0f) canvas.drawRoundRect(RectF(x, yy, x + ww, yy + hh), r, r, fill) else canvas.drawRect(x, yy, x + ww, yy + hh, fill)
        }

        fun layout(t: String, size: Float, bold: Boolean, color: Int, width: Int, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size; this.color = color
                typeface = if (bold) boldFace else regular
            }
            return StaticLayout.Builder.obtain(t, 0, t.length, tp, maxOf(width, 10))
                .setAlignment(align).setTextDirection(TextDirectionHeuristics.RTL).build()
        }

        fun draw(sl: StaticLayout, x: Float, yy: Float) {
            canvas.save(); canvas.translate(x, yy); sl.draw(canvas); canvas.restore()
        }

        private fun footer() {
            rect(m.toFloat(), (h - m - 8).toFloat(), cw.toFloat(), 0.6f, LINE)
            draw(layout("رنين — إدارة الجودة", 8f, false, GRAY, cw / 2), (w - m - cw / 2).toFloat(), (h - m - 4).toFloat())
            draw(layout("صفحة $n", 8f, false, GRAY, 100, Layout.Alignment.ALIGN_OPPOSITE), m.toFloat(), (h - m - 4).toFloat())
        }

        fun newPage() {
            footer(); doc.finishPage(page); n++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create()); y = 100f
            drawHeader()
        }

        fun ensure(hh: Float) { if (y + hh > h - m - 14) newPage() }

        fun finish() { footer(); doc.finishPage(page) }

        fun chip(text: String, color: Int, rightX: Float, yy: Float): Float {
            val sl = layout(text, 10f, true, Color.WHITE, 200, Layout.Alignment.ALIGN_CENTER)
            var tw = 0f
            for (i in 0 until sl.lineCount) tw = maxOf(tw, sl.getLineWidth(i))
            val cwid = tw + 18f
            rect(rightX - cwid, yy, cwid, sl.height + 6f, color, 9f)
            draw(layout(text, 10f, true, Color.WHITE, cwid.toInt(), Layout.Alignment.ALIGN_CENTER), rightX - cwid, yy + 3f)
            return cwid
        }

        fun thumb(f: File, tw: Int): Bitmap? {
            val b = bounds(f) ?: return null
            val src = BitmapFactory.Options().apply { inSampleSize = maxOf(1, b.first / (tw * 2)) }.let { BitmapFactory.decodeFile(f.path, it) } ?: return null
            return Bitmap.createScaledBitmap(src, tw, maxOf(1, src.height * tw / src.width), true)
        }

        fun photos(files: List<File>) {
            val tw = 150f
            val gap = 8
            val startX = w - m - 14 - tw
            var x = startX
            var rowH = 0f
            for (f in files) {
                val bmp = thumb(f, 420) ?: continue          // 420 بكسل بتتعرض في 150 نقطة = جودة أحسن عند التكبير
                val th = bmp.height * tw / bmp.width
                if (x < m + 4) { y += rowH + gap; x = startX; rowH = 0f }
                if (y + th > h - m - 14) { newPage(); x = startX; rowH = 0f }
                rect(x - 1.5f, y - 1.5f, tw + 3f, th + 3f, LINE, 3f)
                canvas.drawBitmap(bmp, null, RectF(x, y, x + tw, y + th), null)
                rowH = maxOf(rowH, th)
                x -= (tw + gap)
            }
            y += rowH + 10f
        }
    }

    fun pdf(ctx: Context, r: ReportData): File {
        val file = outFile(ctx, r, "pdf")
        val doc = PdfDocument()
        // خط ثابت (static) من التطبيق نفسه: خط الجهاز المتغيّر بيبوّظ الحروف العربي جوه PDF
        val reg = try { Typeface.createFromAsset(ctx.assets, "fonts/DejaVuSans.ttf") } catch (e: Exception) { Typeface.DEFAULT }
        val bld = try { Typeface.createFromAsset(ctx.assets, "fonts/DejaVuSans-Bold.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        val logo = try { BitmapFactory.decodeResource(ctx.resources, R.drawable.ic_splash_logo) } catch (_: Exception) { null }
        val p = Pdf(doc, reg, bld, logo, r.inspection.reportNumber)
        val left = p.m.toFloat()
        val right = (p.w - p.m).toFloat()

        // ── بطاقة البيانات
        val cellW = (p.cw - 28) / 2
        val items = listOf(
            "الفرع" to r.branchName.ifBlank { "—" }, "تاريخ الزيارة" to fmt(r.inspection.visitDate),
            "المراقب" to r.inspectorName.ifBlank { "—" }, "الحالة" to Status.label(r.inspection.status)
        ) + (visitTxt(r)?.let { listOf("رقم الزيارة" to it) } ?: emptyList())
        var cardH = 14f
        val ls = items.map { (k, v) -> p.layout(k, 9f, false, GRAY, cellW) to p.layout(v, 12f, true, DARK, cellW) }
        val rowHs = ls.chunked(2).map { row -> row.maxOf { it.first.height + it.second.height } + 10f }
        cardH += rowHs.sum() + 4f
        p.rect(left, p.y, p.cw.toFloat(), cardH, LIGHT, 10f)
        var cy = p.y + 10f
        ls.chunked(2).forEachIndexed { i, row ->
            row.forEachIndexed { j, (kl, vl) ->
                val x = if (j == 0) right - 14f - cellW else left + 14f
                p.draw(kl, x, cy); p.draw(vl, x, cy + kl.height)
            }
            cy += rowHs[i]
        }
        p.y += cardH + 14f
        if (!r.inspection.notes.isNullOrBlank()) {
            val noteLayout = p.layout("ملاحظات الزيارة العامة: ${r.inspection.notes}", 11f, false, DARK, p.cw - 20)
            p.ensure(noteLayout.height + 18f)
            p.rect(left, p.y, p.cw.toFloat(), noteLayout.height + 14f, LIGHT, 6f)
            p.draw(noteLayout, left + 10f, p.y + 7f)
            p.y += noteLayout.height + 22f
        }

        // ── كروت المتوسطات
        val bw = (p.cw - 16) / 3f
        fun scoreCard(x: Float, label: String, v: Double?) {
            p.rect(x, p.y, bw, 70f, Color.WHITE, 10f)
            p.rect(x, p.y, bw, 70f, LINE, 10f)
            p.rect(x + 1f, p.y + 1f, bw - 2f, 68f, Color.WHITE, 9f)
            p.rect(x + 1f, p.y + 1f, 5f, 68f, scoreColor(v), 2f)
            p.draw(p.layout(pct(v), 21f, true, scoreColor(v), bw.toInt(), Layout.Alignment.ALIGN_CENTER), x, p.y + 10f)
            p.draw(p.layout(label, 9f, false, GRAY, bw.toInt(), Layout.Alignment.ALIGN_CENTER), x, p.y + 45f)
        }
        val overall = listOfNotNull(r.sectionsAvg, r.adminsAvg).takeIf { it.isNotEmpty() }?.average()
        scoreCard(right - bw, "النتيجة النهائية العامة", overall)
        scoreCard(right - 2 * bw - 8f, "إدارة التشغيل", r.sectionsAvg)
        scoreCard(left, "الإدارات المساعدة", r.adminsAvg)
        p.y += 70f + 16f

        // ── جدول الدرجات
        p.ensure(60f)
        p.draw(p.layout("الدرجات", 15f, true, RED, p.cw), left, p.y); p.y += 26f
        val cName = 250f; val cScore = 110f; val cPct = 80f
        val xName = right - cName; val xScore = xName - cScore; val xPct = xScore - cPct; val xViol = left
        val wViol = xPct - xViol
        p.rect(left, p.y, p.cw.toFloat(), 22f, RED_SOFT, 5f)
        fun head(t: String, x: Float, ww: Float) = p.draw(p.layout(t, 10f, true, RED, ww.toInt() - 8, if (x == xName) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_CENTER), x + 4f, p.y + 5f)
        head("القسم / الإدارة", xName, cName); head("الدرجة", xScore, cScore); head("النسبة", xPct, cPct); head("مخالفات", xViol, wViol)
        p.y += 24f
        (orderedUnits(r, "SECTION") + orderedUnits(r, "ADMINISTRATION")).forEachIndexed { i, l ->
            val nameL = p.layout(l.unit.name, 11f, false, DARK, cName.toInt() - 12)
            val rh = maxOf(nameL.height + 10f, 24f)
            p.ensure(rh)
            if (i % 2 == 0) p.rect(left, p.y, p.cw.toFloat(), rh, LIGHT, 4f)
            p.draw(nameL, xName + 6f, p.y + 5f)
            val mid = (rh - 14f) / 2f
            if (l.isNA) {
                p.draw(p.layout("غير موجود (N/A)", 10f, false, GRAY, (cScore + cPct).toInt(), Layout.Alignment.ALIGN_CENTER), xPct, p.y + mid)
            } else {
                val sc = l.score!!
                p.draw(p.layout("${num(sc.actual)} / ${num(sc.planned)}", 11f, false, DARK, cScore.toInt(), Layout.Alignment.ALIGN_CENTER), xScore, p.y + mid)
                p.draw(p.layout(pct(sc.percent), 11f, true, scoreColor(sc.percent), cPct.toInt(), Layout.Alignment.ALIGN_CENTER), xPct, p.y + mid)
                p.draw(p.layout(l.violationCount.toString(), 11f, true, if (l.violationCount > 0) RED else GREEN, wViol.toInt(), Layout.Alignment.ALIGN_CENTER), xViol, p.y + mid)
            }
            p.y += rh
        }
        p.y += 18f

        // ── المخالفات
        p.ensure(60f)
        p.draw(p.layout("المخالفات (${r.violations.size})", 15f, true, RED, p.cw), left, p.y); p.y += 28f
        if (r.violations.isEmpty()) p.draw(p.layout("لا توجد مخالفات 🎉", 12f, false, GREEN, p.cw), left, p.y)
        var lastUnit = ""
        var lastKind = ""
        orderedViolations(r).forEach { v ->
            if (v.unitId != lastUnit) {
                lastUnit = v.unitId
                if (p.y > 110f) p.newPage()
                val kind = r.units.firstOrNull { it.unit.id == v.unitId }?.unit?.kind ?: "SECTION"
                p.ensure(60f)
                p.y += 4f
                p.rect(left, p.y, p.cw.toFloat(), 24f, DARK, 5f)
                val unitHeading = if (kind != lastKind) (if (kind == "SECTION") "أولًا: إدارة التشغيل — " else "ثانيًا: الإدارات المساعدة — ") + v.unitName else v.unitName
                p.draw(p.layout(unitHeading, 11f, true, Color.WHITE, p.cw - 20), left + 10f, p.y + 5f)
                p.y += 30f
                lastKind = kind
            }
            val main = p.layout("${v.controlNo}. ${v.controlText}${groupLabel(v)}", 11.5f, true, DARK, p.cw - 30)
            val subText = listOfNotNull(v.categoryName, InlineCensusData.summary(v.findingNote).takeIf { it.isNotBlank() }?.let { "الحصر: $it" }, v.violationNote?.takeIf { it.isNotBlank() }?.let { "ملاحظات: $it" }, if (hasGonePhotos(r, v)) "الصور محفوظة على موبايل المراقب" else if (mediaFiles(r, v).isEmpty() && v.photoRequired) "⚠ بدون صورة" else null, if (videoCount(r, v) > 0) "فيديو: ${videoCount(r, v)} (في التطبيق وملف ZIP)" else null).joinToString("  ·  ")
            val sub = p.layout(subText, 9.5f, false, GRAY, p.cw - 30)
            val ch = main.height + sub.height + 14f
            p.ensure(ch + 6f)
            p.rect(left, p.y, p.cw.toFloat(), ch, Color.rgb(255, 245, 245), 6f)
            p.rect(right - 5f, p.y, 5f, ch, RED, 2f)
            p.draw(main, left + 10f, p.y + 6f)
            p.draw(sub, left + 10f, p.y + 6f + main.height)
            p.y += ch + 6f
            val files = photoFiles(r, v)
            if (files.isNotEmpty()) p.photos(files)
        }
        // ── ضوابط الحصر
        if (r.census.isNotEmpty()) {
            p.ensure(70f)
            p.y += 10f
            p.draw(p.layout("ضوابط الحصر", 15f, true, RED, p.cw), left, p.y); p.y += 28f
            var lastU = ""
            var lastC = ""
            r.census.forEach { c ->
                if (c.unitId != lastU) {
                    lastU = c.unitId; lastC = ""
                    p.ensure(60f)
                    p.y += 4f
                    p.rect(left, p.y, p.cw.toFloat(), 24f, DARK, 5f)
                    p.draw(p.layout(c.unitName, 12f, true, Color.WHITE, p.cw - 20), left + 10f, p.y + 5f)
                    p.y += 30f
                }
                if (c.categoryName != lastC) {
                    lastC = c.categoryName
                    p.ensure(40f)
                    p.draw(p.layout(c.categoryName, 11.5f, true, RED, p.cw - 10), left, p.y); p.y += 22f
                }
                val name = p.layout(c.controlText, 11f, false, DARK, p.cw - 170)
                val display = if (c.priced) "${c.expr}، إجمالي القيمة = ${c.amount} ج.م" else c.expr
                val value = p.layout(display, 11f, true, RED, 190, Layout.Alignment.ALIGN_CENTER)
                val rh = maxOf(name.height, value.height) + 10f
                p.ensure(rh)
                p.rect(left, p.y, p.cw.toFloat(), rh, LIGHT, 4f)
                p.draw(name, right - 8f - (p.cw - 170), p.y + 5f)
                p.draw(value, left + 6f, p.y + 5f)
                p.y += rh + 3f
            }
        }
        p.finish()
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    // ═════════════════════ ZIP helper ═════════════════════
    private fun zip(file: File, entries: List<Pair<String, ByteArray>>) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(file))).use { z ->
            entries.forEach { (name, data) -> z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry() }
        }
    }
    private fun b(s: String) = s.toByteArray(Charsets.UTF_8)
    private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"

    // ═════════════════════ Word (.docx حقيقي) ═════════════════════
    fun docx(ctx: Context, r: ReportData): File {
        val file = outFile(ctx, r, "docx")
        val media = ArrayList<Pair<String, ByteArray>>()
        val rels = StringBuilder()
        var imgId = 0

        fun para(text: String, size: Int = 22, bold: Boolean = false, color: String = hex(DARK), after: Int = 80, pageBreakBefore: Boolean = false): String =
            "<w:p><w:pPr><w:bidi/>" + (if (pageBreakBefore) "<w:pageBreakBefore/>" else "") + "<w:spacing w:after=\"$after\"/></w:pPr><w:r><w:rPr>" +
                (if (bold) "<w:b/><w:bCs/>" else "") +
                "<w:color w:val=\"$color\"/><w:sz w:val=\"$size\"/><w:szCs w:val=\"$size\"/><w:rtl/></w:rPr>" +
                "<w:t xml:space=\"preserve\">${esc(text.replace("\r\n", "\n")).replace("\n", "</w:t><w:br/><w:t xml:space=\"preserve\">")}</w:t></w:r></w:p>"

        fun image(f: File): String {
            val (iw, ih) = bounds(f) ?: return ""
            imgId++
            val name = "img$imgId.jpeg"
            media += "word/media/$name" to embedBytes(f)
            rels.append("<Relationship Id=\"rIdImg$imgId\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/$name\"/>")
            val cx = 1980000L
            val cy = cx * ih / iw
            return "<w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
                "<wp:docPr id=\"$imgId\" name=\"Picture $imgId\"/><a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"$imgId\" name=\"$name\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                "<pic:blipFill><a:blip r:embed=\"rIdImg$imgId\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
                "</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r><w:r><w:t xml:space=\"preserve\">  </w:t></w:r>"
        }

        val body = StringBuilder()
        body.append(para("تقرير جودة — شركة رنين", 40, true, hex(RED), 160))
        body.append(para("رقم التقرير: ${r.inspection.reportNumber}"))
        body.append(para("الفرع: ${r.branchName}"))
        body.append(para("نوع التقييم: " + when (r.inspection.templateId) { "smart", "zayed" -> "تقييم سمارت"; "digital" -> "تقييم ديجتال"; "offline", "main" -> "تقييم أوف لاين"; else -> "تقييم جودة" }))
        visitTxt(r)?.let { body.append(para("رقم الزيارة: $it")) }
        body.append(para("تاريخ الزيارة: ${fmt(r.inspection.visitDate)}"))
        body.append(para("المراقب: ${r.inspectorName}"))
        body.append(para("الحالة: ${Status.label(r.inspection.status)}", 22, true, hex(statusColor(r.inspection.status)), 160))
        r.inspection.notes?.takeIf { it.isNotBlank() }?.let { body.append(para("ملاحظات الزيارة العامة: $it", 22, false, hex(DARK), 140)) }
        val overallScore = listOfNotNull(r.sectionsAvg, r.adminsAvg).takeIf { it.isNotEmpty() }?.average()
        body.append(para("النتيجة النهائية العامة: ${pct(overallScore)}", 28, true, hex(RED), 100))
        body.append(para("إدارة التشغيل — الدرجة الإجمالية: ${pct(r.sectionsAvg)}", 24, true, hex(BLUE), 80))
        body.append(para("الإدارات المساعدة — الدرجة الإجمالية: ${pct(r.adminsAvg)}", 24, true, hex(BLUE), 100))
        body.append(para("الدرجات التفصيلية", 30, true, hex(RED), 100))
        (orderedUnits(r, "SECTION") + orderedUnits(r, "ADMINISTRATION")).forEach {
            if (it.isNA) body.append(para("• ${it.unit.name}: غير موجود بالفرع (N/A)", 22, false, hex(GRAY)))
            else {
                val sc = it.score!!
                body.append(para("• ${it.unit.name}:  ${num(sc.actual)} / ${num(sc.planned)}  (${pct(sc.percent)})  —  مخالفات: ${it.violationCount}", 22, false, hex(scoreColor(sc.percent))))
            }
        }
        body.append(para("المخالفات (${r.violations.size})", 30, true, hex(RED), 100))
        if (r.violations.isEmpty()) body.append(para("لا توجد مخالفات.", 22, false, hex(GREEN)))
        var lastUnit = ""
        var lastKind = ""
        orderedViolations(r).forEach { v ->
            if (v.unitId != lastUnit) {
                lastUnit = v.unitId
                val kind = r.units.firstOrNull { it.unit.id == v.unitId }?.unit?.kind ?: "SECTION"
                val unitHeading = if (kind != lastKind) (if (kind == "SECTION") "أولًا: إدارة التشغيل — " else "ثانيًا: الإدارات المساعدة — ") + v.unitName else v.unitName
                body.append(para(unitHeading, 26, true, hex(DARK), 80, pageBreakBefore = true))
                lastKind = kind
            }
            body.append(para("${v.controlNo}. ${v.controlText}${groupLabel(v)}", 22, true, hex(DARK), 20))
            body.append(para(v.categoryName, 18, false, hex(GRAY), 40))
            InlineCensusData.summary(v.findingNote).takeIf { it.isNotBlank() }?.let { body.append(para("حصر المخالفة: $it", 20, false, hex(BLUE), 80)) }
            v.violationNote?.takeIf { it.isNotBlank() }?.let { body.append(para("ملاحظات المخالفة: $it", 20, false, hex(RED), 80)) }
            val files = photoFiles(r, v)
            when {
                files.isNotEmpty() -> body.append("<w:p><w:pPr><w:bidi/><w:spacing w:after=\"160\"/></w:pPr>${files.joinToString("") { image(it) }}</w:p>")
                hasGonePhotos(r, v) -> body.append(para("الصور محفوظة على موبايل المراقب", 18, false, hex(GRAY), 160))
                videoCount(r, v) > 0 -> body.append(para("فيديو: ${videoCount(r, v)} (في التطبيق وملف ZIP)", 18, false, hex(GRAY), 160))
                v.photoRequired -> body.append(para("⚠ بدون صورة", 18, false, hex(ORANGE), 160))
                else -> body.append(para("", 10, false, hex(GRAY), 100))
            }
        }

        if (r.census.isNotEmpty()) {
            body.append(para("ضوابط الحصر", 30, true, hex(RED), 100))
            var lu = ""
            var lc = ""
            r.census.forEach { c ->
                if (c.unitId != lu) { lu = c.unitId; lc = ""; body.append(para(c.unitName, 26, true, hex(DARK), 80)) }
                if (c.categoryName != lc) { lc = c.categoryName; body.append(para(c.categoryName, 22, true, hex(RED), 40)) }
                body.append(para("• ${c.controlText}:  ${c.expr}", 22, false, hex(DARK), 40))
            }
        }

        val logoBytes = try { ctx.assets.open("raneen_logo.png").use { it.readBytes() } } catch (_: Exception) { null }
        val headerXml = if (logoBytes != null) XML + "<w:hdr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:p><w:pPr><w:bidi/><w:jc w:val=\"right\"/></w:pPr><w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"720000\" cy=\"360000\"/><wp:docPr id=\"9001\" name=\"Raneen Logo\"/><a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic><pic:nvPicPr><pic:cNvPr id=\"9001\" name=\"logo.png\"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed=\"rIdLogo\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"720000\" cy=\"360000\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></w:drawing></w:r><w:r><w:rPr><w:b/><w:sz w:val=\"20\"/><w:rtl/></w:rPr><w:t>شركة رنين — إدارة الجودة</w:t></w:r></w:p></w:hdr>" else null
        logoBytes?.let { media.add("word/media/logo.png" to it) }
        val document = XML + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
            "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
            "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>$body" +
            "<w:sectPr>" + (if (headerXml != null) "<w:headerReference w:type=\"default\" r:id=\"rIdHeader\"/>" else "") + "<w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1200\" w:right=\"900\" w:bottom=\"900\" w:left=\"900\" w:header=\"400\" w:footer=\"400\" w:gutter=\"0\"/><w:bidi/></w:sectPr></w:body></w:document>"
        val contentTypes = XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/><Default Extension=\"png\" ContentType=\"image/png\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" + (if (headerXml != null) "<Override PartName=\"/word/header1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml\"/>" else "") + "</Types>"
        val rootRels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        val docRels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">$rels" + (if (headerXml != null) "<Relationship Id=\"rIdHeader\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/header\" Target=\"header1.xml\"/>" else "") + "</Relationships>"
        val headerRels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rIdLogo\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/logo.png\"/></Relationships>"

        zip(file, listOf(
            "[Content_Types].xml" to b(contentTypes), "_rels/.rels" to b(rootRels),
            "word/document.xml" to b(document), "word/_rels/document.xml.rels" to b(docRels)
        ) + (if (headerXml != null) listOf("word/header1.xml" to b(headerXml), "word/_rels/header1.xml.rels" to b(headerRels)) else emptyList()) + media)
        return file
    }

    // ═════════════════════ Excel (.xlsx حقيقي) ═════════════════════
    private fun colName(i: Int): String = ('A' + i).toString()

    fun xlsx(ctx: Context, r: ReportData): File {
        val file = outFile(ctx, r, "xlsx")
        fun s(ref: String, text: String, style: Int = 0) = "<c r=\"$ref\" t=\"inlineStr\" s=\"$style\"><is><t xml:space=\"preserve\">${esc(text)}</t></is></c>"
        fun n(ref: String, v: Double) = "<c r=\"$ref\"><v>$v</v></c>"

        // ── الورقة 1: الملخص
        val media = ArrayList<Pair<String, ByteArray>>()
        val logoBytes = try { ctx.assets.open("raneen_logo.png").use { it.readBytes() } } catch (_: Exception) { null }
        val sum = StringBuilder()
        sum.append("<row r=\"1\">${s("A1", "شركة رنين — إدارة الجودة", 1)}${s("B1", "تقرير جودة", 1)}</row>")
        sum.append("<row r=\"2\">${s("A2", "رقم التقرير", 2)}${s("B2", r.inspection.reportNumber, 3)}</row>")
        sum.append("<row r=\"3\">${s("A3", "الفرع", 2)}${s("B3", r.branchName, 3)}</row>")
        var row = 4
        fun kv(k: String, v: String) { sum.append("<row r=\"$row\">${s("A$row", k, 2)}${s("B$row", v, 3)}</row>"); row++ }
        visitTxt(r)?.let { kv("رقم الزيارة", it) }; kv("تاريخ الزيارة", fmt(r.inspection.visitDate))
        kv("المراقب", r.inspectorName); kv("الحالة", Status.label(r.inspection.status)); r.inspection.notes?.takeIf { it.isNotBlank() }?.let { kv("ملاحظات الزيارة العامة", it) }
        kv("النتيجة النهائية العامة", pct(listOfNotNull(r.sectionsAvg, r.adminsAvg).takeIf { it.isNotEmpty() }?.average()))
        kv("إدارة التشغيل — الدرجة الإجمالية", pct(r.sectionsAvg)); kv("الإدارات المساعدة — الدرجة الإجمالية", pct(r.adminsAvg))
        row++
        sum.append("<row r=\"$row\">${s("A$row", "القسم / الإدارة", 1)}${s("B$row", "الدرجة", 1)}${s("C$row", "من", 1)}${s("D$row", "النسبة %", 1)}${s("E$row", "المخالفات", 1)}</row>"); row++
        fun appendUnitScoreRows(items: List<UnitLine>) {
            items.forEach {
                if (it.isNA) sum.append("<row r=\"$row\">${s("A$row", it.unit.name)}${s("B$row", "N/A")}</row>")
                else {
                    val sc = it.score!!
                    sum.append("<row r=\"$row\">${s("A$row", it.unit.name)}${n("B$row", Math.round(sc.actual * 10) / 10.0)}${n("C$row", sc.planned)}${n("D$row", Math.round(sc.percent * 10) / 10.0)}${n("E$row", it.violationCount.toDouble())}</row>")
                }
                row++
            }
        }
        sum.append("<row r=\"$row\">${s("A$row", "أولًا: إدارة التشغيل", 1)}</row>"); row++
        appendUnitScoreRows(orderedUnits(r, "SECTION"))
        sum.append("<row r=\"$row\">${s("A$row", "ثانيًا: الإدارات المساعدة", 1)}</row>"); row++
        appendUnitScoreRows(orderedUnits(r, "ADMINISTRATION"))
        val summaryAnchors = if (logoBytes != null) "<xdr:oneCellAnchor><xdr:from><xdr:col>5</xdr:col><xdr:colOff>38100</xdr:colOff><xdr:row>0</xdr:row><xdr:rowOff>38100</xdr:rowOff></xdr:from><xdr:ext cx=\"1200000\" cy=\"600000\"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id=\"9001\" name=\"Raneen Logo\"/><xdr:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></xdr:cNvPicPr></xdr:nvPicPr><xdr:blipFill><a:blip r:embed=\"rIdLogo\"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"1200000\" cy=\"600000\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>" else ""
        val summaryDrawing = XML + "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">$summaryAnchors</xdr:wsDr>"
        val sheet1 = XML + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews>" +
            "<cols><col min=\"1\" max=\"1\" width=\"34\" customWidth=\"1\"/><col min=\"2\" max=\"5\" width=\"18\" customWidth=\"1\"/></cols><sheetData>$sum</sheetData><headerFooter><oddHeader>&amp;Cشركة رنين — إدارة الجودة</oddHeader></headerFooter>" + (if (logoBytes != null) "<drawing r:id=\"rId1\"/>" else "") + "</worksheet>"
        logoBytes?.let { media.add("xl/media/logo.png" to it) }
        val summaryDrawRels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rIdLogo\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/logo.png\"/></Relationships>"
        val sheet1Rels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing2.xml\"/></Relationships>"

        // ── الورقة 2: المخالفات + الصور
        val anchors = StringBuilder()
        val drawRels = StringBuilder()
        var imgId = 0
        val photoCols = 4
        val box = 160.0 to 120.0   // px
        val viol = StringBuilder()
        viol.append("<row r=\"1\" ht=\"24\" customHeight=\"1\">" + listOf("القسم", "الكاتجري", "رقم البند", "البند", "المجموعة / ملاحظات المخالفة").mapIndexed { i, t -> s("${colName(i)}1", t, 1) }.joinToString("") +
            (0 until photoCols).joinToString("") { s("${colName(5 + it)}1", "صورة ${it + 1}", 1) } + "</row>")
        var vr = 2
        orderedViolations(r).forEach { v ->
            val files = photoFiles(r, v).take(photoCols)
            val note = if (files.isEmpty() && hasGonePhotos(r, v)) "الصور محفوظة على موبايل المراقب" else if (videoCount(r, v) > 0) "فيديو: ${videoCount(r, v)}" else ""
            val rowAttr = if (files.isNotEmpty()) " ht=\"98\" customHeight=\"1\"" else ""
            viol.append("<row r=\"$vr\"$rowAttr>${s("A$vr", v.unitName, 3)}${s("B$vr", v.categoryName, 3)}${n("C$vr", v.controlNo.toDouble())}${s("D$vr", v.controlText, 3)}${s("E$vr", (v.groupName ?: "") + (InlineCensusData.summary(v.findingNote).takeIf { it.isNotBlank() }?.let { " — الحصر: $it" } ?: "") + (v.violationNote?.takeIf { it.isNotBlank() }?.let { " — ملاحظات: $it" } ?: "") + (if (note.isNotEmpty()) " $note" else ""), 3)}</row>")
            files.forEachIndexed { i, f ->
                val (iw, ih) = bounds(f) ?: return@forEachIndexed
                imgId++
                val name = "img$imgId.jpeg"
                media += "xl/media/$name" to embedBytes(f)
                drawRels.append("<Relationship Id=\"rId$imgId\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/$name\"/>")
                val k = minOf(box.first / iw, box.second / ih)
                val cx = (iw * k * 9525).toLong(); val cy = (ih * k * 9525).toLong()
                anchors.append("<xdr:oneCellAnchor><xdr:from><xdr:col>${5 + i}</xdr:col><xdr:colOff>38100</xdr:colOff><xdr:row>${vr - 1}</xdr:row><xdr:rowOff>38100</xdr:rowOff></xdr:from>" +
                    "<xdr:ext cx=\"$cx\" cy=\"$cy\"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id=\"${imgId + 1}\" name=\"Picture $imgId\"/><xdr:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></xdr:cNvPicPr></xdr:nvPicPr>" +
                    "<xdr:blipFill><a:blip r:embed=\"rId$imgId\"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>" +
                    "<xdr:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>")
            }
            vr++
        }
        val sheet2 = XML + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
            "<sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews>" +
            "<cols><col min=\"1\" max=\"2\" width=\"20\" customWidth=\"1\"/><col min=\"3\" max=\"3\" width=\"10\" customWidth=\"1\"/><col min=\"4\" max=\"4\" width=\"48\" customWidth=\"1\"/>" +
            "<col min=\"5\" max=\"5\" width=\"22\" customWidth=\"1\"/><col min=\"6\" max=\"${5 + photoCols}\" width=\"24\" customWidth=\"1\"/></cols>" +
            "<sheetData>$viol</sheetData><headerFooter><oddHeader>&amp;Cشركة رنين — إدارة الجودة</oddHeader></headerFooter><drawing r:id=\"rId1\"/></worksheet>"
        val drawing = XML + "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">$anchors</xdr:wsDr>"

        // ── الورقة 3: ضوابط الحصر
        val cen = StringBuilder()
        cen.append("<row r=\"1\" ht=\"24\" customHeight=\"1\">" + listOf("القسم", "الكاتجري", "الضابط", "التفاصيل", "المجموع").mapIndexed { i, t -> s("${colName(i)}1", t, 1) }.joinToString("") + "</row>")
        r.census.forEachIndexed { i, c ->
            val rr = i + 2
            cen.append("<row r=\"$rr\">${s("A$rr", c.unitName, 3)}${s("B$rr", c.categoryName, 3)}${s("C$rr", c.controlText, 3)}${s("D$rr", c.parts.joinToString("+"), 3)}${n("E$rr", if (c.priced) c.amount else c.total.toDouble())}</row>")
        }
        val sheet3 = XML + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews>" +
            "<cols><col min=\"1\" max=\"2\" width=\"26\" customWidth=\"1\"/><col min=\"3\" max=\"3\" width=\"36\" customWidth=\"1\"/><col min=\"4\" max=\"5\" width=\"16\" customWidth=\"1\"/></cols><sheetData>$cen</sheetData><headerFooter><oddHeader>&amp;Cشركة رنين — إدارة الجودة</oddHeader></headerFooter></worksheet>"

        val styles = XML + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"3\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFC8102E\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"4\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>" +
            "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf></cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"
        val workbook = XML + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
            "<sheets><sheet name=\"الملخص\" sheetId=\"1\" r:id=\"rId1\"/><sheet name=\"المخالفات\" sheetId=\"2\" r:id=\"rId2\"/><sheet name=\"الحصر\" sheetId=\"3\" r:id=\"rId4\"/></sheets></workbook>"
        val wbRels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" +
            "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
            "<Relationship Id=\"rId4\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet3.xml\"/></Relationships>"
        val sheet2Rels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing1.xml\"/></Relationships>"
        val drawRelsXml = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">$drawRels</Relationships>"
        val contentTypes = XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/><Default Extension=\"png\" ContentType=\"image/png\"/>" +
            "<Override PartName=\"/xl/drawings/drawing2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
            "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
            "<Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/></Types>"
        val rootRels = XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"

        zip(file, listOf(
            "[Content_Types].xml" to b(contentTypes), "_rels/.rels" to b(rootRels),
            "xl/workbook.xml" to b(workbook), "xl/_rels/workbook.xml.rels" to b(wbRels), "xl/styles.xml" to b(styles),
            "xl/worksheets/sheet1.xml" to b(sheet1), "xl/worksheets/sheet2.xml" to b(sheet2), "xl/worksheets/sheet3.xml" to b(sheet3),
            "xl/worksheets/_rels/sheet2.xml.rels" to b(sheet2Rels),
            "xl/drawings/drawing1.xml" to b(drawing), "xl/drawings/_rels/drawing1.xml.rels" to b(drawRelsXml)
        ) + (if (logoBytes != null) listOf("xl/worksheets/_rels/sheet1.xml.rels" to b(sheet1Rels), "xl/drawings/drawing2.xml" to b(summaryDrawing), "xl/drawings/_rels/drawing2.xml.rels" to b(summaryDrawRels)) else emptyList()) + media)
        return file
    }

    // ═════════════════════ ZIP الصور الأصلية + الحفظ في Downloads ═════════════════════
    /** كل صور التقرير الموجودة على الجهاز (بجودتها الأصلية بعد الختم)، متقسمة فولدر لكل قسم */
    fun photosZip(ctx: Context, r: ReportData): File? {
        val entries = ArrayList<Pair<String, File>>()
        val used = HashSet<String>()
        fun clean(t: String) = t.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        r.violations.forEach { v ->
            mediaFiles(r, v).forEachIndexed { k, f ->
                val base = "${clean(v.unitName)}/${v.controlNo}" + (if (v.groupName.isNullOrBlank()) "" else "_${clean(v.groupName)}") + "_${k + 1}"
                val e = f.extension.ifBlank { "jpg" }
                var name = "$base.$e"
                var n = 2
                while (!used.add(name)) { name = "${base}_$n.$e"; n++ }     // ZIP مبيقبلش اسمين زي بعض
                entries += name to f
            }
        }
        if (entries.isEmpty()) return null
        val out = File(File(ctx.cacheDir, "exports").apply { mkdirs() },
            "Raneen_${r.inspection.reportNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")}_photos.zip")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
            entries.forEach { (name, f) -> z.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(z, 64 * 1024) }; z.closeEntry() }
        }
        return out
    }

    /** بيحفظ الملف في Downloads/Raneen (من غير إذن على أندرويد 10+) */
    fun saveToDownloads(ctx: Context, file: File, mime: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/Raneen")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return false
                ctx.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: return false
                true
            } else {
                val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Raneen").apply { mkdirs() }
                file.copyTo(File(dir, file.name), overwrite = true)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun share(ctx: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "مشاركة التقرير"))
    }
}
