package com.raneen.quality.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** تصدير التقرير: PDF (بالصور) / Word (.doc) / Excel (.csv). الملفات بتتعمل في كاش التطبيق وتتشارك بـ FileProvider. */
object ReportExporter {
    private fun fmt(t: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t))
    private fun pct(v: Double?) = if (v == null) "—" else String.format(Locale.US, "%.1f%%", v)
    private fun num(v: Double) = String.format(Locale.US, "%.1f", v)
    private fun outFile(ctx: Context, r: ReportData, ext: String): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        return File(dir, "Raneen_${r.inspection.reportNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")}.$ext")
    }
    private fun groupLabel(v: ViolationRow) = if (v.groupName.isNullOrBlank()) "" else " (${v.groupName})"

    // ───────── PDF ─────────
    private class Pdf(private val doc: PdfDocument) {
        private val w = 595
        private val h = 842
        private val m = 36
        private var n = 1
        private var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create())
        private var y = m.toFloat()

        private fun newPage() {
            doc.finishPage(page); n++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create()); y = m.toFloat()
        }

        fun gap(v: Float) { y += v }

        fun text(t: String, size: Float = 12f, bold: Boolean = false, color: Int = Color.BLACK) {
            val tp = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size; this.color = color
                typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            val sl = StaticLayout.Builder.obtain(t, 0, t.length, tp, w - 2 * m)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL).build()
            if (y + sl.height > h - m) newPage()
            page.canvas.save(); page.canvas.translate(m.toFloat(), y); sl.draw(page.canvas); page.canvas.restore()
            y += sl.height + 4
        }

        private fun thumb(f: File, tw: Int): Bitmap? {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, b)
            if (b.outWidth <= 0) return null
            val src = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = maxOf(1, b.outWidth / (tw * 2)) })
                ?: return null
            return Bitmap.createScaledBitmap(src, tw, maxOf(1, src.height * tw / src.width), true)
        }

        fun photos(files: List<File>) {
            val tw = 160
            val startX = (w - m - tw).toFloat()
            var x = startX
            var rowH = 0f
            for (f in files) {
                val b = thumb(f, tw) ?: continue
                if (x < m) { y += rowH + 6; x = startX; rowH = 0f }
                if (y + b.height > h - m) { newPage(); x = startX; rowH = 0f }
                page.canvas.drawBitmap(b, x, y, null)
                rowH = maxOf(rowH, b.height.toFloat())
                x -= (tw + 8)
            }
            y += rowH + 8
        }

        fun finish() { doc.finishPage(page) }
    }

    fun pdf(ctx: Context, r: ReportData): File {
        val file = outFile(ctx, r, "pdf")
        val doc = PdfDocument()
        val p = Pdf(doc)
        p.text("تقرير جودة — شركة رنين", 20f, true, Color.rgb(200, 0, 0))
        p.text("رقم التقرير: ${r.inspection.reportNumber}", 12f)
        p.text("الفرع: ${r.branchName}", 12f)
        p.text("تاريخ الزيارة: ${fmt(r.inspection.visitDate)}", 12f)
        p.text("المراقب: ${r.inspectorName}", 12f)
        p.text("الحالة: ${Status.label(r.inspection.status)}", 12f)
        p.gap(6f)
        p.text("متوسط الأقسام: ${pct(r.sectionsAvg)}      متوسط الإدارات المساعدة: ${pct(r.adminsAvg)}", 13f, true)
        p.gap(6f)
        p.text("الدرجات", 15f, true)
        r.units.forEach {
            val s = if (it.isNA) "غير موجود بالفرع (N/A)" else "${num(it.score!!.actual)} / ${num(it.score.planned)}   (${pct(it.score.percent)})   مخالفات: ${it.violationCount}"
            p.text("• ${it.unit.name}: $s", 12f)
        }
        p.gap(8f)
        p.text("المخالفات", 15f, true)
        if (r.violations.isEmpty()) p.text("لا توجد مخالفات.", 12f)
        var lastUnit = ""
        r.violations.forEach { v ->
            if (v.unitId != lastUnit) { lastUnit = v.unitId; p.gap(4f); p.text(v.unitName, 14f, true, Color.rgb(160, 0, 0)) }
            p.text("${v.controlNo}. ${v.controlText}${groupLabel(v)}", 12f)
            val files = r.photosByFinding[v.findingId].orEmpty().map { File(it.filePath) }.filter { it.exists() }
            if (files.isNotEmpty()) p.photos(files) else if (v.photoRequired) p.text("⚠ بدون صورة", 11f, false, Color.rgb(200, 100, 0))
        }
        p.finish()
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    // ───────── Excel (CSV بترميز UTF-8 + BOM عشان العربي يظهر صح) ─────────
    private fun csvCell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun csv(ctx: Context, r: ReportData): File {
        val file = outFile(ctx, r, "csv")
        val sb = StringBuilder("\uFEFF")
        fun row(vararg c: String) { sb.append(c.joinToString(",") { csvCell(it) }).append("\r\n") }
        row("رقم التقرير", r.inspection.reportNumber)
        row("الفرع", r.branchName)
        row("تاريخ الزيارة", fmt(r.inspection.visitDate))
        row("المراقب", r.inspectorName)
        row("الحالة", Status.label(r.inspection.status))
        row("متوسط الأقسام", pct(r.sectionsAvg))
        row("متوسط الإدارات المساعدة", pct(r.adminsAvg))
        row()
        row("القسم / الإدارة", "الدرجة", "من", "النسبة", "عدد المخالفات")
        r.units.forEach {
            if (it.isNA) row(it.unit.name, "N/A", "", "", "")
            else row(it.unit.name, num(it.score!!.actual), num(it.score.planned), pct(it.score.percent), it.violationCount.toString())
        }
        row()
        row("القسم", "الكاتجري", "رقم البند", "البند", "المجموعة", "عدد المخالفات", "عدد الصور")
        r.violations.forEach {
            row(it.unitName, it.categoryName, it.controlNo.toString(), it.controlText, it.groupName ?: "",
                it.cnt.toString(), r.photosByFinding[it.findingId].orEmpty().size.toString())
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    // ───────── Word (.doc: صفحة HTML بيفتحها Word) ─────────
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    fun doc(ctx: Context, r: ReportData): File {
        val file = outFile(ctx, r, "doc")
        val sb = StringBuilder()
        sb.append("<html dir=\"rtl\" lang=\"ar\"><head><meta charset=\"utf-8\"><style>")
            .append("body{font-family:Arial;} table{border-collapse:collapse;width:100%} td,th{border:1px solid #999;padding:4px;text-align:right}")
            .append("</style></head><body>")
        sb.append("<h2 style=\"color:#c00\">تقرير جودة — شركة رنين</h2>")
        sb.append("<p>رقم التقرير: ${esc(r.inspection.reportNumber)}<br>الفرع: ${esc(r.branchName)}<br>")
            .append("تاريخ الزيارة: ${fmt(r.inspection.visitDate)}<br>المراقب: ${esc(r.inspectorName)}<br>")
            .append("الحالة: ${esc(Status.label(r.inspection.status))}</p>")
        sb.append("<p><b>متوسط الأقسام: ${pct(r.sectionsAvg)} — متوسط الإدارات المساعدة: ${pct(r.adminsAvg)}</b></p>")
        sb.append("<h3>الدرجات</h3><table><tr><th>القسم / الإدارة</th><th>الدرجة</th><th>النسبة</th><th>المخالفات</th></tr>")
        r.units.forEach {
            if (it.isNA) sb.append("<tr><td>${esc(it.unit.name)}</td><td colspan=\"3\">N/A</td></tr>")
            else sb.append("<tr><td>${esc(it.unit.name)}</td><td>${num(it.score!!.actual)} / ${num(it.score.planned)}</td><td>${pct(it.score.percent)}</td><td>${it.violationCount}</td></tr>")
        }
        sb.append("</table><h3>المخالفات</h3>")
        if (r.violations.isEmpty()) sb.append("<p>لا توجد مخالفات.</p>")
        else {
            sb.append("<table><tr><th>القسم</th><th>الكاتجري</th><th>البند</th><th>المجموعة</th><th>الصور</th></tr>")
            r.violations.forEach {
                sb.append("<tr><td>${esc(it.unitName)}</td><td>${esc(it.categoryName)}</td><td>${it.controlNo}. ${esc(it.controlText)}</td>")
                    .append("<td>${esc(it.groupName ?: "")}</td><td>${r.photosByFinding[it.findingId].orEmpty().size}</td></tr>")
            }
            sb.append("</table>")
        }
        sb.append("<p><i>الصور مرفقة في نسخة الـ PDF.</i></p></body></html>")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    fun share(ctx: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "مشاركة التقرير"))
    }
}
