package com.raneen.quality.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatAccessTest {
    @Test fun `inspector area manager and deputy dept manager can chat`() {
        assertTrue(ChatAccess.allowed(Roles.INSPECTOR))
        assertTrue(ChatAccess.allowed(Roles.AREA_MANAGER))
        assertTrue(ChatAccess.allowed(Roles.DEPT_MANAGER))
    }

    @Test fun `admin dept director and viewer cannot chat`() {
        assertFalse(ChatAccess.allowed(Roles.ADMIN))
        assertFalse(ChatAccess.allowed(Roles.DEPT_DIRECTOR))
        assertFalse(ChatAccess.allowed(Roles.VIEWER))
    }

    @Test fun `unknown or null role cannot chat`() {
        assertFalse(ChatAccess.allowed(null))
        assertFalse(ChatAccess.allowed("OTHER"))
    }
}
