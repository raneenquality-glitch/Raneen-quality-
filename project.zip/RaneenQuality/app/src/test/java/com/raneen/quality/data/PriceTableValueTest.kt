package com.raneen.quality.data

import org.junit.Assert.assertEquals
import org.junit.Test

class PriceTableValueTest {
    private val cs = CensusSummary(
        priceByType = listOf(
            PriceTypeBlock("التكويد", listOf(PriceSectionCount("a", "الأدوات المنزلية", 2, 500.0), PriceSectionCount("b", "الكهرباء", 1, 0.0))),
            PriceTypeBlock("التسعير", listOf(PriceSectionCount("a", "الأدوات المنزلية", 3)))
        ),
        showPrice = true
    )

    @Test fun `counts and totals are unchanged and value is added`() {
        assertEquals(6, cs.priceGrandTotal)
        assertEquals(500.0, cs.priceGrandValue, 0.0001)
        assertEquals("500.00", cs.priceGrandValueText)
    }

    @Test fun `table rows carry a fifth value column`() {
        val rows = cs.priceTableRows
        assertEquals(3, rows.size)
        assertEquals(listOf("1", "التكويد", "الأدوات المنزلية", "2", "500.00"), rows[0])
        assertEquals("", rows[1][4])
        assertEquals("", rows[2][4])
    }
}
