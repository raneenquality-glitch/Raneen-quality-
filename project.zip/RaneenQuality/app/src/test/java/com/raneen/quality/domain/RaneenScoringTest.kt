package com.raneen.quality.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RaneenScoringTest {

    // بند وزنه 4 وعقوبته 2 (زي بند 17 و23 في الأقسام)
    private val doubleItem = ControlDef("c17", "cat1", maxScore = 4.0, penaltyPerViolation = 2.0)

    @Test fun `two violations on a double-penalty item lose the full weight`() {
        assertEquals(4.0, controlLoss(doubleItem, 2), 0.0)
    }

    @Test fun `loss never exceeds the item weight`() {
        assertEquals(4.0, controlLoss(doubleItem, 5), 0.0)
    }

    @Test fun `no violations means no loss`() {
        assertEquals(0.0, controlLoss(doubleItem, 0), 0.0)
    }

    @Test fun `violations are summed across product groups`() {
        val controls = listOf(
            ControlDef("c1", "cat1", 4.0, 1.0),
            ControlDef("c2", "cat1", 6.0, 6.0)
        )
        // c1: مخالفة في مجموعتين = 2 خصم | c2: مفيش مخالفات
        val findings = listOf(
            FindingIn("c1", "g1", 1),
            FindingIn("c1", "g2", 1)
        )
        val s = scoreUnit(controls, findings)
        assertEquals(10.0, s.planned, 0.0)
        assertEquals(8.0, s.actual, 0.0)
        assertEquals(80.0, s.percent, 0.0)
    }

    @Test fun `services style - four sections at weight over four equals full loss`() {
        // بند وزنه 8، كل X بيخصم 2 → 4 X = 8
        val c = ControlDef("s1", "cat1", 8.0, 2.0)
        val findings = (1..4).map { FindingIn("s1", "q$it", 1) }
        val s = scoreUnit(listOf(c), findings)
        assertEquals(0.0, s.actual, 0.0)
    }

    @Test fun `administration style - one X takes the full weight`() {
        val c = ControlDef("a1", "cat1", 10.0, 10.0)
        val s = scoreUnit(listOf(c, ControlDef("a2", "cat1", 90.0, 90.0)), listOf(FindingIn("a1", "", 1)))
        assertEquals(90.0, s.actual, 0.0)
    }

    @Test fun `category breakdown is reported`() {
        val controls = listOf(
            ControlDef("c1", "clean", 4.0, 1.0),
            ControlDef("c2", "display", 4.0, 1.0)
        )
        val s = scoreUnit(controls, listOf(FindingIn("c2", "", 1)))
        assertEquals(4.0, s.byCategory["clean"]!!.actual, 0.0)
        assertEquals(3.0, s.byCategory["display"]!!.actual, 0.0)
    }

    @Test fun `NA units are excluded from the average`() {
        assertEquals(90.0, kindAverage(listOf(100.0, null, 80.0))!!, 0.0)
    }

    @Test fun `all NA gives null`() {
        assertNull(kindAverage(listOf(null, null)))
    }

    // ───── الاستلامات 1 و2: كل قسم مختار = 5 درجات (حد أقصى 20) ─────
    private val receiving1 = ControlDef("receiving_fmc_i1", "c", maxScore = 20.0, penaltyPerViolation = 5.0)

    @Test fun `receiving - one section selected loses 5`() {
        assertEquals(5.0, controlLoss(receiving1, 1 or AREA_PARTS_FLAG), 0.0)
    }

    @Test fun `receiving - two sections lose 10 and all four lose 20`() {
        assertEquals(10.0, controlLoss(receiving1, (1 or 4) or AREA_PARTS_FLAG), 0.0)
        assertEquals(20.0, controlLoss(receiving1, 15 or AREA_PARTS_FLAG), 0.0)
    }

    // ───── صيانة بند 13: الصيانة 2 + الدهان 2 ─────
    private val maint13 = ControlDef("maintenance_i13", "c", maxScore = 4.0, penaltyPerViolation = 4.0)

    @Test fun `maintenance 13 - each part loses 2`() {
        assertEquals(2.0, controlLoss(maint13, 1), 0.0)
        assertEquals(2.0, controlLoss(maint13, 2), 0.0)
        assertEquals(4.0, controlLoss(maint13, 3), 0.0)
    }

    // ───── مدير المعرض زايد: المخالفة العادية = الوزن كامل (بند 12 وزنه 5) ─────
    @Test fun `zayed branch manager item 12 loses its full weight of 5`() {
        val c = ControlDef("zayed_branch_manager_i12", "c", maxScore = 5.0, penaltyPerViolation = 5.0)
        assertEquals(5.0, controlLoss(c, 1), 0.0)
    }

    @Test fun `zayed branch manager item 1 - each section loses 1`() {
        val c = ControlDef("zayed_branch_manager_i1", "c", maxScore = 4.0, penaltyPerViolation = 1.0)
        assertEquals(2.0, controlLoss(c, 1 or 4), 0.0)
        assertEquals(4.0, controlLoss(c, 15), 0.0)
    }

    // ───── اختبارات تثبيت السلوك الحالي (مفيش معادلة اتغيّرت) ─────
    @Test fun `services admin item 5 - one part loses 4 and both parts lose the weight`() {
        val c = ControlDef("services_admin_i5", "c", maxScore = 8.0, penaltyPerViolation = 4.0)
        assertEquals(4.0, controlLoss(c, 1), 0.0)
        assertEquals(4.0, controlLoss(c, 2), 0.0)
        assertEquals(8.0, controlLoss(c, 3), 0.0)
    }

    @Test fun `services admin item 5 - legacy stored value 4 is read as part 1`() {
        val c = ControlDef("services_admin_i5", "c", maxScore = 8.0, penaltyPerViolation = 4.0)
        assertEquals(4.0, controlLoss(c, 4), 0.0)
    }

    @Test fun `services admin item 6 - each part loses 1`() {
        val c = ControlDef("services_admin_i6", "c", maxScore = 4.0, penaltyPerViolation = 1.0)
        assertEquals(1.0, controlLoss(c, 1), 0.0)
        assertEquals(2.0, controlLoss(c, 3), 0.0)
    }

    @Test fun `direct count controls lose one point per violation up to the weight`() {
        val c = ControlDef("maintenance_i3", "c", maxScore = 10.0, penaltyPerViolation = 1.0)
        assertEquals(3.0, controlLoss(c, 3), 0.0)
        assertEquals(10.0, controlLoss(c, 50), 0.0)
    }

    @Test fun `merge of plain counters is a sum`() {
        assertEquals(5, mergeAreaPartViolations(listOf(2, 3)))
        assertEquals(0, mergeAreaPartViolations(listOf(0, 0)))
    }

    @Test fun `merge of flagged parts is an OR so the same part counts once`() {
        val merged = mergeAreaPartViolations(listOf(1 or AREA_PARTS_FLAG, (1 or 4) or AREA_PARTS_FLAG))
        assertEquals(5 or AREA_PARTS_FLAG, merged)
    }

    @Test fun `empty unit scores zero percent without crashing`() {
        val s = scoreUnit(emptyList(), emptyList())
        assertEquals(0.0, s.planned, 0.0)
        assertEquals(0.0, s.percent, 0.0)
    }

    @Test fun `item score line shows weight deducted and remaining`() {
        assertEquals("الوزن: 4 | الخصم: 1 | المتبقي: 3", itemScoreText(4.0, 1.0))
    }
}
