package com.raneen.quality.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CensusSummaryTest {
    private val unit = EvaluationUnitEntity("digital_electricity", "digital", "الكهرباء الديجيتال", "SECTION")

    private fun finding(note: String, count: Int = 1, unitId: String = unit.id) =
        FindingEntity("f1", "i1", unitId, "digital_electricity_i15", "", count, note)

    @Test fun `QR is counted without value and SKU with count and value`() {
        val note = "RQ_CENSUS_V1:" + """{"no_qr":{"count":3,"value":0},"no_sku":{"count":2,"value":150}}"""
        val s = CensusSummaryBuilder.build(listOf(finding(note)), emptySet(), listOf(unit))
        val qr = s.price.first { it.group == "QR" && it.label == "عدد" }
        assertEquals(3, qr.count)
        assertEquals(2, s.price.first { it.group == "SKU" && it.label == "عدد" }.count)
        assertEquals(150.0, s.price.first { it.group == "SKU" && it.label == "قيمة" }.money ?: 0.0, 0.0)
    }

    @Test fun `QR and SKU rows are hidden when nothing is entered`() {
        val s = CensusSummaryBuilder.build(emptyList(), emptySet(), listOf(unit))
        assertTrue(s.price.none { it.group == "QR" || it.group == "SKU" })
    }

    @Test fun `NA units are ignored in the census summary`() {
        val note = "RQ_CENSUS_V1:" + """{"no_qr":{"count":5,"value":0}}"""
        val s = CensusSummaryBuilder.build(listOf(finding(note)), setOf(unit.id), listOf(unit))
        assertTrue(s.price.none { it.group == "QR" })
    }

    @Test fun `broken census note does not crash`() {
        val s = CensusSummaryBuilder.build(listOf(finding("RQ_CENSUS_V1:{not json")), emptySet(), listOf(unit))
        assertNull(s.price.firstOrNull { it.group == "QR" })
    }
}
