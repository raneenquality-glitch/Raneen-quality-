package com.raneen.quality.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineLoginPolicyTest {
    private val day = 24L * 60 * 60 * 1000
    private val t0 = 1_000_000_000_000L

    @Test fun `valid inside the window`() {
        assertTrue(OfflineLoginPolicy.isValid(t0, t0 + 2 * day))
    }

    @Test fun `valid exactly at the limit`() {
        assertTrue(OfflineLoginPolicy.isValid(t0, t0 + OfflineLoginPolicy.VALID_MS))
    }

    @Test fun `expired after the window`() {
        assertFalse(OfflineLoginPolicy.isValid(t0, t0 + OfflineLoginPolicy.VALID_MS + 1))
    }

    @Test fun `never verified online is not valid`() {
        assertFalse(OfflineLoginPolicy.isValid(0L, t0))
    }

    @Test fun `clock moved backwards is not valid`() {
        assertFalse(OfflineLoginPolicy.isValid(t0, t0 - day))
    }

    @Test fun `window is three days`() {
        assertEquals(3, OfflineLoginPolicy.VALID_DAYS)
    }
}
