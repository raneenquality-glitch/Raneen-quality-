#!/usr/bin/env bash
# =============================================================================
# Raneen — Supabase export (READ-ONLY)
# بيصدّر: schema + سياسات RLS + كل RPC/Functions + triggers + grants + إعدادات التخزين + (اختياري) البيانات
# مفيش أي أمر هنا بيكتب أو يعدّل في الـ production: pg_dump و SELECT بس.
#
# المتطلبات: psql و pg_dump (PostgreSQL client 15+)، وللـ Edge Functions: supabase CLI.
# المتغيرات (من الـ shell، ومتتكتبش جوه أي ملف):
#   SUPABASE_DB_URL         postgresql://postgres:<password>@db.<ref>.supabase.co:5432/postgres
#   SUPABASE_PROJECT_REF    (اختياري) لتحميل الـ Edge Functions
#   SUPABASE_ACCESS_TOKEN   (اختياري) لتحميل الـ Edge Functions
#   EDGE_FUNCTIONS          (اختياري) الافتراضي: "smart-processor swift-worker media-transfer"
#   WITH_DATA=1             (اختياري) يضيف dump للبيانات (فيه بيانات شخصية — ماتحطوش في Git!)
#   OUT_DIR                 (اختياري) الافتراضي backup_out/<timestamp>
# =============================================================================
set -euo pipefail

: "${SUPABASE_DB_URL:?SUPABASE_DB_URL مش متحدد (Dashboard → Project Settings → Database → Connection string)}"
command -v psql >/dev/null || { echo "psql مش موجود"; exit 1; }
command -v pg_dump >/dev/null || { echo "pg_dump مش موجود"; exit 1; }

OUT="${OUT_DIR:-backup_out/$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$OUT"/schema "$OUT"/functions "$OUT"/data
echo "Output → $OUT"
q() { psql "$SUPABASE_DB_URL" -X -v ON_ERROR_STOP=1 "$@"; }

echo "[1/8] schema (tables, indexes, constraints, RLS enable, POLICIES, functions, triggers, grants) — public"
pg_dump "$SUPABASE_DB_URL" --schema-only --no-owner --schema=public -f "$OUT/schema/public_schema.sql"

echo "[2/8] RLS policies (public + storage)"
q -A -c "\copy (select schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check from pg_policies where schemaname in ('public','storage') order by 1,2,3) to '$OUT/schema/policies.csv' csv header"

echo "[3/8] RLS status per table"
q -A -c "\copy (select n.nspname as schema, c.relname as table, c.relrowsecurity as rls_enabled, c.relforcerowsecurity as rls_forced from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind='r' and n.nspname in ('public','storage') order by 1,2) to '$OUT/schema/rls_status.csv' csv header"

echo "[4/8] كل الـ RPC/Functions (public) — النص الكامل"
q -t -A -c "select pg_get_functiondef(p.oid) || E';\n' from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.prokind in ('f','p') order by p.proname" -o "$OUT/schema/rpc_functions.sql"

echo "[5/8] triggers + extensions + cron + storage buckets"
q -A -c "\copy (select event_object_table, trigger_name, action_timing, event_manipulation, action_statement from information_schema.triggers where trigger_schema='public' order by 1,2) to '$OUT/schema/triggers.csv' csv header"
q -A -c "\copy (select extname, extversion from pg_extension order by 1) to '$OUT/schema/extensions.csv' csv header"
q -A -c "\copy (select id, name, public, file_size_limit, allowed_mime_types from storage.buckets order by 1) to '$OUT/schema/storage_buckets.csv' csv header" || echo "  (storage.buckets مش متاح)"
q -A -c "\copy (select jobid, schedule, command, active from cron.job order by 1) to '$OUT/schema/cron_jobs.csv' csv header" 2>/dev/null || echo "  (pg_cron مش متفعّل — عادي)"

echo "[6/8] عدد الصفوف لكل جدول (للمراجعة بعد أي استرجاع)"
q -A -c "\copy (select relname as table, n_live_tup as approx_rows from pg_stat_user_tables where schemaname='public' order by 1) to '$OUT/schema/table_row_estimates.csv' csv header"

if [[ "${WITH_DATA:-0}" == "1" ]]; then
  echo "[7/8] البيانات (public) — فيها بيانات شخصية: خزّنها مشفّرة خارج Git"
  pg_dump "$SUPABASE_DB_URL" --data-only --no-owner --schema=public -Fc -f "$OUT/data/public_data.dump"
else
  echo "[7/8] تخطّي البيانات (فعّلها بـ WITH_DATA=1)"
fi

echo "[8/8] Edge Functions"
if command -v supabase >/dev/null && [[ -n "${SUPABASE_PROJECT_REF:-}" && -n "${SUPABASE_ACCESS_TOKEN:-}" ]]; then
  ( cd "$OUT/functions" && for fn in ${EDGE_FUNCTIONS:-smart-processor swift-worker media-transfer}; do
      echo "  - $fn"; supabase functions download "$fn" --project-ref "$SUPABASE_PROJECT_REF" || echo "    فشل تحميل $fn"
    done )
else
  echo "  متخطّى: محتاج supabase CLI + SUPABASE_PROJECT_REF + SUPABASE_ACCESS_TOKEN (supabase functions list بيعرض كل الدوال)"
fi

# بصمة الملفات
( cd "$OUT" && find . -type f ! -name MANIFEST.sha256 -print0 | sort -z | xargs -0 sha256sum > MANIFEST.sha256 )
echo
echo "تم. الملفات اللي ممكن تتحط في repo خاص (من غير بيانات): schema/ و functions/"
echo "ممنوع تتحط في Git: data/ — ومعاها أي نسخة وسائط. شفّر النسخة: tar c \"$OUT\" | age -p > backup.tar.age"
