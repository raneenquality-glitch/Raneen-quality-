#!/usr/bin/env bash
# =============================================================================
# Raneen — نسخة احتياطية للصور والفيديوهات (READ-ONLY على الـ production)
# بينسخ (copy) من Supabase Storage و Backblaze B2 لمجلد محلي، ويتأكد بالـ checksum.
# مفيش أي كتابة أو مسح على المصدر: rclone copy / rclone check --one-way بس.
#
# المتطلبات: rclone (https://rclone.org).
# المتغيرات:
#   SUPABASE_PROJECT_REF, SUPABASE_S3_ACCESS_KEY_ID, SUPABASE_S3_SECRET_ACCESS_KEY, [SUPABASE_S3_REGION]
#       (Dashboard → Storage → S3 Connection → New access key — مفتاح مؤقت امسحه بعد النسخ)
#   SUPABASE_BUCKETS   الافتراضي: "report-photos chat-media" (أكّدها من schema/storage_buckets.csv)
#   B2_KEY_ID, B2_APPLICATION_KEY, B2_BUCKET   (مفتاح B2 بصلاحية readFiles بس يكفي)
#   OUT_DIR            الافتراضي backup_out/media-<timestamp>
# =============================================================================
set -euo pipefail
command -v rclone >/dev/null || { echo "rclone مش موجود"; exit 1; }
OUT="${OUT_DIR:-backup_out/media-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$OUT"
MAN="$OUT/MANIFEST.txt"; : > "$MAN"

# ريموتات بالـ environment (مفيش ملف config ولا أسرار على القرص)
if [[ -n "${SUPABASE_PROJECT_REF:-}" && -n "${SUPABASE_S3_ACCESS_KEY_ID:-}" ]]; then
  export RCLONE_CONFIG_SUPA_TYPE=s3 RCLONE_CONFIG_SUPA_PROVIDER=Other
  export RCLONE_CONFIG_SUPA_ENDPOINT="https://${SUPABASE_PROJECT_REF}.supabase.co/storage/v1/s3"
  export RCLONE_CONFIG_SUPA_ACCESS_KEY_ID="$SUPABASE_S3_ACCESS_KEY_ID"
  export RCLONE_CONFIG_SUPA_SECRET_ACCESS_KEY="${SUPABASE_S3_SECRET_ACCESS_KEY:?}"
  export RCLONE_CONFIG_SUPA_REGION="${SUPABASE_S3_REGION:-us-east-1}"
  for b in ${SUPABASE_BUCKETS:-report-photos chat-media}; do
    echo "== Supabase bucket: $b"
    rclone copy "SUPA:$b" "$OUT/supabase/$b" --checksum --transfers 8 --stats 15s
    rclone check "SUPA:$b" "$OUT/supabase/$b" --one-way --checksum && echo "OK  supabase/$b" | tee -a "$MAN"
    rclone size "SUPA:$b" | tee -a "$MAN"
  done
else
  echo "متخطّى Supabase Storage (متغيرات SUPABASE_* ناقصة)"
fi

if [[ -n "${B2_KEY_ID:-}" && -n "${B2_BUCKET:-}" ]]; then
  export RCLONE_CONFIG_B2_TYPE=b2 RCLONE_CONFIG_B2_ACCOUNT="$B2_KEY_ID" RCLONE_CONFIG_B2_KEY="${B2_APPLICATION_KEY:?}"
  echo "== B2 bucket: $B2_BUCKET"
  rclone copy "B2:$B2_BUCKET" "$OUT/b2" --checksum --transfers 8 --stats 15s
  rclone check "B2:$B2_BUCKET" "$OUT/b2" --one-way --checksum && echo "OK  b2/$B2_BUCKET" | tee -a "$MAN"
  rclone size "B2:$B2_BUCKET" | tee -a "$MAN"
else
  echo "متخطّى B2 (B2_KEY_ID / B2_BUCKET ناقصين)"
fi

echo; echo "تمت النسخة في: $OUT  (التقرير: $MAN)"
echo "النسخة فيها صور وفيديوهات حساسة: شفّرها وخزّنها خارج Git ومكان تاني غير المصدر."
