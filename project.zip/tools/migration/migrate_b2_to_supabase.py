#!/usr/bin/env python3
"""ينقل كل ملفات B2 لـ Supabase Storage (bucket report-photos) بنفس المسارات، من غير حذف أي حاجة من B2.
يتشغل على جهازك. الأسرار من متغيرات البيئة بس (ماتتكتبش في الملف ولا الشات):
  B2_ENDPOINT (مثال https://s3.us-west-004.backblazeb2.com)  B2_KEY_ID  B2_APP_KEY  B2_BUCKET
  SUPABASE_URL  SUPABASE_SERVICE_KEY   (service_role: بتتستخدم محليًا بس)
pip install boto3 requests
الاستخدام:  python migrate_b2_to_supabase.py --dry-run   ثم   python migrate_b2_to_supabase.py
آمن للإعادة: الملف الموجود بنفس الحجم بيتخطى. في الآخر تقرير بأي ملف ناقص أو حجمه مختلف.
"""
import os, sys, mimetypes, requests, boto3

DRY = "--dry-run" in sys.argv
BUCKET = os.environ.get("SUPABASE_BUCKET", "report-photos")
SB = os.environ["SUPABASE_URL"].rstrip("/")
H = {"apikey": os.environ["SUPABASE_SERVICE_KEY"], "Authorization": "Bearer " + os.environ["SUPABASE_SERVICE_KEY"]}
s3 = boto3.client("s3", endpoint_url=os.environ["B2_ENDPOINT"], aws_access_key_id=os.environ["B2_KEY_ID"], aws_secret_access_key=os.environ["B2_APP_KEY"])
b2 = os.environ["B2_BUCKET"]

def sb_size(key):
    r = requests.head(f"{SB}/storage/v1/object/authenticated/{BUCKET}/{key}", headers=H, timeout=30)
    return int(r.headers.get("content-length", -1)) if r.status_code == 200 else None

copied = skipped = 0
bad = []
for page in s3.get_paginator("list_objects_v2").paginate(Bucket=b2):
    for o in page.get("Contents", []):
        key, size = o["Key"], o["Size"]
        have = sb_size(key)
        if have == size:
            skipped += 1; continue
        if DRY:
            print("would copy", key, size); copied += 1; continue
        body = s3.get_object(Bucket=b2, Key=key)["Body"].read()
        mime = mimetypes.guess_type(key)[0] or "application/octet-stream"
        r = requests.post(f"{SB}/storage/v1/object/{BUCKET}/{key}", headers={**H, "Content-Type": mime, "x-upsert": "true"}, data=body, timeout=300)
        if r.status_code >= 300:
            bad.append((key, r.status_code)); print("FAIL", key, r.status_code); continue
        if sb_size(key) != size:
            bad.append((key, "size-mismatch")); print("MISMATCH", key); continue
        copied += 1
print(f"copied={copied} skipped(already there)={skipped} failed={len(bad)}")
for b in bad: print(b)
sys.exit(1 if bad else 0)
